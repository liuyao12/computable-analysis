import ComputableAnalysis.DomainFunctions
import ComputableAnalysis.RiemannHilbert.CertifiedFunctions

/-! Compatibility adapters for the foundation's domain-dependent interface.
The map, domain, and holomorphic structures are defined in the foundation. -/
namespace ComputableAnalysis.RiemannHilbert.DomainFunctions
open ComplexRaw FunctionTheory

def ofCertified (f : CertifiedFunctions.Map) : Map where
  domain := f.domain
  eval z hz := ⟨f.eval z, f.valid z hz⟩
  domain_congr := f.domain_congr
  eval_congr := f.eval_congr

def ofCertifiedHolomorphic {f : CertifiedFunctions.Map} (h : CertifiedFunctions.Holomorphic f) :
    Holomorphic (ofCertified f) where
  openDomain := {
    radius := h.openDomain.radius
    inside := h.openDomain.inside }
  derivative a ha := ⟨h.derivative a, (h.atPoint a ha).derivative_valid⟩
  atPoint a ha := {
    delta := (h.atPoint a ha).delta
    estimate := (h.atPoint a ha).estimate }
  derivative_congr a b ha hb hab := h.derivative_congr a b ha hb hab
  continuousDerivative := {
    delta := h.continuousDerivative.delta
    estimate := h.continuousDerivative.estimate }

end ComputableAnalysis.RiemannHilbert.DomainFunctions
