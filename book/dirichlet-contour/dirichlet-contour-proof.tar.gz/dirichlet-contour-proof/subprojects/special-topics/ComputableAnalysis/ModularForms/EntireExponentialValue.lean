import ComputableAnalysis.ModularForms.ExponentialCharts

/-! Entire represented exponential obtained from agreeing factorial-series
charts. Every point has an executable evaluator; internal chart radii are hidden. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert

/-- An integer radius prevents a large rational denominator from causing
an oversized numerator-based factorial majorant in the chart evaluator. -/
def exponentialInputRadius (z : Scalar) : QPos :=
  ⟨((LocalODE.boxCoordinateBound (z.val.compute 0)).ceil.natAbs:Rat)+1,
    by have h := Rat.natCast_nonneg (a := (LocalODE.boxCoordinateBound (z.val.compute 0)).ceil.natAbs); grind only⟩

theorem exponentialInputRadius_bound (z : Scalar) :
    LocalODE.boxCoordinateBound (z.val.compute 0)<(exponentialInputRadius z).val := by
  let B := LocalODE.boxCoordinateBound (z.val.compute 0)
  have hI := Int.le_natAbs (a := B.ceil)
  have hC : (B.ceil:Rat)≤(B.ceil.natAbs:Rat) := by exact_mod_cast hI
  have h := Rat.le_trans Rat.le_ceil hC
  change B<(B.ceil.natAbs:Rat)+1
  grind only

theorem exponentialInputRadius_mem (z : Scalar) :
    (exponentialChart (exponentialInputRadius z)).domain z := by
  exact ⟨LocalODE.boxCoordinateBound (z.val.compute 0),
    LocalODE.boxCoordinateBound_nonneg _,exponentialInputRadius_bound z,LocalODE.small_from_box z.val z.property 0⟩

/-- The value is computed using a certified chart chosen from the input box. -/
def entireExponentialValue (z : Scalar) : Scalar :=
  ⟨(exponentialChart (exponentialInputRadius z)).eval z,
    (exponentialChart (exponentialInputRadius z)).valid z (exponentialInputRadius_mem z)⟩

theorem entireExponentialValue_congr (z w : Scalar) (hzw : z.val.Equiv w.val) :
    (entireExponentialValue z).val.Equiv (entireExponentialValue w).val :=
  exponentialChart_agreement _ _ z w (exponentialInputRadius_mem z) (exponentialInputRadius_mem w) hzw

/-- Every supplied exponential chart agrees with the global evaluator. -/
theorem entireExponential_chart (R : QPos) (z : Scalar) (hz : (exponentialChart R).domain z) :
    ((exponentialChart R).eval z).Equiv (entireExponentialValue z).val :=
  exponentialChart_agreement R (exponentialInputRadius z) z z hz
    (exponentialInputRadius_mem z) (equiv_refl _ z.property)

end ComputableAnalysis.ModularForms
