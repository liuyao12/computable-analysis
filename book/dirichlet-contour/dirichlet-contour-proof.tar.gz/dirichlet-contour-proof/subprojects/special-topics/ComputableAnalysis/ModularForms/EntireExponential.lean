import ComputableAnalysis.ModularForms.EntireExponentialValue
import ComputableAnalysis.RiemannHilbert.DomainHolomorphicLocality

namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert

def entireExponential : DomainFunctions.Map where
  domain _ := True
  eval z _ := entireExponentialValue z
  domain_congr _ _ _ := Iff.rfl
  eval_congr z w _ _ hzw := entireExponentialValue_congr z w hzw

/-- Actual holomorphicity on all valid represented complex inputs, derived
from local derivatives and proved overlap agreement. -/
def entireExponential_holomorphic : DomainFunctions.Holomorphic entireExponential :=
  DomainFunctions.holomorphic_of_local entireExponential
    (fun a _ => DomainFunctions.ofCertified (exponentialChart (exponentialInputRadius a)))
    (fun a _ => DomainFunctions.ofCertifiedHolomorphic (exponentialChart_holomorphic (exponentialInputRadius a)))
    (fun a _ => exponentialInputRadius_mem a)
    (fun _ _ _ _ => trivial)
    (fun a _ z hz => entireExponential_chart (exponentialInputRadius a) z hz)

end ComputableAnalysis.ModularForms
