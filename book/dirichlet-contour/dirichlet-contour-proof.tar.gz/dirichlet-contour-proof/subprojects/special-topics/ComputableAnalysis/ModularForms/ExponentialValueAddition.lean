import ComputableAnalysis.ModularForms.ExponentialSeriesAddition
import ComputableAnalysis.ModularForms.EntireExponentialValue

namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert LocalODE

/-- Exact addition for every pair of valid represented complex inputs;
the internal rational chart choice is hidden from callers. -/
theorem entireExponential_addition (x y : Scalar) :
    (mul (entireExponentialValue x).val (entireExponentialValue y).val).Equiv
      (entireExponentialValue ⟨add x.val y.val, add_valid x.property y.property⟩).val := by
  let A := boxCoordinateBound (x.val.compute 0)
  let B := boxCoordinateBound (y.val.compute 0)
  have hA : 0 ≤ A := boxCoordinateBound_nonneg _
  have hB : 0 ≤ B := boxCoordinateBound_nonneg _
  let R : QPos := ⟨A+B+1, by grind⟩
  have hxA : Small x.val A := small_from_box x.val x.property 0
  have hyB : Small y.val B := small_from_box y.val y.property 0
  have hxR : Small x.val R.val := hxA.mono (by dsimp [R]; grind)
  have hyR : Small y.val R.val := hyB.mono (by dsimp [R]; grind)
  have hsR : Small (add x.val y.val) R.val :=
    (small_add hxA hyB).mono (by dsimp [R]; grind)
  have hxD : (exponentialChart R).domain x := ⟨A,hA,by dsimp [R]; grind,hxA⟩
  have hyD : (exponentialChart R).domain y := ⟨B,hB,by dsimp [R]; grind,hyB⟩
  let z : Scalar := ⟨add x.val y.val, add_valid x.property y.property⟩
  have hzD : (exponentialChart R).domain z :=
    ⟨A+B,Rat.add_nonneg hA hB,by dsimp [R]; grind,small_add hxA hyB⟩
  have hxy := exponential_series_addition x.val y.val x.property y.property R hxR hyR hsR
  have hvalidX := (exponentialChart R).valid x hxD
  have hvalidY := (exponentialChart R).valid y hyD
  have hvalidZ := (exponentialChart R).valid z hzD
  exact equiv_trans
    (mul_valid (entireExponentialValue x).property (entireExponentialValue y).property)
    (mul_valid hvalidX hvalidY) (entireExponentialValue z).property
    (mul_equiv (entireExponentialValue x).property hvalidX
      (entireExponentialValue y).property hvalidY (equiv_symm (entireExponential_chart R x hxD))
      (equiv_symm (entireExponential_chart R y hyD)))
    (equiv_trans (mul_valid hvalidX hvalidY) hvalidZ (entireExponentialValue z).property
      hxy (entireExponential_chart R z hzD))

end ComputableAnalysis.ModularForms
