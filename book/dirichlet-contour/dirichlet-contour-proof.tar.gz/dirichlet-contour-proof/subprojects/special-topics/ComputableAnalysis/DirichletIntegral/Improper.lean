import ComputableAnalysis.DirichletIntegral.Kernel
import ComputableAnalysis.EffectiveImproperIntegral

/-! The independently computed two-ended improper geometric sinc integral.
Only proper quadratures and the origin/Dirichlet tail estimates enter its
construction. No Feynman value or circle-area answer is an input. -/
namespace ComputableAnalysis.DirichletIntegral
open ComputableCoefficient RealApproximationOrder Integral LipschitzQuadrature
set_option maxHeartbeats 800000

def cutoff (n : Nat) : Rat := ((n+1:Nat):Rat)
def origin (n : Nat) : Rat := 1/cutoff n

theorem cutoff_positive (n : Nat) : 0<cutoff n := by
  change (0:Rat)<((n+1:Nat):Rat)
  exact_mod_cast Nat.succ_pos n

theorem cutoff_ge_one (n : Nat) : 1≤cutoff n := by
  change (1:Rat)≤((n+1:Nat):Rat)
  exact_mod_cast (show 1≤n+1 by omega)

theorem origin_positive (n : Nat) : 0<origin n := by
  rw [origin,Rat.div_def,Rat.one_mul]
  exact Rat.inv_pos.mpr (cutoff_positive n)

theorem origin_le_one (n : Nat) : origin n≤1 := by
  have H := QInterval.one_div_le_one_div_of_pos (show (0:Rat)<1 by decide +kernel) (cutoff_ge_one n)
  simpa only [origin,show (1:Rat)/1=1 by decide +kernel] using H

theorem cutoff_mono {n m : Nat} (hnm : n≤m) : cutoff n≤cutoff m := by
  change ((n+1:Nat):Rat)≤((m+1:Nat):Rat)
  exact_mod_cast (show n+1≤m+1 by omega)

theorem origin_antitone {n m : Nat} (hnm : n≤m) : origin m≤origin n :=
  QInterval.one_div_le_one_div_of_pos (cutoff_positive n) (cutoff_mono hnm)

def compactWindow (n : Nat) : Data sincValue (origin n) (cutoff n) :=
  compactData _ _ (origin_positive n) (Rat.le_trans (origin_le_one n) (cutoff_ge_one n))

def compactValue (n : Nat) : Value := (compactWindow n).value

/-- Upper/lower cutoffs are actual function-domain data for the exhaustion. -/
def exhaustion (n : Nat) : FunctionOnInterval :=
  LipschitzIntegralBounds.onInterval sincValue (origin n) (cutoff n)

/-- Finite interval comparison: separate the missing origin segment from
an oscillatory tail. The larger window is independently integrated. -/
theorem compact_extension_bound (a b c d : Rat) (ha : 0<a) (hab : a≤b)
    (hbc : b≤c) (hcd : c≤d) :
    Small (sub (compactData a d ha (Rat.le_trans hab (Rat.le_trans hbc hcd))).value
      (compactData b c (by grind only) hbc).value) (8*b+2/c) := by
  have hb0 : 0<b := by grind only
  have hc0 : 0<c := by grind only
  let L := compactData a b ha hab
  let M := compactData b d hb0 (Rat.le_trans hbc hcd)
  let U := compactData c d hc0 hcd
  let V := compactData a d ha (Rat.le_trans hab (Rat.le_trans hbc hcd))
  let W := compactData b c hb0 hbc
  have hA : V.value.real.preferred.Equiv (Value.add L.value M.value).real.preferred :=
    L.append M V
  have hB : M.value.real.preferred.Equiv (Value.add W.value U.value).real.preferred :=
    W.append U M
  have hC : (Value.add L.value M.value).real.preferred.Equiv
      (Value.add L.value (Value.add W.value U.value)).real.preferred :=
    RealRaw.add_equiv L.hasIntegral.valid L.hasIntegral.valid M.hasIntegral.valid
      (Value.add W.value U.value).real.valid (RealRaw.equiv_refl _ L.hasIntegral.valid) hB
  have hD : V.value.real.preferred.Equiv
      (Value.add L.value (Value.add W.value U.value)).real.preferred :=
    RealRaw.equiv_trans V.value.real.valid (Value.add L.value M.value).real.valid
      (Value.add L.value (Value.add W.value U.value)).real.valid hA hC
  have hE : (sub V.value W.value).real.preferred.Equiv
      (sub (Value.add L.value (Value.add W.value U.value)) W.value).real.preferred :=
    RealRaw.sub_equiv V.value.real.valid
      (Value.add L.value (Value.add W.value U.value)).real.valid W.value.real.valid
      W.value.real.valid hD (RealRaw.equiv_refl _ W.value.real.valid)
  have hF : (sub (Value.add L.value (Value.add W.value U.value)) W.value).real.preferred.Equiv
      (Value.add L.value U.value).real.preferred := by
    apply arithmetic_identity; intro s; simp only [Value.add,sub]; grind only
  have smallL := L.small 8 (by
    intro t ht _
    exact sinc_small t (by grind only))
  have smallU := compact_tail c d hc0 hcd
  have H := smallL.add smallU
  have hb : (b-a)*8+2/c≤8*b+2/c := by grind only
  have H' := H.mono hb
  apply H'.congr
  exact RealRaw.equiv_symm (RealRaw.equiv_trans (sub V.value W.value).real.valid
    (sub (Value.add L.value (Value.add W.value U.value)) W.value).real.valid
    (Value.add L.value U.value).real.valid hE hF)

/-- Finite comparison of two independently computed compact windows. -/
theorem window_tail (n m : Nat) (hnm : n≤m) :
    Small (sub (compactValue m) (compactValue n)) (10/cutoff n) := by
  have H := compact_extension_bound (origin m) (origin n) (cutoff n) (cutoff m)
    (origin_positive m) (origin_antitone hnm)
    (Rat.le_trans (origin_le_one n) (cutoff_ge_one n)) (cutoff_mono hnm)
  have he : 8*origin n+2/cutoff n=10/cutoff n := by dsimp [origin]; grind only [Rat.div_def]
  rw [he] at H
  exact H

/-- The tail data are proved from actual integrals, without an assumed sum. -/
def construction : EffectiveImproperIntegral.Data where
  compact := compactValue
  error n := 10/cutoff n
  nonnegative n := by
    rw [Rat.div_def]
    exact Rat.mul_nonneg (by decide +kernel) (Rat.le_of_lt (Rat.inv_pos.mpr (cutoff_positive n)))
  shrinks := shrinksToZero_of_ratOverSuccBound (fun _ => Rat.le_refl)
  tail := window_tail

/-- Literal rational interval computation of the improper integral. -/
def integral : RealRaw := construction.raw

theorem integral_valid : integral.Valid := construction.valid

theorem integral_error (n : Nat) : Within integral (compactValue n).real.preferred (10/cutoff n) :=
  construction.within n

/-- This is the ordinary compact-exhaustion integral role, constructed
before introducing exponential damping or its parameter derivative. -/
theorem integral_hasIntegralLimit : HasIntegralLimit exhaustion integral :=
  construction.hasIntegralLimit exhaustion (fun n => (compactWindow n).hasIntegral)

/-- A bound for arbitrary positive cutoffs, not merely the chosen sequence.
It proves ordinary two-ended improper convergence independently of damping. -/
theorem integral_truncation_error (a b : Rat) (ha : 0<a) (hab : a≤b) :
    Small (sub construction.value (compactData a b ha hab).value) (8*a+2/b) := by
  let K := max (b.num.natAbs+1) (RationalMajorant.natRateStage 1 ⟨a,ha⟩)
  apply construction.uniform_bound (compactData a b ha hab).value (8*a+2/b) K
  intro n hn
  have hleft : origin n≤a := by
    have H := RationalMajorant.natRateStage_spec_of_le (bound := 1) (by decide +kernel) ⟨a,ha⟩
      (show RationalMajorant.natRateStage 1 ⟨a,ha⟩≤n by dsimp [K] at hn; omega)
    simpa only [origin,cutoff] using H
  have hright : b≤cutoff n := by
    have hb := Rat.le_trans (self_le_qabs b) (qabs_le_numNatAbs_succ b)
    have hc : (((b.num.natAbs+1:Nat):Rat))≤cutoff n := by
      change (((b.num.natAbs+1:Nat):Rat))≤((n+1:Nat):Rat)
      exact_mod_cast (show b.num.natAbs+1≤n+1 by dsimp [K] at hn; omega)
    exact Rat.le_trans hb hc
  exact compact_extension_bound (origin n) a b (cutoff n) (origin_positive n) hleft hab hright

end ComputableAnalysis.DirichletIntegral
