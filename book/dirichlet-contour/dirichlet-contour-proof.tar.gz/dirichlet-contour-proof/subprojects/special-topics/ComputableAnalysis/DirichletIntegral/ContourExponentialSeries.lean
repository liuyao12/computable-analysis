import ComputableAnalysis.DirichletIntegral.ContourSeriesCoordinates

/-! Actual convergence of complex factorial prefixes and identification
with the independently constructed geometric rotation. -/
namespace ComputableAnalysis.DirichletIntegral.ContourExponentialSeries
open ComputableCoefficient RealApproximationOrder TaylorPolynomialValues RawLimit
open ComplexRaw RiemannHilbert FunctionTheory ModularForms ContourSeriesCoordinates
set_option maxHeartbeats 1000000
set_option autoImplicit false

def coordinate (c : Bool) (z : ComplexRaw) : RealRaw := if c then z.realPart else z.imagPart

theorem coordinate_valid (c : Bool) {z : ComplexRaw} (hz : z.Valid) : (coordinate c z).Valid := by
  cases c
  · exact imagPart_valid hz
  · exact realPart_valid hz

def coordinateValue (c : Bool) (z : ComplexRaw) (hz : z.Valid) : Value :=
  parameter (coordinate c z) (coordinate_valid c hz)

theorem coordinate_distance (c : Bool) {z w : ComplexRaw} (hz : z.Valid) (hw : w.Valid) {B : Rat}
    (H : FunctionTheory.Small (ComplexRaw.sub z w) B) :
    RealApproximationOrder.Small (RealApproximationOrder.sub (coordinateValue c z hz) (coordinateValue c w hw)) B := by
  cases c
  · constructor
    · intro i j
      have h := H.2.2.1 i j
      change -B≤(z.compute j).hi.im + -(w.compute j).lo.im at h
      change -B≤(z.compute j).hi.im-(w.compute j).lo.im
      grind only
    · intro i j
      have h := H.2.2.2 i j
      change (z.compute i).lo.im + -(w.compute i).hi.im≤B at h
      change (z.compute i).lo.im-(w.compute i).hi.im≤B
      grind only
  · constructor
    · intro i j
      have h := H.1 i j
      change -B≤(z.compute j).hi.re + -(w.compute j).lo.re at h
      change -B≤(z.compute j).hi.re-(w.compute j).lo.re
      grind only
    · intro i j
      have h := H.2.1 i j
      change (z.compute i).lo.re + -(w.compute i).hi.re≤B at h
      change (z.compute i).lo.re-(w.compute i).hi.re≤B
      grind only

theorem coordinate_limit (c : Bool) (p : Nat → ComplexRaw) (z : ComplexRaw)
    (hp : ∀ n,(p n).Valid) (hz : z.Valid) (e : Nat → Rat) (he : ShrinksToZero e)
    (H : ∀ n,FunctionTheory.Small (ComplexRaw.sub z (p n)) (e n)) :
    TendsTo (fun n => coordinate c (p n)) (coordinate c z) := by
  refine ⟨coordinate_valid c hz,fun n => coordinate_valid c (hp n),?_⟩
  intro m eps
  obtain ⟨N,hN⟩ := he eps
  refine ⟨N,fun n hn => ?_⟩
  have S := (coordinate_distance c hz (hp n) (H n)).neg
  have A : Same (Value.neg (RealApproximationOrder.sub (coordinateValue c z hz) (coordinateValue c (p n) (hp n))))
      (RealApproximationOrder.sub (coordinateValue c (p n) (hp n)) (coordinateValue c z hz)) := by
    apply arithmetic_identity; intro s; simp only [Value.neg,RealApproximationOrder.sub]; grind only
  have T := (S.congr A).mono (hN n hn)
  exact inInterval_of_sub_bound (coordinate_valid c (hp n)) (coordinate_valid c hz) eps.val T.1 T.2 m

theorem exponential_prefix_converges (c : Bool) (z : Scalar) :
    TendsTo (fun N => coordinate c (BoundedSeries.valueBlock exponentialCoefficients z.val 0 N))
      (coordinate c (entireExponentialValue z).val) := by
  let R := exponentialInputRadius z
  let K := exponentialRatio R
  let C := exponentialBudget K
  have hC : 0≤C := exponentialBudget_nonnegative K (exponentialRatio_positive R)
  have hK : 0≤K := Rat.le_of_lt (exponentialRatio_positive R)
  have hR : 0≤R.val := Rat.le_of_lt R.property
  have h8 := exponentialRatio_local R
  have hq : 0≤2*K*R.val := Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hK) hR
  have h2 : 2*K*R.val≤(1:Rat)/2 := by
    change 8*K*R.val≤(1:Rat)/2 at h8
    grind only
  apply coordinate_limit c (fun N => BoundedSeries.valueBlock exponentialCoefficients z.val 0 N)
    (entireExponentialValue z).val (fun N => BoundedSeries.valueBlock_valid _ _ exponentialCoefficients_valid z.property 0 N)
    (entireExponentialValue z).property (LocalODE.valueTail C K R.val)
    (LocalODE.tail_bound_shrinks C (2*K*R.val) hC hq h2)
  intro N
  exact BoundedSeries.sumValue_close_prefix exponentialCoefficients z.val exponentialCoefficients_valid z.property
    C K R.val hC hK hR (exponentialCoefficients_small K (exponentialRatio_positive R))
    (LocalODE.interior_bound R.val z (exponentialInputRadius_mem z)) h2 N

theorem imaginary_coordinate_hasSum (c : Bool) {x : RealRaw} (hx : x.Valid) :
    RepresentedSeries.HasSum (EulerImaginarySeries.exponentialTerm c (parameter x hx))
      (coordinate c (entireExponentialValue
        ⟨imaginary (angular (parameter x hx)),pair_valid _ _⟩).val) := by
  let X := parameter x hx
  have H := exponential_prefix_converges c ⟨imaginary (angular X),pair_valid _ _⟩
  apply congr_sequence H (fun N => (RepresentedSeries.finiteSum (EulerImaginarySeries.exponentialTerm c X) N).real.valid)
  intro N
  have P := imaginary_prefix X N
  cases c
  · exact imagPart_equiv P
  · exact realPart_equiv P

/-- Exact agreement with the geometric rotation, proved by common finite
factorial prefixes and the independently established geometric Taylor theorem. -/
theorem imaginary_agrees_euler {x : RealRaw} (hx : x.Valid) :
    (entireExponentialValue ⟨imaginary (angular (parameter x hx)),pair_valid _ _⟩).val.Equiv
      (EulerImaginary.eval x) := by
  have R := RawLimit.unique (imaginary_coordinate_hasSum true hx) (EulerImaginarySeries.factorial_series_converges hx).1
  have S := RawLimit.unique (imaginary_coordinate_hasSum false hx) (EulerImaginarySeries.factorial_series_converges hx).2
  intro n
  apply (compareAt_overlap_iff _ _ n n).mpr
  have A := (RealRaw.compareAt_overlap_iff _ _ n n).mp (R n)
  have B := (RealRaw.compareAt_overlap_iff _ _ n n).mp (S n)
  exact ⟨⟨A.1,B.1⟩,⟨A.2,B.2⟩⟩

theorem real_coordinate_hasSum {x : RealRaw} (hx : x.Valid) :
    RepresentedSeries.HasSum (EulerSeriesIdentity.terms (parameter x hx))
      (entireExponentialValue ⟨real (parameter x hx),pair_valid _ _⟩).val.realPart := by
  let X := parameter x hx
  have H := exponential_prefix_converges true ⟨real X,pair_valid _ _⟩
  apply congr_sequence H (fun N => (RepresentedSeries.finiteSum (EulerSeriesIdentity.terms X) N).real.valid)
  intro N
  exact realPart_equiv (real_prefix X N)

theorem zero_limit : TendsTo (fun _ : Nat => RealRaw.ofRat 0) (RealRaw.ofRat 0) := by
  refine ⟨RealRaw.ofRat_valid 0,fun _ => RealRaw.ofRat_valid 0,?_⟩
  intro m eps
  refine ⟨0,fun n _ => ⟨?_,?_⟩⟩
  · intro i j; change (0:Rat)-eps.val≤0; have := eps.property; grind only
  · intro i j; change (0:Rat)≤0+eps.val; have := eps.property; grind only

/-- The represented real axis is identified with the Euler ODE exponential
by actual common factorial prefixes, for every valid real input. -/
theorem real_agrees_euler {x : RealRaw} (hx : x.Valid) :
    (entireExponentialValue ⟨real (parameter x hx),pair_valid _ _⟩).val.Equiv
      (EulerImaginary.pair (EulerReal.eval x) (RealRaw.ofRat 0)) := by
  have R := RawLimit.unique (real_coordinate_hasSum hx) (EulerSeriesIdentity.exponential_hasSum hx)
  have H := exponential_prefix_converges false ⟨real (parameter x hx),pair_valid _ _⟩
  have Z : TendsTo (fun _ : Nat => RealRaw.ofRat 0)
      (coordinate false (entireExponentialValue ⟨real (parameter x hx),pair_valid _ _⟩).val) := by
    apply congr_sequence (v := fun _ : Nat => RealRaw.ofRat 0) H (fun _ => RealRaw.ofRat_valid 0)
    intro N
    exact imagPart_equiv (real_prefix (parameter x hx) N)
  have S := RawLimit.unique Z zero_limit
  intro n
  apply (compareAt_overlap_iff _ _ n n).mpr
  have A := (RealRaw.compareAt_overlap_iff _ _ n n).mp (R n)
  have B := (RealRaw.compareAt_overlap_iff _ _ n n).mp (S n)
  exact ⟨⟨A.1,B.1⟩,⟨A.2,B.2⟩⟩

end ComputableAnalysis.DirichletIntegral.ContourExponentialSeries
