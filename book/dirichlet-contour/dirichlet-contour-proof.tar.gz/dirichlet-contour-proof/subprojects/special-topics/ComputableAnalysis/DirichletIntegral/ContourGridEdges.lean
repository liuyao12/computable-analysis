import ComputableAnalysis.DirichletIntegral.ContourGridGeometry

/-! Finite bottom/left identifications and the actual rectangle boundary algebra. -/
namespace ComputableAnalysis.DirichletIntegral.ContourGridEdges
open ComputableCoefficient RealApproximationOrder LipschitzQuadrature
open ComplexRaw RiemannHilbert FunctionTheory RectangularContour
open ContourGridAlgebra ContourGridGeometry
open _root_.ComputableAnalysis.RiemannHilbert.DomainFunctions
set_option maxHeartbeats 800000
set_option autoImplicit false

def bottom (eta R H : Rat) (he : 0<eta) (M : Nat) : Scalar :=
  gridScalarSum M (fun j => rectangleGridHorizontal (sample eta R H he) (ContourFunction.rectangle R H) M j 0)
def top (eta R H : Rat) (he : 0<eta) (M : Nat) : Scalar :=
  gridScalarSum M (fun j => rectangleGridHorizontal (sample eta R H he) (ContourFunction.rectangle R H) M j M)
def right (eta R H : Rat) (he : 0<eta) (M : Nat) : Scalar :=
  gridScalarSum M (fun j => rectangleGridVertical (sample eta R H he) (ContourFunction.rectangle R H) M M j)
def left (eta R H : Rat) (he : 0<eta) (M : Nat) : Scalar :=
  gridScalarSum M (fun j => rectangleGridVertical (sample eta R H he) (ContourFunction.rectangle R H) M 0 j)

def bottomFunction (eta t : Rat) : Value :=
  RealApproximationOrder.sub (ContourRegularization.sineRegularized eta t) (ContourRegularization.cosineRegularized eta t)

theorem valueSum_congr (n : Nat) (f g : Nat → Value) (H : ∀ j,j<n → Same (f j) (g j)) :
    Same (valueSum f n) (valueSum g n) := by
  induction n with
  | zero => exact Same.refl (Value.rational 0)
  | succ n ih => exact (ih (fun j hj => H j (by omega))).add (H n (by omega))

theorem valueSum_zero (n : Nat) : Same (valueSum (fun _ => Value.rational 0) n) (Value.rational 0) := by
  induction n with
  | zero => exact Same.refl (Value.rational 0)
  | succ n ih =>
    apply (ih.add (Same.refl (Value.rational 0))).trans
    apply arithmetic_identity; intro s; simp only [Value.add,Value.rational]; grind only

theorem valueSum_midpoint (f : Rat → Value) (a b : Rat) (M n : Nat) :
    valueSum (fun j => scale (mesh a b M) (f (midpointTag a b M j))) n=midpointPrefix f a b M n := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [valueSum,midpointPrefix,ih]

theorem bottom_imaginary (eta R H : Rat) (he : 0<eta) (hR : 0≤R) (hH : 0≤H) (M : Nat) (hM : 0<M) :
    Same (imaginaryValue (bottom eta R H he M)) (midpointPrefix (bottomFunction eta) 0 R M M) := by
  have A := imaginary_sum M (fun j => rectangleGridHorizontal (sample eta R H he) (ContourFunction.rectangle R H) M j 0)
  have B : Same (valueSum (fun j => imaginaryValue (rectangleGridHorizontal (sample eta R H he) (ContourFunction.rectangle R H) M j 0)) M)
      (valueSum (fun j => scale (mesh 0 R M) (bottomFunction eta (midpointTag 0 R M j))) M) := by
    apply valueSum_congr
    intro j hj
    unfold rectangleGridHorizontal
    rw [point_bottom R H M hM j,step_x R H M hM]
    have S := horizontal_weight (sample eta R H he (rectangleGridHorizontalPoint (ContourFunction.rectangle R H) M j 0))
      (rectangleGridStepX (ContourFunction.rectangle R H) M)
    rw [point_bottom R H M hM j,step_x R H M hM] at S
    have T := sample_bottom eta R H (midpointTag 0 R M j) he hH (tag_bounds R hR M hM j hj).1 (tag_bounds R hR M hM j hj).2
    exact S.trans (T.scale (mesh 0 R M))
  rw [valueSum_midpoint] at B
  exact A.trans B

theorem left_imaginary (eta R H : Rat) (he : 0<eta) (hR : 0≤R) (hH : 0≤H) (M : Nat) (hM : 0<M) :
    Same (imaginaryValue (left eta R H he M)) (Value.rational 0) := by
  have A := imaginary_sum M (fun j => rectangleGridVertical (sample eta R H he) (ContourFunction.rectangle R H) M 0 j)
  have B : Same (valueSum (fun j => imaginaryValue (rectangleGridVertical (sample eta R H he) (ContourFunction.rectangle R H) M 0 j)) M)
      (valueSum (fun _ => Value.rational 0) M) := by
    apply valueSum_congr
    intro j hj
    unfold rectangleGridVertical
    rw [point_left R H M hM j,step_y R H M hM]
    have S := vertical_weight (sample eta R H he (rectangleGridVerticalPoint (ContourFunction.rectangle R H) M 0 j))
      (rectangleGridStepY (ContourFunction.rectangle R H) M)
    rw [point_left R H M hM j,step_y R H M hM] at S
    have T := sample_left eta R H (midpointTag 0 H M j) he hR (tag_bounds H hH M hM j hj).1 (tag_bounds H hH M hM j hj).2
    apply (S.trans (T.scale (mesh 0 H M))).trans
    apply arithmetic_identity; intro s; simp only [scale,Value.rational]; grind only
  exact A.trans (B.trans (valueSum_zero M))

theorem boundary_edges (eta R H : Rat) (he : 0<eta) (M : Nat) :
    (rectangleGridBoundary (sample eta R H he) (ContourFunction.rectangle R H) M).val.Equiv
      (add (ComplexRaw.sub (bottom eta R H he M).val (top eta R H he M).val)
        (ComplexRaw.sub (right eta R H he M).val (left eta R H he M).val)) :=
  add_equiv (sum_sub M
    (fun j => rectangleGridHorizontal (sample eta R H he) (ContourFunction.rectangle R H) M j 0)
    (fun j => rectangleGridHorizontal (sample eta R H he) (ContourFunction.rectangle R H) M j M))
    (sum_sub M
    (fun j => rectangleGridVertical (sample eta R H he) (ContourFunction.rectangle R H) M M j)
    (fun j => rectangleGridVertical (sample eta R H he) (ContourFunction.rectangle R H) M 0 j))

theorem imaginary_boundary (eta R H : Rat) (he : 0<eta) (M : Nat) :
    Same (imaginaryValue (rectangleGridBoundary (sample eta R H he) (ContourFunction.rectangle R H) M))
      (Value.add (RealApproximationOrder.sub (imaginaryValue (bottom eta R H he M)) (imaginaryValue (top eta R H he M)))
        (RealApproximationOrder.sub (imaginaryValue (right eta R H he M)) (imaginaryValue (left eta R H he M)))) := by
  let B := bottom eta R H he M
  let T := top eta R H he M
  let R' := right eta R H he M
  let L := left eta R H he M
  have A : Same (imaginaryValue (rectangleGridBoundary (sample eta R H he) (ContourFunction.rectangle R H) M))
      (imaginaryValue (scalarSum (gridScalarSub B T) (gridScalarSub R' L))) := imagPart_equiv (boundary_edges eta R H he M)
  exact A.trans ((imaginary_add (gridScalarSub B T) (gridScalarSub R' L)).trans
    ((imaginary_sub B T).add (imaginary_sub R' L)))

end ComputableAnalysis.DirichletIntegral.ContourGridEdges
