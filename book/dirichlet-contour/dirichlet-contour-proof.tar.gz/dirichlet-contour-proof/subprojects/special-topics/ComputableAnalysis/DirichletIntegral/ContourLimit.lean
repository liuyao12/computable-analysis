import ComputableAnalysis.DirichletIntegral.ContourOuterEdges

/-! The literal rectangular Cauchy sums identify the actual proper bottom
integral. Finite quadrature errors are sent to zero with explicit bounds. -/
namespace ComputableAnalysis.DirichletIntegral.ContourLimit
open ComputableCoefficient RealApproximationOrder LipschitzQuadrature RawLimit
open ComplexRaw RiemannHilbert FunctionTheory RectangularContour
open ContourGridAlgebra ContourGridGeometry ContourGridEdges ContourOuterEdges ContourRegularization
set_option maxHeartbeats 1000000
set_option autoImplicit false

def bottomData (eta R : Rat) (he : 0<eta) (hR : 0≤R) : Data (bottomFunction eta) 0 R :=
  (ContourRegularization.sineData eta 0 R he Rat.le_refl hR).subtract (cosineDataRegularized eta 0 R he Rat.le_refl hR)

def midpointError (eta R : Rat) (he : 0<eta) (hR : 0≤R) (n : Nat) : Rat :=
  (bottomData eta R he hR).constant*R*mesh 0 R (2^n)

theorem midpointError_shrinks (eta R : Rat) (he : 0<eta) (hR : 0≤R) :
    ShrinksToZero (midpointError eta R he hR) := by
  let C := (bottomData eta R he hR).constant*R*R
  have c0 : 0≤C := Rat.mul_nonneg (Rat.mul_nonneg (bottomData eta R he hR).nonnegative hR) hR
  have eq (n : Nat) : midpointError eta R he hR n=C*((1:Rat)/2)^n := by
    have P := two_pow_half_pow n
    have mc := Rat.mul_inv_cancel ((2^n:Nat):Rat) (Rat.ne_of_gt (Rat.natCast_pos.mpr (Nat.two_pow_pos n)))
    have inv : (((2^n:Nat):Rat))⁻¹=((1:Rat)/2)^n := by grind only
    simp only [midpointError,mesh,if_neg (Nat.ne_of_gt (Nat.two_pow_pos n)),Rat.div_def,inv]
    dsimp [C]
    grind only
  have htail := LocalODE.tail_bound_shrinks (C+1) ((1:Rat)/2) (by grind only) (by decide +kernel) Rat.le_refl
  intro eps
  obtain ⟨N,hN⟩ := htail eps
  refine ⟨N,fun n hn => ?_⟩
  rw [eq]
  have p0 := Rat.pow_nonneg (n := n) (by decide +kernel : (0:Rat)≤1/2)
  have H := Rat.mul_le_mul_of_nonneg_right (show C≤4*(C+1) by grind only) p0
  exact Rat.le_trans H (hN n hn)

theorem imaginary_small (z : Scalar) (B : Rat) (H : FunctionTheory.Small z.val B) :
    RealApproximationOrder.Small (imaginaryValue z) B := ⟨H.2.2.1,H.2.2.2⟩

theorem bottom_bound (eta R H : Rat) (he : 0<eta) (hR : 0<R) (hH : 0<H)
    (M : Nat) (hM : 0<M) (eps : Rat)
    (hb : RealApproximationOrder.Small (imaginaryValue
      (rectangleGridBoundary (sample eta R H he) (ContourFunction.rectangle R H) M)) eps) :
    RealApproximationOrder.Small (imaginaryValue (bottom eta R H he M))
      (eps+4*R*(1/H)*(1/H)+4*H/R) := by
  let B := imaginaryValue (bottom eta R H he M)
  let T := imaginaryValue (top eta R H he M)
  let R' := imaginaryValue (right eta R H he M)
  let L := imaginaryValue (left eta R H he M)
  let Q := imaginaryValue (rectangleGridBoundary (sample eta R H he) (ContourFunction.rectangle R H) M)
  have boundary : Same Q (Value.add (RealApproximationOrder.sub B T) (RealApproximationOrder.sub R' L)) :=
    imaginary_boundary eta R H he M
  have Lzero : Same L (Value.rational 0) := left_imaginary eta R H he (Rat.le_of_lt hR) (Rat.le_of_lt hH) M hM
  have boundary' := boundary.trans ((Same.refl (RealApproximationOrder.sub B T)).add ((Same.refl R').sub Lzero))
  have A : Same (Value.add (Value.add Q T) (Value.neg R')) B := by
    apply ((boundary'.add (Same.refl T)).add (Same.refl (Value.neg R'))).trans
    apply arithmetic_identity; intro s; simp only [Value.add,Value.neg,Value.rational,RealApproximationOrder.sub]; grind only
  have boundT := imaginary_small (top eta R H he M) (4*R*(1/H)*(1/H)) (top_small eta R H he (Rat.le_of_lt hR) hH M hM)
  have boundR := imaginary_small (right eta R H he M) (4*H/R) (right_small eta R H he hR (Rat.le_of_lt hH) M hM)
  exact ((hb.add boundT).add boundR.neg).congr A

theorem proper_estimate (eta R H : Rat) (he : 0<eta) (hR : 0<R) (hH : 0<H) :
    RealApproximationOrder.Small (bottomData eta R he (Rat.le_of_lt hR)).value
      (4*R*(1/H)*(1/H)+4*H/R) := by
  let D := bottomData eta R he (Rat.le_of_lt hR)
  let errors := fun n => RawLimit.allowance n+RawLimit.allowance n
  apply EffectiveImproperIntegral.small_of_errors D.value (4*R*(1/H)*(1/H)+4*H/R) errors
    (RepresentedCauchySum.sum_shrinks _ _ RawLimit.allowance_shrinks RawLimit.allowance_shrinks)
  intro N
  let eps : QPos := ⟨RawLimit.allowance N,RawLimit.allowance_pos N⟩
  obtain ⟨A,hA⟩ := ContourFunction.boundary_converges_zero eta R H he (Rat.le_of_lt hR) (Rat.le_of_lt hH) eps
  obtain ⟨B,hB⟩ := midpointError_shrinks eta R he (Rat.le_of_lt hR) eps
  let n := max A B
  let M := 2^n
  have hM : 0<M := Nat.two_pow_pos n
  have hc := hA n (Nat.le_max_left A B)
  have bc : RealApproximationOrder.Small (imaginaryValue
      (rectangleGridBoundary (sample eta R H he) (ContourFunction.rectangle R H) M)) eps.val := by
    constructor
    · intro i j
      have L := hc.2.2.1 i j
      change -eps.val≤((ContourFunction.boundary eta R H he n).val.compute j).hi.im + -(0:Rat) at L
      change -eps.val≤((ContourFunction.boundary eta R H he n).val.compute j).hi.im
      grind only
    · intro i j
      have U := hc.2.2.2 i j
      change ((ContourFunction.boundary eta R H he n).val.compute i).lo.im + -(0:Rat)≤eps.val at U
      change ((ContourFunction.boundary eta R H he n).val.compute i).lo.im≤eps.val
      grind only
  have bottomSmall := bottom_bound eta R H he hR hH M hM eps.val bc
  have quadrature := D.midpoint_error M hM
  have representation := bottom_imaginary eta R H he (Rat.le_of_lt hR) (Rat.le_of_lt hH) M hM
  have transfer : Same (RealApproximationOrder.sub D.value (midpointPrefix (bottomFunction eta) 0 R M M))
      (RealApproximationOrder.sub D.value (imaginaryValue (bottom eta R H he M))) := (Same.refl D.value).sub representation.symm
  have Q := quadrature.congr transfer
  have bound := Q.add bottomSmall
  have algebra : Same (Value.add (RealApproximationOrder.sub D.value (imaginaryValue (bottom eta R H he M)))
      (imaginaryValue (bottom eta R H he M))) D.value := by
    apply arithmetic_identity; intro s; simp only [Value.add,RealApproximationOrder.sub]; grind only
  have error := hB n (Nat.le_max_right A B)
  apply (bound.congr algebra).mono
  change D.constant*(R-0)*mesh 0 R M+(eps.val+4*R*(1/H)*(1/H)+4*H/R)≤
    (4*R*(1/H)*(1/H)+4*H/R)+errors N
  change D.constant*R*mesh 0 R M≤eps.val at error
  dsimp [errors,eps]
  grind only

theorem regularized_relation (eta R H : Rat) (he : 0<eta) (hR : 0<R) (hH : 0<H) :
    RealApproximationOrder.Small (RealApproximationOrder.sub
      (ContourRegularization.sineData eta 0 R he Rat.le_refl (Rat.le_of_lt hR)).value
      (cosineDataRegularized eta 0 R he Rat.le_refl (Rat.le_of_lt hR)).value)
      (4*R*(1/H)*(1/H)+4*H/R) :=
  (proper_estimate eta R H he hR hH).congr
    ((ContourRegularization.sineData eta 0 R he Rat.le_refl (Rat.le_of_lt hR)).subtract_identity
      (cosineDataRegularized eta 0 R he Rat.le_refl (Rat.le_of_lt hR)))

end ComputableAnalysis.DirichletIntegral.ContourLimit
