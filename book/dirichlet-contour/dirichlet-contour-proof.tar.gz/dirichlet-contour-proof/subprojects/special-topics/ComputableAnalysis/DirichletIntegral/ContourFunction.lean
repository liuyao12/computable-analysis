import ComputableAnalysis.RiemannHilbert.DomainAffineFunction
import ComputableAnalysis.RiemannHilbert.ReciprocalHolomorphic
import ComputableAnalysis.ModularForms.EntireExponential
import ComputableAnalysis.RiemannHilbert.ContourLimits
import ComputableAnalysis.GeometricIntegralData
import ComputableAnalysis.EulerImaginaryExtension

/-! Actual holomorphicity on the entire closed rectangle; the pole lies below it. -/
namespace ComputableAnalysis.DirichletIntegral.ContourFunction
open ComplexRaw RiemannHilbert RectangularContour
open _root_.ComputableAnalysis.RiemannHilbert.DomainFunctions
set_option maxHeartbeats 600000
set_option autoImplicit false

def pole (eta : Rat) : Scalar := ⟨ofQComplex ⟨0,-eta⟩,ofQComplex_valid _⟩
def zeroScalar : Scalar := ⟨zero,ofQComplex_valid _⟩
def imaginaryPi : Scalar := ⟨EulerImaginary.pair (RealRaw.ofRat 0) GeometricTrig.pi,
 EulerImaginary.pair_valid (RealRaw.ofRat_valid 0) GeometricTrig.pi_valid⟩
def denominator (eta : Rat) : RiemannHilbert.DomainFunctions.Map := shift (pole eta)
def phase : RiemannHilbert.DomainFunctions.Map := affine zeroScalar imaginaryPi
def numerator : RiemannHilbert.DomainFunctions.Map := compose ModularForms.entireExponential phase
def inverse (eta : Rat) : RiemannHilbert.DomainFunctions.Map := compose ReciprocalHolomorphic.function (denominator eta)
def function (eta : Rat) : RiemannHilbert.DomainFunctions.Map :=
 productOn (inverse eta) numerator (fun _ _ => ⟨trivial,trivial⟩)

def numerator_holomorphic : RiemannHilbert.DomainFunctions.Holomorphic numerator :=
 ModularForms.entireExponential_holomorphic.compose (affine_holomorphic zeroScalar imaginaryPi)
def inverse_holomorphic (eta : Rat) : RiemannHilbert.DomainFunctions.Holomorphic (inverse eta) :=
 ReciprocalHolomorphic.holomorphic.compose (affine_holomorphic (scalarNeg (pole eta)) oneScalar)
def holomorphic (eta : Rat) : RiemannHilbert.DomainFunctions.Holomorphic (function eta) :=
 (inverse_holomorphic eta).productOn numerator_holomorphic (fun _ _ => ⟨trivial,trivial⟩)

theorem domain_iff (eta : Rat) (z : Scalar) :
    (function eta).domain z ↔ ¬z.val.Equiv (pole eta).val := by
 change (∃ h : True, ¬((shift (pole eta)).eval z h).val.Equiv zero) ↔ _
 constructor
 · rintro ⟨h,hh⟩ he
   exact hh ((shift_zero_iff (pole eta) z).2 he)
 · intro hh
   exact ⟨trivial,fun he => hh ((shift_zero_iff (pole eta) z).1 he)⟩

def rectangle (R H : Rat) : QInterval × QInterval := (⟨0,R⟩,⟨0,H⟩)

theorem rectangle_domain (eta R H : Rat) (heta : 0<eta) (z : Scalar)
    (hz : representedRectangleContains (rectangle R H) z) : (function eta).domain z := by
 apply (domain_iff eta z).2
 intro he
 have hi := ComplexRaw.imagPart_equiv he
 have h := RealRaw.le_trans (ComplexRaw.imagPart_valid z.property)
   hz.2.2.1
   (RealRaw.le_of_equiv (ComplexRaw.imagPart_valid z.property)
     (ComplexRaw.imagPart_valid (pole eta).property) hi) 0 0
 change (0:Rat)≤ -eta at h
 grind only

def boundary (eta R H : Rat) (heta : 0<eta) :=
 RectangularContour.holomorphicRectangleGridBoundary
  (function eta) (holomorphic eta) (rectangle R H) (rectangle_domain eta R H heta)

theorem boundary_converges_zero (eta R H : Rat) (heta : 0<eta)
    (hR : 0≤R) (hH : 0≤H) :
    RectangularContour.Converges (boundary eta R H heta) ⟨zero,ofQComplex_valid _⟩ :=
 RectangularContour.holomorphic_rectangle_zero
  (function eta) (holomorphic eta) (rectangle R H) (rectangle_domain eta R H heta) hR hH
end ComputableAnalysis.DirichletIntegral.ContourFunction
