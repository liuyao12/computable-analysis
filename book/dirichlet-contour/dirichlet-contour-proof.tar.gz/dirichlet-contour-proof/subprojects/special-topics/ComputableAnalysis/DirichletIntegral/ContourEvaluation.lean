import ComputableAnalysis.DirichletIntegral.ContourLimit
import ComputableAnalysis.DirichletIntegral.ContourCosine

/-! Independent rectangular-contour evaluation of the already constructed
improper integral. No Feynman parameter calculation is imported. -/
namespace ComputableAnalysis.DirichletIntegral.ContourEvaluation
open ComputableCoefficient RealApproximationOrder FTCRealOrder
open GeometricTrig LipschitzQuadrature ContourRegularization
set_option maxHeartbeats 1500000
set_option autoImplicit false

theorem error_bound (N : Rat) (hN : 1≤N) :
    Small (sub construction.value ContourPoisson.halfPi) (64/N) := by
  have n0 : 0<N := by grind only
  let d := N⁻¹
  let eta := d*d
  let R := N*N*N
  let H := N*N
  have di : 0<d := Rat.inv_pos.mpr n0
  have d0 := Rat.le_of_lt di
  have dn : d≤1 := by
    have A := QInterval.one_div_le_one_div_of_pos (show (0:Rat)<1 by decide +kernel) hN
    simpa only [d,Rat.div_def,Rat.one_mul,show (1:Rat)⁻¹=1 by decide +kernel] using A
  have e0 : 0<eta := Rat.mul_pos di di
  have r0 : 0<R := Rat.mul_pos (Rat.mul_pos n0 n0) n0
  have h0 : 0<H := Rat.mul_pos n0 n0
  have square : N≤N*N := by
    have P := Rat.mul_le_mul_of_nonneg_right hN (Rat.le_of_lt n0)
    simpa only [Rat.one_mul] using P
  have cube : N*N≤N*N*N := by
    have P := Rat.mul_le_mul_of_nonneg_right hN (Rat.mul_nonneg (Rat.le_of_lt n0) (Rat.le_of_lt n0))
    simpa only [Rat.one_mul,Rat.mul_one,Rat.mul_comm] using P
  have d2 : d*d≤d := by
    have P := Rat.mul_le_mul_of_nonneg_right dn d0
    simpa only [Rat.one_mul] using P
  have ed : eta≤d := d2
  have dr : d≤R := by dsimp [R]; grind only
  have er : eta≤R := Rat.le_trans ed dr
  let L := ContourRegularization.sineData eta 0 R e0 Rat.le_refl (Rat.le_of_lt r0)
  let C := cosineDataRegularized eta 0 R e0 Rat.le_refl (Rat.le_of_lt r0)
  have S := sine_to_improper eta R e0 er
  have T := ContourLimit.regularized_relation eta R H e0 r0 h0
  have U := ContourCosine.cosine_to_halfPi eta d R e0 ed dr
  have V := (S.neg.add T).add U
  have A : Same (Value.add (Value.add (Value.neg (sub L.value construction.value)) (sub L.value C.value))
      (sub C.value ContourPoisson.halfPi)) (sub construction.value ContourPoisson.halfPi) := by
    apply arithmetic_identity; intro s; simp only [Value.add,Value.neg,sub]; grind only
  have result := V.congr A
  have nc := Rat.mul_inv_cancel N (Rat.ne_of_gt n0)
  have dc := Rat.mul_inv_cancel d (Rat.ne_of_gt di)
  have hc := Rat.mul_inv_cancel H (Rat.ne_of_gt h0)
  have rc := Rat.mul_inv_cancel R (Rat.ne_of_gt r0)
  have dd : N*d=1 := nc
  have hi : H⁻¹=d*d := by dsimp [H] at hc; grind only
  have ri : R⁻¹=d*d*d := by dsimp [R] at rc; grind only
  have d3 : d*d*d≤d := by
    have P := Rat.mul_le_mul_of_nonneg_right d2 d0
    grind only
  have d30 : 0≤d*d*d := Rat.mul_nonneg (Rat.mul_nonneg d0 d0) d0
  have d5 : (d*d)*(d*d*d)≤d := by
    have e1 : d*d≤1 := Rat.le_trans d2 dn
    have P := Rat.mul_le_mul_of_nonneg_right e1 d30
    grind only
  have relation : 4*R*(1/H)*(1/H)+4*H/R=8*d := by
    simp only [Rat.div_def,Rat.one_mul,hi,ri]
    dsimp [R,H]
    grind only
  have sineError : 24*eta+2/R=24*(d*d)+2*(d*d*d) := by
    simp only [Rat.div_def,ri,eta]
  have cosineError : 24*d+2*eta/d+eta/R=26*d+(d*d)*(d*d*d) := by
    simp only [Rat.div_def,ri,eta]
    grind only
  apply result.mono
  rw [relation,sineError,cosineError]
  change (24*(d*d)+2*(d*d*d))+8*d+(26*d+(d*d)*(d*d*d))≤64*N⁻¹
  change (24*(d*d)+2*(d*d*d))+8*d+(26*d+(d*d)*(d*d*d))≤64*d
  grind only

/-- The ordinary independently sampled improper integral equals the geometric
half-circle constant. The proof uses rectangular Cauchy sums and their actual
edge evaluations, without the parameter FTC or the Feynman evaluation. -/
theorem integral_eq_halfPi : integral.Equiv ContourPoisson.halfPi.real.preferred := by
  have H : Small (sub construction.value ContourPoisson.halfPi) 0 :=
    EffectiveImproperIntegral.small_of_errors (sub construction.value ContourPoisson.halfPi) 0
      (fun n => 64/cutoff n)
      (shrinksToZero_of_ratOverSuccBound (C := 64) (fun _ => Rat.le_refl))
      (by intro n; simpa only [Rat.zero_add] using error_bound (cutoff n) (cutoff_ge_one n))
  intro n
  apply (RealRaw.compareAt_overlap_iff integral ContourPoisson.halfPi.real.preferred n n).mpr
  constructor
  · have U := H.2 n 0
    change (integral.compute n).lo-(ContourPoisson.halfPi.real.compute n).hi≤0 at U
    change (integral.compute n).lo≤(ContourPoisson.halfPi.real.compute n).hi
    grind only
  · have L := H.1 0 n
    change -(0:Rat)≤(integral.compute n).hi-(ContourPoisson.halfPi.real.compute n).lo at L
    change (ContourPoisson.halfPi.real.compute n).lo≤(integral.compute n).hi
    grind only

theorem integral_eq_pi_half : integral.Equiv (scale (1/2) piValue).real.preferred :=
  RealRaw.equiv_trans integral_valid ContourPoisson.halfPi.real.valid (scale (1/2) piValue).real.valid
    integral_eq_halfPi ContourPoisson.halfPi_identity

end ComputableAnalysis.DirichletIntegral.ContourEvaluation
