import ComputableAnalysis.DirichletIntegral.ContourFunction
import ComputableAnalysis.DirichletIntegral.ContourExponentialSeries
import ComputableAnalysis.ModularForms.ExponentialValueAddition
import ComputableAnalysis.EulerNegativeRate

/-! Identification of the actual contour exponential with geometric rotation
and the Euler-method real decay. -/
namespace ComputableAnalysis.DirichletIntegral.ContourNumerator
open ComputableCoefficient RealApproximationOrder FTCRealOrder TaylorPolynomialValues
open ComplexRaw RiemannHilbert FunctionTheory ModularForms GeometricTrig GeometricIntegralData
open ContourSeriesCoordinates ContourExponentialSeries
set_option maxHeartbeats 1000000
set_option autoImplicit false

def argument (y : Rat) : Value := EulerNegativeRate.argument piValue y
def decay (y : Rat) : Value := EulerNegativeRate.evaluate piValue y

def realInput (y : Rat) : Scalar :=
  ⟨real (parameter (argument y).real.preferred (argument y).real.valid),pair_valid _ _⟩
def imaginaryInput (x : Rat) : Scalar :=
  ⟨imaginary (angular (parameter (RealRaw.ofRat x) (RealRaw.ofRat_valid x))),pair_valid _ _⟩
def input (x y : Rat) : Scalar :=
  ⟨add (realInput y).val (imaginaryInput x).val,add_valid (realInput y).property (imaginaryInput x).property⟩

theorem real_agreement (y : Rat) :
    (entireExponentialValue (realInput y)).val.Equiv (pair (decay y) (Value.rational 0)) :=
  real_agrees_euler (argument y).real.valid

theorem rotation_agreement (x : Rat) :
    (entireExponentialValue (imaginaryInput x)).val.Equiv (pair (valueFor true x) (valueFor false x)) := by
  have C : (cosAt (RealRaw.ofRat x)).Equiv (valueFor true x).real.preferred := by
    rw [valueFor_raw]; exact cosAt_rational x
  have S : (sinAt (RealRaw.ofRat x)).Equiv (valueFor false x).real.preferred := by
    rw [valueFor_raw]; exact sinAt_rational x
  exact equiv_trans (entireExponentialValue (imaginaryInput x)).property (EulerImaginary.eval_valid (x := RealRaw.ofRat x) (RealRaw.ofRat_valid x)) (pair_valid _ _)
    (imaginary_agrees_euler (x := RealRaw.ofRat x) (RealRaw.ofRat_valid x))
    (equiv_trans (EulerImaginary.eval_valid (x := RealRaw.ofRat x) (RealRaw.ofRat_valid x))
      (EulerImaginary.pair_valid (cosAt_valid (x := RealRaw.ofRat x) (RealRaw.ofRat_valid x)) (sinAt_valid (x := RealRaw.ofRat x) (RealRaw.ofRat_valid x)))
      (pair_valid _ _) (EulerImaginary.eval_agrees_circle (x := RealRaw.ofRat x) (RealRaw.ofRat_valid x)) (EulerImaginary.pair_equiv C S))

theorem addition_formula (x y : Rat) :
    (entireExponentialValue (input x y)).val.Equiv
      (pair (Value.mul (decay y) (valueFor true x)) (Value.mul (decay y) (valueFor false x))) := by
  have A := entireExponential_addition (realInput y) (imaginaryInput x)
  have P := mul_equiv (entireExponentialValue (realInput y)).property (pair_valid _ _)
    (entireExponentialValue (imaginaryInput x)).property (pair_valid _ _)
    (real_agreement y) (rotation_agreement x)
  have H := equiv_trans (entireExponentialValue (input x y)).property
    (mul_valid (entireExponentialValue (realInput y)).property (entireExponentialValue (imaginaryInput x)).property)
    (mul_valid (pair_valid _ _) (pair_valid _ _)) (equiv_symm A) P
  rw [pair_product] at H
  apply equiv_trans (entireExponentialValue (input x y)).property (pair_valid _ _) (pair_valid _ _) H
  apply pair_congr <;> apply arithmetic_identity <;> intro s <;>
    simp only [Value.mul,Value.add,Value.rational,RealApproximationOrder.sub] <;> grind only

theorem pi_ge_one : LE (Value.rational 1) piValue := by
  intro i j
  have L := pi_lower j
  have O := RealRaw.interval_order_of_valid _ pi_valid j
  change 1≤(pi.compute j).hi
  change (pi.compute j).lo≤(pi.compute j).hi at O
  grind only

theorem decay_bound (y : Rat) (hy : 0≤y) : RealApproximationOrder.Small (decay y) (1/(1+y)) := by
  have P := le_scale pi_ge_one hy
  have Arg : LE (argument y) (Value.rational (-y)) := by
    apply le_congr (x := Value.neg (scale y piValue)) (y := Value.neg (scale y (Value.rational 1))) (RealRaw.le_neg_le_neg P)
    · apply arithmetic_identity; intro s; simp only [argument,EulerNegativeRate.argument,scale,Value.neg] <;> grind only
    · apply arithmetic_identity; intro s; simp only [scale,Value.rational,Value.neg] <;> grind only
  have O := EulerReal.eval_monotone (x := (argument y).real.preferred) (y := RealRaw.ofRat (-y)) (argument y).real.valid (RealRaw.ofRat_valid (-y)) Arg
  have U := RealRaw.le_trans (EulerReal.sample_valid (-y)) O (EulerReal.sample_negative_decay y hy)
  have nonnegative := EulerReal.eval_nonnegative (argument y).real.valid
  have epos : 0≤1/(1+y) := by
    rw [Rat.div_def,Rat.one_mul]
    exact Rat.le_of_lt (Rat.inv_pos.mpr (show (0:Rat)<1+y by grind only))
  constructor
  · exact RealRaw.le_trans (y := RealRaw.ofRat 0) (RealRaw.ofRat_valid 0)
      (fun _ _ => by change -(1/(1+y))≤0; grind only) nonnegative
  · exact U

def rationalPoint (x y : Rat) : Scalar := ⟨ofQComplex ⟨x,y⟩,ofQComplex_valid _⟩

theorem parameter_same (X : Value) : Same (parameter X.real.preferred X.real.valid) X :=
  RealRaw.equiv_refl _ X.real.valid

theorem rational_parameter (q : Rat) : Same (parameter (RealRaw.ofRat q) (RealRaw.ofRat_valid q)) (Value.rational q) :=
  RealRaw.equiv_refl _ (RealRaw.ofRat_valid q)

theorem phase_point (x y : Rat) :
    ((ContourFunction.phase).eval (rationalPoint x y) trivial).val.Equiv (input x y).val := by
  let X := parameter (RealRaw.ofRat x) (RealRaw.ofRat_valid x)
  let Y := parameter (argument y).real.preferred (argument y).real.valid
  let C := Value.add (Value.rational 0)
    (RealApproximationOrder.sub (Value.mul (Value.rational 0) (Value.rational x)) (Value.mul piValue (Value.rational y)))
  let S := Value.add (Value.rational 0)
    (Value.add (Value.mul (Value.rational 0) (Value.rational y)) (Value.mul piValue (Value.rational x)))
  have P0 : ContourFunction.zeroScalar.val.Equiv (pair (Value.rational 0) (Value.rational 0)) :=
    of_compute ContourFunction.zeroScalar.property (pair_valid (Value.rational 0) (Value.rational 0)) (fun _ => rfl)
  have PP : ContourFunction.imaginaryPi.val.Equiv (pair (Value.rational 0) piValue) :=
    of_compute ContourFunction.imaginaryPi.property (pair_valid (Value.rational 0) piValue) (fun _ => rfl)
  have PZ : (rationalPoint x y).val.Equiv (pair (Value.rational x) (Value.rational y)) :=
    of_compute (rationalPoint x y).property (pair_valid (Value.rational x) (Value.rational y)) (fun _ => rfl)
  have M := mul_equiv ContourFunction.imaginaryPi.property (pair_valid (Value.rational 0) piValue)
    (rationalPoint x y).property (pair_valid (Value.rational x) (Value.rational y)) PP PZ
  have H : ((ContourFunction.phase).eval (rationalPoint x y) trivial).val.Equiv (pair C S) := by
    have A := add_equiv P0 M
    rw [pair_product,pair_sum] at A
    exact A
  change ((ContourFunction.phase).eval (rationalPoint x y) trivial).val.Equiv
    (add (pair Y (Value.rational 0)) (pair (Value.rational 0) (angular X)))
  rw [pair_sum]
  apply equiv_trans ((ContourFunction.phase).eval (rationalPoint x y) trivial).property
    (pair_valid C S) (pair_valid (Value.add Y (Value.rational 0)) (Value.add (Value.rational 0) (angular X))) H
  apply pair_congr
  · have A : Same (Value.add (Value.rational 0)
        (RealApproximationOrder.sub (Value.mul (Value.rational 0) (Value.rational x)) (Value.mul piValue (Value.rational y))))
        (Value.add (argument y) (Value.rational 0)) := by
      apply arithmetic_identity; intro s
      simp only [Value.add,Value.mul,Value.rational,RealApproximationOrder.sub,argument,EulerNegativeRate.argument,Value.neg,scale] <;> grind only
    exact A.trans (((parameter_same (argument y)).add (Same.refl (Value.rational 0))).symm)
  · have A : Same (Value.add (Value.rational 0)
        (Value.add (Value.mul (Value.rational 0) (Value.rational y)) (Value.mul piValue (Value.rational x))))
        (Value.add (Value.rational 0) (Value.mul piValue (Value.rational x))) := by
      apply arithmetic_identity; intro s; simp only [Value.add,Value.mul,Value.rational] <;> grind only
    exact A.trans (((Same.refl (Value.rational 0)).add ((Same.refl piValue).mul (rational_parameter x))).symm)

theorem numerator_point (x y : Rat) (hz : ContourFunction.numerator.domain (rationalPoint x y)) :
    (ContourFunction.numerator.eval (rationalPoint x y) hz).val.Equiv
      (pair (Value.mul (decay y) (valueFor true x)) (Value.mul (decay y) (valueFor false x))) := by
  have H := entireExponentialValue_congr (ContourFunction.phase.eval (rationalPoint x y) trivial) (input x y) (phase_point x y)
  exact equiv_trans (ContourFunction.numerator.eval (rationalPoint x y) hz).property
    (entireExponentialValue (input x y)).property (pair_valid _ _) H (addition_formula x y)

end ComputableAnalysis.DirichletIntegral.ContourNumerator
