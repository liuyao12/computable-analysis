import ComputableAnalysis.DirichletIntegral.ContourPullbacks
import ComputableAnalysis.DirichletIntegral.ContourBounds
import ComputableAnalysis.LipschitzTaggedQuadrature

/-! Coordinate algebra for literal finite contour sums. -/
namespace ComputableAnalysis.DirichletIntegral.ContourGridAlgebra
open ComputableCoefficient RealApproximationOrder
open ComplexRaw RiemannHilbert FunctionTheory RectangularContour
open ContourSeriesCoordinates ContourExponentialSeries
open _root_.ComputableAnalysis.RiemannHilbert.DomainFunctions
set_option maxHeartbeats 800000
set_option autoImplicit false

def imaginaryValue (z : Scalar) : Value := coordinateValue false z.val z.property
def realValue (z : Scalar) : Value := coordinateValue true z.val z.property

theorem real_of_compute {x y : RealRaw} (_hx : x.Valid) (hy : y.Valid)
    (eq : ∀ n,x.compute n=y.compute n) : x.Equiv y := by
  intro n
  apply (RealRaw.compareAt_overlap_iff x y n n).mpr
  rw [eq n]
  exact (RealRaw.compareAt_overlap_iff y y n n).mp (RealRaw.equiv_refl y hy n)

theorem imaginary_add (z w : Scalar) :
    Same (imaginaryValue (scalarSum z w)) (Value.add (imaginaryValue z) (imaginaryValue w)) := by
  apply real_of_compute (imaginaryValue (scalarSum z w)).real.valid (Value.add (imaginaryValue z) (imaginaryValue w)).real.valid
  intro n; rfl

theorem imaginary_sub (z w : Scalar) :
    Same (imaginaryValue (gridScalarSub z w)) (RealApproximationOrder.sub (imaginaryValue z) (imaginaryValue w)) := by
  apply real_of_compute (imaginaryValue (gridScalarSub z w)).real.valid (RealApproximationOrder.sub (imaginaryValue z) (imaginaryValue w)).real.valid
  intro n
  change ({lo := (z.val.compute n).lo.im + -(w.val.compute n).hi.im,hi := (z.val.compute n).hi.im + -(w.val.compute n).lo.im} : QInterval)=
    {lo := (z.val.compute n).lo.im-(w.val.compute n).hi.im,hi := (z.val.compute n).hi.im-(w.val.compute n).lo.im}
  congr 1 <;> grind only [Rat.sub_eq_add_neg]

theorem imaginary_zero : Same (imaginaryValue ⟨zero,ofQComplex_valid _⟩) (Value.rational 0) := by
  exact RealRaw.equiv_refl _ (RealRaw.ofRat_valid 0)

theorem horizontal_weight (z : Scalar) (h : Rat) :
    Same (imaginaryValue (scalarProduct z (rationalRectangleScalar ⟨h,0⟩))) (scale h (imaginaryValue z)) := by
  have Z : z.val.Equiv (pair (realValue z) (imaginaryValue z)) := of_compute z.property (pair_valid (realValue z) (imaginaryValue z)) (fun _ => rfl)
  have V : (rationalRectangleScalar ⟨h,0⟩).val.Equiv (pair (Value.rational h) (Value.rational 0)) := equiv_refl _ (ofQComplex_valid _)
  have M := mul_equiv z.property (pair_valid (realValue z) (imaginaryValue z)) (ofQComplex_valid ⟨h,0⟩)
    (pair_valid (Value.rational h) (Value.rational 0)) Z V
  rw [pair_product] at M
  have A : Same (imaginaryValue (scalarProduct z (rationalRectangleScalar ⟨h,0⟩)))
      (Value.add (Value.mul (realValue z) (Value.rational 0)) (Value.mul (imaginaryValue z) (Value.rational h))) := imagPart_equiv M
  apply A.trans
  apply arithmetic_identity; intro s; simp only [Value.add,Value.mul,Value.rational,scale]; grind only

theorem vertical_weight (z : Scalar) (h : Rat) :
    Same (imaginaryValue (scalarProduct z (rationalRectangleScalar ⟨0,h⟩))) (scale h (realValue z)) := by
  have Z : z.val.Equiv (pair (realValue z) (imaginaryValue z)) := of_compute z.property (pair_valid (realValue z) (imaginaryValue z)) (fun _ => rfl)
  have V : (rationalRectangleScalar ⟨0,h⟩).val.Equiv (pair (Value.rational 0) (Value.rational h)) := equiv_refl _ (ofQComplex_valid _)
  have M := mul_equiv z.property (pair_valid (realValue z) (imaginaryValue z)) (ofQComplex_valid ⟨0,h⟩)
    (pair_valid (Value.rational 0) (Value.rational h)) Z V
  rw [pair_product] at M
  have A : Same (imaginaryValue (scalarProduct z (rationalRectangleScalar ⟨0,h⟩)))
      (Value.add (Value.mul (realValue z) (Value.rational h)) (Value.mul (imaginaryValue z) (Value.rational 0))) := imagPart_equiv M
  apply A.trans
  apply arithmetic_identity; intro s; simp only [Value.add,Value.mul,Value.rational,scale]; grind only

def valueSum (f : Nat → Value) : Nat → Value
  | 0 => Value.rational 0
  | n+1 => Value.add (valueSum f n) (f n)

theorem imaginary_sum (n : Nat) (f : Nat → Scalar) :
    Same (imaginaryValue (gridScalarSum n f)) (valueSum (fun j => imaginaryValue (f j)) n) := by
  induction n with
  | zero => exact imaginary_zero
  | succ n ih => exact (imaginary_add (gridScalarSum n f) (f n)).trans (ih.add (Same.refl (imaginaryValue (f n))))

theorem sum_sub (n : Nat) (f g : Nat → Scalar) :
    (gridScalarSum n (fun j => gridScalarSub (f j) (g j))).val.Equiv
      (ComplexRaw.sub (gridScalarSum n f).val (gridScalarSum n g).val) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (gridScalarSum n (fun j => gridScalarSub (f j) (g j))).property)
    (hright := sub_valid (gridScalarSum n f).property (gridScalarSum n g).property)
  change gridScalarValue (gridScalarSum n (fun j => gridScalarSub (f j) (g j)))=
    gridScalarValue (gridScalarSum n f)-gridScalarValue (gridScalarSum n g)
  simp only [gridScalarSum_value,gridScalarValue_sub]
  exact gridValueSum_sub n (fun j => gridScalarValue (f j)) (fun j => gridScalarValue (g j))

end ComputableAnalysis.DirichletIntegral.ContourGridAlgebra
