import ComputableAnalysis.DirichletIntegral.ContourGridEdges

/-! Uniform bounds for the literal top and right midpoint edge sums. -/
namespace ComputableAnalysis.DirichletIntegral.ContourOuterEdges
open ComputableCoefficient RealApproximationOrder LipschitzQuadrature
open ComplexRaw RiemannHilbert FunctionTheory RectangularContour
open ContourNumerator ContourBounds ContourGridAlgebra ContourGridGeometry ContourGridEdges
set_option maxHeartbeats 800000
set_option autoImplicit false

theorem horizontal_velocity (h : Rat) (hh : 0≤h) : FunctionTheory.Small (rationalRectangleScalar ⟨h,0⟩).val h := by
  refine ⟨?_,?_,?_,?_⟩
  · intro i j; change -h≤h; grind only
  · intro i j; change h≤h; exact Rat.le_refl
  · intro i j; change -h≤0; grind only
  · intro i j; change (0:Rat)≤h; exact hh

theorem vertical_velocity (h : Rat) (hh : 0≤h) : FunctionTheory.Small (rationalRectangleScalar ⟨0,h⟩).val h := by
  refine ⟨?_,?_,?_,?_⟩
  · intro i j; change -h≤0; grind only
  · intro i j; change (0:Rat)≤h; exact hh
  · intro i j; change -h≤h; grind only
  · intro i j; change h≤h; exact Rat.le_refl

theorem total_mesh (R : Rat) (M : Nat) (hM : 0<M) : (M:Rat)*mesh 0 R M=R := by
  have mc := Rat.mul_inv_cancel (M:Rat) (Rat.ne_of_gt (Rat.natCast_pos.mpr hM))
  simp only [mesh,if_neg (Nat.ne_of_gt hM),Rat.div_def]
  grind only

theorem top_small (eta R H : Rat) (he : 0<eta) (hR : 0≤R) (hH : 0<H) (M : Nat) (hM : 0<M) :
    FunctionTheory.Small (top eta R H he M).val (4*R*(1/H)*(1/H)) := by
  let E := 2*(2*(1/H)*(1/H))*mesh 0 R M
  have hm : 0≤mesh 0 R M := mesh_nonneg_of_le hM hR
  have hi : 0≤1/H := by simpa only [Rat.div_def,Rat.one_mul] using Rat.le_of_lt (Rat.inv_pos.mpr hH)
  have hb : 0≤2*(1/H)*(1/H) := Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hi) hi
  have e0 : 0≤E := Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hb) hm
  have S := gridScalarSum_bound M
    (fun j => rectangleGridHorizontal (sample eta R H he) (ContourFunction.rectangle R H) M j M) E e0 (by
      intro j hj
      change FunctionTheory.Small (mul (sample eta R H he (rectangleGridHorizontalPoint (ContourFunction.rectangle R H) M j M)).val
        (rationalRectangleScalar ⟨rectangleGridStepX (ContourFunction.rectangle R H) M,0⟩).val) E
      rw [point_top R H M hM j,step_x R H M hM]
      let x := midpointTag 0 R M j
      have xb := tag_bounds R hR M hM j hj
      have hq : rationalRectangleContains (ContourFunction.rectangle R H) ⟨x,H⟩ := ⟨xb.1,xb.2,Rat.le_of_lt hH,Rat.le_refl⟩
      have hz := ContourFunction.rectangle_domain eta R H he _ (rationalRectangle_represented_mem _ _ hq)
      have actual := top_bound eta x H he xb.1 hH hz
      have agreement := holomorphicRectangleSample_agreement (ContourFunction.function eta) (ContourFunction.holomorphic eta)
        (ContourFunction.rectangle R H) (ContourFunction.rectangle_domain eta R H he) ⟨x,H⟩ hq hz
      have bound := FunctionTheory.Small.congr ((ContourFunction.function eta).eval _ hz).property (sample eta R H he ⟨x,H⟩).property agreement actual
      exact FunctionTheory.Small.mul (sample eta R H he ⟨x,H⟩).property (ofQComplex_valid _)
        hb hm bound (horizontal_velocity _ hm))
  have total := total_mesh R M hM
  have eq : (M:Rat)*E=4*R*(1/H)*(1/H) := by dsimp [E]; grind only
  rw [eq] at S
  exact S

theorem right_small (eta R H : Rat) (he : 0<eta) (hR : 0<R) (hH : 0≤H) (M : Nat) (hM : 0<M) :
    FunctionTheory.Small (right eta R H he M).val (4*H/R) := by
  let E := 2*(2/R)*mesh 0 H M
  have hm : 0≤mesh 0 H M := mesh_nonneg_of_le hM hH
  have hi : 0≤2/R := by
    rw [Rat.div_def]
    exact Rat.mul_nonneg (by decide +kernel) (Rat.le_of_lt (Rat.inv_pos.mpr hR))
  have e0 : 0≤E := Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hi) hm
  have S := gridScalarSum_bound M
    (fun j => rectangleGridVertical (sample eta R H he) (ContourFunction.rectangle R H) M M j) E e0 (by
      intro j hj
      change FunctionTheory.Small (mul (sample eta R H he (rectangleGridVerticalPoint (ContourFunction.rectangle R H) M M j)).val
        (rationalRectangleScalar ⟨0,rectangleGridStepY (ContourFunction.rectangle R H) M⟩).val) E
      rw [point_right R H M hM j,step_y R H M hM]
      let y := midpointTag 0 H M j
      have yb := tag_bounds H hH M hM j hj
      have hq : rationalRectangleContains (ContourFunction.rectangle R H) ⟨R,y⟩ := ⟨Rat.le_of_lt hR,Rat.le_refl,yb.1,yb.2⟩
      have hz := ContourFunction.rectangle_domain eta R H he _ (rationalRectangle_represented_mem _ _ hq)
      have actual := right_bound eta R y he hR yb.1 hz
      have agreement := holomorphicRectangleSample_agreement (ContourFunction.function eta) (ContourFunction.holomorphic eta)
        (ContourFunction.rectangle R H) (ContourFunction.rectangle_domain eta R H he) ⟨R,y⟩ hq hz
      have bound := FunctionTheory.Small.congr ((ContourFunction.function eta).eval _ hz).property (sample eta R H he ⟨R,y⟩).property agreement actual
      exact FunctionTheory.Small.mul (sample eta R H he ⟨R,y⟩).property (ofQComplex_valid _)
        hi hm bound (vertical_velocity _ hm))
  have total := total_mesh H M hM
  have eq : (M:Rat)*E=4*H/R := by dsimp [E]; simp only [Rat.div_def]; grind only
  rw [eq] at S
  exact S

end ComputableAnalysis.DirichletIntegral.ContourOuterEdges
