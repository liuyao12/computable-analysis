import ComputableAnalysis.DirichletIntegral.ContourRational

/-! Bounds for the actual rational contour evaluations. The tall, wider
rectangle will use separate horizontal and vertical separation bounds. -/
namespace ComputableAnalysis.DirichletIntegral.ContourBounds
open ComputableCoefficient RealApproximationOrder FTCRealOrder
open ComplexRaw RiemannHilbert FunctionTheory GeometricTrig GeometricIntegralData
open ContourSeriesCoordinates ContourNumerator ContourRational
open _root_.ComputableAnalysis.RiemannHilbert.DomainFunctions
set_option maxHeartbeats 800000
set_option autoImplicit false

theorem cross_le_den (eta x y : Rat) (he : 0<eta) (hx : 0≤x) (hy : 0≤y) :
    x*(y+eta)≤den eta x y := by
  have S := RationalCircle.Stage.ratSquare_nonneg (x-(y+eta))
  have P := Rat.mul_nonneg hx (show 0≤y+eta by grind only)
  dsimp [den]; grind only

theorem inverse_bound (eta x y d : Rat) (he : 0<eta) (hx : 0≤x) (hy : 0≤y) (hd : 0<d)
    (hxd : x*d≤den eta x y) (hyd : (y+eta)*d≤den eta x y) :
    FunctionTheory.Small (expectedInverse eta x y).val (1/d) := by
  have dp := den_positive eta x y he hy
  have dc := Rat.mul_inv_cancel (den eta x y) (Rat.ne_of_gt dp)
  have dd := Rat.mul_inv_cancel d (Rat.ne_of_gt hd)
  have di := Rat.le_of_lt (Rat.inv_pos.mpr dp)
  have ei := Rat.le_of_lt (Rat.inv_pos.mpr hd)
  have A := Rat.mul_le_mul_of_nonneg_right hxd (Rat.mul_nonneg di ei)
  have B := Rat.mul_le_mul_of_nonneg_right hyd (Rat.mul_nonneg di ei)
  have simp_left (z : Rat) : z*d*((den eta x y)⁻¹*d⁻¹)=z*(den eta x y)⁻¹ := by grind only
  have simp_right : den eta x y*((den eta x y)⁻¹*d⁻¹)=d⁻¹ := by grind only
  rw [simp_left x,simp_right] at A
  rw [simp_left (y+eta),simp_right] at B
  have X := Rat.mul_nonneg hx di
  have Y := Rat.mul_nonneg (show 0≤y+eta by grind only) di
  refine ⟨?_,?_,?_,?_⟩ <;> intro i j
  · change -(1/d)≤x/den eta x y
    simp only [Rat.div_def,Rat.one_mul]; grind only
  · change x/den eta x y≤1/d
    simp only [Rat.div_def,Rat.one_mul]; grind only
  · change -(1/d)≤ -(y+eta)/den eta x y
    simp only [Rat.div_def,Rat.one_mul]; grind only
  · change -(y+eta)/den eta x y≤1/d
    simp only [Rat.div_def,Rat.one_mul]; grind only

theorem numerator_bound (x y B : Rat) (H : RealApproximationOrder.Small (decay y) B) :
    FunctionTheory.Small (pair (Value.mul (decay y) (valueFor true x)) (Value.mul (decay y) (valueFor false x))) B := by
  have C := H.mul (trig_small true x)
  have S := H.mul (trig_small false x)
  simp only [Rat.mul_one] at C S
  exact ⟨C.1,C.2,S.1,S.2⟩

theorem function_bound (eta x y d B : Rat) (he : 0<eta) (hx : 0≤x) (hy : 0≤y) (hd : 0<d)
    (hxd : x*d≤den eta x y) (hyd : (y+eta)*d≤den eta x y) (hB : 0≤B)
    (hb : RealApproximationOrder.Small (decay y) B)
    (hz : (ContourFunction.function eta).domain (rationalPoint x y)) :
    FunctionTheory.Small ((ContourFunction.function eta).eval (rationalPoint x y) hz).val (2*(1/d)*B) := by
  have I := inverse_point eta x y he hy hz
  have N := numerator_point x y (⟨trivial,trivial⟩)
  have bi := FunctionTheory.Small.congr (expectedInverse eta x y).property
    ((ContourFunction.inverse eta).eval (rationalPoint x y) hz).property (equiv_symm I)
    (inverse_bound eta x y d he hx hy hd hxd hyd)
  have bn := FunctionTheory.Small.congr (pair_valid (Value.mul (decay y) (valueFor true x)) (Value.mul (decay y) (valueFor false x)))
    (ContourFunction.numerator.eval (rationalPoint x y) ⟨trivial,trivial⟩).property (equiv_symm N) (numerator_bound x y B hb)
  exact FunctionTheory.Small.mul ((ContourFunction.inverse eta).eval (rationalPoint x y) hz).property
    (ContourFunction.numerator.eval (rationalPoint x y) ⟨trivial,trivial⟩).property
    (by simpa only [Rat.div_def,Rat.one_mul] using Rat.le_of_lt (Rat.inv_pos.mpr hd)) hB bi bn

theorem right_bound (eta x y : Rat) (he : 0<eta) (hx : 0<x) (hy : 0≤y)
    (hz : (ContourFunction.function eta).domain (rationalPoint x y)) :
    FunctionTheory.Small ((ContourFunction.function eta).eval (rationalPoint x y) hz).val (2/x) := by
  have Y := RationalCircle.Stage.ratSquare_nonneg (y+eta)
  have xx : x*x≤den eta x y := by dsimp [den]; grind only
  have xy : (y+eta)*x≤den eta x y := by have H := cross_le_den eta x y he (Rat.le_of_lt hx) hy; grind only
  have D := decay_bound y hy
  have H := QInterval.one_div_le_one_div_of_pos (show (0:Rat)<1 by decide +kernel)
    (show (1:Rat)≤1+y by grind only)
  have D' := D.mono (show 1/(1+y)≤1 by simpa only [show (1:Rat)/1=1 by decide +kernel] using H)
  have B := function_bound eta x y x 1 he (Rat.le_of_lt hx) hy hx xx xy (by decide +kernel) D' hz
  simpa only [Rat.mul_one,Rat.div_def,Rat.one_mul] using B

theorem top_bound (eta x y : Rat) (he : 0<eta) (hx : 0≤x) (hy : 0<y)
    (hz : (ContourFunction.function eta).domain (rationalPoint x y)) :
    FunctionTheory.Small ((ContourFunction.function eta).eval (rationalPoint x y) hz).val (2*(1/y)*(1/y)) := by
  have y0 := Rat.le_of_lt hy
  have e0 := Rat.le_of_lt he
  have xy : x*y≤den eta x y := by
    have H := cross_le_den eta x y he hx y0
    have P := Rat.mul_nonneg hx e0
    grind only
  have yy : (y+eta)*y≤den eta x y := by
    have X := RationalCircle.Stage.ratSquare_nonneg x
    have P := Rat.mul_nonneg (show 0≤y+eta by grind only) e0
    dsimp [den]; grind only
  have D := (decay_bound y y0).mono (QInterval.one_div_le_one_div_of_pos hy (show y≤1+y by grind only))
  exact function_bound eta x y y (1/y) he hx y0 hy xy yy
    (by simpa only [Rat.div_def,Rat.one_mul] using Rat.le_of_lt (Rat.inv_pos.mpr hy)) D hz

end ComputableAnalysis.DirichletIntegral.ContourBounds
