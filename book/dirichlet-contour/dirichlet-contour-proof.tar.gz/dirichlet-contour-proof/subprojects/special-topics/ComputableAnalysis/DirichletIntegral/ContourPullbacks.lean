import ComputableAnalysis.DirichletIntegral.ContourRational
import ComputableAnalysis.DirichletIntegral.ContourRegularization

/-! Exact coordinate pullbacks on the bottom and left edges. -/
namespace ComputableAnalysis.DirichletIntegral.ContourPullbacks
open ComputableCoefficient RealApproximationOrder FTCRealOrder
open ComplexRaw RiemannHilbert FunctionTheory GeometricTrig GeometricIntegralData
open ContourSeriesCoordinates ContourNumerator ContourRational ContourRegularization
set_option maxHeartbeats 800000
set_option autoImplicit false

theorem sine_zero : Same (valueFor false 0) (Value.rational 0) := by
  change (valueFor false 0).real.preferred.Equiv (RealRaw.ofRat 0)
  rw [valueFor_raw]
  exact sample_zero false

theorem decay_zero : Same (decay 0) (Value.rational 1) := by
  have A : Same (argument 0) (Value.rational 0) := by
    apply arithmetic_identity; intro s
    simp only [argument,EulerNegativeRate.argument,scale,Value.rational,Value.neg] <;> grind only
  have E := EulerReal.eval_congr (x := (argument 0).real.preferred) (y := RealRaw.ofRat 0)
    (argument 0).real.valid (RealRaw.ofRat_valid 0) A
  exact RealRaw.equiv_trans (decay 0).real.valid (EulerReal.sample_valid 0) (RealRaw.ofRat_valid 1) E EulerReal.sample_zero

theorem bottom_value (eta x : Rat) : Same (imagPartValue eta x 0)
    (RealApproximationOrder.sub (sineRegularized eta x) (cosineRegularized eta x)) := by
  let K := RealApproximationOrder.sub (scale (x/den eta x 0) (valueFor false x))
    (scale ((0+eta)/den eta x 0) (valueFor true x))
  have D : Same (imagPartValue eta x 0) (Value.mul (Value.rational 1) K) :=
    decay_zero.mul (Same.refl K)
  apply D.trans
  apply arithmetic_identity; intro s
  simp only [K,imagPartValue,den,sineRegularized,cosineRegularized,ContourPoisson.kernel,ContourPoisson.rational,
    ContourPoisson.denominator,Value.mul,Value.rational,RealApproximationOrder.sub,scale,Rat.zero_add] <;> grind only [Rat.div_def]

theorem bottom_point (eta x : Rat) (he : 0<eta)
    (hz : (ContourFunction.function eta).domain (rationalPoint x 0)) :
    (((ContourFunction.function eta).eval (rationalPoint x 0) hz).val.imagPart).Equiv
      (RealApproximationOrder.sub (sineRegularized eta x) (cosineRegularized eta x)).real.preferred := by
  have A : (((ContourFunction.function eta).eval (rationalPoint x 0) hz).val.imagPart).Equiv
      (imagPartValue eta x 0).real.preferred := imagPart_equiv (function_point eta x 0 he Rat.le_refl hz)
  exact RealRaw.equiv_trans (imagPart_valid ((ContourFunction.function eta).eval (rationalPoint x 0) hz).property)
    (imagPartValue eta x 0).real.valid
    (RealApproximationOrder.sub (sineRegularized eta x) (cosineRegularized eta x)).real.valid A (bottom_value eta x)

theorem left_value (eta y : Rat) : Same (realPartValue eta 0 y) (Value.rational 0) := by
  let c := (y+eta)/den eta 0 y
  have A : Same (realPartValue eta 0 y) (scale c (Value.mul (decay y) (valueFor false 0))) := by
    apply arithmetic_identity; intro s
    simp only [realPartValue,Value.mul,Value.add,scale,c] <;> grind only [Rat.div_def]
  have B := ((Same.refl (decay y)).mul sine_zero).scale c
  apply (A.trans B).trans
  apply arithmetic_identity; intro s; simp only [scale,Value.mul,Value.rational] <;> grind only

theorem left_point (eta y : Rat) (he : 0<eta) (hy : 0≤y)
    (hz : (ContourFunction.function eta).domain (rationalPoint 0 y)) :
    (((ContourFunction.function eta).eval (rationalPoint 0 y) hz).val.realPart).Equiv (RealRaw.ofRat 0) := by
  have A : (((ContourFunction.function eta).eval (rationalPoint 0 y) hz).val.realPart).Equiv
      (realPartValue eta 0 y).real.preferred := realPart_equiv (function_point eta 0 y he hy hz)
  exact RealRaw.equiv_trans (realPart_valid ((ContourFunction.function eta).eval (rationalPoint 0 y) hz).property)
    (realPartValue eta 0 y).real.valid (RealRaw.ofRat_valid 0) A (left_value eta y)

end ComputableAnalysis.DirichletIntegral.ContourPullbacks
