import ComputableAnalysis.DirichletIntegral.ContourNumerator

/-! Actual reciprocal evaluations and the bottom/left contour pullbacks. -/
namespace ComputableAnalysis.DirichletIntegral.ContourRational
open ComputableCoefficient RealApproximationOrder FTCRealOrder
open ComplexRaw RiemannHilbert FunctionTheory GeometricTrig GeometricIntegralData
open ContourSeriesCoordinates ContourNumerator
open _root_.ComputableAnalysis.RiemannHilbert.DomainFunctions
set_option maxHeartbeats 1000000
set_option autoImplicit false

def den (eta x y : Rat) : Rat := x*x+(y+eta)*(y+eta)
def expectedInverse (eta x y : Rat) : Scalar :=
  ⟨pair (Value.rational (x/den eta x y)) (Value.rational (-(y+eta)/den eta x y)),pair_valid _ _⟩

theorem denominator_point (eta x y : Rat) :
    ((ContourFunction.denominator eta).eval (rationalPoint x y) trivial).val.Equiv
      (pair (Value.rational x) (Value.rational (y+eta))) := by
  have N : (scalarNeg (ContourFunction.pole eta)).val.Equiv (pair (Value.rational 0) (Value.rational eta)) := by
    apply of_compute (scalarNeg (ContourFunction.pole eta)).property (pair_valid (Value.rational 0) (Value.rational eta))
    intro n
    simp only [scalarNeg,ContourFunction.pole,neg,ofQComplex,QBox.neg,QBox.point,QComplex.neg,pair,EulerImaginary.pair,Value.rational,Real.ofRat,RealRaw.ofRat,Rat.neg_zero,Rat.neg_neg]
    rfl
  have O : oneScalar.val.Equiv (pair (Value.rational 1) (Value.rational 0)) := equiv_refl _ (ofQComplex_valid _)
  have Z : (rationalPoint x y).val.Equiv (pair (Value.rational x) (Value.rational y)) := equiv_refl _ (ofQComplex_valid _)
  have M := mul_equiv oneScalar.property (pair_valid (Value.rational 1) (Value.rational 0))
    (rationalPoint x y).property (pair_valid (Value.rational x) (Value.rational y)) O Z
  have H := add_equiv N M
  rw [pair_product,pair_sum] at H
  let C := Value.add (Value.rational 0) (RealApproximationOrder.sub
    (Value.mul (Value.rational 1) (Value.rational x)) (Value.mul (Value.rational 0) (Value.rational y)))
  let S := Value.add (Value.rational eta) (Value.add
    (Value.mul (Value.rational 1) (Value.rational y)) (Value.mul (Value.rational 0) (Value.rational x)))
  apply equiv_trans ((ContourFunction.denominator eta).eval (rationalPoint x y) trivial).property
    (pair_valid C S) (pair_valid (Value.rational x) (Value.rational (y+eta))) H
  apply pair_congr <;> apply arithmetic_identity <;> intro s <;>
    simp only [C,S,Value.add,Value.mul,Value.rational,RealApproximationOrder.sub] <;> grind only

theorem den_positive (eta x y : Rat) (he : 0<eta) (hy : 0≤y) : 0<den eta x y := by
  have X := RationalCircle.Stage.ratSquare_nonneg x
  have Y : 0<y+eta := by grind only
  have YY := Rat.mul_pos Y Y
  dsimp [den]; grind only

theorem inverse_point (eta x y : Rat) (he : 0<eta) (hy : 0≤y)
    (hz : (ContourFunction.inverse eta).domain (rationalPoint x y)) :
    ((ContourFunction.inverse eta).eval (rationalPoint x y) hz).val.Equiv (expectedInverse eta x y).val := by
  let z := (ContourFunction.denominator eta).eval (rationalPoint x y) trivial
  have Z : z.val.Equiv (pair (Value.rational x) (Value.rational (y+eta))) := denominator_point eta x y
  have M := mul_equiv z.property (pair_valid (Value.rational x) (Value.rational (y+eta)))
    (expectedInverse eta x y).property (expectedInverse eta x y).property Z (equiv_refl _ (expectedInverse eta x y).property)
  change (mul z.val (pair (Value.rational (x/den eta x y)) (Value.rational (-(y+eta)/den eta x y)))).Equiv _ at M
  rw [expectedInverse,pair_product] at M
  let C := RealApproximationOrder.sub (Value.mul (Value.rational x) (Value.rational (x/den eta x y)))
    (Value.mul (Value.rational (y+eta)) (Value.rational (-(y+eta)/den eta x y)))
  let S := Value.add (Value.mul (Value.rational x) (Value.rational (-(y+eta)/den eta x y)))
    (Value.mul (Value.rational (y+eta)) (Value.rational (x/den eta x y)))
  have dc := Rat.mul_inv_cancel (den eta x y) (Rat.ne_of_gt (den_positive eta x y he hy))
  have A : (pair C S).Equiv (ofQComplex QComplex.one) := by
    change (pair C S).Equiv (pair (Value.rational 1) (Value.rational 0))
    apply pair_congr <;> apply arithmetic_identity <;> intro s <;>
      simp only [C,S,Value.mul,Value.add,Value.rational,RealApproximationOrder.sub,Rat.div_def] <;>
      dsimp [den] at dc ⊢ <;> grind only
  have P := equiv_trans (mul_valid z.property (expectedInverse eta x y).property)
    (pair_valid C S) (ofQComplex_valid _) M A
  exact RepresentedReciprocal.inverse_unique z (compose_outer_mem hz) (expectedInverse eta x y) P

def realPartValue (eta x y : Rat) : Value := Value.mul (decay y)
  (Value.add (scale (x/den eta x y) (valueFor true x)) (scale ((y+eta)/den eta x y) (valueFor false x)))
def imagPartValue (eta x y : Rat) : Value := Value.mul (decay y)
  (RealApproximationOrder.sub (scale (x/den eta x y) (valueFor false x)) (scale ((y+eta)/den eta x y) (valueFor true x)))

theorem function_point (eta x y : Rat) (he : 0<eta) (hy : 0≤y)
    (hz : (ContourFunction.function eta).domain (rationalPoint x y)) :
    ((ContourFunction.function eta).eval (rationalPoint x y) hz).val.Equiv
      (pair (realPartValue eta x y) (imagPartValue eta x y)) := by
  have I := inverse_point eta x y he hy hz
  have N := numerator_point x y (⟨trivial,trivial⟩)
  have H := mul_equiv ((ContourFunction.inverse eta).eval (rationalPoint x y) hz).property (expectedInverse eta x y).property
    (ContourFunction.numerator.eval (rationalPoint x y) ⟨trivial,trivial⟩).property
    (pair_valid (Value.mul (decay y) (valueFor true x)) (Value.mul (decay y) (valueFor false x))) I N
  change (mul ((ContourFunction.inverse eta).eval (rationalPoint x y) hz).val
    (ContourFunction.numerator.eval (rationalPoint x y) ⟨trivial,trivial⟩).val).Equiv _
  change (mul ((ContourFunction.inverse eta).eval (rationalPoint x y) hz).val
    (ContourFunction.numerator.eval (rationalPoint x y) ⟨trivial,trivial⟩).val).Equiv _ at H
  rw [expectedInverse,pair_product] at H
  let P := Value.rational (x/den eta x y)
  let Q := Value.rational (-(y+eta)/den eta x y)
  let C := RealApproximationOrder.sub (Value.mul P (Value.mul (decay y) (valueFor true x))) (Value.mul Q (Value.mul (decay y) (valueFor false x)))
  let S := Value.add (Value.mul P (Value.mul (decay y) (valueFor false x))) (Value.mul Q (Value.mul (decay y) (valueFor true x)))
  apply equiv_trans ((ContourFunction.function eta).eval (rationalPoint x y) hz).property
    (pair_valid C S) (pair_valid (realPartValue eta x y) (imagPartValue eta x y)) H
  apply pair_congr <;> apply arithmetic_identity <;> intro s <;>
    simp only [P,Q,C,S,realPartValue,imagPartValue,Value.mul,Value.add,Value.rational,scale,RealApproximationOrder.sub] <;> grind only [Rat.div_def]

end ComputableAnalysis.DirichletIntegral.ContourRational
