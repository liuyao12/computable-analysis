import ComputableAnalysis.GeometricIntegralData
import ComputableAnalysis.FTCRealReciprocal
import ComputableAnalysis.LipschitzQuadrature

/-! Proper integrals of geometric sin(pi*x)/x on positive compact segments.
The partial function keeps its actual positive domain. -/
namespace ComputableAnalysis.DirichletIntegral
open ComputableCoefficient RealApproximationOrder FTCRealCalculus
open GeometricTrig GeometricIntegralData LipschitzQuadrature Integral
set_option maxHeartbeats 1000000

def sincValue (x : Rat) : Value := Value.mul (valueFor false x) (reciprocalValue x)

def sinc : PartialRealFunRaw where
  definedAt x := 0<x
  compute x _ := (sincValue x).real.compute

theorem sinc_valid : sinc.Valid := fun x _ => (sincValue x).real.valid

theorem sinc_formula (x : Rat) : (sincValue x).real.preferred.Equiv
    (RealRaw.scaleRat (1/x) (GeometricTrig.sin x)) := by
  change (sincValue x).real.preferred.Equiv (RealRaw.scaleRat (1/x) (sample false x))
  rw [←valueFor_raw false x]
  apply arithmetic_identity _ (scale (1/x) (valueFor false x))
  intro s; simp only [sincValue,Value.mul,reciprocalValue,Value.rational,scale]
  grind only

theorem sinc_small (x : Rat) (hx : 0<x) : Small (sincValue x) 8 := by
  have hi : 0≤1/x := by rw [Rat.div_def,Rat.one_mul]; exact Rat.le_of_lt (Rat.inv_pos.mpr hx)
  have H := (sine_linear_bound x (Rat.le_of_lt hx)).scale_nonnegative hi
  have hc := Rat.inv_mul_cancel x (Rat.ne_of_gt hx)
  have he : (1/x)*(8*x)=8 := by simp only [Rat.div_def,Rat.one_mul]; grind only
  rw [he] at H
  apply H.congr
  apply arithmetic_identity; intro s; simp only [sincValue,Value.mul,reciprocalValue,Value.rational,scale]; grind only

def sineData (a b : Rat) (hab : a≤b) : Data (valueFor false) a b where
  ordered := hab
  constant := 8
  nonnegative := by decide +kernel
  lipschitz := lipschitz_of_firstOrder (trigStep false a b).firstOrder
    (trigStep false a b).error_nonnegative (trigStep false a b).radius.property
    (fun t _ _ => derivative_small false t)

def inverseData (a b : Rat) (ha : 0<a) (hab : a≤b) : Data reciprocalValue a b where
  ordered := hab
  constant := a⁻¹*a⁻¹
  nonnegative := Rat.mul_nonneg (Rat.le_of_lt (Rat.inv_pos.mpr ha)) (Rat.le_of_lt (Rat.inv_pos.mpr ha))
  lipschitz := lipschitz_of_firstOrder (reciprocalStep a b ha).firstOrder
    (reciprocalStep a b ha).error_nonnegative (reciprocalStep a b ha).radius.property
    (fun t ht _ => reciprocalDerivative_small a t ha ht)

/-- The compact computation is independent of any Feynman parameter. -/
def compactData (a b : Rat) (ha : 0<a) (hab : a≤b) : Data sincValue a b :=
  (sineData a b hab).mul (inverseData a b ha hab) 1 a⁻¹ (by decide +kernel)
    (Rat.le_of_lt (Rat.inv_pos.mpr ha))
    (fun t _ _ => trig_small false t) (fun t ht _ => reciprocal_small a t ha ht)

def compact (a b : Rat) (ha : 0<a) (hab : a≤b) : RealRaw := (compactData a b ha hab).integral

theorem compact_hasIntegral (a b : Rat) (ha : 0<a) (hab : a≤b) :
    HasIntegral (LipschitzIntegralBounds.onInterval sincValue a b) (compact a b ha hab) :=
  (compactData a b ha hab).hasIntegral

def primitiveData (a b : Rat) (hab : a≤b) : Data sineIntegral a b where
  ordered := hab
  constant := 1
  nonnegative := by decide +kernel
  lipschitz := lipschitz_of_firstOrder (sineIntegralStep a b).firstOrder
    (sineIntegralStep a b).error_nonnegative (sineIntegralStep a b).radius.property
    (fun t _ _ => trig_small false t)

def inverseDerivativeData (a b : Rat) (ha : 0<a) (hab : a≤b) : Data reciprocalDerivative a b where
  ordered := hab
  constant := (reciprocalStep a b ha).variation
  nonnegative := (reciprocalStep a b ha).variation_nonnegative
  lipschitz := (reciprocalStep a b ha).lipschitz

def auxiliaryData (a b : Rat) (ha : 0<a) (hab : a≤b) :
    Data (fun t => Value.mul (sineIntegral t) (reciprocalDerivative t)) a b :=
  (primitiveData a b hab).mul (inverseDerivativeData a b ha hab) 1 (a⁻¹*a⁻¹)
    (by decide +kernel) (Rat.mul_nonneg (Rat.le_of_lt (Rat.inv_pos.mpr ha)) (Rat.le_of_lt (Rat.inv_pos.mpr ha)))
    (fun t _ _ => sineIntegral_small t) (fun t ht _ => reciprocalDerivative_small a t ha ht)

private def positiveInverseStep (a b : Rat) (ha : 0<a) :
    Step (fun t => Value.rational (-1/t)) (fun t => Value.rational ((1/t)*(1/t))) a b := by
  apply ((reciprocalStep a b ha).scale (-1)).congr
  · intro t; apply arithmetic_identity; intro s; simp only [scale,reciprocalValue,Value.rational]; grind only [Rat.div_def]
  · intro t; apply arithmetic_identity; intro s; simp only [scale,reciprocalDerivative,Value.rational]; grind only

private theorem auxiliary_small (a b : Rat) (ha : 0<a) (hab : a≤b) :
    Small (auxiliaryData a b ha hab).value (1/a-1/b) := by
  have lower : HasIntegral (LipschitzIntegralBounds.onInterval reciprocalDerivative a b) (RealRaw.ofRat (1/b-1/a)) := by
    have H := (reciprocalStep a b ha).hasIntegral hab
    refine H.congr (J := RealRaw.ofRat (1/b-1/a)) (RealRaw.ofRat_valid _) ?_
    apply arithmetic_identity (sub (reciprocalValue b) (reciprocalValue a)) (Value.rational _)
    intro s; rfl
  have upper : HasIntegral (LipschitzIntegralBounds.onInterval (fun t => Value.rational ((1/t)*(1/t))) a b)
      (RealRaw.ofRat (1/a-1/b)) := by
    have H := (positiveInverseStep a b ha).hasIntegral hab
    refine H.congr (J := RealRaw.ofRat (1/a-1/b)) (RealRaw.ofRat_valid _) ?_
    apply arithmetic_identity (sub (Value.rational (-1/b)) (Value.rational (-1/a))) (Value.rational _)
    intro s; simp only [sub,Value.rational]; grind only [Rat.div_def]
  have pointwise (t : Rat) (ht : a≤t) :
      Small (Value.mul (sineIntegral t) (reciprocalDerivative t)) ((1/t)*(1/t)) := by
    have ht0 : 0<t := by grind only
    have H := (sineIntegral_small t).mul (reciprocalDerivative_small t t ht0 Rat.le_refl)
    simpa only [Rat.one_mul,Rat.div_def,Rat.one_mul] using H
  have lo := lower.mono (auxiliaryData a b ha hab).hasIntegral rfl rfl (by
    intro t ht _
    have H := (pointwise t ht.1).1
    intro i j
    have h := H i j
    change -(1/t)*(1/t)≤((Value.mul (sineIntegral t) (reciprocalDerivative t)).real.compute j).hi
    change -((1/t)*(1/t))≤((Value.mul (sineIntegral t) (reciprocalDerivative t)).real.compute j).hi at h
    grind only)
  have hi := (auxiliaryData a b ha hab).hasIntegral.mono upper rfl rfl (by
    intro t ht _; exact (pointwise t ht.1).2)
  constructor
  · intro i j
    have H := lo i j
    change 1/b-1/a≤((auxiliaryData a b ha hab).integral.compute j).hi at H
    change -(1/a-1/b)≤((auxiliaryData a b ha hab).integral.compute j).hi
    grind only
  · exact hi

/-- Dirichlet's oscillatory tail bound, from product FTC and the actual
positive reciprocal-square integral. No absolute integrability of sinc is used. -/
theorem compact_tail (a b : Rat) (ha : 0<a) (hab : a≤b) :
    Small (compactData a b ha hab).value (2/a) := by
  have hb : 0<b := by grind only
  let D := compactData a b ha hab
  let A := auxiliaryData a b ha hab
  have ip := (sineIntegralStep a b).integrationByParts (reciprocalStep a b ha) hab
    1 a⁻¹ 1 (a⁻¹*a⁻¹) (by decide +kernel) (Rat.le_of_lt (Rat.inv_pos.mpr ha)) (by decide +kernel)
    (Rat.mul_nonneg (Rat.le_of_lt (Rat.inv_pos.mpr ha)) (Rat.le_of_lt (Rat.inv_pos.mpr ha)))
    (fun t _ _ => sineIntegral_small t) (fun t ht _ => reciprocal_small a t ha ht)
    (fun t _ _ => trig_small false t) (fun t ht _ => reciprocalDerivative_small a t ha ht)
    D.hasIntegral A.hasIntegral
  let endpoint := sub (Value.mul (sineIntegral b) (reciprocalValue b))
    (Value.mul (sineIntegral a) (reciprocalValue a))
  have endpointSmall : Small endpoint (1/b+1/a) := by
    have X := (sineIntegral_small b).mul (reciprocal_small b b hb Rat.le_refl)
    have Y := (sineIntegral_small a).mul (reciprocal_small a a ha Rat.le_refl)
    have H := X.add Y.neg
    have H' : Small (Value.add (Value.mul (sineIntegral b) (reciprocalValue b))
        (Value.neg (Value.mul (sineIntegral a) (reciprocalValue a)))) (1/b+1/a) := by
      simpa only [Rat.one_mul,Rat.div_def] using H
    apply H'.congr
    apply arithmetic_identity; intro s; simp only [endpoint,Value.add,Value.neg,sub]; grind only
  have H := endpointSmall.add (auxiliary_small a b ha hab).neg
  have he : 1/b+1/a+(1/a-1/b)=2/a := by grind only [Rat.div_def]
  rw [he] at H
  apply H.congr
  have alg : (Value.add endpoint (Value.neg A.value)).real.preferred.Equiv
      (sub endpoint A.value).real.preferred := by
    apply arithmetic_identity; intro s; simp only [Value.add,Value.neg,sub]; grind only
  exact RealRaw.equiv_trans (Value.add endpoint (Value.neg A.value)).real.valid
    (sub endpoint A.value).real.valid D.value.real.valid alg (RealRaw.equiv_symm ip)

end ComputableAnalysis.DirichletIntegral
