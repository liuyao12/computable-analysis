import ComputableAnalysis.FTCRealReparametrize
import ComputableAnalysis.ArctanReciprocalFTC
import ComputableAnalysis.LipschitzQuadrature
import ComputableAnalysis.IntegralDomination

/-! Actual proper quadrature of the rational Poisson kernel, evaluated by
geometric arctangent FTC without a Feynman parameter theorem. -/
namespace ComputableAnalysis.DirichletIntegral.ContourPoisson
open ComputableCoefficient RealApproximationOrder FTCRealOrder FTCRealCalculus
open ArctanPositiveFTC LipschitzQuadrature
set_option maxHeartbeats 800000
set_option autoImplicit false

def denominator (eta t : Rat) : Rat := t*t+eta*eta
def rational (eta t : Rat) : Rat := eta/denominator eta t
def kernel (eta t : Rat) : Value := Value.rational (rational eta t)

theorem denominator_positive (eta t : Rat) (he : 0<eta) : 0<denominator eta t := by
  have T := RationalCircle.Stage.ratSquare_nonneg t
  have E := Rat.mul_pos he he
  dsimp [denominator]; grind only

theorem inverse_bounds (eta t : Rat) (he : 0<eta) :
    0≤(denominator eta t)⁻¹ ∧ (denominator eta t)⁻¹≤(eta*eta)⁻¹ := by
  have T := RationalCircle.Stage.ratSquare_nonneg t
  have H := QInterval.one_div_le_one_div_of_pos (Rat.mul_pos he he)
    (show eta*eta≤denominator eta t by dsimp [denominator]; grind only)
  exact ⟨Rat.le_of_lt (Rat.inv_pos.mpr (denominator_positive eta t he)),by
    simpa only [Rat.div_def,Rat.one_mul] using H⟩

theorem rational_bounds (eta t : Rat) (he : 0<eta) : 0≤rational eta t ∧ rational eta t≤eta⁻¹ := by
  have H := inverse_bounds eta t he
  have A := Rat.mul_le_mul_of_nonneg_left H.2 (Rat.le_of_lt he)
  have ec := Rat.mul_inv_cancel eta (Rat.ne_of_gt he)
  have dc := Rat.mul_inv_cancel (eta*eta) (Rat.ne_of_gt (Rat.mul_pos he he))
  have E : eta*(eta*eta)⁻¹=eta⁻¹ := by grind only
  rw [E] at A
  exact ⟨Rat.mul_nonneg (Rat.le_of_lt he) H.1,A⟩

def constant (eta R : Rat) : Rat := eta*(2*R)*((eta*eta)⁻¹*(eta*eta)⁻¹)

theorem variation (eta R u v : Rat) (he : 0<eta) (hu : 0≤u) (huv : u≤v) (hv : v≤R) :
    0≤rational eta u-rational eta v ∧ rational eta u-rational eta v≤constant eta R*(v-u) := by
  have hv0 : 0≤v := Rat.le_trans hu huv
  have R0 : 0≤R := Rat.le_trans hv0 hv
  have U := inverse_bounds eta u he
  have V := inverse_bounds eta v he
  have P := rat_mul_le_mul_of_nonneg U.1 U.2 V.1 V.2
  have S : 0≤u+v ∧ u+v≤2*R := by grind only
  have Q := rat_mul_le_mul_of_nonneg S.1 S.2 (Rat.mul_nonneg U.1 V.1) P
  have H := Rat.mul_le_mul_of_nonneg_left Q
    (Rat.mul_nonneg (Rat.le_of_lt he) (show 0≤v-u by grind only))
  have uc := Rat.mul_inv_cancel (denominator eta u) (Rat.ne_of_gt (denominator_positive eta u he))
  have vc := Rat.mul_inv_cancel (denominator eta v) (Rat.ne_of_gt (denominator_positive eta v he))
  have eq : rational eta u-rational eta v=eta*(v-u)*(u+v)*((denominator eta u)⁻¹*(denominator eta v)⁻¹) := by
    simp only [rational,Rat.div_def]
    dsimp [denominator] at *
    grind only
  constructor
  · rw [eq]
    exact Rat.mul_nonneg (Rat.mul_nonneg (Rat.mul_nonneg (Rat.le_of_lt he) (by grind only)) S.1) (Rat.mul_nonneg U.1 V.1)
  · rw [eq]; dsimp [constant]; grind only

def data (eta a b : Rat) (he : 0<eta) (ha : 0≤a) (hab : a≤b) : Data (kernel eta) a b where
  ordered := hab
  constant := constant eta b
  nonnegative := Rat.mul_nonneg (Rat.mul_nonneg (Rat.le_of_lt he) (by grind only))
    (Rat.mul_nonneg (Rat.le_of_lt (Rat.inv_pos.mpr (Rat.mul_pos he he))) (Rat.le_of_lt (Rat.inv_pos.mpr (Rat.mul_pos he he))))
  lipschitz := by
    intro u v hu huv hv
    have H := variation eta b u v he (Rat.le_trans ha hu) huv hv
    constructor
    · intro i j; change -(constant eta b*(v-u))≤rational eta v-rational eta u; grind only
    · intro i j; change rational eta v-rational eta u≤constant eta b*(v-u); grind only

theorem derivative_identity (eta t : Rat) (he : 0<eta) :
    Same (scale eta⁻¹ (ArctanPositiveFTC.kernel (eta⁻¹*t))) (kernel eta t) := by
  have ec := Rat.mul_inv_cancel eta (Rat.ne_of_gt he)
  have A := Rat.mul_inv_cancel (1+(eta⁻¹*t)*(eta⁻¹*t))
    (Rat.ne_of_gt (RationalCircle.Stage.one_add_square_pos (eta⁻¹*t)))
  have B := Rat.mul_inv_cancel (denominator eta t) (Rat.ne_of_gt (denominator_positive eta t he))
  apply arithmetic_identity; intro s
  simp only [scale,ArctanPositiveFTC.kernel,kernel,rational,Value.rational,ArctanGeometry.integralKernel,Rat.div_def,Rat.one_mul]
  dsimp [denominator] at B ⊢
  grind only

def lowerStep (eta : Rat) (he : 0<eta) : Step (fun t => atan (eta⁻¹*t)) (kernel eta) 0 eta := by
  have ec := Rat.inv_mul_cancel eta (Rat.ne_of_gt he)
  apply (ArctanPositiveFTC.step.reparametrize eta⁻¹ 0 eta (Rat.inv_pos.mpr he)
    (by change (0:Rat)≤eta⁻¹*0; grind only) (by grind only)).congr
  · intro t; exact Same.refl (atan (eta⁻¹*t))
  · intro t; exact derivative_identity eta t he

def upperStep (eta R : Rat) (he : 0<eta) :
    Step (fun t => Value.neg (ArctanReciprocalFTC.reciprocalAtan (eta⁻¹*t))) (kernel eta) eta R := by
  have ec := Rat.inv_mul_cancel eta (Rat.ne_of_gt he)
  apply ((ArctanReciprocalFTC.step (eta⁻¹*R)).reparametrize eta⁻¹ eta R (Rat.inv_pos.mpr he)
    (by grind only) Rat.le_refl).congr
  · intro t; exact Same.refl _
  · intro t; exact derivative_identity eta t he

def halfPi : Value := scale 2 (atan 1)

theorem halfPi_identity : Same halfPi (scale (1/2) GeometricTrig.piValue) := by
  let G := parameter (ArctanGeometry.arctanGeom 1) ArctanGeometry.arctanGeom_one_valid
  have A : Same (atan 1) G := by
    change (atan 1).real.preferred.Equiv (ArctanGeometry.arctanGeom 1)
    simp only [atan,dif_pos (show (0:Rat)≤1 ∧ (1:Rat)≤1 by decide +kernel)]
    exact arctanScheduledRectangleRaw_equiv_arctanGeom (by decide +kernel) Rat.le_refl
  have P : Same GeometricTrig.piValue (scale 4 G) := GeometricTrig.pi_geometric
  have B : Same (scale 2 G) (scale (1/2) (scale 4 G)) := by
    apply arithmetic_identity; intro s; simp only [scale]; grind only
  exact (A.scale 2).trans (B.trans (P.scale (1/2)).symm)

theorem integral_identity (eta R : Rat) (he : 0<eta) (hR : eta≤R) :
    Same (data eta 0 R he Rat.le_refl (Rat.le_trans (Rat.le_of_lt he) hR)).value (sub halfPi (atan (eta/R))) := by
  let L := data eta 0 eta he Rat.le_refl (Rat.le_of_lt he)
  let U := data eta eta R he (Rat.le_of_lt he) hR
  let V := data eta 0 R he Rat.le_refl (Rat.le_trans (Rat.le_of_lt he) hR)
  have A : Same L.value (sub (atan (eta⁻¹*eta)) (atan (eta⁻¹*0))) := L.identify ((lowerStep eta he).hasIntegral (Rat.le_of_lt he))
  have B : Same U.value (sub (Value.neg (ArctanReciprocalFTC.reciprocalAtan (eta⁻¹*R)))
      (Value.neg (ArctanReciprocalFTC.reciprocalAtan (eta⁻¹*eta)))) := U.identify ((upperStep eta R he).hasIntegral hR)
  have ec := Rat.inv_mul_cancel eta (Rat.ne_of_gt he)
  have r0 : 0<R := by grind only
  have rc := Rat.mul_inv_cancel R (Rat.ne_of_gt r0)
  have ic := Rat.mul_inv_cancel (eta⁻¹*R) (Rat.ne_of_gt (Rat.mul_pos (Rat.inv_pos.mpr he) r0))
  have inv : (eta⁻¹*R)⁻¹=eta/R := by simp only [Rat.div_def]; grind only
  have S : Same V.value (Value.add L.value U.value) := L.append U V
  have T := S.trans (A.add B)
  have Z : Same (atan (eta⁻¹*0)) (Value.rational 0) := by rw [Rat.mul_zero]; exact atan_zero
  apply (T.trans (((Same.refl _).sub Z).add (Same.refl _))).trans
  apply arithmetic_identity; intro s
  simp only [sub,Value.add,Value.neg,Value.rational,halfPi,scale,ArctanReciprocalFTC.reciprocalAtan,ec,inv,show (1:Rat)⁻¹=1 by decide +kernel]
  grind only

theorem integral_error (eta R : Rat) (he : 0<eta) (hR : eta≤R) :
    Small (sub (data eta 0 R he Rat.le_refl (Rat.le_trans (Rat.le_of_lt he) hR)).value halfPi) (eta/R) := by
  have r0 : 0<R := by grind only
  have er : 0≤eta/R := Rat.mul_nonneg (Rat.le_of_lt he) (Rat.le_of_lt (Rat.inv_pos.mpr r0))
  have er1 : eta/R≤1 := by
    have H := Rat.mul_le_mul_of_nonneg_right hR (Rat.le_of_lt (Rat.inv_pos.mpr r0))
    have rc := Rat.mul_inv_cancel R (Rat.ne_of_gt r0)
    change eta*R⁻¹≤1; grind only
  have H := (integral_identity eta R he hR).sub (Same.refl halfPi)
  have A : Same (sub (sub halfPi (atan (eta/R))) halfPi) (Value.neg (atan (eta/R))) := by
    apply arithmetic_identity; intro s; simp only [sub,Value.neg]; grind only
  exact (atan_small (eta/R) er er1).neg.congr (H.trans A).symm

theorem integral_bound (eta R : Rat) (he : 0<eta) (hR : eta≤R) :
    Small (data eta 0 R he Rat.le_refl (Rat.le_trans (Rat.le_of_lt he) hR)).value 3 := by
  have r0 : 0<R := by grind only
  have er : 0≤eta/R := Rat.mul_nonneg (Rat.le_of_lt he) (Rat.le_of_lt (Rat.inv_pos.mpr r0))
  have er1 : eta/R≤1 := by
    have H := Rat.mul_le_mul_of_nonneg_right hR (Rat.le_of_lt (Rat.inv_pos.mpr r0))
    have rc := Rat.mul_inv_cancel R (Rat.ne_of_gt r0)
    change eta*R⁻¹≤1; grind only
  have H := (scale_small (atan_small 1 (by decide +kernel) Rat.le_refl) 2).add ((atan_small (eta/R) er er1).neg)
  have A : Same (Value.add halfPi (Value.neg (atan (eta/R)))) (sub halfPi (atan (eta/R))) := by
    apply arithmetic_identity; intro s; simp only [sub,Value.add,Value.neg]; grind only
  have B := H.congr (A.trans (integral_identity eta R he hR).symm)
  exact B.mono (by change qabs 2*1+eta/R≤3; rw [show qabs (2:Rat)=2 by decide +kernel]; grind only)

end ComputableAnalysis.DirichletIntegral.ContourPoisson
