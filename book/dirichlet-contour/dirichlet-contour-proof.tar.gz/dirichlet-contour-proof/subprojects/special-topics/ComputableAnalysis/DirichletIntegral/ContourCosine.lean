import ComputableAnalysis.DirichletIntegral.ContourRegularization

/-! Concentration of the rational Poisson kernel against geometric cosine.
The estimates are for actual proper quadratures, with no assumed limit interchange. -/
namespace ComputableAnalysis.DirichletIntegral.ContourCosine
open ComputableCoefficient RealApproximationOrder FTCRealOrder FTCRealCalculus
open GeometricTrig GeometricIntegralData LipschitzQuadrature ContourPoisson ContourRegularization
set_option maxHeartbeats 1000000

def difference (eta t : Rat) : Value := sub (cosineRegularized eta t) (kernel eta t)
def differenceData (eta a b : Rat) (he : 0<eta) (ha : 0≤a) (hab : a≤b) :
    Data (difference eta) a b :=
  (cosineDataRegularized eta a b he ha hab).subtract (ContourPoisson.data eta a b he ha hab)

theorem cosine_minus_one (t : Rat) (ht : 0≤t) :
    Small (sub (valueFor true t) (Value.rational 1)) (8*t) := by
  have H := (cosineData 0 t ht).lipschitz 0 t Rat.le_refl ht Rat.le_refl
  have Z : Same (valueFor true 0) (Value.rational 1) := by
    change (valueFor true 0).real.preferred.Equiv (RealRaw.ofRat 1)
    rw [valueFor_raw]; exact sample_zero true
  have A := (Same.refl (valueFor true t)).sub Z
  change Small (sub (valueFor true t) (valueFor true 0)) (8*(t-0)) at H
  simpa only [Rat.sub_eq_add_neg,Rat.neg_zero,Rat.add_zero] using H.congr A

theorem pointwise_near (eta d t : Rat) (he : 0<eta) (ht : 0≤t) (hd : t≤d) :
    Small (difference eta t) ((8*d)*rational eta t) := by
  have K := rational_bounds eta t he
  have C := (cosine_minus_one t ht).mono
    (show 8*t≤8*d by grind only)
  have H := C.scale_nonnegative K.1
  have A : Same (scale (rational eta t) (sub (valueFor true t) (Value.rational 1))) (difference eta t) := by
    apply arithmetic_identity; intro s
    simp only [scale,sub,Value.rational,kernel,difference,cosineRegularized,Value.mul]
    grind only
  have H' := H.congr A
  simpa only [Rat.mul_comm] using H'

theorem pointwise_far (eta t : Rat) (he : 0<eta) (ht : 0<t) :
    Small (difference eta t) ((2*eta)*((1/t)*(1/t))) := by
  have K := rational_bounds eta t he
  have C := (trig_small true t).add (rational_small 1).neg
  have C' : Small (sub (valueFor true t) (Value.rational 1)) 2 := by
    have A : Same (Value.add (valueFor true t) (Value.neg (Value.rational 1)))
        (sub (valueFor true t) (Value.rational 1)) := by
      apply arithmetic_identity; intro s; simp only [Value.add,Value.neg,sub] <;> grind only
    have eq : (1:Rat)+qabs 1=2 := by decide +kernel
    rw [eq] at C
    exact C.congr A
  have H := C'.scale_nonnegative K.1
  have A : Same (scale (rational eta t) (sub (valueFor true t) (Value.rational 1))) (difference eta t) := by
    apply arithmetic_identity; intro s
    simp only [scale,sub,Value.rational,kernel,difference,cosineRegularized,Value.mul]
    grind only
  have ep := Rat.mul_nonneg (Rat.le_of_lt he) (Rat.le_of_lt he)
  have inv := QInterval.one_div_le_one_div_of_pos (Rat.mul_pos ht ht)
    (show t*t≤denominator eta t by dsimp [denominator] <;> grind only)
  have tc := Rat.mul_inv_cancel t (Rat.ne_of_gt ht)
  have sc := Rat.mul_inv_cancel (t*t) (Rat.ne_of_gt (Rat.mul_pos ht ht))
  have sq : (t*t)⁻¹=t⁻¹*t⁻¹ := by grind only
  simp only [Rat.div_def,Rat.one_mul,sq] at inv
  have B := Rat.mul_le_mul_of_nonneg_left inv (Rat.mul_nonneg (by decide +kernel : (0:Rat)≤2) (Rat.le_of_lt he))
  exact (H.congr A).mono (by simp only [rational,Rat.div_def,Rat.one_mul] <;> grind only)

theorem near_bound (eta d : Rat) (he : 0<eta) (hd : eta≤d) :
    Small (differenceData eta 0 d he Rat.le_refl (by grind only)).value (24*d) := by
  have d0 : 0≤d := by grind only
  let P := ContourPoisson.data eta 0 d he Rat.le_refl d0
  let E := P.scale (8*d)
  have S : Same E.value (scale (8*d) P.value) := P.scale_identity (8*d)
  have bound := ((integral_bound eta d he hd).scale_nonnegative
    (show 0≤8*d by grind only)).congr S.symm
  have eq : (8*d)*3=24*d := by grind only
  rw [eq] at bound
  have bound' : Small E.value (24*d) := bound
  apply (differenceData eta 0 d he Rat.le_refl d0).dominated E (24*d) bound'
  · intro t ht ht'
    have A := (pointwise_near eta d t he ht ht').1
    apply le_congr (x := Value.rational (-((8*d)*rational eta t))) (y := difference eta t) A
    · apply arithmetic_identity; intro s; simp only [scale,kernel,Value.rational,Value.neg] <;> grind only
    · exact Same.refl _
  · intro t ht ht'
    have A := (pointwise_near eta d t he ht ht').2
    apply le_congr (x := difference eta t) (y := Value.rational ((8*d)*rational eta t)) A
    · exact Same.refl _
    · apply arithmetic_identity; intro s; simp only [scale,kernel,Value.rational] <;> grind only

theorem far_bound (eta d R : Rat) (he : 0<eta) (hd : 0<d) (hdR : d≤R) :
    Small (differenceData eta d R he (Rat.le_of_lt hd) hdR).value (2*eta/d) := by
  let E := (squareData d R hd hdR).scale (2*eta)
  have bound : Small E.value (2*eta/d) := scaled_square_bound d R (2*eta) hd hdR (by grind only)
  apply (differenceData eta d R he (Rat.le_of_lt hd) hdR).dominated E (2*eta/d) bound
  · intro t ht _
    have A := (pointwise_far eta t he (by grind only)).1
    apply le_congr (x := Value.rational (-((2*eta)*((1/t)*(1/t))))) (y := difference eta t) A
    · apply arithmetic_identity; intro s; simp only [scale,Value.neg,reciprocalDerivative,Value.rational] <;> grind only
    · exact Same.refl _
  · intro t ht _
    have A := (pointwise_far eta t he (by grind only)).2
    apply le_congr (x := difference eta t) (y := Value.rational ((2*eta)*((1/t)*(1/t)))) A
    · exact Same.refl _
    · apply arithmetic_identity; intro s; simp only [scale,Value.neg,reciprocalDerivative,Value.rational] <;> grind only

theorem cosine_to_halfPi (eta d R : Rat) (he : 0<eta) (hd : eta≤d) (hdR : d≤R) :
    Small (sub (cosineDataRegularized eta 0 R he Rat.le_refl (by grind only)).value halfPi)
      (24*d+2*eta/d+eta/R) := by
  have d0 : 0<d := by grind only
  have R0 : 0≤R := by grind only
  let L := differenceData eta 0 d he Rat.le_refl (Rat.le_of_lt d0)
  let U := differenceData eta d R he (Rat.le_of_lt d0) hdR
  let V := differenceData eta 0 R he Rat.le_refl R0
  let C := cosineDataRegularized eta 0 R he Rat.le_refl R0
  let P := ContourPoisson.data eta 0 R he Rat.le_refl R0
  have S : Same V.value (Value.add L.value U.value) := L.append U V
  have D : Same V.value (sub C.value P.value) := C.subtract_identity P
  have H := ((near_bound eta d he hd).add (far_bound eta d R he d0 hdR)).congr (S.symm.trans D)
  have T := H.add (ContourPoisson.integral_error eta R he (Rat.le_trans hd hdR))
  apply T.congr
  apply arithmetic_identity; intro s; simp only [Value.add,sub] <;> grind only

end ComputableAnalysis.DirichletIntegral.ContourCosine
