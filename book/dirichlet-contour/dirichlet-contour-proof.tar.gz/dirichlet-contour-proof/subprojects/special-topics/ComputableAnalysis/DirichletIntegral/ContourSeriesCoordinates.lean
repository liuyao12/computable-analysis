import ComputableAnalysis.ModularForms.EntireExponentialValue
import ComputableAnalysis.EulerImaginarySeries
import ComputableAnalysis.EulerSeriesIdentity
import ComputableAnalysis.RealValueCongruence

/-! Finite coordinate algebra connecting the complex factorial prefixes to
actual represented real monomials. No infinite-series identity is assumed. -/
namespace ComputableAnalysis.DirichletIntegral.ContourSeriesCoordinates
open ComputableCoefficient RealApproximationOrder TaylorPolynomialValues
open ComplexRaw RiemannHilbert FunctionTheory ModularForms
set_option maxHeartbeats 800000
set_option autoImplicit false

def pair (C S : Value) : ComplexRaw := EulerImaginary.pair C.real.preferred S.real.preferred

theorem pair_valid (C S : Value) : (pair C S).Valid := EulerImaginary.pair_valid C.real.valid S.real.valid

theorem pair_congr {C S D T : Value} (hC : Same C D) (hS : Same S T) :
    (pair C S).Equiv (pair D T) := EulerImaginary.pair_equiv hC hS

theorem pair_product (C S D T : Value) :
    mul (pair C S) (pair D T)=pair (RealApproximationOrder.sub (Value.mul C D) (Value.mul S T))
      (Value.add (Value.mul C T) (Value.mul S D)) := by rfl

theorem of_compute {z w : ComplexRaw} (hz : z.Valid) (hw : w.Valid)
    (eq : ∀ n,z.compute n=w.compute n) : z.Equiv w := by
  intro n
  apply (compareAt_overlap_iff z w n n).mpr
  rw [eq n]
  exact (compareAt_overlap_iff w w n n).mp (equiv_refl w hw n)

theorem pair_scale (q : Rat) (C S : Value) :
    (scaleRat q (pair C S)).Equiv (pair (RealApproximationOrder.scale q C) (RealApproximationOrder.scale q S)) := by
  apply of_compute (scaleRat_valid (pair_valid C S)) (pair_valid _ _)
  intro n
  simp only [scaleRat,pair,EulerImaginary.pair,RealApproximationOrder.scale,
    RealRaw.scaleRat,RealRaw.scaleRatCompute]
  change QBox.scaleRat q {lo := ⟨(C.real.compute n).lo,(S.real.compute n).lo⟩, hi := ⟨(C.real.compute n).hi,(S.real.compute n).hi⟩} = {lo := ⟨(RealRaw.scaleRatCompute q C.real.preferred n).lo,(RealRaw.scaleRatCompute q S.real.preferred n).lo⟩, hi := ⟨(RealRaw.scaleRatCompute q C.real.preferred n).hi,(RealRaw.scaleRatCompute q S.real.preferred n).hi⟩}
  simp only [QBox.scaleRat,RealRaw.scaleRatCompute]
  split <;> rfl

def imaginary (A : Value) : ComplexRaw := pair (Value.rational 0) A

def powerCoordinate (c : Bool) (A : Value) (n : Nat) : Value :=
  RealApproximationOrder.scale (phase n c) (TaylorPolynomialValues.power A n)

theorem imaginary_power (A : Value) (n : Nat) :
    (LocalODE.power (imaginary A) n).Equiv
      (pair (powerCoordinate true A n) (powerCoordinate false A n)) := by
  induction n with
  | zero =>
    have P : (LocalODE.power (imaginary A) 0).Equiv (pair (Value.rational 1) (Value.rational 0)) :=
      equiv_refl _ (ofQComplex_valid _)
    apply equiv_trans (LocalODE.power_valid _ (pair_valid _ _) 0) (pair_valid _ _) (pair_valid _ _) P
    apply pair_congr <;> apply arithmetic_identity <;> intro s <;>
      simp only [powerCoordinate,phase,TaylorPolynomialValues.power,RealApproximationOrder.scale,Value.rational] <;> grind only
  | succ n ih =>
    have M := mul_equiv (LocalODE.power_valid _ (pair_valid _ _) n) (pair_valid _ _)
      (pair_valid (Value.rational 0) A) (pair_valid (Value.rational 0) A)
      ih (equiv_refl _ (pair_valid _ _))
    change (mul (LocalODE.power (imaginary A) n) (imaginary A)).Equiv _
    apply equiv_trans (mul_valid (LocalODE.power_valid _ (pair_valid _ _) n) (pair_valid _ _))
      (mul_valid (pair_valid _ _) (pair_valid _ _)) (pair_valid _ _) M
    rw [pair_product]
    apply pair_congr <;> apply arithmetic_identity <;> intro s <;>
      simp only [powerCoordinate,phase_succ,TaylorPolynomialValues.power,RealApproximationOrder.scale,
        Value.mul,Value.add,RealApproximationOrder.sub,Value.rational] <;> grind only

theorem pair_sum (C S D T : Value) :
    add (pair C S) (pair D T)=pair (Value.add C D) (Value.add S T) := by rfl

theorem imaginary_term (X : Value) (n : Nat) :
    (LocalODE.seriesTerm exponentialCoefficients (imaginary (angular X)) n).Equiv
      (pair (EulerImaginarySeries.exponentialTerm true X n) (EulerImaginarySeries.exponentialTerm false X n)) := by
  have M := mul_equiv (exponentialCoefficients_valid n)
    (pair_valid (Value.rational (1/factorialRat n)) (Value.rational 0))
    (LocalODE.power_valid _ (pair_valid _ _) n) (pair_valid _ _)
    (equiv_refl _ (exponentialCoefficients_valid n)) (imaginary_power (angular X) n)
  change (mul (exponentialCoefficients n) (LocalODE.power (imaginary (angular X)) n)).Equiv _
  apply equiv_trans (mul_valid (exponentialCoefficients_valid n) (LocalODE.power_valid _ (pair_valid _ _) n))
    (mul_valid (pair_valid _ _) (pair_valid _ _)) (pair_valid _ _) M
  rw [pair_product]
  apply pair_congr <;> apply arithmetic_identity <;> intro s <;>
    simp only [EulerImaginarySeries.exponentialTerm,EulerImaginarySeries.unit_power_coordinates,
      powerCoordinate,Value.mul,Value.add,Value.rational,RealApproximationOrder.sub,
      RealApproximationOrder.scale,Bool.false_eq_true,↓reduceIte] <;> grind only [Rat.div_def]

theorem imaginary_prefix (X : Value) (N : Nat) :
    (BoundedSeries.valueBlock exponentialCoefficients (imaginary (angular X)) 0 N).Equiv
      (pair (RepresentedSeries.finiteSum (EulerImaginarySeries.exponentialTerm true X) N)
        (RepresentedSeries.finiteSum (EulerImaginarySeries.exponentialTerm false X) N)) := by
  induction N with
  | zero => exact equiv_refl _ (ofQComplex_valid _)
  | succ N ih =>
    simp only [BoundedSeries.valueBlock,RepresentedSeries.finiteSum,Nat.zero_add]
    have H := add_equiv ih (imaginary_term X N)
    rw [pair_sum] at H
    exact H

def real (A : Value) : ComplexRaw := pair A (Value.rational 0)

theorem power_agreement (A : Value) (n : Nat) : TaylorPolynomialValues.power A n=EulerPowerLimit.power A n := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [TaylorPolynomialValues.power,EulerPowerLimit.power,ih]

theorem real_power (A : Value) (n : Nat) :
    (LocalODE.power (real A) n).Equiv (pair (TaylorPolynomialValues.power A n) (Value.rational 0)) := by
  induction n with
  | zero => exact equiv_refl _ (ofQComplex_valid _)
  | succ n ih =>
    have M := mul_equiv (LocalODE.power_valid _ (pair_valid _ _) n) (pair_valid _ _)
      (pair_valid A (Value.rational 0)) (pair_valid A (Value.rational 0)) ih (equiv_refl _ (pair_valid _ _))
    change (mul (LocalODE.power (real A) n) (real A)).Equiv _
    apply equiv_trans (mul_valid (LocalODE.power_valid _ (pair_valid _ _) n) (pair_valid _ _))
      (mul_valid (pair_valid _ _) (pair_valid _ _)) (pair_valid _ _) M
    rw [pair_product]
    apply pair_congr <;> apply arithmetic_identity <;> intro s <;>
      simp only [TaylorPolynomialValues.power,RealApproximationOrder.scale,Value.mul,Value.add,
        RealApproximationOrder.sub,Value.rational] <;> grind only

theorem real_term (X : Value) (n : Nat) :
    (LocalODE.seriesTerm exponentialCoefficients (real X) n).Equiv
      (pair (EulerSeriesIdentity.terms X n) (Value.rational 0)) := by
  have M := mul_equiv (exponentialCoefficients_valid n)
    (pair_valid (Value.rational (1/factorialRat n)) (Value.rational 0))
    (LocalODE.power_valid _ (pair_valid _ _) n) (pair_valid _ _)
    (equiv_refl _ (exponentialCoefficients_valid n)) (real_power X n)
  change (mul (exponentialCoefficients n) (LocalODE.power (real X) n)).Equiv _
  apply equiv_trans (mul_valid (exponentialCoefficients_valid n) (LocalODE.power_valid _ (pair_valid _ _) n))
    (mul_valid (pair_valid _ _) (pair_valid _ _)) (pair_valid _ _) M
  rw [pair_product,power_agreement]
  apply pair_congr <;> apply arithmetic_identity <;> intro s <;>
    simp only [EulerSeriesIdentity.terms,Value.mul,Value.add,Value.rational,RealApproximationOrder.sub,
      RealApproximationOrder.scale] <;> grind only [Rat.div_def]

theorem real_prefix (X : Value) (N : Nat) :
    (BoundedSeries.valueBlock exponentialCoefficients (real X) 0 N).Equiv
      (pair (RepresentedSeries.finiteSum (EulerSeriesIdentity.terms X) N) (Value.rational 0)) := by
  induction N with
  | zero => exact equiv_refl _ (ofQComplex_valid _)
  | succ N ih =>
    simp only [BoundedSeries.valueBlock,RepresentedSeries.finiteSum,Nat.zero_add]
    have H := add_equiv ih (real_term X N)
    rw [pair_sum] at H
    apply equiv_trans (add_valid (BoundedSeries.valueBlock_valid _ _ exponentialCoefficients_valid (pair_valid _ _) 0 N)
      (LocalODE.seriesTerm_valid _ _ exponentialCoefficients_valid (pair_valid _ _) N)) (pair_valid _ _) (pair_valid _ _) H
    apply pair_congr
    · exact Same.refl _
    · apply arithmetic_identity; intro s; simp only [Value.add,Value.rational]; grind only

end ComputableAnalysis.DirichletIntegral.ContourSeriesCoordinates
