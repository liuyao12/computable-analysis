import ComputableAnalysis.DirichletIntegral.ContourGridAlgebra

/-! Literal grid tags in the regularized first-quadrant rectangle. -/
namespace ComputableAnalysis.DirichletIntegral.ContourGridGeometry
open ComputableCoefficient RealApproximationOrder LipschitzQuadrature
open ComplexRaw RiemannHilbert FunctionTheory RectangularContour
open ContourNumerator ContourPullbacks ContourBounds ContourGridAlgebra
set_option maxHeartbeats 800000
set_option autoImplicit false

def sample (eta R H : Rat) (he : 0<eta) : QComplex → Scalar :=
  holomorphicRectangleSample (ContourFunction.function eta) (ContourFunction.holomorphic eta)
    (ContourFunction.rectangle R H) (ContourFunction.rectangle_domain eta R H he)

theorem tag_bounds (R : Rat) (hR : 0≤R) (M : Nat) (hM : 0<M) (j : Nat) (hj : j<M) :
    0≤midpointTag 0 R M j ∧ midpointTag 0 R M j≤R := by
  have h0 := mesh_nonneg_of_le hM hR
  have jm : (j:Rat)+1≤(M:Rat) := by exact_mod_cast (show j+1≤M by omega)
  have j0 := Rat.natCast_nonneg (a := j)
  have mc := Rat.mul_inv_cancel (M:Rat) (Rat.ne_of_gt (Rat.natCast_pos.mpr hM))
  have total : (M:Rat)*mesh 0 R M=R := by
    simp only [mesh,if_neg (Nat.ne_of_gt hM),Rat.div_def]
    grind only
  have P := Rat.mul_le_mul_of_nonneg_right (show (j:Rat)+1/2≤(M:Rat) by grind only) h0
  have N := Rat.mul_nonneg (show 0≤(j:Rat)+1/2 by grind only) h0
  simp only [midpointTag,Rat.zero_add]
  constructor <;> grind only

theorem step_x (R H : Rat) (M : Nat) (hM : 0<M) :
    rectangleGridStepX (ContourFunction.rectangle R H) M=mesh 0 R M := by
  simp only [rectangleGridStepX,ContourFunction.rectangle,QInterval.width,mesh,if_neg (Nat.ne_of_gt hM)]

theorem step_y (R H : Rat) (M : Nat) (hM : 0<M) :
    rectangleGridStepY (ContourFunction.rectangle R H) M=mesh 0 H M := by
  simp only [rectangleGridStepY,ContourFunction.rectangle,QInterval.width,mesh,if_neg (Nat.ne_of_gt hM)]

theorem point_bottom (R H : Rat) (M : Nat) (hM : 0<M) (j : Nat) :
    rectangleGridHorizontalPoint (ContourFunction.rectangle R H) M j 0=⟨midpointTag 0 R M j,0⟩ := by
  simp only [rectangleGridHorizontalPoint,ContourFunction.rectangle,midpointTag,rectangleGridStepX,QInterval.width,mesh,
    if_neg (Nat.ne_of_gt hM),show ((0:Nat):Rat)=0 by decide +kernel,Rat.zero_mul,Rat.zero_add]

theorem point_left (R H : Rat) (M : Nat) (hM : 0<M) (j : Nat) :
    rectangleGridVerticalPoint (ContourFunction.rectangle R H) M 0 j=⟨0,midpointTag 0 H M j⟩ := by
  simp only [rectangleGridVerticalPoint,ContourFunction.rectangle,midpointTag,rectangleGridStepY,QInterval.width,mesh,
    if_neg (Nat.ne_of_gt hM),show ((0:Nat):Rat)=0 by decide +kernel,Rat.zero_mul,Rat.zero_add]

theorem point_top (R H : Rat) (M : Nat) (hM : 0<M) (j : Nat) :
    rectangleGridHorizontalPoint (ContourFunction.rectangle R H) M j M=⟨midpointTag 0 R M j,H⟩ := by
  have mc := Rat.mul_inv_cancel (M:Rat) (Rat.ne_of_gt (Rat.natCast_pos.mpr hM))
  simp only [rectangleGridHorizontalPoint,ContourFunction.rectangle,midpointTag,rectangleGridStepX,rectangleGridStepY,
    QInterval.width,mesh,if_neg (Nat.ne_of_gt hM),Rat.zero_add]
  congr 1 <;> simp only [Rat.div_def] <;> grind only

theorem point_right (R H : Rat) (M : Nat) (hM : 0<M) (j : Nat) :
    rectangleGridVerticalPoint (ContourFunction.rectangle R H) M M j=⟨R,midpointTag 0 H M j⟩ := by
  have mc := Rat.mul_inv_cancel (M:Rat) (Rat.ne_of_gt (Rat.natCast_pos.mpr hM))
  simp only [rectangleGridVerticalPoint,ContourFunction.rectangle,midpointTag,rectangleGridStepX,rectangleGridStepY,
    QInterval.width,mesh,if_neg (Nat.ne_of_gt hM),Rat.zero_add]
  congr 1 <;> simp only [Rat.div_def] <;> grind only

theorem sample_bottom (eta R H x : Rat) (he : 0<eta) (hH : 0≤H) (hx : 0≤x) (hxR : x≤R) :
    Same (imaginaryValue (sample eta R H he ⟨x,0⟩))
      (RealApproximationOrder.sub (ContourRegularization.sineRegularized eta x) (ContourRegularization.cosineRegularized eta x)) := by
  have hq : rationalRectangleContains (ContourFunction.rectangle R H) ⟨x,0⟩ := ⟨hx,hxR,Rat.le_refl,hH⟩
  have hz := ContourFunction.rectangle_domain eta R H he _ (rationalRectangle_represented_mem _ _ hq)
  have B := imagPart_equiv (holomorphicRectangleSample_agreement (ContourFunction.function eta) (ContourFunction.holomorphic eta)
    (ContourFunction.rectangle R H) (ContourFunction.rectangle_domain eta R H he) ⟨x,0⟩ hq hz)
  exact RealRaw.equiv_trans (imaginaryValue (sample eta R H he ⟨x,0⟩)).real.valid
    (imagPart_valid ((ContourFunction.function eta).eval _ hz).property)
    (RealApproximationOrder.sub (ContourRegularization.sineRegularized eta x) (ContourRegularization.cosineRegularized eta x)).real.valid
    (RealRaw.equiv_symm B) (bottom_point eta x he hz)

theorem sample_left (eta R H y : Rat) (he : 0<eta) (hR : 0≤R) (hy : 0≤y) (hyH : y≤H) :
    Same (realValue (sample eta R H he ⟨0,y⟩)) (Value.rational 0) := by
  have hq : rationalRectangleContains (ContourFunction.rectangle R H) ⟨0,y⟩ := ⟨Rat.le_refl,hR,hy,hyH⟩
  have hz := ContourFunction.rectangle_domain eta R H he _ (rationalRectangle_represented_mem _ _ hq)
  have B := realPart_equiv (holomorphicRectangleSample_agreement (ContourFunction.function eta) (ContourFunction.holomorphic eta)
    (ContourFunction.rectangle R H) (ContourFunction.rectangle_domain eta R H he) ⟨0,y⟩ hq hz)
  exact RealRaw.equiv_trans (realValue (sample eta R H he ⟨0,y⟩)).real.valid
    (realPart_valid ((ContourFunction.function eta).eval _ hz).property) (RealRaw.ofRat_valid 0)
    (RealRaw.equiv_symm B) (left_point eta y he hy hz)

end ComputableAnalysis.DirichletIntegral.ContourGridGeometry
