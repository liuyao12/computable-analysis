import ComputableAnalysis.DirichletIntegral.ContourPoisson
import ComputableAnalysis.DirichletIntegral.Improper

/-! Proper regularizations of the geometric sine kernel, with independently
constructed quadratures. All cutoffs and regularization parameters are rational. -/
namespace ComputableAnalysis.DirichletIntegral.ContourRegularization
open ComputableCoefficient RealApproximationOrder FTCRealOrder FTCRealCalculus
open GeometricTrig GeometricIntegralData LipschitzQuadrature ContourPoisson
set_option maxHeartbeats 1000000

def transport {f g : Rat → Value} {a b : Rat} (D : Data f a b)
    (eq : ∀ t,Same (f t) (g t)) : Data g a b where
  ordered := D.ordered
  constant := D.constant
  nonnegative := D.nonnegative
  lipschitz u v hu huv hv := (D.lipschitz u v hu huv hv).congr ((eq v).sub (eq u))

def linearData (a b : Rat) (hab : a≤b) : Data Value.rational a b where
  ordered := hab
  constant := 1
  nonnegative := by decide +kernel
  lipschitz u v _ huv _ := by
    constructor
    · intro i j; change -(1*(v-u))≤v-u; grind only
    · intro i j; change v-u≤1*(v-u); grind only

def cosineData (a b : Rat) (hab : a≤b) : Data (valueFor true) a b where
  ordered := hab
  constant := 8
  nonnegative := by decide +kernel
  lipschitz := lipschitz_of_firstOrder (trigStep true a b).firstOrder
    (trigStep true a b).error_nonnegative (trigStep true a b).radius.property
    (fun t _ _ => derivative_small true t)

def sineRegularized (eta t : Rat) : Value :=
  scale (t/(denominator eta t)) (valueFor false t)

def cosineRegularized (eta t : Rat) : Value :=
  Value.mul (valueFor true t) (kernel eta t)

def sineData (eta a b : Rat) (he : 0<eta) (ha : 0≤a) (hab : a≤b) : Data (sineRegularized eta) a b := by
  have b0 : 0≤b := Rat.le_trans ha hab
  let P := (linearData a b hab).mul (ContourPoisson.data eta a b he ha hab)
    b eta⁻¹ b0 (Rat.le_of_lt (Rat.inv_pos.mpr he))
    (by intro t ht ht'; constructor
        · intro i j; change -b≤t; grind only
        · intro i j; change t≤b; exact ht')
    (by intro t _ _; exact ⟨by intro i j; change -eta⁻¹≤rational eta t; have := rational_bounds eta t he; have := Rat.le_of_lt (Rat.inv_pos.mpr he); grind only,
      by intro i j; exact (rational_bounds eta t he).2⟩)
  let W := P.scale eta⁻¹
  have WB : ∀ t,a≤t → t≤b → Small (scale eta⁻¹ (Value.mul (Value.rational t) (kernel eta t))) (eta⁻¹*b*eta⁻¹) := by
    intro t ht ht'
    have T : Small (Value.rational t) b := by
      constructor
      · intro i j; change -b≤t; grind only
      · intro i j; change t≤b; exact ht'
    have K : Small (kernel eta t) eta⁻¹ := ⟨by intro i j; change -eta⁻¹≤rational eta t; have := rational_bounds eta t he; have := Rat.le_of_lt (Rat.inv_pos.mpr he); grind only,
      by intro i j; exact (rational_bounds eta t he).2⟩
    simpa only [Rat.mul_assoc] using (T.mul K).scale_nonnegative (Rat.le_of_lt (Rat.inv_pos.mpr he))
  let D := (DirichletIntegral.sineData a b hab).mul W 1 (eta⁻¹*b*eta⁻¹) (by decide +kernel)
    (Rat.mul_nonneg (Rat.mul_nonneg (Rat.le_of_lt (Rat.inv_pos.mpr he)) b0) (Rat.le_of_lt (Rat.inv_pos.mpr he)))
    (fun t _ _ => trig_small false t) WB
  apply transport D
  intro t
  have ec := Rat.mul_inv_cancel eta (Rat.ne_of_gt he)
  apply arithmetic_identity; intro s
  simp only [sineRegularized,scale,Value.mul,Value.rational,kernel,rational,Rat.div_def]
  grind only

def cosineDataRegularized (eta a b : Rat) (he : 0<eta) (ha : 0≤a) (hab : a≤b) : Data (cosineRegularized eta) a b :=
  (cosineData a b hab).mul (ContourPoisson.data eta a b he ha hab) 1 eta⁻¹ (by decide +kernel)
    (Rat.le_of_lt (Rat.inv_pos.mpr he)) (fun t _ _ => trig_small true t)
    (by intro t _ _; exact ⟨by intro i j; change -eta⁻¹≤rational eta t; have := rational_bounds eta t he; have := Rat.le_of_lt (Rat.inv_pos.mpr he); grind only,
      by intro i j; exact (rational_bounds eta t he).2⟩)

theorem sineRegularized_small (eta t : Rat) (he : 0<eta) (ht : 0≤t) :
    Small (sineRegularized eta t) 8 := by
  have dp := denominator_positive eta t he
  have di := Rat.le_of_lt (Rat.inv_pos.mpr dp)
  have ep := Rat.mul_nonneg (Rat.le_of_lt he) (Rat.le_of_lt he)
  have dc := Rat.mul_inv_cancel (denominator eta t) (Rat.ne_of_gt dp)
  have H := (sine_linear_bound t ht).scale_nonnegative (Rat.mul_nonneg ht di)
  have E := Rat.mul_nonneg ep di
  have bound : (t/(denominator eta t))*(8*t)≤8 := by
    dsimp [denominator] at dc E ⊢
    simp only [Rat.div_def]
    grind only
  exact H.mono bound

theorem sine_difference_pointwise (eta t : Rat) (he : 0<eta) (ht : 0<t) :
    Small (sub (sincValue t) (sineRegularized eta t)) (8*eta*eta*((1/t)*(1/t))) := by
  have ep := Rat.mul_nonneg (Rat.le_of_lt he) (Rat.le_of_lt he)
  have dp := denominator_positive eta t he
  have di := Rat.le_of_lt (Rat.inv_pos.mpr dp)
  have dc := Rat.mul_inv_cancel (denominator eta t) (Rat.ne_of_gt dp)
  have tc := Rat.mul_inv_cancel t (Rat.ne_of_gt ht)
  have H := (sinc_small t ht).scale_nonnegative (Rat.mul_nonneg ep di)
  have A : Same (scale ((eta*eta)/(denominator eta t)) (sincValue t))
      (sub (sincValue t) (sineRegularized eta t)) := by
    apply arithmetic_identity; intro s
    simp only [scale,sincValue,sineRegularized,sub,Value.mul,reciprocalValue,Value.rational,Rat.div_def]
    dsimp [denominator] at dc ⊢
    grind only
  have inv := QInterval.one_div_le_one_div_of_pos (Rat.mul_pos ht ht)
    (show t*t≤denominator eta t by dsimp [denominator]; grind only)
  have sc := Rat.mul_inv_cancel (t*t) (Rat.ne_of_gt (Rat.mul_pos ht ht))
  have sq : (t*t)⁻¹=t⁻¹*t⁻¹ := by grind only
  simp only [Rat.div_def,Rat.one_mul,sq] at inv
  have B := Rat.mul_le_mul_of_nonneg_left inv
    (Rat.mul_nonneg (by decide +kernel : (0:Rat)≤8) ep)
  exact (H.congr A).mono (by simp only [Rat.div_def,Rat.one_mul]; grind only)

def squareData (a b : Rat) (ha : 0<a) (hab : a≤b) :
    Data (fun t => Value.neg (reciprocalDerivative t)) a b :=
  (inverseDerivativeData a b ha hab).neg

theorem square_integral (a b : Rat) (ha : 0<a) (hab : a≤b) :
    Same (squareData a b ha hab).value (Value.rational (1/a-1/b)) := by
  have S : Step (fun t => Value.rational (-1/t)) (fun t => Value.neg (reciprocalDerivative t)) a b := by
    apply ((reciprocalStep a b ha).scale (-1)).congr
    · intro t; apply arithmetic_identity; intro s; simp only [scale,reciprocalValue,Value.rational]; grind only [Rat.div_def]
    · intro t; apply arithmetic_identity; intro s; simp only [scale,Value.neg]; grind only
  have H : Same (squareData a b ha hab).value (sub (Value.rational (-1/b)) (Value.rational (-1/a))) :=
    (squareData a b ha hab).identify (S.hasIntegral hab)
  apply H.trans
  apply arithmetic_identity; intro s; simp only [sub,Value.rational]; grind only [Rat.div_def]

theorem sine_difference_integral (eta a b : Rat) (he : 0<eta) (ha : 0<a) (hab : a≤b) :
    Small (sub (compactData a b ha hab).value
      (sineData eta a b he (Rat.le_of_lt ha) hab).value) (8*eta*eta/a) := by
  let D := (compactData a b ha hab).subtract (sineData eta a b he (Rat.le_of_lt ha) hab)
  let E := (squareData a b ha hab).scale (8*eta*eta)
  have pos : 0≤8*eta*eta := Rat.mul_nonneg
    (Rat.mul_nonneg (by decide +kernel) (Rat.le_of_lt he)) (Rat.le_of_lt he)
  have b0 : 0<b := by grind only
  have ib := QInterval.one_div_le_one_div_of_pos ha hab
  have nb := Rat.le_of_lt (Rat.inv_pos.mpr b0)
  have S : Same E.value (scale (8*eta*eta) (squareData a b ha hab).value) :=
    (squareData a b ha hab).scale_identity (8*eta*eta)
  have V : Same E.value (scale (8*eta*eta) (Value.rational (1/a-1/b))) :=
    S.trans ((square_integral a b ha hab).scale (8*eta*eta))
  have V' : Same E.value (Value.rational ((8*eta*eta)*(1/a-1/b))) := by
    apply V.trans
    apply arithmetic_identity; intro s; rfl
  have smallE : Small E.value (8*eta*eta/a) := by
    have P : 0≤(8*eta*eta)*(1/a-1/b) := Rat.mul_nonneg pos (by grind only)
    have H := rational_small ((8*eta*eta)*(1/a-1/b))
    rw [qabs_eq_self_of_nonneg P] at H
    apply (H.congr V'.symm).mono
    have X := Rat.mul_nonneg pos nb
    simp only [Rat.div_def,Rat.one_mul] at ib ⊢
    grind only
  have H : Small D.value (8*eta*eta/a) := D.dominated E (8*eta*eta/a) smallE
    (by intro t ht _
        have A := (sine_difference_pointwise eta t he (by grind only)).1
        apply le_congr (x := Value.rational (-(8*eta*eta*((1/t)*(1/t)))))
          (y := sub (sincValue t) (sineRegularized eta t)) A
        · apply arithmetic_identity; intro s
          simp only [scale,Value.neg,reciprocalDerivative,Value.rational]; grind only
        · exact Same.refl _)
    (by intro t ht _
        have A := (sine_difference_pointwise eta t he (by grind only)).2
        apply le_congr (x := sub (sincValue t) (sineRegularized eta t))
          (y := Value.rational (8*eta*eta*((1/t)*(1/t)))) A
        · exact Same.refl _
        · apply arithmetic_identity; intro s
          simp only [scale,Value.neg,reciprocalDerivative,Value.rational]; grind only)
  exact H.congr ((compactData a b ha hab).subtract_identity (sineData eta a b he (Rat.le_of_lt ha) hab))

/-- Removal of the sine regularization is compared with the already
constructed improper integral, rather than with its proposed value. -/
theorem sine_to_improper (eta R : Rat) (he : 0<eta) (hR : eta≤R) :
    Small (sub (sineData eta 0 R he Rat.le_refl (Rat.le_trans (Rat.le_of_lt he) hR)).value
      construction.value) (24*eta+2/R) := by
  let L := sineData eta 0 eta he Rat.le_refl (Rat.le_of_lt he)
  let U := sineData eta eta R he (Rat.le_of_lt he) hR
  let V := sineData eta 0 R he Rat.le_refl (Rat.le_trans (Rat.le_of_lt he) hR)
  let K := compactData eta R he hR
  have left : Small L.value (8*eta) := by
    have H := L.small 8 (fun t ht _ => sineRegularized_small eta t he ht)
    simpa only [Rat.sub_eq_add_neg,Rat.neg_zero,Rat.add_zero,Rat.mul_comm] using H
  have middle := (sine_difference_integral eta eta R he he hR).neg
  have ec := Rat.mul_inv_cancel eta (Rat.ne_of_gt he)
  have eh : 8*eta*eta/eta=8*eta := by simp only [Rat.div_def]; grind only
  rw [eh] at middle
  have tail := (integral_truncation_error eta R he hR).neg
  have H := (left.add middle).add tail
  have B : Same V.value (Value.add L.value U.value) := L.append U V
  have A : Same (Value.add (Value.add L.value (Value.neg (sub K.value U.value)))
      (Value.neg (sub construction.value K.value)))
      (sub (Value.add L.value U.value) construction.value) := by
    apply arithmetic_identity; intro s; simp only [Value.add,Value.neg,sub]; grind only
  have T := H.congr (A.trans (B.sub (Same.refl construction.value)).symm)
  exact T.mono (by grind only)

theorem scaled_square_bound (a b c : Rat) (ha : 0<a) (hab : a≤b) (hc : 0≤c) :
    Small ((squareData a b ha hab).scale c).value (c/a) := by
  let E := (squareData a b ha hab).scale c
  have S : Same E.value (scale c (squareData a b ha hab).value) := (squareData a b ha hab).scale_identity c
  have V : Same E.value (Value.rational (c*(1/a-1/b))) := by
    apply (S.trans ((square_integral a b ha hab).scale c)).trans
    apply arithmetic_identity; intro s; rfl
  have b0 : 0<b := by grind only
  have ib := QInterval.one_div_le_one_div_of_pos ha hab
  have nb := Rat.le_of_lt (Rat.inv_pos.mpr b0)
  have P : 0≤c*(1/a-1/b) := Rat.mul_nonneg hc (by grind only)
  have H := rational_small (c*(1/a-1/b))
  rw [qabs_eq_self_of_nonneg P] at H
  apply (H.congr V.symm).mono
  have X := Rat.mul_nonneg hc nb
  simp only [Rat.div_def,Rat.one_mul] at ib ⊢
  grind only

end ComputableAnalysis.DirichletIntegral.ContourRegularization
