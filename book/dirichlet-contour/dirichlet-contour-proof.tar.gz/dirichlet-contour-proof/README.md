# Independent rectangular-contour proof

The source files here are the transitive import closure of
`ComputableAnalysis.DirichletIntegral.ContourEvaluation.integral_eq_pi_half`.
They preserve the independent foundation and companion source boundary.

With the pinned Lean toolchain installed:

```sh
python3 scripts/foundation_layout.py
cd subprojects/special-topics
lake build ComputableAnalysis.DirichletIntegral.ContourEvaluation
lake env lean ../../scripts/check_dirichlet_contour.lean
```

The final theorem uses the independently constructed improper integral.
Its proof-dependency audit excludes the parameter/Feynman evaluation,
exponential damping calculation, and ambient Mathlib real/complex types.
