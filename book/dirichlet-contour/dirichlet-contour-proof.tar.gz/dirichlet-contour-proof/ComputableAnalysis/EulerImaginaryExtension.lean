import ComputableAnalysis.EulerImaginary
import ComputableAnalysis.Numbers

/-! The Euler rotation computation on arbitrary represented real inputs.
The public coordinate is the normalized angle: the physical argument is i*pi*x. -/
namespace ComputableAnalysis.EulerImaginary
open RawLimit
set_option maxHeartbeats 2000000

theorem coordinate_lipschitz (c : Bool) :
    LipschitzRealExtension.Lipschitz (coordinateSample c) 32 := by
  intro u v
  have H := GeometricTrig.sample_lipschitz c u v
  have he := RealRaw.sub_equiv (GeometricTrig.sample_valid c v) (coordinateSample_valid c v)
    (GeometricTrig.sample_valid c u) (coordinateSample_valid c u)
    (RealRaw.equiv_symm (coordinateSample_agrees c v)) (RealRaw.equiv_symm (coordinateSample_agrees c u))
  have hG := RealRaw.sub_valid (GeometricTrig.sample_valid c v) (GeometricTrig.sample_valid c u)
  have hE := RealRaw.sub_valid (coordinateSample_valid c v) (coordinateSample_valid c u)
  exact ⟨RealRaw.le_trans hG H.1 (RealRaw.le_of_equiv hG hE he),
    RealRaw.le_trans hG (RealRaw.le_of_equiv hE hG (RealRaw.equiv_symm he)) H.2⟩

def coordinateAt (c : Bool) (x : RealRaw) : RealRaw :=
  LipschitzRealExtension.extend (coordinateSample c) 32 x

theorem coordinateAt_valid (c : Bool) {x : RealRaw} (hx : x.Valid) : (coordinateAt c x).Valid :=
  LipschitzRealExtension.valid (coordinateSample_valid c) (by decide +kernel) (coordinate_lipschitz c)
    (fun n => 4/((n+1:Nat):Rat)) (shrinksToZero_of_ratOverSuccBound (fun _ => Rat.le_refl))
    (coordinateSample_width c) hx

theorem coordinateAt_continuous (c : Bool) {x : RealRaw} (hx : x.Valid) :
    BracketContinuity.HasContinuousAt (fun _ => True) (coordinateSample c) x (coordinateAt c x) :=
  LipschitzRealExtension.continuous (coordinateSample_valid c) (by decide +kernel) (coordinate_lipschitz c)
    (fun n => 4/((n+1:Nat):Rat)) (shrinksToZero_of_ratOverSuccBound (fun _ => Rat.le_refl))
    (coordinateSample_width c) hx

theorem coordinateAt_rational (c : Bool) (q : Rat) :
    (coordinateAt c (RealRaw.ofRat q)).Equiv (coordinateSample c q) :=
  LipschitzRealExtension.rational_agreement (coordinateSample_valid c) (by decide +kernel) (coordinate_lipschitz c) q

theorem coordinateAt_congr (c : Bool) {x y : RealRaw} (hx : x.Valid) (hy : y.Valid) (he : x.Equiv y) :
    (coordinateAt c x).Equiv (coordinateAt c y) :=
  LipschitzRealExtension.congr (coordinateSample_valid c) (by decide +kernel) (coordinate_lipschitz c) hx hy he

theorem coordinateAt_agrees (c : Bool) {x : RealRaw} (hx : x.Valid) :
    (coordinateAt c x).Equiv
      (LipschitzRealExtension.extend (GeometricTrig.sample c) 32 x) := by
  have Hgeo := LipschitzRealExtension.continuous (GeometricTrig.sample_valid c) (by decide +kernel)
    (GeometricTrig.sample_lipschitz c) (fun n => 4*ArctanInverseConstruction.width n)
    (GeometricTrig.scaled_width_shrinks (by decide +kernel)) (GeometricTrig.sample_width c) hx
  have H := BracketContinuity.congr_function Hgeo (fun q _ => coordinateSample_valid c q)
    (fun q _ => RealRaw.equiv_symm (coordinateSample_agrees c q))
  exact BracketContinuity.unique (coordinateAt_continuous c hx) H

def pair (C S : RealRaw) : ComplexRaw where
  compute n :=
    {lo := ⟨(C.compute n).lo,(S.compute n).lo⟩,
     hi := ⟨(C.compute n).hi,(S.compute n).hi⟩}

theorem pair_valid {C S : RealRaw} (hC : C.Valid) (hS : S.Valid) : (pair C S).Valid := by
  refine ⟨?_,?_,?_⟩
  · intro n; exact ⟨hC.1 n,hS.1 n⟩
  · intro n m hnm
    have H := hC.2.1 n m hnm
    have K := hS.2.1 n m hnm
    exact ⟨H.1,H.2.2,K.1,K.2.2⟩
  · intro eps
    obtain ⟨N,hN⟩ := hC.2.2 eps
    obtain ⟨M,hM⟩ := hS.2.2 eps
    exact ⟨max N M,fun n hn => ⟨hN n (by omega),hM n (by omega)⟩⟩

theorem pair_equiv {C S D T : RealRaw} (hC : C.Equiv D) (hS : S.Equiv T) :
    (pair C S).Equiv (pair D T) := by
  intro n
  have H := (RealRaw.compareAt_overlap_iff _ _ n n).mp (hC n)
  have K := (RealRaw.compareAt_overlap_iff _ _ n n).mp (hS n)
  exact (ComplexRaw.compareAt_overlap_iff _ _ n n).mpr ⟨⟨H.1,K.1⟩,⟨H.2,K.2⟩⟩

def eval (x : RealRaw) : ComplexRaw := pair (coordinateAt true x) (coordinateAt false x)

theorem eval_valid {x : RealRaw} (hx : x.Valid) : (eval x).Valid :=
  pair_valid (coordinateAt_valid true hx) (coordinateAt_valid false hx)

theorem eval_congr {x y : RealRaw} (hx : x.Valid) (hy : y.Valid) (he : x.Equiv y) :
    (eval x).Equiv (eval y) := pair_equiv (coordinateAt_congr true hx hy he) (coordinateAt_congr false hx hy he)

/-- Exact Euler identity on the whole represented real normalized-angle axis. -/
theorem eval_agrees_circle {x : RealRaw} (hx : x.Valid) :
    (eval x).Equiv (pair (GeometricTrig.cosAt x) (GeometricTrig.sinAt x)) :=
  pair_equiv (coordinateAt_agrees true hx) (coordinateAt_agrees false hx)

theorem eval_rational (q : Rat) : (eval (RealRaw.ofRat q)).Equiv (sample q) := by
  intro n
  have H := (RealRaw.compareAt_overlap_iff _ _ n n).mp (coordinateAt_rational true q n)
  have K := (RealRaw.compareAt_overlap_iff _ _ n n).mp (coordinateAt_rational false q n)
  exact (ComplexRaw.compareAt_overlap_iff _ _ n n).mpr ⟨⟨H.1,K.1⟩,⟨H.2,K.2⟩⟩

theorem coordinate_zero (c : Bool) :
    (coordinateAt c (RealRaw.ofRat 0)).Equiv (RealRaw.ofRat (if c then 1 else 0)) := by
  have HG := geometric_zero c
  rw [GeometricTrig.valueFor_raw] at HG
  have HE : (coordinateSample c 0).Equiv (RealRaw.ofRat (if c then 1 else 0)) :=
    RealRaw.equiv_trans (coordinateSample_valid c 0) (GeometricTrig.sample_valid c 0)
    (RealRaw.ofRat_valid _) (coordinateSample_agrees c 0) HG
  exact RealRaw.equiv_trans (coordinateAt_valid c (RealRaw.ofRat_valid 0))
    (coordinateSample_valid c 0) (RealRaw.ofRat_valid _) (coordinateAt_rational c 0) HE

/-- The actual represented Euler rotation starts at one. -/
theorem eval_zero :
    (eval (RealRaw.ofRat 0)).Equiv (ComplexRaw.ofRealRaw (RealRaw.ofRat 1)) :=
  pair_equiv (coordinate_zero true) (coordinate_zero false)

theorem sine_derivative {x : RealRaw} (hx : x.Valid) :
    RealSecantDerivative.HasDerivativeAt (fun _ => True) (coordinateSample false) x
      (RealRaw.mul GeometricTrig.pi (coordinateAt true x)) := by
  have H := RealSecantDerivative.congr_function (GeometricTrig.sin_derivative hx)
    (fun q _ => coordinateSample_valid false q)
    (fun q _ => RealRaw.equiv_symm (coordinateSample_agrees false q))
  exact RealSecantDerivative.congr_value H
    (RealRaw.mul_valid GeometricTrig.pi_valid (coordinateAt_valid true hx))
    (RealRaw.mul_equiv GeometricTrig.pi_valid GeometricTrig.pi_valid (GeometricTrig.cosAt_valid hx)
      (coordinateAt_valid true hx) (RealRaw.equiv_refl _ GeometricTrig.pi_valid)
      (RealRaw.equiv_symm (coordinateAt_agrees true hx)))

theorem cosine_derivative {x : RealRaw} (hx : x.Valid) :
    RealSecantDerivative.HasDerivativeAt (fun _ => True) (coordinateSample true) x
      (-(RealRaw.mul GeometricTrig.pi (coordinateAt false x))) := by
  have H := RealSecantDerivative.congr_function (GeometricTrig.cos_derivative hx)
    (fun q _ => coordinateSample_valid true q)
    (fun q _ => RealRaw.equiv_symm (coordinateSample_agrees true q))
  exact RealSecantDerivative.congr_value H
    (RealRaw.neg_valid (RealRaw.mul_valid GeometricTrig.pi_valid (coordinateAt_valid false hx)))
    (RealRaw.neg_equiv (RealRaw.mul_equiv GeometricTrig.pi_valid GeometricTrig.pi_valid (GeometricTrig.sinAt_valid hx)
      (coordinateAt_valid false hx) (RealRaw.equiv_refl _ GeometricTrig.pi_valid)
      (RealRaw.equiv_symm (coordinateAt_agrees false hx))))

/-- The two real component laws are the normalized complex rotation equation
Z'=i*pi*Z, without a complex differentiability or series premise. -/
theorem solves_rotation {x : RealRaw} (hx : x.Valid) :
    RealSecantDerivative.HasDerivativeAt (fun _ => True) (coordinateSample true) x
      (-(RealRaw.mul GeometricTrig.pi (eval x).imagPart)) ∧
    RealSecantDerivative.HasDerivativeAt (fun _ => True) (coordinateSample false) x
      (RealRaw.mul GeometricTrig.pi (eval x).realPart) :=
  ⟨cosine_derivative hx,sine_derivative hx⟩

def value : Numbers.Real → Numbers.Complex :=
  Quotient.lift
    (fun x : RealRawQuotient.Certified => ComplexRawQuotient.ofRaw (eval x.val) (eval_valid x.property))
    (fun x y h => ComplexRawQuotient.ofRaw_eq_ofRaw (eval_congr x.property y.property h))

theorem value_ofRaw (x : RealRaw) (hx : x.Valid) :
    value (RealRawQuotient.ofRaw x hx)=ComplexRawQuotient.ofRaw (eval x) (eval_valid hx) := rfl

theorem value_agrees_circle (x : RealRaw) (hx : x.Valid) :
    value (RealRawQuotient.ofRaw x hx)=
      ComplexRawQuotient.ofRaw (pair (GeometricTrig.cosAt x) (GeometricTrig.sinAt x))
        (pair_valid (GeometricTrig.cosAt_valid hx) (GeometricTrig.sinAt_valid hx)) :=
  ComplexRawQuotient.ofRaw_eq_ofRaw (eval_agrees_circle hx)

theorem pair_compute_as_sum (C S : RealRaw) (n : Nat) :
    (pair C S).compute n=
      (ComplexRaw.add (ComplexRaw.ofRealRaw C) (ComplexRaw.mulI (ComplexRaw.ofRealRaw S))).compute n := by
  simp only [pair,ComplexRaw.add,QBox.add,QComplex.add,ComplexRaw.ofRealRaw,ComplexRaw.mulI,
    QBox.mk.injEq,QComplex.mk.injEq]
  exact ⟨⟨by grind only,by grind only⟩,⟨by grind only,by grind only⟩⟩

theorem pair_as_sum {C S : RealRaw} (hC : C.Valid) (hS : S.Valid) :
    (pair C S).Equiv (ComplexRaw.add (ComplexRaw.ofRealRaw C) (ComplexRaw.mulI (ComplexRaw.ofRealRaw S))) := by
  intro n
  apply (ComplexRaw.compareAt_overlap_iff _ _ n n).mpr
  rw [←pair_compute_as_sum C S n]
  have HC := RealRaw.interval_order_of_valid C hC n
  have HS := RealRaw.interval_order_of_valid S hS n
  exact ⟨⟨HC,HS⟩,⟨HC,HS⟩⟩

/-- The familiar sum form of the exact imaginary-exponential/circle identity. -/
theorem euler_identity {x : RealRaw} (hx : x.Valid) :
    (eval x).Equiv (ComplexRaw.add (ComplexRaw.ofRealRaw (GeometricTrig.cosAt x))
      (ComplexRaw.mulI (ComplexRaw.ofRealRaw (GeometricTrig.sinAt x)))) :=
  ComplexRaw.equiv_trans (eval_valid hx)
    (pair_valid (GeometricTrig.cosAt_valid hx) (GeometricTrig.sinAt_valid hx))
    (ComplexRaw.add_valid (ComplexRaw.ofRealRaw_valid _ (GeometricTrig.cosAt_valid hx))
      (ComplexRaw.mulI_valid (ComplexRaw.ofRealRaw_valid _ (GeometricTrig.sinAt_valid hx))))
    (eval_agrees_circle hx) (pair_as_sum (GeometricTrig.cosAt_valid hx) (GeometricTrig.sinAt_valid hx))

end ComputableAnalysis.EulerImaginary
