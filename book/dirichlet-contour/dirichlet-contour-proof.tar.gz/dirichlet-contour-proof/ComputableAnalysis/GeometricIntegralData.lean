import ComputableAnalysis.GeometricFTCData
import ComputableAnalysis.FTCRealProduct

/-! Global finite-interval FTC data and a bounded integral computation for the
actual normalized geometric sine. No independent trigonometric series is used. -/
namespace ComputableAnalysis.GeometricIntegralData
open ComputableCoefficient RealApproximationOrder FTCRealCalculus GeometricTrig
set_option maxHeartbeats 800000

theorem trig_small (cosine : Bool) (t : Rat) : Small (valueFor cosine t) 1 := by
  have H := GeometricFTCData.family_small 1 0 cosine t
  simpa only [GeometricFTCData.family,Rat.one_mul,Rat.pow_zero] using H

theorem derivative_small (cosine : Bool) (t : Rat) : Small (derivativeValue cosine t) 8 := by
  have H : Small (if cosine then Value.neg (valueFor false t) else valueFor true t) 1 := by
    cases cosine
    · exact trig_small true t
    · exact (trig_small false t).neg
  simpa only [derivativeValue,pairSlope,Rat.mul_one] using pi_small.mul H

/-- The established geometric first-order estimate includes quadrant joins. -/
def trigStep (cosine : Bool) (a b : Rat) : Step (valueFor cosine) (derivativeValue cosine) a b where
  error := 1600
  error_nonnegative := by decide +kernel
  radius := ⟨1/4,by decide +kernel⟩
  firstOrder u v _ huv _ hs := full_firstOrder_small cosine huv hs
  variation := 256
  variation_nonnegative := by decide +kernel
  lipschitz u v _ huv _ := derivative_value_lipschitz cosine huv

theorem pi_lower (n : Nat) : 1≤(pi.compute n).lo := by
  have H := (unitArea_bounds n).1
  simp only [pi,RealRaw.scaleRat,RealRaw.scaleRatCompute,RealRaw.schedule,areaSchedule,
    if_pos (show (0:Rat)≤4 by decide +kernel)]
  grind only

def inversePi : Value := Value.positiveInv piValue 0 (by
  have H := pi_lower 0
  change 0<(pi.compute 0).lo
  grind only)

private theorem pi_sample_lower (m : Nat) (hm : piValue.observation 0≤m)
    (s : Real → Rat) (hs : Samples m s) : 1≤piValue.sample s := by
  have H := piValue.encloses 0 m hm s hs
  have P := pi_lower 0
  change (pi.compute 0).lo≤piValue.sample s ∧ _ at H
  grind only

theorem inversePi_small : Small inversePi 1 := by
  apply small_of_samples _ _ (piValue.observation 0)
  intro m hm s hs
  have hp := pi_sample_lower m hm s hs
  have hp0 : 0<piValue.sample s := by grind only
  have H := QInterval.one_div_le_one_div_of_pos (show (0:Rat)<1 by decide +kernel) hp
  change qabs ((piValue.sample s)⁻¹)≤1
  rw [qabs_eq_self_of_nonneg (Rat.le_of_lt (Rat.inv_pos.mpr hp0))]
  simpa only [Rat.div_def,Rat.one_mul,show (1:Rat)⁻¹=1 by decide +kernel] using H

theorem pi_inverse_identity : (Value.mul piValue inversePi).real.preferred.Equiv (RealRaw.ofRat 1) := by
  apply Value.equiv_of_samples _ (Value.rational 1) (piValue.observation 0)
  intro m hm s hs
  have hp := pi_sample_lower m hm s hs
  change piValue.sample s*(piValue.sample s)⁻¹=1
  exact Rat.mul_inv_cancel _ (by grind only)

/-- A bounded geometric integral of sine; the normalization is explicit. -/
def sineIntegral (t : Rat) : Value := Value.mul (Value.neg inversePi) (valueFor true t)

theorem sineIntegral_small (t : Rat) : Small (sineIntegral t) 1 := by
  simpa only [sineIntegral,Rat.mul_one] using inversePi_small.neg.mul (trig_small true t)

def sineIntegralStep (a b : Rat) : Step sineIntegral (valueFor false) a b := by
  apply ((trigStep true a b).mul_constant (Value.neg inversePi) 1 (by decide +kernel) inversePi_small.neg).congr
  · intro t; exact RealRaw.equiv_refl _ (sineIntegral t).real.valid
  · intro t
    apply Value.equiv_of_samples _ (valueFor false t) (piValue.observation 0)
    intro m hm s hs
    have hp := pi_sample_lower m hm s hs
    have hc := Rat.inv_mul_cancel (piValue.sample s) (by grind only : piValue.sample s≠0)
    simp only [Value.mul,Value.neg,inversePi,Value.positiveInv,derivativeValue,pairSlope,if_true]
    grind [Rat.mul_comm]

/-- A usable bound near the removable endpoint, derived by geometric FTC. -/
theorem sine_linear_bound (t : Rat) (ht : 0≤t) : Small (valueFor false t) (8*t) := by
  have H := lipschitz_of_firstOrder (trigStep false 0 t).firstOrder
    (trigStep false 0 t).error_nonnegative (trigStep false 0 t).radius.property
    (fun x _ _ => derivative_small false x)
  have B := H 0 t (Rat.le_refl) ht (Rat.le_refl)
  have he := RealRaw.sub_equiv (x := (valueFor false t).real.preferred)
    (x' := (valueFor false t).real.preferred) (y := (valueFor false 0).real.preferred) (y' := RealRaw.ofRat 0)
    (valueFor false t).real.valid (valueFor false t).real.valid (valueFor false 0).real.valid (RealRaw.ofRat_valid 0)
    (RealRaw.equiv_refl _ (valueFor false t).real.valid) (by rw [valueFor_raw]; exact sample_zero false)
  have he' : (sub (valueFor false t) (Value.rational 0)).real.preferred.Equiv (valueFor false t).real.preferred := by
    apply arithmetic_identity; intro s; simp only [sub,Value.rational]; grind only
  have H' := B.congr (RealRaw.equiv_trans (sub (valueFor false t) (valueFor false 0)).real.valid
    (sub (valueFor false t) (Value.rational 0)).real.valid (valueFor false t).real.valid he he')
  simpa only [Rat.sub_eq_add_neg,Rat.neg_zero,Rat.add_zero] using H'

end ComputableAnalysis.GeometricIntegralData
