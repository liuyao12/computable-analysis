import ComputableAnalysis.ComplexRawQuotientRing
import ComputableAnalysis.RealMultiplication

/-! Real values are equivalence classes of valid interval names.
The quotient forgets the choice of computation, not the interval construction
or its validity obligations. Executable algorithms remain at the raw layer. -/
namespace ComputableAnalysis.RealRawQuotient

abbrev Certified := {x : RealRaw // x.Valid}

private def certifiedSetoid : Setoid Certified where
  r x y := x.val.Equiv y.val
  iseqv := ⟨fun x => RealRaw.equiv_refl x.val x.property,
    RealRaw.equiv_symm,
    fun {x y z} h k => RealRaw.equiv_trans x.property y.property z.property h k⟩

/-- The real numbers, formed from the existing valid interval names. -/
def Value := Quotient certifiedSetoid

def ofRaw (x : RealRaw) (hx : x.Valid) : Value :=
  Quotient.mk certifiedSetoid ⟨x,hx⟩

def ofRat (q : Rat) : Value := ofRaw (RealRaw.ofRat q) (RealRaw.ofRat_valid q)

theorem ofRaw_eq_ofRaw {x y : RealRaw} {hx : x.Valid} {hy : y.Valid}
    (h : x.Equiv y) : ofRaw x hx = ofRaw y hy := Quotient.sound h

theorem equiv_of_ofRaw_eq {x y : RealRaw} {hx : x.Valid} {hy : y.Valid}
    (h : ofRaw x hx = ofRaw y hy) : x.Equiv y := Quotient.exact h

theorem ofRaw_eq_iff {x y : RealRaw} {hx : x.Valid} {hy : y.Valid} :
    ofRaw x hx = ofRaw y hy ↔ x.Equiv y :=
  ⟨equiv_of_ofRaw_eq,ofRaw_eq_ofRaw⟩

/-- A legacy computation bundle denotes a value, independently of its metadata. -/
def ofComputation (x : ComputableAnalysis.Real) : Value := ofRaw x.preferred x.valid

def add (x y : Value) : Value := Quotient.liftOn₂ x y
  (fun x y => ofRaw (x.val+y.val) (RealRaw.add_valid x.property y.property))
  (by
    intro x y x' y' hx hy
    exact Quotient.sound (RealRaw.add_equiv x.property x'.property y.property y'.property hx hy))

def neg (x : Value) : Value := Quotient.liftOn x
  (fun x => ofRaw (-x.val) (RealRaw.neg_valid x.property))
  (by intro x y h; exact Quotient.sound (RealRaw.neg_equiv h))

def mul (x y : Value) : Value := Quotient.liftOn₂ x y
  (fun x y => ofRaw (x.val*y.val) (RealRaw.mul_valid x.property y.property))
  (by
    intro x y x' y' hx hy
    exact Quotient.sound (RealRaw.mul_equiv x.property x'.property y.property y'.property hx hy))

instance : Zero Value := ⟨ofRat 0⟩
instance : One Value := ⟨ofRat 1⟩
instance : Add Value := ⟨add⟩
instance : Neg Value := ⟨neg⟩
instance : Sub Value := ⟨fun x y => add x (neg y)⟩
instance : Mul Value := ⟨mul⟩

private theorem raw_le_congr {x y a b : Certified}
    (hx : x.val.Equiv a.val) (hy : y.val.Equiv b.val) :
    x.val.Le y.val ↔ a.val.Le b.val := by
  constructor
  · intro h
    exact RealRaw.le_trans y.property
      (RealRaw.le_trans x.property
        (RealRaw.le_of_equiv a.property x.property (RealRaw.equiv_symm hx)) h)
      (RealRaw.le_of_equiv y.property b.property hy)
  · intro h
    exact RealRaw.le_trans b.property
      (RealRaw.le_trans a.property (RealRaw.le_of_equiv x.property a.property hx) h)
      (RealRaw.le_of_equiv b.property y.property (RealRaw.equiv_symm hy))

def le (x y : Value) : Prop := Quotient.liftOn₂ x y
  (fun x y => x.val.Le y.val)
  (by intro x y a b hx hy; exact propext (raw_le_congr hx hy))

instance : LE Value := ⟨le⟩

@[simp] theorem ofRaw_le_iff (x y : RealRaw) (hx : x.Valid) (hy : y.Valid) :
    ofRaw x hx ≤ ofRaw y hy ↔ x.Le y := Iff.rfl

theorem le_refl (x : Value) : x ≤ x := by
  refine Quotient.inductionOn x ?_
  intro x
  exact RealRaw.le_refl x.val x.property

theorem le_trans {x y z : Value} (h : x≤y) (k : y≤z) : x≤z := by
  revert h k
  refine Quotient.inductionOn₃ x y z ?_
  intro x y z h k
  exact RealRaw.le_trans y.property h k

theorem le_antisymm {x y : Value} (h : x≤y) (k : y≤x) : x=y := by
  revert h k
  refine Quotient.inductionOn₂ x y ?_
  intro x y h k
  exact Quotient.sound (RealRaw.le_antisymm h k)

/-- Inclusion of real values in the existing complex quotient. -/
def toComplex (x : Value) : ComplexRawQuotient.Value := Quotient.liftOn x
  (fun x => ComplexRawQuotient.ofRaw (ComplexRaw.ofRealRaw x.val)
    (ComplexRaw.ofRealRaw_valid x.val x.property))
  (by
    intro x y h
    exact ComplexRawQuotient.ofRaw_eq_ofRaw
      (ComplexRaw.ofRealRaw_equiv_of_equiv x.property y.property h))

theorem toComplex_injective {x y : Value} (h : toComplex x = toComplex y) : x=y := by
  revert h
  refine Quotient.inductionOn₂ x y ?_
  intro x y h
  have hc := ComplexRaw.realPart_equiv (ComplexRawQuotient.equiv_of_ofRaw_eq h)
  exact Quotient.sound hc

end ComputableAnalysis.RealRawQuotient
