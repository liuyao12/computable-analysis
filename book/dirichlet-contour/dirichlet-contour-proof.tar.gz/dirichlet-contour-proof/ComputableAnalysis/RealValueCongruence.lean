import ComputableAnalysis.RealValueBounds

namespace ComputableAnalysis.RealApproximationOrder
open ComputableCoefficient
abbrev Same (X Y : Value) : Prop := X.real.preferred.Equiv Y.real.preferred
namespace Same

theorem refl (X : Value) : Same X X := RealRaw.equiv_refl _ X.real.valid

theorem symm {X Y : Value} (h : Same X Y) : Same Y X := RealRaw.equiv_symm h

theorem trans {X Y Z : Value} (h : Same X Y) (k : Same Y Z) : Same X Z :=
  RealRaw.equiv_trans X.real.valid Y.real.valid Z.real.valid h k

theorem add {X Y U V : Value} (h : Same X Y) (k : Same U V) : Same (Value.add X U) (Value.add Y V) :=
  RealRaw.add_equiv X.real.valid Y.real.valid U.real.valid V.real.valid h k

theorem mul {X Y U V : Value} (h : Same X Y) (k : Same U V) : Same (Value.mul X U) (Value.mul Y V) :=
  RealRaw.mul_equiv X.real.valid Y.real.valid U.real.valid V.real.valid h k

theorem sub {X Y U V : Value} (h : Same X Y) (k : Same U V) : Same (RealApproximationOrder.sub X U) (RealApproximationOrder.sub Y V) :=
  RealRaw.sub_equiv X.real.valid Y.real.valid U.real.valid V.real.valid h k

theorem neg {X Y : Value} (h : Same X Y) : Same (Value.neg X) (Value.neg Y) :=
  RealRaw.neg_equiv h

theorem scale {X Y : Value} (h : Same X Y) (c : Rat) : Same (RealApproximationOrder.scale c X) (RealApproximationOrder.scale c Y) :=
  RealRaw.scaleRat_equiv h

end Same
end ComputableAnalysis.RealApproximationOrder
