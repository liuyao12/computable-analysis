import ComputableAnalysis.EulerReal
import ComputableAnalysis.GeometricDerivative

/-! Forward Euler steps for the normalized rotation equation. The finite
error proof uses the geometric derivative remainder, not a series. -/
namespace ComputableAnalysis.EulerImaginary
open ComputableCoefficient RealApproximationOrder GeometricTrig
set_option maxHeartbeats 3000000

theorem small_zero : Small (Value.rational 0) 0 := by
  constructor <;> intro i j <;> exact (Rat.le_refl : (0:Rat)≤0)

theorem small_of_zero (v : Value) (hv : v.real.preferred.Equiv (RealRaw.ofRat 0)) : Small v 0 :=
  small_zero.congr (RealRaw.equiv_symm hv)

theorem scale_small {v : Value} {B h : Rat} (hv : Small v B) :
    Small (scale h v) (qabs h*B) := by
  by_cases hh : 0≤h
  · rw [qabs_eq_self_of_nonneg hh]
    exact hv.scale_nonnegative hh
  · have hn : h≤0 := by grind only
    rw [qabs_eq_neg_of_nonpos hn]
    apply (hv.neg.scale_nonnegative (show 0≤-h by grind only)).congr
    apply arithmetic_identity
    intro s
    simp only [scale,Value.neg]
    grind only

theorem signed_remainder (c : Bool) (u v : Rat) (hstep : qabs (v-u)≤1/4) :
    Small (remainderValue c u v) (2000*(v-u)*(v-u)) := by
  have hs := rat_square_nonneg_basic (v-u)
  by_cases he : u=v
  · subst v
    apply (small_zero.mono (by grind only : (0:Rat)≤2000*(u-u)*(u-u))).congr
    apply arithmetic_identity
    intro s
    simp only [remainderValue,sub,scale,Value.rational]
    grind only
  by_cases huv : u<v
  · have H := full_firstOrder_small c huv (Rat.le_trans (self_le_qabs (v-u)) hstep)
    exact H.mono (by grind only)
  · have hvu : v<u := by grind only
    have hsmall : u-v≤1/4 := by have := neg_qabs_le_self (v-u); grind only
    have H := full_firstOrder_small c hvu hsmall
    have D := derivative_value_lipschitz c (Rat.le_of_lt hvu)
    have S := D.scale_nonnegative (show 0≤u-v by grind only)
    have B := H.neg.add S
    apply (B.mono (by grind only : 1600*(u-v)*(u-v)+(u-v)*(256*(u-v))≤2000*(v-u)*(v-u))).congr
    apply arithmetic_identity
    intro s
    simp only [remainderValue,sub,scale,Value.add,Value.neg]
    grind only

theorem geometric_zero (c : Bool) :
    (valueFor c 0).real.preferred.Equiv (RealRaw.ofRat (if c then 1 else 0)) := by
  rw [valueFor_raw]
  have H := sample_on_closed_quarter 0 c (q := 0) (by decide +kernel) (by decide +kernel)
  have harg : (0:Rat)-((0:Int):Rat)/2=0 := by decide +kernel
  rw [harg] at H
  simp only [turn,show (0:Int)%4=0 by decide,↓reduceIte] at H
  exact RealRaw.equiv_trans (GeometricTrig.sample_valid c 0) (quarter_valid c 0)
    (RealRaw.ofRat_valid _) H (quarter_zero c)

/-- Finite Euler states; `false` is the imaginary/sine coordinate and `true`
is the real/cosine coordinate. Only pi, field arithmetic and the mesh occur. -/
def state (h : Rat) : Nat → Bool → Value
  | 0 => fun c => Value.rational (if c then 1 else 0)
  | k+1 =>
    let previous := state h k
    fun c => Value.add (previous c) (scale h (pairSlope c (previous false) (previous true)))

def error (h : Rat) (k : Nat) (c : Bool) : Value :=
  sub (state h k c) (valueFor c ((k:Rat)*h))

def errorBound (h : Rat) (k : Nat) : Rat :=
  2000*h*h*(k:Rat)*(1+8*qabs h)^k

theorem state_error (h : Rat) (hstep : qabs h≤1/4) (k : Nat) :
    ∀ c,Small (error h k c) (errorBound h k) := by
  have hh := qabs_nonneg h
  have hs := rat_square_nonneg_basic h
  have hR : (1:Rat)≤1+8*qabs h := by grind only
  induction k with
  | zero =>
    intro c
    have hc := geometric_zero c
    let V := Value.rational (if c then 1 else 0)
    have H := RealRaw.sub_equiv V.real.valid V.real.valid (valueFor c 0).real.valid V.real.valid
      (RealRaw.equiv_refl _ V.real.valid) hc
    have H0 : (sub V (valueFor c 0)).real.preferred.Equiv (RealRaw.ofRat 0) :=
      RealRaw.equiv_trans (RealRaw.sub_valid V.real.valid (valueFor c 0).real.valid)
      (RealRaw.sub_valid V.real.valid V.real.valid) (RealRaw.ofRat_valid 0) H
      (RealRaw.sub_self_equiv_zero V.real.valid)
    have Hz : errorBound h 0=0 := by dsimp [errorBound]; grind only
    rw [Hz]
    change Small (sub V (valueFor c ((0:Rat)*h))) 0
    rw [show (0:Rat)*h=0 by grind only]
    exact small_of_zero _ H0
  | succ k ih =>
    intro c
    let D := sub (pairSlope c (state h k false) (state h k true))
      (derivativeValue c ((k:Rat)*h))
    let V := if c then Value.neg (error h k false) else error h k true
    have HV : Small V (errorBound h k) := by cases c; exact ih true; exact (ih false).neg
    have HD : Small D (8*errorBound h k) := by
      apply (pi_small.mul HV).congr
      apply arithmetic_identity
      intro s
      cases c <;> simp only [D,V,pairSlope,derivativeValue,error,sub,Value.mul,Value.neg,
        Bool.false_eq_true,↓reduceIte] <;> grind only
    have Hs := scale_small (h := h) HD
    have htime : (((k+1:Nat):Rat)*h)-((k:Rat)*h)=h := by rw [Rat.natCast_add]; grind only
    have HR := signed_remainder c ((k:Rat)*h) (((k+1:Nat):Rat)*h) (by rw [htime]; exact hstep)
    rw [htime] at HR
    have H := ((ih c).add Hs).add HR.neg
    have hp := EulerFinite.pow_mono (show (0:Rat)≤1 by decide +kernel) hR (k+1)
    rw [EulerFinite.one_pow] at hp
    have hrec : errorBound h k+qabs h*(8*errorBound h k)+2000*h*h≤errorBound h (k+1) := by
      have Hpos := Rat.mul_le_mul_of_nonneg_left hp (show 0≤2000*h*h by grind only)
      simp only [Rat.pow_succ,Rat.mul_one] at Hpos
      simp only [errorBound,Rat.pow_succ,Rat.natCast_add]
      grind only
    apply (H.mono hrec).congr
    apply arithmetic_identity
    intro s
    simp only [state,error,D,remainderValue,sub,scale,Value.add,Value.neg]
    rw [htime]
    grind only

def radius (q : Rat) : Rat := 8*qabs q+1
def errorConstant (q : Rat) : Rat := 2000*q^2*EulerReal.budget (radius q)
def meshFactor (q : Rat) (n : Nat) : Nat := 2*EulerReal.start (errorConstant q)*(n+1)
def mesh (q : Rat) (n : Nat) : Nat := EulerReal.start (radius q)*meshFactor q n
def stepSize (q : Rat) (n : Nat) : Rat := q/(mesh q n:Rat)
def numericalTolerance (n : Nat) : Rat := (1/((n+1:Nat):Rat))/2

theorem radius_nonnegative (q : Rat) : 0≤radius q := by
  have := qabs_nonneg q
  dsimp [radius]; grind only

theorem errorConstant_nonnegative (q : Rat) : 0≤errorConstant q := by
  have hq : 0≤q^2 := by simpa only [Rat.pow_succ,Rat.pow_zero,Rat.one_mul] using rat_square_nonneg_basic q
  exact Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hq)
    (Rat.le_of_lt (EulerReal.budget_positive _))

theorem meshFactor_positive (q : Rat) (n : Nat) : 0<meshFactor q n := by
  exact Nat.mul_pos (Nat.mul_pos (by decide) (Rat.natCast_pos.mp (EulerReal.start_positive _))) (Nat.succ_pos n)

theorem mesh_positive (q : Rat) (n : Nat) : 0<(mesh q n:Rat) :=
  Rat.natCast_pos.mpr (Nat.mul_pos (Rat.natCast_pos.mp (EulerReal.start_positive _)) (meshFactor_positive q n))

theorem mesh_large (q : Rat) (n : Nat) : radius q<(mesh q n:Rat) := by
  have H := Nat.le_mul_of_pos_right (EulerReal.start (radius q)) (meshFactor_positive q n)
  have Hrat : (EulerReal.start (radius q):Rat)≤(mesh q n:Rat) := by exact_mod_cast H
  have hs := EulerReal.start_large (radius q)
  grind only

theorem abs_stepSize (q : Rat) (n : Nat) : qabs (stepSize q n)=qabs q/(mesh q n:Rat) := by
  simp only [stepSize,Rat.div_def,qabs_mul,
    qabs_eq_self_of_nonneg (Rat.le_of_lt (Rat.inv_pos.mpr (mesh_positive q n)))]

theorem stepSize_small (q : Rat) (n : Nat) : qabs (stepSize q n)≤1/4 := by
  have H := mesh_large q n
  have hq := qabs_nonneg q
  have hi := Rat.le_of_lt (Rat.inv_pos.mpr (mesh_positive q n))
  have Hmul := Rat.mul_le_mul_of_nonneg_right (show 4*qabs q≤(mesh q n:Rat) by dsimp [radius] at H; grind only) hi
  have hc := Rat.mul_inv_cancel (mesh q n:Rat) (Rat.ne_of_gt (mesh_positive q n))
  rw [abs_stepSize]
  grind [Rat.div_def]

theorem growth_bound (q : Rat) (n : Nat) :
    (1+8*qabs (stepSize q n))^(mesh q n)≤EulerReal.budget (radius q) := by
  have hN := mesh_positive q n
  have hM := radius_nonnegative q
  have hlarge := mesh_large q n
  have H1 := EulerFinite.lower_mono hN (a := 8*qabs q) (b := radius q)
    (by have := qabs_nonneg q; grind only) (by dsimp [radius]; grind only)
  have H2 := EulerFinite.lower_le_upper hN (q := radius q) (by grind only) hlarge
  have H3 := EulerFinite.upper_refine (EulerReal.start_positive (radius q))
    (meshFactor_positive q n) (EulerReal.start_large (radius q))
  have he : 1+8*qabs (stepSize q n)=1+(8*qabs q)/(mesh q n:Rat) := by
    rw [abs_stepSize]; grind [Rat.div_def]
  rw [he]
  exact Rat.le_trans H1 (Rat.le_trans H2 H3)

theorem tolerance_positive (n : Nat) : 0<numericalTolerance n := by
  exact Rat.mul_pos (one_div_nat_pos (Nat.succ_pos n)) (by decide +kernel : (0:Rat)<(2:Rat)⁻¹)

theorem mesh_error_bound (q : Rat) (n : Nat) :
    errorConstant q/(mesh q n:Rat)≤numericalTolerance n := by
  have hS : (1:Rat)≤(EulerReal.start (radius q):Rat) := by
    exact_mod_cast (show 1≤EulerReal.start (radius q) by
      have := Rat.natCast_pos.mp (EulerReal.start_positive (radius q)); omega)
  have hC := EulerReal.start_large (errorConstant q)
  have hK := Rat.le_of_lt (EulerReal.start_positive (errorConstant q))
  have H := Rat.mul_le_mul_of_nonneg_right hS hK
  rw [Rat.one_mul] at H
  have hn := Rat.natCast_pos.mpr (Nat.succ_pos n)
  have hcN := Rat.div_mul_cancel (a := errorConstant q) (Rat.ne_of_gt (mesh_positive q n))
  have hcnt : (mesh q n:Rat)=(EulerReal.start (radius q):Rat)*
      (2*(EulerReal.start (errorConstant q):Rat)*((n+1:Nat):Rat)) := by
    simp only [mesh,meshFactor,Rat.natCast_mul,show ((2:Nat):Rat)=(2:Rat) by decide +kernel]
  have hcancel := Rat.inv_mul_cancel ((n+1:Nat):Rat) (Rat.ne_of_gt hn)
  have htwo : (2:Rat)⁻¹*2=1 := by decide +kernel
  have ht : numericalTolerance n*(mesh q n:Rat)=
      (EulerReal.start (radius q):Rat)*(EulerReal.start (errorConstant q):Rat) := by
    rw [hcnt]
    dsimp [numericalTolerance]
    calc
      _=((EulerReal.start (radius q):Rat)*(EulerReal.start (errorConstant q):Rat))*
          ((((n+1:Nat):Rat)⁻¹)*((n+1:Nat):Rat))*((2:Rat)⁻¹*2) := by grind [Rat.div_def]
      _=_ := by rw [hcancel,htwo,Rat.mul_one,Rat.mul_one]
  apply Rat.le_of_mul_le_mul_right (c := (mesh q n:Rat)) _ (mesh_positive q n)
  rw [hcN,ht]
  grind only

/-- The actual finite Euler state approximates the independently geometric
circle value with a certified error at every rational normalized angle. -/
theorem terminal_error (q : Rat) (n : Nat) (c : Bool) :
    Small (sub (state (stepSize q n) (mesh q n) c) (valueFor c q))
      (errorConstant q/(mesh q n:Rat)) := by
  have H := state_error (stepSize q n) (stepSize_small q n) (mesh q n) c
  have hc := Rat.div_mul_cancel (a := q) (Rat.ne_of_gt (mesh_positive q n))
  have hend : (mesh q n:Rat)*stepSize q n=q := by dsimp [stepSize]; grind only
  change Small (sub (state (stepSize q n) (mesh q n) c)
    (valueFor c ((mesh q n:Rat)*stepSize q n))) _ at H
  rw [hend] at H
  have hs := EulerFinite.mesh_square_count q (mesh_positive q n)
  have hN := mesh_positive q n
  have hb := growth_bound q n
  have hcoef : 0≤2000*stepSize q n*stepSize q n*(mesh q n:Rat) := by
    have Hsq := rat_square_nonneg_basic (stepSize q n)
    have HN := Rat.le_of_lt (mesh_positive q n)
    exact Rat.mul_nonneg (by grind only) HN
  have Hb := Rat.mul_le_mul_of_nonneg_left hb hcoef
  have he : 2000*stepSize q n*stepSize q n*(mesh q n:Rat)=2000*(q^2/(mesh q n:Rat)) := by
    calc
      _=2000*((mesh q n:Rat)*(q/(mesh q n:Rat))^2) := by
        dsimp [stepSize]
        simp only [Rat.pow_succ,Rat.pow_zero,Rat.one_mul]
        grind only
      _=_ := by rw [hs]
  have he' : (2000*(q^2/(mesh q n:Rat)))*EulerReal.budget (radius q)=
      errorConstant q/(mesh q n:Rat) := by
    dsimp [errorConstant]; grind [Rat.div_def]
  rw [he,he'] at Hb
  apply H.mono
  change (2000*stepSize q n*stepSize q n*(mesh q n:Rat))*
    (1+8*qabs (stepSize q n))^(mesh q n)≤_
  rw [he]
  exact Hb

end ComputableAnalysis.EulerImaginary
