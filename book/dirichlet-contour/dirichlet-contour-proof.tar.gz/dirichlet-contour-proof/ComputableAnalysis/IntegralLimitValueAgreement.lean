import ComputableAnalysis.IntegralExtensions

/-! Equality of represented values preserves the role of an actual improper
integral. This changes no exhaustion or compact witnesses; convergence is
transported by the exact order laws for valid represented values. -/
namespace ComputableAnalysis.Integral
set_option autoImplicit false
set_option maxHeartbeats 1000000

theorem Within.congr_left {I J K : RealRaw} {eps : Rat}
    (hI : I.Valid) (hJ : J.Valid) (hK : K.Valid) (he : I.Equiv J) (h : Within I K eps) : Within J K eps := by
  have hFirst : I.Le (RealRaw.add K (RealRaw.ofRat eps)) := fun i j => (h i j).1
  have hSecond : K.Le (RealRaw.add I (RealRaw.ofRat eps)) := fun i j => (h j i).2
  have hLeft := RealRaw.le_trans hI (RealRaw.le_of_equiv hJ hI (RealRaw.equiv_symm he)) hFirst
  have hAdd := RealRaw.le_add_le_add (RealRaw.le_of_equiv hI hJ he)
    (RealRaw.le_refl (RealRaw.ofRat eps) (RealRaw.ofRat_valid eps))
  have hRight := RealRaw.le_trans (RealRaw.add_valid (x := I) (y := RealRaw.ofRat eps) hI (RealRaw.ofRat_valid eps)) hSecond hAdd
  exact fun i j => ⟨hLeft i j,hRight j i⟩

/-- A proved value identity transports an already justified integral-limit
role. It does not infer an integral role from numerical validity. -/
theorem HasIntegralLimit.congr {F : Nat → FunctionOnInterval} {I J : RealRaw}
    (hI : HasIntegralLimit F I) (hJ : J.Valid) (he : I.Equiv J) : HasIntegralLimit F J := by
  refine ⟨hJ,hI.compact,?_⟩
  intro eps
  obtain ⟨N,hN⟩ := hI.converges eps
  exact ⟨N,fun n hn K hK => Within.congr_left hI.valid hJ hK.valid he (hN n hn K hK)⟩

end ComputableAnalysis.Integral
