import ComputableAnalysis.Numbers
import ComputableAnalysis.Holomorphic

/-! The single domain-dependent represented evaluator convention.
These declarations retain their historical namespace for downstream source
compatibility; the independent foundation owns their implementation. -/
namespace ComputableAnalysis.RiemannHilbert.DomainFunctions
open ComplexRaw FunctionTheory

abbrev Name := {z : ComplexRaw // z.Valid}

structure Map where
  domain : Name → Prop
  eval : (z : Name) → domain z → Name
  domain_congr : ∀ z w, z.val.Equiv w.val → (domain z ↔ domain w)
  eval_congr : ∀ z w hz hw, z.val.Equiv w.val → (eval z hz).val.Equiv (eval w hw).val

/-- The actual domain as a predicate on mathematical complex values. -/
def Map.valueDomain (f : Map) (z : Numbers.Complex) : Prop :=
  Quotient.liftOn z (fun c : ComplexRawQuotient.Certified => f.domain ⟨c.raw,c.valid⟩)
    (by intro a b h; exact propext (f.domain_congr _ _ h))

@[simp] theorem Map.valueDomain_ofRaw (f : Map) (z : ComplexRaw) (hz : z.Valid) :
    f.valueDomain (ComplexRawQuotient.ofRaw z hz) ↔ f.domain ⟨z,hz⟩ := Iff.rfl

/-- Evaluation descends through the quotient without choosing a representative.
Numerical execution uses the supplied name and `eval`. -/
def Map.value (f : Map) (z : Numbers.Complex) (hz : f.valueDomain z) :
    Numbers.Complex := by
  refine Quotient.pliftOn z (fun c hc => ?_) ?_
  · have hd : f.domain ⟨c.raw,c.valid⟩ := by
      have hd := hz
      rw [hc] at hd
      exact hd
    exact ComplexRawQuotient.ofRaw (f.eval ⟨c.raw,c.valid⟩ hd).val
      (f.eval ⟨c.raw,c.valid⟩ hd).property
  · intro a b ha hb hab
    apply ComplexRawQuotient.ofRaw_eq_ofRaw
    exact f.eval_congr _ _ _ _ hab

/-- Supplied executable names evaluate to exactly the semantic quotient value. -/
theorem Map.value_ofRaw (f : Map) (z : Name) (hz : f.domain z) :
    f.value (ComplexRawQuotient.ofRaw z.val z.property) hz =
      ComplexRawQuotient.ofRaw (f.eval z hz).val (f.eval z hz).property := rfl

def remainder (f : Map) (a : Name) (ha : f.domain a) (d : Name)
    (z : Name) (hz : f.domain z) : ComplexRaw :=
  sub (sub (f.eval z hz).val (f.eval a ha).val) (mul d.val (sub z.val a.val))

structure HasDerivativeAt (f : Map) (a : Name) (ha : f.domain a) (d : Name) where
  delta : QPos → QPos
  estimate : ∀ (eps H : QPos) (z : Name) (hz : f.domain z),
    H.val ≤ (delta eps).val → Small (sub z.val a.val) H.val →
    Small (remainder f a ha d z hz) (eps.val*H.val)

structure OpenDomain (f : Map) where
  radius : ∀ a, f.domain a → QPos
  inside : ∀ a ha z, Small (sub z.val a.val) (radius a ha).val → f.domain z

structure ContinuousOn (domain : Name → Prop) (g : ∀ z, domain z → Name) where
  delta : ∀ a, domain a → QPos → QPos
  estimate : ∀ a ha (eps : QPos) z hz,
    Small (sub z.val a.val) (delta a ha eps).val →
    Small (sub (g z hz).val (g a ha).val) eps.val

structure Holomorphic (f : Map) where
  openDomain : OpenDomain f
  derivative : ∀ a, f.domain a → Name
  atPoint : ∀ a ha, HasDerivativeAt f a ha (derivative a ha)
  derivative_congr : ∀ a b ha hb, a.val.Equiv b.val →
    (derivative a ha).val.Equiv (derivative b hb).val
  continuousDerivative : ContinuousOn f.domain derivative


end ComputableAnalysis.RiemannHilbert.DomainFunctions

namespace ComputableAnalysis.DomainFunctions
abbrev Map := RiemannHilbert.DomainFunctions.Map
end ComputableAnalysis.DomainFunctions
