import ComputableAnalysis.EulerFinite

/-! Turning independently computed rational centers with certified errors into
nested complex boxes. The runtime contains no reference evaluator. -/
namespace ComputableAnalysis.EulerBoxLimit
open EulerFinite
set_option maxHeartbeats 1000000

def allowance (n : Nat) : Rat := 1/((n+1:Nat):Rat)
def coordinate (z : QComplex) (c : Bool) : Rat := if c then z.re else z.im

def CenterBounds (x : RealRaw) (p e : Rat) : Prop :=
  (RealRaw.ofRat (p-e)).Le x ∧ x.Le (RealRaw.ofRat (p+e))

theorem allowance_positive (n : Nat) : 0<allowance n := by
  exact one_div_nat_pos (Nat.succ_pos n)

theorem allowance_antitone {n m : Nat} (hnm : n≤m) : allowance m≤allowance n := by
  have H := inv_antitone (Rat.natCast_pos.mpr (Nat.succ_pos n))
    (show ((n+1:Nat):Rat)≤((m+1:Nat):Rat) by exact_mod_cast (show n+1≤m+1 by omega))
  simpa only [allowance,Rat.div_def,Rat.one_mul] using H

theorem center_comparison {x : RealRaw} (hx : x.Valid) {p q e d : Rat}
    (hp : CenterBounds x p e) (hq : CenterBounds x q d) :
    p-e≤q+d ∧ q-d≤p+e :=
  ⟨RealRaw.le_trans hx hp.1 hq.2 0 0,RealRaw.le_trans hx hq.1 hp.2 0 0⟩

def candidate (centers : Nat → QComplex) : ComplexRaw where
  compute n := QBox.point (centers n)

def limit (centers : Nat → QComplex) : ComplexRaw :=
  ComplexRaw.cauchyStabilize (candidate centers) (fun n => 2*allowance n)

theorem future (centers : Nat → QComplex) (anchor : Bool → RealRaw)
    (hv : ∀ c,(anchor c).Valid)
    (hc : ∀ c n,CenterBounds (anchor c) (coordinate (centers n) c) (allowance n)) :
    ∀ k n,k≤n → ((candidate centers).compute n).NestedIn
      (QBox.expand ((candidate centers).compute k) (2*allowance k)) := by
  intro k n hkn
  have Hr := center_comparison (hv true) (hc true k) (hc true n)
  have Hi := center_comparison (hv false) (hc false k) (hc false n)
  have Hle := allowance_antitone hkn
  have Hp := Rat.le_of_lt (allowance_positive k)
  dsimp only [candidate,QBox.point,QBox.expand,QBox.NestedIn,QComplex.le_def,coordinate] at *
  exact ⟨⟨by grind only,by grind only⟩,⟨by grind only,by grind only⟩⟩

theorem valid (centers : Nat → QComplex) (anchor : Bool → RealRaw)
    (hv : ∀ c,(anchor c).Valid)
    (hc : ∀ c n,CenterBounds (anchor c) (coordinate (centers n) c) (allowance n)) :
    (limit centers).Valid := by
  apply ComplexRaw.cauchyStabilize_valid
  · intro n; exact ⟨Rat.le_refl,Rat.le_refl⟩
  · intro eps
    refine ⟨0,?_⟩
    intro n hn
    have H := eps.property
    change (centers n).re-(centers n).re≤eps.val ∧ (centers n).im-(centers n).im≤eps.val
    constructor <;> grind only
  · exact future centers anchor hv hc
  · apply shrinksToZero_of_ratOverSuccBound (C := 2)
    intro n
    dsimp [allowance]
    grind [Rat.div_def]

theorem coordinate_bounds (centers : Nat → QComplex) (anchor : Bool → RealRaw)
    (hc : ∀ c n,CenterBounds (anchor c) (coordinate (centers n) c) (allowance n))
    (c : Bool) (n j : Nat) :
    coordinate ((limit centers).compute n).lo c≤((anchor c).compute j).hi ∧
      ((anchor c).compute j).lo≤coordinate ((limit centers).compute n).hi c := by
  have current (k : Nat) :
      coordinate (centers k) c-2*allowance k≤((anchor c).compute j).hi ∧
      ((anchor c).compute j).lo≤coordinate (centers k) c+2*allowance k := by
    have H := hc c k
    have Hlo := H.1 0 j
    have Hhi := H.2 j 0
    change coordinate (centers k) c-allowance k≤((anchor c).compute j).hi at Hlo
    change ((anchor c).compute j).lo≤coordinate (centers k) c+allowance k at Hhi
    have Hp := allowance_positive k
    constructor <;> grind only
  induction n with
  | zero =>
    cases c <;> exact current 0
  | succ n ih =>
    have H := current (n+1)
    cases c <;>
      simp only [limit,ComplexRaw.cauchyStabilize,ComplexRaw.cauchyStabilizeCompute,
        QBox.intersection,QBox.expand,candidate,QBox.point,coordinate,Bool.false_eq_true,↓reduceIte] at ih H ⊢ <;>
      constructor <;> grind [maxRat2,minRat]

theorem realPart_equiv (centers : Nat → QComplex) (anchor : Bool → RealRaw)
    (hc : ∀ c n,CenterBounds (anchor c) (coordinate (centers n) c) (allowance n)) :
    (limit centers).realPart.Equiv (anchor true) := by
  intro n
  exact (RealRaw.compareAt_overlap_iff _ _ n n).mpr (coordinate_bounds centers anchor hc true n n)

theorem imagPart_equiv (centers : Nat → QComplex) (anchor : Bool → RealRaw)
    (hc : ∀ c n,CenterBounds (anchor c) (coordinate (centers n) c) (allowance n)) :
    (limit centers).imagPart.Equiv (anchor false) := by
  intro n
  exact (RealRaw.compareAt_overlap_iff _ _ n n).mpr (coordinate_bounds centers anchor hc false n n)

theorem widths (centers : Nat → QComplex) (n : Nat) :
    ((limit centers).compute n).width≤4/((n+1:Nat):Rat) ∧
      ((limit centers).compute n).height≤4/((n+1:Nat):Rat) := by
  have Hr := ComplexRaw.cauchyStabilize_width_le_current_expand (candidate := candidate centers) (radius := fun n => 2*allowance n) n
  have Hi := ComplexRaw.cauchyStabilize_height_le_current_expand (candidate := candidate centers) (radius := fun n => 2*allowance n) n
  dsimp only [candidate,QBox.point,QBox.width,QBox.height,allowance] at Hr Hi
  dsimp only [limit,candidate,QBox.point,QBox.width,QBox.height,allowance]
  constructor <;> grind [Rat.div_def]

end ComputableAnalysis.EulerBoxLimit
