import ComputableAnalysis.FTCRealProduct
import ComputableAnalysis.LipschitzIntegralBounds
import ComputableAnalysis.BoundsQuadrature
import ComputableAnalysis.IntegralLaws
import ComputableAnalysis.IntegralValueBounds

/-! An executable proper integral for a supplied sampler and justified
Lipschitz evidence. This is one sufficient construction route; it imposes no
integrand class on other integral constructions. -/
namespace ComputableAnalysis.LipschitzQuadrature
open ComputableCoefficient RealApproximationOrder RawLimit Integral
set_option maxHeartbeats 600000

structure Data (f : Rat → Value) (a b : Rat) where
  ordered : a≤b
  constant : Rat
  nonnegative : 0≤constant
  lipschitz : LipschitzIntegralBounds.Lipschitz f a b constant

def Data.tests {f : Rat → Value} {a b : Rat} (D : Data f a b) (n : Nat) :
    Bounds (LipschitzIntegralBounds.onInterval f a b) :=
  LipschitzIntegralBounds.bounds f a b D.constant D.ordered D.lipschitz D.nonnegative
    ⟨allowance n,allowance_pos n⟩

theorem Data.tests_shrink {f : Rat → Value} {a b : Rat} (D : Data f a b) :
    ShrinksToZero (fun n => (D.tests n).upperSum-(D.tests n).lowerSum) := by
  intro eps
  obtain ⟨N,hN⟩ := allowance_shrinks eps
  refine ⟨N,fun n hn => ?_⟩
  exact Rat.le_trans (LipschitzIntegralBounds.bounds_gap f a b D.constant D.ordered D.lipschitz D.nonnegative
    ⟨allowance n,allowance_pos n⟩) (hN n hn)

def Data.integral {f : Rat → Value} {a b : Rat} (D : Data f a b) : RealRaw :=
  if a=b then RealRaw.ofRat 0 else
    BoundsQuadrature.raw (LipschitzIntegralBounds.onInterval f a b) D.tests

private theorem zero_sums (f : Rat → Value) (a : Rat)
    (B : Bounds (LipschitzIntegralBounds.onInterval f a a)) : B.lowerSum=0 ∧ B.upperSum=0 := by
  have point (k : Nat) (hk : k≤B.partition.pieces) : B.partition.point k=a := by
    have H := B.partition.point_in_bounds hk
    change a≤B.partition.point k ∧ B.partition.point k≤a at H
    grind only
  have zero (w : Nat → Rat) :
      rectangleSum (fun k => (B.partition.point (k+1)-B.partition.point k)*w k) B.partition.pieces=0 := by
    have H : rectangleSum (fun k => (B.partition.point (k+1)-B.partition.point k)*w k) B.partition.pieces=
        rectangleSum (fun _ => 0) B.partition.pieces := by
      apply rectangleSum_congr
      intro k hk
      rw [point k (by omega),point (k+1) (by omega),Rat.sub_self,Rat.zero_mul]
    rw [H,rectangleSum_zero]
  exact ⟨zero B.lower,zero B.upper⟩

theorem Data.hasIntegral {f : Rat → Value} {a b : Rat} (D : Data f a b) :
    HasIntegral (LipschitzIntegralBounds.onInterval f a b) D.integral := by
  by_cases h : a=b
  · subst b
    simp only [Data.integral,if_pos rfl]
    refine ⟨RealRaw.ofRat_valid 0,?_,LipschitzIntegralBounds.tight f a a D.constant D.ordered D.lipschitz D.nonnegative⟩
    intro B n
    have H := zero_sums f a B
    change B.lowerSum≤0 ∧ 0≤B.upperSum
    rw [H.1,H.2]
    exact ⟨Rat.le_refl,Rat.le_refl⟩
  · simp only [Data.integral,if_neg h]
    exact BoundsQuadrature.hasIntegral _ D.tests D.tests_shrink

def Data.value {f : Rat → Value} {a b : Rat} (D : Data f a b) : Value :=
  parameter D.integral D.hasIntegral.valid

theorem Data.identify {f : Rat → Value} {a b : Rat} (D : Data f a b) {I : RealRaw}
    (hI : HasIntegral (LipschitzIntegralBounds.onInterval f a b) I) : D.integral.Equiv I :=
  D.hasIntegral.unique hI

def Data.restrict {f : Rat → Value} {a b : Rat} (D : Data f a b)
    (u v : Rat) (hu : a≤u) (huv : u≤v) (hv : v≤b) : Data f u v where
  ordered := huv
  constant := D.constant
  nonnegative := D.nonnegative
  lipschitz x y hx hxy hy := D.lipschitz x y (Rat.le_trans hu hx) hxy (Rat.le_trans hy hv)

def Data.add {f g : Rat → Value} {a b : Rat} (D : Data f a b) (E : Data g a b) :
    Data (fun t => Value.add (f t) (g t)) a b where
  ordered := D.ordered
  constant := D.constant+E.constant
  nonnegative := Rat.add_nonneg D.nonnegative E.nonnegative
  lipschitz := by
    intro u v hu huv hv
    have H := (D.lipschitz u v hu huv hv).add (E.lipschitz u v hu huv hv)
    have he : D.constant*(v-u)+E.constant*(v-u)=(D.constant+E.constant)*(v-u) := by grind only
    rw [he] at H
    apply H.congr
    apply arithmetic_identity; intro s; simp only [Value.add,sub]; grind only

def Data.scale {f : Rat → Value} {a b : Rat} (D : Data f a b) (c : Rat) :
    Data (fun t => RealApproximationOrder.scale c (f t)) a b where
  ordered := D.ordered
  constant := qabs c*D.constant
  nonnegative := Rat.mul_nonneg (qabs_nonneg c) D.nonnegative
  lipschitz := by
    intro u v hu huv hv
    have H := FTCRealCalculus.scale_small (D.lipschitz u v hu huv hv) c
    have he : qabs c*(D.constant*(v-u))=(qabs c*D.constant)*(v-u) := by grind only
    rw [he] at H
    apply H.congr
    apply arithmetic_identity; intro s; simp only [RealApproximationOrder.scale,sub]; grind only

def Data.neg {f : Rat → Value} {a b : Rat} (D : Data f a b) : Data (fun t => Value.neg (f t)) a b where
  ordered := D.ordered
  constant := D.constant
  nonnegative := D.nonnegative
  lipschitz := by
    intro u v hu huv hv
    apply (D.lipschitz u v hu huv hv).neg.congr
    apply arithmetic_identity; intro s; simp only [Value.neg,sub]; grind only

def Data.subtract {f g : Rat → Value} {a b : Rat} (D : Data f a b) (E : Data g a b) :
    Data (fun t => sub (f t) (g t)) a b where
  ordered := D.ordered
  constant := D.constant+E.constant
  nonnegative := Rat.add_nonneg D.nonnegative E.nonnegative
  lipschitz := by
    intro u v hu huv hv
    have H := (D.lipschitz u v hu huv hv).add (E.lipschitz u v hu huv hv).neg
    have he : D.constant*(v-u)+E.constant*(v-u)=(D.constant+E.constant)*(v-u) := by grind only
    rw [he] at H
    apply H.congr
    apply arithmetic_identity; intro s; simp only [Value.add,Value.neg,sub]; grind only

theorem Data.small {f : Rat → Value} {a b : Rat} (D : Data f a b) (B : Rat)
    (hB : ∀ t,a≤t → t≤b → Small (f t) B) : Small D.value ((b-a)*B) := by
  have hl := D.hasIntegral.lower_bound (-B) (fun t ht n => (hB t ht.1 ht.2).1 0 n)
  have hu := D.hasIntegral.upper_bound B (fun t ht n => (hB t ht.1 ht.2).2 n 0)
  constructor
  · intro i j
    have h := hl 0 j
    change (b-a)*(-B)≤(D.integral.compute j).hi at h
    change -((b-a)*B)≤(D.integral.compute j).hi
    grind only
  · exact hu

/-- The algorithmic choices disappear from the public integral law. -/
theorem Data.add_identity {f g : Rat → Value} {a b : Rat} (D : Data f a b) (E : Data g a b) :
    (D.add E).integral.Equiv (D.integral+E.integral) :=
  D.hasIntegral.add_identity E.hasIntegral (D.add E).hasIntegral rfl rfl rfl rfl
    (by intro t _ _ _; exact RealRaw.equiv_refl _ (Value.add (f t) (g t)).real.valid)

def Data.mul {f g : Rat → Value} {a b : Rat} (D : Data f a b) (E : Data g a b)
    (B C : Rat) (hB : 0≤B) (hC : 0≤C)
    (bf : ∀ t,a≤t → t≤b → Small (f t) B)
    (bg : ∀ t,a≤t → t≤b → Small (g t) C) : Data (fun t => Value.mul (f t) (g t)) a b where
  ordered := D.ordered
  constant := D.constant*C+B*E.constant
  nonnegative := Rat.add_nonneg (Rat.mul_nonneg D.nonnegative hC) (Rat.mul_nonneg hB E.nonnegative)
  lipschitz := FTCRealCalculus.product_lipschitz f g a b D.constant E.constant B C D.lipschitz E.lipschitz bf bg

theorem Data.congr {f g : Rat → Value} {a b : Rat} (D : Data f a b) (E : Data g a b)
    (he : ∀ t,a≤t → t≤b → (f t).real.preferred.Equiv (g t).real.preferred) : D.integral.Equiv E.integral :=
  (D.hasIntegral.congrFunction (G := LipschitzIntegralBounds.onInterval g a b) ⟨rfl,rfl,fun t ht _ => he t ht.1 ht.2⟩).unique E.hasIntegral

theorem Data.scale_identity {f : Rat → Value} {a b : Rat} (D : Data f a b) (c : Rat) :
    (D.scale c).integral.Equiv (RealRaw.scaleRat c D.integral) :=
  D.hasIntegral.scaleRat_identity (D.scale c).hasIntegral c ⟨rfl,rfl,by
    intro t _ _
    exact RealRaw.equiv_refl _ (RealApproximationOrder.scale c (f t)).real.valid⟩

theorem Data.neg_identity {f : Rat → Value} {a b : Rat} (D : Data f a b) :
    D.neg.integral.Equiv (-D.integral) := by
  have H := (D.scale (-1)).congr D.neg (by
    intro t _ _
    apply arithmetic_identity; intro s; simp only [RealApproximationOrder.scale,Value.neg]; grind only)
  have S := D.scale_identity (-1)
  have C : (RealRaw.scaleRat (-1) D.integral).Equiv (-D.integral) := by
    apply arithmetic_identity (RealApproximationOrder.scale (-1) D.value) (Value.neg D.value)
    intro s; simp only [RealApproximationOrder.scale,Value.neg]; grind only
  exact RealRaw.equiv_trans D.neg.hasIntegral.valid (D.scale (-1)).hasIntegral.valid
    (RealRaw.neg_valid D.hasIntegral.valid) (RealRaw.equiv_symm H)
    (RealRaw.equiv_trans (D.scale (-1)).hasIntegral.valid (RealRaw.scaleRat_valid D.hasIntegral.valid)
      (RealRaw.neg_valid D.hasIntegral.valid) S C)

theorem Data.subtract_identity {f g : Rat → Value} {a b : Rat} (D : Data f a b) (E : Data g a b) :
    (D.subtract E).integral.Equiv (D.integral-E.integral) := by
  have H := (D.add E.neg).congr (D.subtract E) (by
    intro t _ _
    apply arithmetic_identity; intro s; simp only [Value.add,Value.neg,sub]; grind only)
  have S := (D.add_identity E.neg)
  have A := RealRaw.add_equiv D.hasIntegral.valid D.hasIntegral.valid E.neg.hasIntegral.valid
    (RealRaw.neg_valid E.hasIntegral.valid) (RealRaw.equiv_refl _ D.hasIntegral.valid) E.neg_identity
  have C : (D.integral+(-E.integral)).Equiv (D.integral-E.integral) := by
    apply arithmetic_identity (Value.add D.value (Value.neg E.value)) (sub D.value E.value)
    intro s; simp only [Value.add,Value.neg,sub]; grind only
  exact RealRaw.equiv_trans (D.subtract E).hasIntegral.valid (D.add E.neg).hasIntegral.valid
    (RealRaw.sub_valid D.hasIntegral.valid E.hasIntegral.valid) (RealRaw.equiv_symm H)
    (RealRaw.equiv_trans (D.add E.neg).hasIntegral.valid (RealRaw.add_valid D.hasIntegral.valid E.neg.hasIntegral.valid)
      (RealRaw.sub_valid D.hasIntegral.valid E.hasIntegral.valid) S
      (RealRaw.equiv_trans (RealRaw.add_valid D.hasIntegral.valid E.neg.hasIntegral.valid)
        (RealRaw.add_valid D.hasIntegral.valid (RealRaw.neg_valid E.hasIntegral.valid))
        (RealRaw.sub_valid D.hasIntegral.valid E.hasIntegral.valid) A C))

theorem Data.difference_small {f g : Rat → Value} {a b : Rat} (D : Data f a b) (E : Data g a b)
    (B : Rat) (hb : ∀ t,a≤t → t≤b → Small (sub (f t) (g t)) B) :
    Small (sub D.value E.value) ((b-a)*B) :=
  ((D.subtract E).small B hb).congr (D.subtract_identity E)

/-- Interval additivity for independently computed compact quadratures. -/
theorem Data.append {f : Rat → Value} {a b c : Rat}
    (D : Data f a b) (E : Data f b c) (F : Data f a c) :
    F.integral.Equiv (D.integral+E.integral) := by
  let G := LipschitzIntegralBounds.onInterval f a c
  have hD : HasIntegral (G.restrict a b Rat.le_refl D.ordered E.ordered) D.integral :=
    D.hasIntegral.congrFunction (G := G.restrict a b Rat.le_refl D.ordered E.ordered)
      ⟨rfl,rfl,by intro t _ _ n; exact (RealRaw.equiv_refl (f t).real.preferred (f t).real.valid) n⟩
  have hE : HasIntegral (G.restrict b c D.ordered E.ordered Rat.le_refl) E.integral :=
    E.hasIntegral.congrFunction (G := G.restrict b c D.ordered E.ordered Rat.le_refl)
      ⟨rfl,rfl,by intro t _ _ n; exact (RealRaw.equiv_refl (f t).real.preferred (f t).real.valid) n⟩
  exact HasIntegral.append_identity (F := G) b D.ordered E.ordered hD hE F.hasIntegral

end ComputableAnalysis.LipschitzQuadrature
