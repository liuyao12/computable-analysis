import ComputableAnalysis.ArctanSecantFoundation
import ComputableAnalysis.GeometricSinCos
import ComputableAnalysis.LipschitzQuadrature
import ComputableAnalysis.RealValueCongruence

/-! Geometric arctangent FTC on the unit slope interval and rational
kernel estimates on the positive half line. -/
namespace ComputableAnalysis.ArctanPositiveFTC
open ComputableCoefficient RealApproximationOrder FTCRealOrder FTCRealCalculus
open ArctanGeometry LipschitzQuadrature
set_option maxHeartbeats 600000

private theorem sub_hi (x y : RealRaw) (n : Nat) : ((x-y).compute n).hi=(x.compute n).hi-(y.compute n).lo := by rfl
private theorem sub_lo (x y : RealRaw) (n : Nat) : ((x-y).compute n).lo=(x.compute n).lo-(y.compute n).hi := by rfl
private theorem scale_hi (c : Rat) (x : RealRaw) (n : Nat) (hc : 0≤c) :
    ((RealRaw.scaleRat c x).compute n).hi=c*(x.compute n).hi := by simp only [RealRaw.scaleRat,RealRaw.scaleRatCompute,if_pos hc]
private theorem scale_lo (c : Rat) (x : RealRaw) (n : Nat) (hc : 0≤c) :
    ((RealRaw.scaleRat c x).compute n).lo=c*(x.compute n).lo := by simp only [RealRaw.scaleRat,RealRaw.scaleRatCompute,if_pos hc]

def atan (q : Rat) : Value := if h : 0≤q ∧ q≤1 then
  parameter (ArctanSecantFoundation.value q) (ArctanSecantFoundation.value_valid h) else Value.rational 0

def kernel (q : Rat) : Value := Value.rational (integralKernel q)

theorem kernel_variation (u v : Rat) (hu : 0≤u) (huv : u≤v) :
    0≤integralKernel u-integralKernel v ∧ integralKernel u-integralKernel v≤2*(v-u) := by
  have hv : 0≤v := Rat.le_trans hu huv
  have U := RationalCircle.Stage.one_add_square_pos u
  have V := RationalCircle.Stage.one_add_square_pos v
  have uc := Rat.mul_inv_cancel (1+u*u) (Rat.ne_of_gt U)
  have vc := Rat.mul_inv_cancel (1+v*v) (Rat.ne_of_gt V)
  have up : 0≤(1+u*u)⁻¹ := Rat.le_of_lt (Rat.inv_pos.mpr U)
  have vp : 0≤(1+v*v)⁻¹ := Rat.le_of_lt (Rat.inv_pos.mpr V)
  have ub := integralKernel_le_one u
  have vb := integralKernel_le_one v
  simp only [integralKernel,Rat.div_def,Rat.one_mul] at ub vb
  have us := RationalCircle.Stage.ratSquare_nonneg (u-1)
  have vs := RationalCircle.Stage.ratSquare_nonneg (v-1)
  have ut : u≤1+u*u := by grind only
  have vt : v≤1+v*v := by grind only
  have ur := Rat.mul_le_mul_of_nonneg_right ut up
  have vr := Rat.mul_le_mul_of_nonneg_right vt vp
  have ur' : u*(1+u*u)⁻¹≤1 := by grind only
  have vr' : v*(1+v*v)⁻¹≤1 := by grind only
  have A := rat_mul_le_mul_of_nonneg (Rat.mul_nonneg hu up) ur' vp vb
  have B := rat_mul_le_mul_of_nonneg (Rat.mul_nonneg hv vp) vr' up ub
  have F : (u+v)*((1+u*u)⁻¹*(1+v*v)⁻¹)≤2 := by grind only
  have H := Rat.mul_le_mul_of_nonneg_left F (by grind only : 0≤v-u)
  have eq : integralKernel u-integralKernel v=(v-u)*(u+v)*((1+u*u)⁻¹*(1+v*v)⁻¹) := by
    simp only [integralKernel,Rat.div_def,Rat.one_mul]; grind only
  constructor
  · have M := integralKernel_antitone_nonneg hu huv; grind only
  · rw [eq]; grind only

theorem kernel_lipschitz (l r : Rat) (hl : 0≤l) : LipschitzIntegralBounds.Lipschitz kernel l r 2 := by
  intro u v hu huv _
  have H := kernel_variation u v (Rat.le_trans hl hu) huv
  constructor
  · intro i j; change -(2*(v-u))≤integralKernel v-integralKernel u; grind only
  · intro i j; change integralKernel v-integralKernel u≤2*(v-u); grind only

def kernelData (l r : Rat) (hl : 0≤l) (hlr : l≤r) : Data kernel l r where
  ordered := hlr
  constant := 2
  nonnegative := by decide +kernel
  lipschitz := kernel_lipschitz l r hl

theorem increment (u v : Rat) (hu : 0≤u) (huv : u≤v) (hv : v≤1) :
    LE (Value.rational ((v-u)*integralKernel v)) (sub (atan v) (atan u)) ∧
    LE (sub (atan v) (atan u)) (Value.rational ((v-u)*integralKernel u)) := by
  have ud : 0≤u ∧ u≤1 := ⟨hu,Rat.le_trans huv hv⟩
  have vd : 0≤v ∧ v≤1 := ⟨Rat.le_trans hu huv,hv⟩
  constructor
  · intro i j
    have H := (ArctanSecantFoundation.increment_bounds hu huv j).1
    simpa only [atan,dif_pos ud,dif_pos vd,sub,parameter,Value.parameter,Real.ofRaw,Value.rational,Real.ofRat,RealRaw.ofRat,RealRaw.instHSub,RealRaw.sub,RealRaw.subCompute,sub_hi,sub_lo] using H
  · intro i j
    have H := (ArctanSecantFoundation.increment_bounds hu huv i).2
    simpa only [atan,dif_pos ud,dif_pos vd,sub,parameter,Value.parameter,Real.ofRaw,Value.rational,Real.ofRat,RealRaw.ofRat,RealRaw.instHSub,RealRaw.sub,RealRaw.subCompute,sub_hi,sub_lo] using H

def step : Step atan kernel 0 1 where
  error := 2
  error_nonnegative := by decide +kernel
  radius := ⟨1,by decide +kernel⟩
  firstOrder := by
    intro u v hu huv hv _
    have H := increment u v hu (Rat.le_of_lt huv) hv
    have K := kernel_variation u v hu (Rat.le_of_lt huv)
    have Q := Rat.mul_le_mul_of_nonneg_left K.2 (by grind only : 0≤v-u)
    constructor
    · intro i j
      simp only [sub,scale,kernel,Value.rational,Real.ofRat,Real.ofRaw,RealRaw.ofRat,RealRaw.scaleRat]
      have A := H.1 0 j
      change (v-u)*integralKernel v≤((atan v).real.compute j).hi-((atan u).real.compute j).lo at A
      rw [sub_hi,sub_hi]
      simp only [RealRaw.scaleRatCompute,if_pos (show 0≤v-u by grind only)]
      change -(2*(v-u)*(v-u))≤((atan v).real.compute j).hi-((atan u).real.compute j).lo-(v-u)*integralKernel u
      grind only
    · intro i j
      simp only [sub,scale,kernel,Value.rational,Real.ofRat,Real.ofRaw,RealRaw.ofRat,RealRaw.scaleRat]
      have A := H.2 i 0
      change ((atan v).real.compute i).lo-((atan u).real.compute i).hi≤(v-u)*integralKernel u at A
      rw [sub_lo,sub_lo]
      simp only [RealRaw.scaleRatCompute,if_pos (show 0≤v-u by grind only)]
      change ((atan v).real.compute i).lo-((atan u).real.compute i).hi-(v-u)*integralKernel u≤2*(v-u)*(v-u)
      have P := Rat.mul_nonneg (by grind only : 0≤v-u) (by grind only : 0≤v-u)
      grind only
  variation := 2
  variation_nonnegative := by decide +kernel
  lipschitz := kernel_lipschitz 0 1 Rat.le_refl

theorem atan_zero : Same (atan 0) (Value.rational 0) := by
  change (atan 0).real.preferred.Equiv (RealRaw.ofRat 0)
  simp only [atan,dif_pos (show (0:Rat)≤0 ∧ (0:Rat)≤1 by decide +kernel)]
  have H := arctanScheduledRectangleRaw_equiv_arctanGeom (x := (0:Rat)) (by decide +kernel) (by decide +kernel)
  rw [arctanGeom_zero] at H
  exact H

theorem atan_small (q : Rat) (hq : 0≤q) (hq1 : q≤1) : Small (atan q) q := by
  have H := increment 0 q Rat.le_refl hq hq1
  have lo := H.1
  have up := H.2
  have kz : integralKernel 0=1 := by decide +kernel
  have H' : Small (sub (atan q) (atan 0)) q := by
    constructor
    · intro i j
      have A := lo 0 j
      have P := Rat.mul_nonneg hq (Rat.le_of_lt (integralKernel_pos q))
      change (q-0)*integralKernel q≤((atan q).real.compute j).hi-((atan 0).real.compute j).lo at A
      change -q≤((atan q).real.compute j).hi-((atan 0).real.compute j).lo
      grind only
    · intro i j
      have A := up i 0
      change ((atan q).real.compute i).lo-((atan 0).real.compute i).hi≤q
      change ((atan q).real.compute i).lo-((atan 0).real.compute i).hi≤(q-0)*integralKernel 0 at A
      rw [kz] at A
      grind only
  have A := (Same.refl (atan q)).sub atan_zero
  have B : Same (sub (atan q) (Value.rational 0)) (atan q) := by
    apply arithmetic_identity; intro s; simp only [sub,Value.rational]; grind only
  exact H'.congr (A.trans B)

end ComputableAnalysis.ArctanPositiveFTC
