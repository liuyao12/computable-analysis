import ComputableAnalysis.LipschitzQuadrature
import ComputableAnalysis.RealValueCongruence

/-! Actual represented tagged sums approximate the independent proper integral. -/
namespace ComputableAnalysis.LipschitzQuadrature
open ComputableCoefficient RealApproximationOrder FTCRealOrder FTCRealCalculus
set_option maxHeartbeats 800000
set_option autoImplicit false

def constantData (K : Value) (a b : Rat) (hab : a≤b) : Data (fun _ => K) a b where
  ordered := hab
  constant := 0
  nonnegative := by decide +kernel
  lipschitz := by
    intro u v _ _ _
    have H := rational_small 0
    rw [show qabs (0:Rat)=0 by decide +kernel] at H
    simp only [Rat.zero_mul]
    apply H.congr
    apply arithmetic_identity; intro s; simp only [sub,Value.rational]; grind only

theorem constant_value (K : Value) (a b : Rat) (hab : a≤b) :
    Same (constantData K a b hab).value (RealApproximationOrder.scale (b-a) K) :=
  by
    have H := Integral.constant_hasIntegral K.real.preferred K.real.valid a b hab
    have H' : Integral.HasIntegral (LipschitzIntegralBounds.onInterval (fun _ => K) a b)
        (RealRaw.scaleRat (b-a) K.real.preferred) := H.congrFunction ⟨rfl,rfl,by
      intro t _ _
      exact RealRaw.equiv_refl _ K.real.valid⟩
    exact (constantData K a b hab).identify H' 

theorem Data.tag_error {f : Rat → Value} {a b : Rat} (D : Data f a b)
    (t : Rat) (ht : a≤t) (htb : t≤b) :
    Small (sub D.value (RealApproximationOrder.scale (b-a) (f t))) (D.constant*(b-a)*(b-a)) := by
  let C := constantData (f t) a b D.ordered
  have pointwise : ∀ q,a≤q → q≤b → Small (sub (f q) (f t)) (D.constant*(b-a)) := by
    intro q hq hqb
    by_cases h : t≤q
    · exact (D.lipschitz t q ht h hqb).mono (by
        have H := Rat.mul_le_mul_of_nonneg_left (show q-t≤b-a by grind only) D.nonnegative
        exact H)
    · have hqt : q≤t := by grind only
      have H := (D.lipschitz q t hq hqt htb).neg
      have A : Same (Value.neg (sub (f t) (f q))) (sub (f q) (f t)) := by
        apply arithmetic_identity; intro s; simp only [sub,Value.neg]; grind only
      exact (H.congr A).mono (by
        have H := Rat.mul_le_mul_of_nonneg_left (show t-q≤b-a by grind only) D.nonnegative
        exact H)
  have H := D.difference_small C (D.constant*(b-a)) pointwise
  have A : Same (sub D.value C.value) (sub D.value (RealApproximationOrder.scale (b-a) (f t))) :=
    (Same.refl D.value).sub (constant_value (f t) a b D.ordered)
  exact (H.congr A).mono (by grind only)

def taggedSum {a b : Rat} (f : Rat → Value) (P : RationalPartition a b) (tag : Nat → Rat) : Nat → Value
  | 0 => Value.rational 0
  | k+1 => Value.add (taggedSum f P tag k) (RealApproximationOrder.scale (P.point (k+1)-P.point k) (f (tag k)))

theorem zero_value {f : Rat → Value} {a : Rat} (D : Data f a a) : Same D.value (Value.rational 0) := by
  change D.integral.Equiv (RealRaw.ofRat 0)
  simp only [Data.integral]
  exact RealRaw.equiv_refl _ (RealRaw.ofRat_valid 0)

theorem zero_value_of_eq {f : Rat → Value} {a b : Rat} (D : Data f a b) (h : b=a) : Same D.value (Value.rational 0) := by
  subst b
  exact zero_value D

theorem Data.tagged_prefix_error {f : Rat → Value} {a b : Rat} (D : Data f a b)
    (P : RationalPartition a b) (tag : Nat → Rat) (h : Rat) (_hh : 0≤h)
    (width : ∀ k,k<P.pieces → P.point (k+1)-P.point k≤h)
    (tags : ∀ k,k<P.pieces → P.point k≤tag k ∧ tag k≤P.point (k+1))
    (k : Nat) (hk : k≤P.pieces) :
    Small (sub (D.restrict a (P.point k) Rat.le_refl (P.point_in_bounds hk).1 (P.point_in_bounds hk).2).value
      (taggedSum f P tag k)) (D.constant*(P.point k-a)*h) := by
  induction k with
  | zero =>
    simp only [P.left_endpoint,taggedSum]
    have Z := zero_value_of_eq (D.restrict a (P.point 0) Rat.le_refl (P.point_in_bounds hk).1 (P.point_in_bounds hk).2) P.left_endpoint
    have B := rational_small 0
    rw [show qabs (0:Rat)=0 by decide +kernel] at B
    have A : Same (sub (D.restrict a (P.point 0) Rat.le_refl (P.point_in_bounds hk).1 (P.point_in_bounds hk).2).value (Value.rational 0)) (Value.rational 0) := by
      apply ((Z.sub (Same.refl (Value.rational 0))).trans)
      apply arithmetic_identity; intro s; simp only [sub,Value.rational]; grind only
    have E : D.constant*(a-a)*h=0 := by grind only
    rw [E]
    exact B.congr A.symm
  | succ k ih =>
    have hk' : k<P.pieces := by omega
    have hkle : k≤P.pieces := by omega
    have hstep := P.monotone k (k+1) (by omega) hk
    let L := D.restrict a (P.point k) Rat.le_refl (P.point_in_bounds hkle).1 (P.point_in_bounds hkle).2
    let U := D.restrict (P.point k) (P.point (k+1)) (P.point_in_bounds hkle).1 hstep (P.point_in_bounds hk).2
    let V := D.restrict a (P.point (k+1)) Rat.le_refl (P.point_in_bounds hk).1 (P.point_in_bounds hk).2
    have HU := U.tag_error (tag k) (tags k hk').1 (tags k hk').2
    have dw : 0≤P.point (k+1)-P.point k := by grind only
    have mult := Rat.mul_le_mul_of_nonneg_left (width k hk') (Rat.mul_nonneg D.nonnegative dw)
    have HU' : Small (sub U.value (RealApproximationOrder.scale (P.point (k+1)-P.point k) (f (tag k))))
        (D.constant*(P.point (k+1)-P.point k)*h) := HU.mono mult
    have H := (ih hkle).add HU'
    have S : Same V.value (Value.add L.value U.value) := L.append U V
    have A : Same (sub V.value (taggedSum f P tag (k+1)))
        (Value.add (sub L.value (taggedSum f P tag k))
          (sub U.value (RealApproximationOrder.scale (P.point (k+1)-P.point k) (f (tag k))))) := by
      apply (S.sub (Same.refl _)).trans
      apply arithmetic_identity; intro s; simp only [taggedSum,sub,Value.add]; grind only
    exact (H.congr A.symm).mono (by grind only)

theorem Data.tagged_error {f : Rat → Value} {a b : Rat} (D : Data f a b)
    (P : RationalPartition a b) (tag : Nat → Rat) (h : Rat) (hh : 0≤h)
    (width : ∀ k,k<P.pieces → P.point (k+1)-P.point k≤h)
    (tags : ∀ k,k<P.pieces → P.point k≤tag k ∧ tag k≤P.point (k+1)) :
    Small (sub D.value (taggedSum f P tag P.pieces)) (D.constant*(b-a)*h) := by
  have H := D.tagged_prefix_error P tag h hh width tags P.pieces (Nat.le_refl _)
  let E := D.restrict a (P.point P.pieces) Rat.le_refl (P.point_in_bounds (Nat.le_refl _)).1 (P.point_in_bounds (Nat.le_refl _)).2
  have HI : Integral.HasIntegral (LipschitzIntegralBounds.onInterval f a b) E.integral :=
    E.hasIntegral.congrFunction ⟨rfl,P.right_endpoint,by intro t _ _; exact RealRaw.equiv_refl _ (f t).real.valid⟩
  have B : Same E.value D.value := HI.unique D.hasIntegral
  have T := H.congr (B.sub (Same.refl (taggedSum f P tag P.pieces)))
  simpa only [P.right_endpoint] using T

def midpointTag (a b : Rat) (M k : Nat) : Rat := a+((k:Rat)+1/2)*mesh a b M

def midpointPrefix (f : Rat → Value) (a b : Rat) (M : Nat) : Nat → Value
  | 0 => Value.rational 0
  | k+1 => Value.add (midpointPrefix f a b M k) (RealApproximationOrder.scale (mesh a b M) (f (midpointTag a b M k)))

theorem Data.midpoint_error {f : Rat → Value} {a b : Rat} (D : Data f a b) (M : Nat) (hM : 0<M) :
    Small (sub D.value (midpointPrefix f a b M M)) (D.constant*(b-a)*mesh a b M) := by
  let P := RationalPartition.uniform a b M hM D.ordered
  let h := mesh a b M
  have nonnegative : 0≤h := (RationalPartition.uniform_maxStepAtMost_mesh a b M hM D.ordered).1
  have step (k : Nat) : P.point (k+1)-P.point k=h := by
    simp only [P,RationalPartition.uniform,leftPoint,Rat.natCast_add]
    change (a+((k:Rat)+1)*h)-(a+(k:Rat)*h)=h
    grind only
  have tags (k : Nat) (_hk : k<P.pieces) : P.point k≤midpointTag a b M k ∧ midpointTag a b M k≤P.point (k+1) := by
    simp only [P,RationalPartition.uniform,leftPoint,midpointTag,Rat.natCast_add]
    change a+(k:Rat)*h≤a+((k:Rat)+1/2)*h ∧ a+((k:Rat)+1/2)*h≤a+((k:Rat)+1)*h
    constructor <;> grind only
  have H := D.tagged_error P (midpointTag a b M) h nonnegative (fun k _ => by rw [step]; exact Rat.le_refl) tags
  have S (k : Nat) : taggedSum f P (midpointTag a b M) k=midpointPrefix f a b M k := by
    induction k with
    | zero => rfl
    | succ k ih => simp only [taggedSum,midpointPrefix,step,ih]; rfl
  rw [S] at H
  exact H

end ComputableAnalysis.LipschitzQuadrature
