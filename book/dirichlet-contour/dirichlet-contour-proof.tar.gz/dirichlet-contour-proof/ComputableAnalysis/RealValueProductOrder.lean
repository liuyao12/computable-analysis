import ComputableAnalysis.FTCRealOrder
import ComputableAnalysis.RealIntervalImage

/-! Product order from common rational points in actual interval boxes.
These laws use represented value order, not decidable real comparisons. -/
namespace ComputableAnalysis.RealApproximationOrder
open ComputableCoefficient FTCRealOrder
set_option maxHeartbeats 600000

theorem mul_nonnegative (X Y : Value) (hX : LE (Value.rational 0) X) (hY : LE (Value.rational 0) Y) :
    LE (Value.rational 0) (Value.mul X Y) := by
  intro i j
  have xhi := hX 0 j
  have yhi := hY 0 j
  have xo := RealRaw.interval_order_of_valid _ X.real.valid j
  have yo := RealRaw.interval_order_of_valid _ Y.real.valid j
  let x := max 0 (X.real.compute j).lo
  let y := max 0 (Y.real.compute j).lo
  have hx : 0≤x ∧ (X.real.compute j).lo≤x ∧ x≤(X.real.compute j).hi := by
    change 0≤(X.real.compute j).hi at xhi
    change (X.real.compute j).lo≤(X.real.compute j).hi at xo
    dsimp [x]; rw [Rat.max_def]; split <;> grind only
  have hy : 0≤y ∧ (Y.real.compute j).lo≤y ∧ y≤(Y.real.compute j).hi := by
    change 0≤(Y.real.compute j).hi at yhi
    change (Y.real.compute j).lo≤(Y.real.compute j).hi at yo
    dsimp [y]; rw [Rat.max_def]; split <;> grind only
  have hp := QBox.mulRealInterval_contains hx.2.1 hx.2.2 hy.2.1 hy.2.2
  exact Rat.le_trans (Rat.mul_nonneg hx.1 hy.1) hp.2

/-- A multiplier between -1 and 1 preserves the symmetric bound determined
by a nonpositive factor, even when its name straddles zero. -/
theorem unit_mul_nonpositive (P D : Value) (hP : Small P 1) (hD : LE D (Value.rational 0)) :
    LE D (Value.mul P D) ∧ LE (Value.mul P D) (Value.neg D) := by
  have common (i j : Nat) : ∃ p d,
      -1≤p ∧ p≤1 ∧ (P.real.compute i).lo≤p ∧ p≤(P.real.compute i).hi ∧
      (D.real.compute i).lo≤d ∧ d≤(D.real.compute i).hi ∧ d≤0 ∧ (D.real.compute j).lo≤d := by
    obtain ⟨p,hp,hp',hp0,hp1⟩ := RealIntervalImage.common_point P.real.valid (I := {lo := -1,hi := 1}) hP i
    let d := min (D.real.compute i).hi 0
    have hi := hD i 0
    have hj := hD j 0
    have ho := RealRaw.interval_order_of_valid _ D.real.valid i
    have hc := RealRaw.le_refl _ D.real.valid j i
    change (D.real.compute i).lo≤0 at hi
    change (D.real.compute j).lo≤0 at hj
    change (D.real.compute i).lo≤(D.real.compute i).hi at ho
    change (D.real.compute j).lo≤(D.real.compute i).hi at hc
    refine ⟨p,d,hp,hp',hp0,hp1,?_,?_,?_,?_⟩
    all_goals dsimp [d]; rw [Rat.min_def]; split <;> grind only
  constructor
  · intro i j
    obtain ⟨p,d,hp,hp',hp0,hp1,hd0,hd1,hd,hdj⟩ := common j i
    have H := QBox.mulRealInterval_contains hp0 hp1 hd0 hd1
    have hm := rat_mul_le_mul_of_nonpos_left hp' hd
    change d*1≤d*p at hm
    have hpd : d≤p*d := by grind only
    change (D.real.compute i).lo≤((Value.mul P D).real.compute j).hi
    exact Rat.le_trans hdj (Rat.le_trans hpd H.2)
  · intro i j
    obtain ⟨p,d,hp,hp',hp0,hp1,hd0,hd1,hd,hdj⟩ := common i j
    have H := QBox.mulRealInterval_contains hp0 hp1 hd0 hd1
    have hm := rat_mul_le_mul_of_nonpos_left hp hd
    change d*p≤d*(-1) at hm
    have hpd : p*d≤ -d := by grind only
    change ((Value.mul P D).real.compute i).lo≤ -(D.real.compute j).lo
    exact Rat.le_trans H.1 (Rat.le_trans hpd (Rat.neg_le_neg hdj))

theorem unit_mul_nonnegative (P D : Value) (hP : Small P 1) (hD : LE (Value.rational 0) D) :
    LE (Value.neg D) (Value.mul P D) ∧ LE (Value.mul P D) D := by
  have hn : LE (Value.neg D) (Value.rational 0) := by
    intro i j
    have H := hD 0 i
    change 0≤(D.real.compute i).hi at H
    change -(D.real.compute i).hi≤0
    grind only
  have H := unit_mul_nonpositive P (Value.neg D) hP hn
  constructor
  · have A := RealRaw.le_neg_le_neg H.2
    apply le_congr (x := Value.neg (Value.neg (Value.neg D))) (y := Value.neg (Value.mul P (Value.neg D))) A
    · apply arithmetic_identity; intro s; simp only [Value.neg]; grind only
    · apply arithmetic_identity; intro s; simp only [Value.neg,Value.mul]; grind only
  · have A := RealRaw.le_neg_le_neg H.1
    apply le_congr (x := Value.neg (Value.mul P (Value.neg D))) (y := Value.neg (Value.neg D)) A
    · apply arithmetic_identity; intro s; simp only [Value.neg,Value.mul]; grind only
    · apply arithmetic_identity; intro s; simp only [Value.neg]; grind only

theorem mul_le_mul_nonnegative_left (C X Y : Value) (hC : LE (Value.rational 0) C) (h : LE X Y) :
    LE (Value.mul C X) (Value.mul C Y) := by
  have hd : LE (Value.rational 0) (sub Y X) := by
    have H := RealRaw.le_sub_le_sub h (RealRaw.le_refl X.real.preferred X.real.valid)
    apply le_congr (x := sub X X) (y := sub Y X) H
    · apply arithmetic_identity; intro s; simp only [sub,Value.rational]; grind only
    · exact RealRaw.equiv_refl _ (sub Y X).real.valid
  have H := mul_nonnegative C (sub Y X) hC hd
  have A := le_add H (RealRaw.le_refl (Value.mul C X).real.preferred (Value.mul C X).real.valid)
  apply le_congr (x := Value.add (Value.rational 0) (Value.mul C X))
    (y := Value.add (Value.mul C (sub Y X)) (Value.mul C X)) A
  · apply arithmetic_identity; intro s; simp only [Value.add,Value.rational]; grind only
  · apply arithmetic_identity; intro s; simp only [Value.add,Value.mul,sub]; grind only

end ComputableAnalysis.RealApproximationOrder
