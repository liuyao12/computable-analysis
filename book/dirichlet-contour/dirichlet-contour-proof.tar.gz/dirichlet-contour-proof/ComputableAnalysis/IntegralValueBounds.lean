import ComputableAnalysis.IntegralBoundsComparison

/-! Constant bounds for supplied integral witnesses, proved by replacing
one side of an actual rectangle-bound family and telescoping its lengths. -/
namespace ComputableAnalysis.Integral
set_option maxHeartbeats 1000000

theorem HasIntegral.lower_bound {F : FunctionOnInterval} {I : RealRaw} (hI : HasIntegral F I) (c : Rat)
    (hc : ∀ x (hx : inDomainInterval F.lower F.upper x) n,c≤(F.compute x hx n).hi) :
    (RealRaw.ofRat ((F.upper-F.lower)*c)).Le I := by
  obtain ⟨B,_⟩ := hI.tight ⟨1,by decide +kernel⟩
  let A : Bounds F := {
    partition := B.partition
    lower := fun _ => c
    upper := B.upper
    lower_le := fun k hk x hx n => hc x ((B.partition.cell k hk).contains_inDomain hx) n
    upper_ge := B.upper_ge }
  have hs : A.lowerSum=(F.upper-F.lower)*c := by
    change rectangleSum (fun k => (B.partition.point (k+1)-B.partition.point k)*c) B.partition.pieces=_
    rw [rectangleSum_scale,rectangleSum_telescope,B.partition.right_endpoint,B.partition.left_endpoint]
  intro n m
  have h := (hI.bounds A m).1
  rw [hs] at h
  exact h

theorem HasIntegral.upper_bound {F : FunctionOnInterval} {I : RealRaw} (hI : HasIntegral F I) (c : Rat)
    (hc : ∀ x (hx : inDomainInterval F.lower F.upper x) n,(F.compute x hx n).lo≤c) :
    I.Le (RealRaw.ofRat ((F.upper-F.lower)*c)) := by
  obtain ⟨B,_⟩ := hI.tight ⟨1,by decide +kernel⟩
  let A : Bounds F := {
    partition := B.partition
    lower := B.lower
    upper := fun _ => c
    lower_le := B.lower_le
    upper_ge := fun k hk x hx n => hc x ((B.partition.cell k hk).contains_inDomain hx) n }
  have hs : A.upperSum=(F.upper-F.lower)*c := by
    change rectangleSum (fun k => (B.partition.point (k+1)-B.partition.point k)*c) B.partition.pieces=_
    rw [rectangleSum_scale,rectangleSum_telescope,B.partition.right_endpoint,B.partition.left_endpoint]
  intro n m
  have h := (hI.bounds A n).2
  rw [hs] at h
  exact h

theorem HasIntegral.nonnegative {F : FunctionOnInterval} {I : RealRaw} (hI : HasIntegral F I)
    (hc : ∀ x (hx : inDomainInterval F.lower F.upper x) n,0≤(F.compute x hx n).hi) :
    (RealRaw.ofRat 0).Le I := by
  have h := hI.lower_bound 0 hc
  simpa only [Rat.mul_zero] using h

end ComputableAnalysis.Integral
