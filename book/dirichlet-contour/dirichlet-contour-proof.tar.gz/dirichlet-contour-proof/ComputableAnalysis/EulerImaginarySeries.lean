import ComputableAnalysis.EulerImaginaryExtension
import ComputableAnalysis.GeometricTaylorSeries

/-! The factorial series on the normalized imaginary axis agrees with the
Euler ODE computation and the geometric circle computation. The original
series-free ODE and circle proofs are kept in their independent modules. -/
namespace ComputableAnalysis.EulerImaginarySeries
open ComputableCoefficient RealApproximationOrder RawLimit GeometricTrig
open TaylorPolynomialValues
set_option maxHeartbeats 1500000

/-- The real and imaginary coordinates of the exponential factorial series
at i*pi*x. The checked four-phase coefficients are the powers of i. -/
def seriesAt (x : RealRaw) (hx : x.Valid) : ComplexRaw :=
  EulerImaginary.pair (GeometricTaylorSeries.cosTaylorAt x hx) (GeometricTaylorSeries.sinTaylorAt x hx)

theorem seriesAt_valid {x : RealRaw} (hx : x.Valid) : (seriesAt x hx).Valid :=
  EulerImaginary.pair_valid (GeometricTaylorSeries.cosTaylorAt_valid hx) (GeometricTaylorSeries.sinTaylorAt_valid hx)

theorem seriesAt_equiv_circle {x : RealRaw} (hx : x.Valid) :
    (seriesAt x hx).Equiv (EulerImaginary.pair (cosAt x) (sinAt x)) :=
  EulerImaginary.pair_equiv (GeometricTaylorSeries.cos_taylor hx) (GeometricTaylorSeries.sin_taylor hx)

/-- Exact agreement of the imaginary Euler method with its factorial series,
on the whole represented real normalized-angle parameter domain. -/
theorem seriesAt_equiv_euler {x : RealRaw} (hx : x.Valid) :
    (seriesAt x hx).Equiv (EulerImaginary.eval x) :=
  ComplexRaw.equiv_trans (seriesAt_valid hx)
    (EulerImaginary.pair_valid (cosAt_valid hx) (sinAt_valid hx)) (EulerImaginary.eval_valid hx)
    (seriesAt_equiv_circle hx) (ComplexRaw.equiv_symm (EulerImaginary.eval_agrees_circle hx))

theorem seriesAt_congr {x y : RealRaw} (hx : x.Valid) (hy : y.Valid) (h : x.Equiv y) :
    (seriesAt x hx).Equiv (seriesAt y hy) :=
  ComplexRaw.equiv_trans (seriesAt_valid hx) (EulerImaginary.eval_valid hx) (seriesAt_valid hy)
    (seriesAt_equiv_euler hx)
    (ComplexRaw.equiv_trans (EulerImaginary.eval_valid hx) (EulerImaginary.eval_valid hy) (seriesAt_valid hy)
      (EulerImaginary.eval_congr hx hy h) (ComplexRaw.equiv_symm (seriesAt_equiv_euler hy)))

/-- Convergence of all factorial terms, with the usual four-phase cycle,
not just an equality between names of preconstructed sums. -/
theorem real_exponential_series {x : RealRaw} (hx : x.Valid) :
    RepresentedSeries.HasSum (GeometricTaylorSeries.terms true (parameter x hx))
      (EulerImaginary.eval x).realPart :=
  congr_target (GeometricTaylorSeries.full_hasSum true (parameter x hx))
    (EulerImaginary.coordinateAt_valid true hx) (RealRaw.equiv_symm (EulerImaginary.coordinateAt_agrees true hx))

theorem imaginary_exponential_series {x : RealRaw} (hx : x.Valid) :
    RepresentedSeries.HasSum (GeometricTaylorSeries.terms false (parameter x hx))
      (EulerImaginary.eval x).imagPart :=
  congr_target (GeometricTaylorSeries.full_hasSum false (parameter x hx))
    (EulerImaginary.coordinateAt_valid false hx) (RealRaw.equiv_symm (EulerImaginary.coordinateAt_agrees false hx))

/-- The coordinate coefficient cycle is exactly multiplication by i.
This finite identity explains why the pair of real series above is the
complex exponential series, rather than a newly chosen coefficient family. -/
theorem imaginary_power_coordinates (t : Rat) (n : Nat) :
    QComplex.pow ⟨0,t⟩ n=⟨phase n true*t^n,phase n false*t^n⟩ := by
  induction n with
  | zero => simp only [QComplex.pow,phase,Rat.pow_zero]; decide +kernel
  | succ n ih =>
    rw [QComplex.pow,ih]
    simp only [QComplex.mul,phase_succ,Rat.pow_succ,Bool.false_eq_true,↓reduceIte]
    congr 1 <;> grind only

/-- The usual exponential monomial on the imaginary axis, with coefficient
 i^n/n! and real argument pi*x. Its two coordinates are actual real values. -/
def exponentialTerm (c : Bool) (X : Value) (n : Nat) : Value :=
  let coefficient := QComplex.pow ⟨0,1⟩ n
  scale ((if c then coefficient.re else coefficient.im)/factorialRat n) (power (angular X) n)

theorem unit_power_coordinates (n : Nat) :
    (QComplex.pow ⟨0,1⟩ n).re=phase n true ∧ (QComplex.pow ⟨0,1⟩ n).im=phase n false := by
  rw [imaginary_power_coordinates,EulerFinite.one_pow]
  constructor <;> simp only [Rat.mul_one]

theorem exponential_term_agrees (c : Bool) (X : Value) (n : Nat) :
    (GeometricTaylorSeries.terms c X n).real.preferred.Equiv (exponentialTerm c X n).real.preferred := by
  apply arithmetic_identity
  intro s
  cases c <;> simp only [exponentialTerm,GeometricTaylorSeries.terms,TaylorPolynomialValues.term,
    coefficient,scale,unit_power_coordinates,Bool.false_eq_true,↓reduceIte] <;> grind only [Rat.div_def]

/-- Convergence of the actual i^n*(pi*x)^n/n! coordinate series to the
Euler rotation value, for every valid represented input. -/
theorem factorial_series_converges {x : RealRaw} (hx : x.Valid) :
    RepresentedSeries.HasSum (exponentialTerm true (parameter x hx)) (EulerImaginary.eval x).realPart ∧
    RepresentedSeries.HasSum (exponentialTerm false (parameter x hx)) (EulerImaginary.eval x).imagPart :=
  ⟨(real_exponential_series hx).congr_terms (exponential_term_agrees true (parameter x hx)),
   (imaginary_exponential_series hx).congr_terms (exponential_term_agrees false (parameter x hx))⟩

end ComputableAnalysis.EulerImaginarySeries
