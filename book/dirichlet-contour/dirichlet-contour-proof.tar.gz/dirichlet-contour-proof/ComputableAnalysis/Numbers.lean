import ComputableAnalysis.RealRawQuotient

/-! Public mathematical values, distinct from particular numerical computations.
Both types quotient already valid rational-interval/box names; neither imports
an external completion or selects a preferred executable representative. -/
namespace ComputableAnalysis.Numbers

abbrev Real := RealRawQuotient.Value
abbrev Complex := ComplexRawQuotient.Value

def ofReal : Real → Complex := RealRawQuotient.toComplex

theorem ofReal_injective {x y : Real} (h : ofReal x = ofReal y) : x=y :=
  RealRawQuotient.toComplex_injective h

end ComputableAnalysis.Numbers
