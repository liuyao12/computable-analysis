import ComputableAnalysis.GeometricTaylorReal
import ComputableAnalysis.RepresentedSeries

/-! The infinite Taylor expansions derived from geometric repeated FTC.
The finite polynomial and factorial remainder are proved first. Shrinking
that remainder then gives the series and its exact geometric value. -/
namespace ComputableAnalysis.GeometricTaylorSeries
open ComputableCoefficient RealApproximationOrder RawLimit GeometricTrig
open TaylorPolynomialValues RationalMajorant
set_option maxHeartbeats 800000

def terms (cosine : Bool) (X : Value) (n : Nat) : Value :=
  TaylorPolynomialValues.term n cosine (angular X)

theorem finiteSum_eq (cosine : Bool) (X : Value) (N : Nat) :
    RepresentedSeries.finiteSum (terms cosine X) N=sumPrefix cosine (angular X) N := by
  induction N with
  | zero => rfl
  | succ n ih => simp only [RepresentedSeries.finiteSum,sumPrefix,ih,terms]

theorem factorial_shift_shrinks (C : Rat) (hC : 0≤C) :
    ShrinksToZero (fun n => factorialTailTerm C (factorialTailStart C+n)) := by
  intro eps
  let B := factorialTailTerm C (factorialTailStart C)
  refine ⟨halfDecayShift B eps,fun n hn => ?_⟩
  have h := factorialTailTerm_le_geometric_from_start hC (factorialTailStart_satisfies C) n
  exact Rat.le_trans h (halfDecayShift_spec_of_le (factorialTailTerm_nonneg hC _) eps hn)

theorem factorial_shrinks (C : Rat) (hC : 0≤C) : ShrinksToZero (factorialTailTerm C) := by
  intro eps
  obtain ⟨K,hK⟩ := factorial_shift_shrinks C hC eps
  refine ⟨factorialTailStart C+K,fun n hn => ?_⟩
  have h := hK (n-factorialTailStart C) (by omega)
  have he : factorialTailStart C+(n-factorialTailStart C)=n := by omega
  simpa only [he] using h

/-- Convergence is a consequence of the finite geometric FTC remainder. -/
theorem full_hasSum (cosine : Bool) (X : Value) :
    RepresentedSeries.HasSum (terms cosine X) (evaluate cosine X.real.preferred) := by
  apply RepresentedSeries.hasSum_of_errors (terms cosine X) (GeometricTaylorReal.geometricValue cosine X)
    (factorialTailTerm (GeometricTaylorReal.bound X))
    (factorial_shrinks _ (GeometricTaylorReal.bound_nonnegative X))
  intro N
  rw [finiteSum_eq]
  exact GeometricTaylorReal.remainder_bound cosine X N

/-- A finite-polynomial evaluator with the FTC error in its actual boxes. -/
def series (cosine : Bool) (X : Value) : RealRaw :=
  let C := GeometricTaylorReal.bound X
  RepresentedSeries.sum
    (fun n => sumPrefix cosine (angular X) (factorialTailStart C+n))
    (fun n => factorialTailTerm C (factorialTailStart C+n))

theorem series_valid (cosine : Bool) (X : Value) : (series cosine X).Valid :=
  RepresentedSeries.sum_valid _ _
    (factorial_shift_shrinks _ (GeometricTaylorReal.bound_nonnegative X))
    (GeometricTaylorReal.geometricValue cosine X)
    (fun n => GeometricTaylorReal.remainder_bound cosine X (factorialTailStart (GeometricTaylorReal.bound X)+n))

/-- Exact equality, for arbitrary valid represented input and represented pi.
No formal coefficient or series identity is assumed in its proof. -/
theorem series_exact (cosine : Bool) (X : Value) :
    (series cosine X).Equiv (evaluate cosine X.real.preferred) :=
  RepresentedSeries.sum_identify _ _ (GeometricTaylorReal.geometricValue cosine X)
    (fun n => GeometricTaylorReal.remainder_bound cosine X (factorialTailStart (GeometricTaylorReal.bound X)+n))

theorem series_hasSum (cosine : Bool) (X : Value) : RepresentedSeries.HasSum (terms cosine X) (series cosine X) :=
  RawLimit.congr_target (full_hasSum cosine X) (series_valid cosine X) (RealRaw.equiv_symm (series_exact cosine X))

theorem series_congr {X Y : Value} (h : X.real.preferred.Equiv Y.real.preferred) (cosine : Bool) :
    (series cosine X).Equiv (series cosine Y) :=
  RealRaw.equiv_trans (series_valid cosine X) (at_valid cosine X.real.valid) (series_valid cosine Y)
    (series_exact cosine X)
    (RealRaw.equiv_trans (at_valid cosine X.real.valid) (at_valid cosine Y.real.valid) (series_valid cosine Y)
      (at_congr cosine X.real.valid Y.real.valid h) (RealRaw.equiv_symm (series_exact cosine Y)))

private theorem phase_two (n : Nat) (cosine : Bool) : phase (n+2) cosine= -(phase n cosine) := by
  rw [show n+2=(n+1)+1 by omega]
  cases cosine <;> simp only [phase_succ,Bool.false_eq_true,↓reduceIte]

theorem phase_even_odd (k : Nat) :
    phase (2*k) false=0 ∧ phase (2*k) true=(-1:Rat)^k ∧
    phase (2*k+1) false=(-1:Rat)^k ∧ phase (2*k+1) true=0 := by
  induction k with
  | zero => decide +kernel
  | succ k ih =>
    rw [show 2*(k+1)=2*k+2 by omega,show 2*k+2+1=(2*k+1)+2 by omega]
    rw [phase_two,phase_two,phase_two,phase_two,ih.1,ih.2.1,ih.2.2.1,ih.2.2.2,Rat.pow_succ]
    constructor
    · decide +kernel
    constructor
    · grind only
    constructor
    · grind only
    · decide +kernel

/-- The zero coefficients are omitted in the conventional sine/cosine sums. -/
def selectedTerms (cosine : Bool) (X : Value) (k : Nat) : Value :=
  terms cosine X (if cosine then 2*k else 2*k+1)

theorem selected_terms_closed (X : Value) (k : Nat) :
    (selectedTerms false X k).real.preferred.Equiv
      (scale (((-1:Rat)^k)/factorialRat (2*k+1)) (power (angular X) (2*k+1))).real.preferred ∧
    (selectedTerms true X k).real.preferred.Equiv
      (scale (((-1:Rat)^k)/factorialRat (2*k)) (power (angular X) (2*k))).real.preferred := by
  constructor
  · apply arithmetic_identity
    intro s
    simp only [selectedTerms,terms,TaylorPolynomialValues.term,coefficient,scale,
      phase_even_odd,Bool.false_eq_true,↓reduceIte]
    simp only [Rat.div_def,Rat.one_mul]
    grind only
  · apply arithmetic_identity
    intro s
    simp only [selectedTerms,terms,TaylorPolynomialValues.term,coefficient,scale,
      (phase_even_odd k).2.1,↓reduceIte]
    simp only [Rat.div_def,Rat.one_mul]
    grind only

private theorem selected_prefix_samples (cosine : Bool) (X : Value) (N : Nat) (s : Real → Rat) :
    (RepresentedSeries.finiteSum (selectedTerms cosine X) N).sample s=
      (sumPrefix cosine (angular X) (2*N)).sample s := by
  induction N with
  | zero => rfl
  | succ n ih =>
    rw [show 2*(n+1)=2*n+1+1 by omega]
    change (RepresentedSeries.finiteSum (selectedTerms cosine X) n).sample s+
      (selectedTerms cosine X n).sample s=
      (sumPrefix cosine (angular X) (2*n)).sample s+
        (terms cosine X (2*n)).sample s+(terms cosine X (2*n+1)).sample s
    rw [ih]
    cases cosine
    · simp only [selectedTerms,terms,TaylorPolynomialValues.term,coefficient,scale,
        (phase_even_odd n).1,Bool.false_eq_true,↓reduceIte,Rat.zero_mul,Rat.mul_zero,Rat.add_zero]
    · simp only [selectedTerms,terms,TaylorPolynomialValues.term,coefficient,scale,
        (phase_even_odd n).2.2.2,↓reduceIte,Rat.zero_mul,Rat.mul_zero,Rat.add_zero]

/-- The usual odd/even factorial expansions converge to the geometric
functions at every valid represented real, as a consequence of repeated FTC. -/
theorem geometric_hasSum (cosine : Bool) (X : Value) :
    RepresentedSeries.HasSum (selectedTerms cosine X) (evaluate cosine X.real.preferred) := by
  have H := full_hasSum cosine X
  have hsub : RawLimit.TendsTo (fun n => (sumPrefix cosine (angular X) (2*n)).real.preferred)
      (evaluate cosine X.real.preferred) := by
    refine ⟨H.1,fun n => (sumPrefix cosine (angular X) (2*n)).real.valid,?_⟩
    intro m eps
    obtain ⟨N,hN⟩ := H.2.2 m eps
    refine ⟨N,fun n hn => ?_⟩
    have h := hN (2*n) (by omega)
    change InInterval (RepresentedSeries.finiteSum (terms cosine X) (2*n)).real.preferred _ at h
    rw [finiteSum_eq] at h
    exact h
  apply RawLimit.congr_sequence hsub (fun n => (RepresentedSeries.finiteSum (selectedTerms cosine X) n).real.valid)
  intro n
  apply arithmetic_identity
  intro s
  exact (selected_prefix_samples cosine X n s).symm

/-- The conventional odd factorial terms, obtained from the FTC coefficients. -/
def sineTerm (X : Value) (k : Nat) : Value :=
  scale (((-1:Rat)^k)/factorialRat (2*k+1)) (power (angular X) (2*k+1))
/-- The conventional even factorial terms in the same normalized coordinate. -/
def cosineTerm (X : Value) (k : Nat) : Value :=
  scale (((-1:Rat)^k)/factorialRat (2*k)) (power (angular X) (2*k))

def sinTaylor (q : Rat) : RealRaw := series false (Value.rational q)
def cosTaylor (q : Rat) : RealRaw := series true (Value.rational q)
def sinTaylorAt (x : RealRaw) (hx : x.Valid) : RealRaw := series false (parameter x hx)
def cosTaylorAt (x : RealRaw) (hx : x.Valid) : RealRaw := series true (parameter x hx)

theorem sin_taylor {x : RealRaw} (hx : x.Valid) : (sinTaylorAt x hx).Equiv (sinAt x) := series_exact false _
theorem cos_taylor {x : RealRaw} (hx : x.Valid) : (cosTaylorAt x hx).Equiv (cosAt x) := series_exact true _

theorem sin_taylor_converges {x : RealRaw} (hx : x.Valid) :
    RepresentedSeries.HasSum (sineTerm (parameter x hx)) (sinAt x) :=
  (geometric_hasSum false (parameter x hx)).congr_terms (fun k => (selected_terms_closed (parameter x hx) k).1)
theorem cos_taylor_converges {x : RealRaw} (hx : x.Valid) :
    RepresentedSeries.HasSum (cosineTerm (parameter x hx)) (cosAt x) :=
  (geometric_hasSum true (parameter x hx)).congr_terms (fun k => (selected_terms_closed (parameter x hx) k).2)

theorem sinTaylor_valid (q : Rat) : (sinTaylor q).Valid := series_valid false _
theorem cosTaylor_valid (q : Rat) : (cosTaylor q).Valid := series_valid true _
theorem sinTaylorAt_valid {x : RealRaw} (hx : x.Valid) : (sinTaylorAt x hx).Valid := series_valid false _
theorem cosTaylorAt_valid {x : RealRaw} (hx : x.Valid) : (cosTaylorAt x hx).Valid := series_valid true _

theorem sinTaylor_agrees (q : Rat) : (sinTaylor q).Equiv (sin q) :=
  RealRaw.equiv_trans (sinTaylor_valid q) (sinAt_valid (x := RealRaw.ofRat q) (RealRaw.ofRat_valid q)) (sin_valid q)
    (series_exact false _) (sinAt_rational q)
theorem cosTaylor_agrees (q : Rat) : (cosTaylor q).Equiv (cos q) :=
  RealRaw.equiv_trans (cosTaylor_valid q) (cosAt_valid (x := RealRaw.ofRat q) (RealRaw.ofRat_valid q)) (cos_valid q)
    (series_exact true _) (cosAt_rational q)

theorem sinTaylorAt_congr {x y : RealRaw} (hx : x.Valid) (hy : y.Valid) (h : x.Equiv y) :
    (sinTaylorAt x hx).Equiv (sinTaylorAt y hy) := series_congr h false
theorem cosTaylorAt_congr {x y : RealRaw} (hx : x.Valid) (hy : y.Valid) (h : x.Equiv y) :
    (cosTaylorAt x hx).Equiv (cosTaylorAt y hy) := series_congr h true

end ComputableAnalysis.GeometricTaylorSeries
