import ComputableAnalysis.FTCRealCalculus

/-! Quantitative reciprocal FTC on a complete positive segment. -/
namespace ComputableAnalysis.FTCRealCalculus
open ComputableCoefficient RealApproximationOrder
set_option maxHeartbeats 800000

def reciprocalValue (t : Rat) : Value := Value.rational (1/t)
def reciprocalDerivative (t : Rat) : Value := Value.rational (-(1/t)*(1/t))

theorem inverse_bounds (a t : Rat) (ha : 0<a) (hat : a≤t) :
    0<t⁻¹ ∧ t⁻¹≤a⁻¹ := by
  have ht : 0<t := by grind only
  exact ⟨Rat.inv_pos.mpr ht,by
    simpa only [Rat.div_def,Rat.one_mul] using QInterval.one_div_le_one_div_of_pos ha hat⟩

theorem reciprocal_small (a t : Rat) (ha : 0<a) (ht : a≤t) : Small (reciprocalValue t) a⁻¹ := by
  have H := inverse_bounds a t ha ht
  apply small_of_samples _ _ 0
  intro m hm s hs
  change qabs (1/t)≤a⁻¹
  simpa only [Rat.div_def,Rat.one_mul,qabs_eq_self_of_nonneg (Rat.le_of_lt H.1)] using H.2

theorem reciprocalDerivative_small (a t : Rat) (ha : 0<a) (ht : a≤t) :
    Small (reciprocalDerivative t) (a⁻¹*a⁻¹) := by
  have H := inverse_bounds a t ha ht
  have P := rat_mul_le_mul_of_nonneg (Rat.le_of_lt H.1) H.2 (Rat.le_of_lt H.1) H.2
  apply small_of_samples _ _ 0
  intro m hm s hs
  change qabs (-(1/t)*(1/t))≤a⁻¹*a⁻¹
  simp only [Rat.div_def,Rat.one_mul]
  rw [show -(t⁻¹)*t⁻¹= -(t⁻¹*t⁻¹) by grind only,qabs_neg,
    qabs_eq_self_of_nonneg (Rat.mul_nonneg (Rat.le_of_lt H.1) (Rat.le_of_lt H.1))]
  exact P

/-- No pole occurs anywhere in the source segment. -/
def reciprocalStep (a b : Rat) (ha : 0<a) :
    Step reciprocalValue reciprocalDerivative a b where
  error := a⁻¹*a⁻¹*a⁻¹
  error_nonnegative := Rat.mul_nonneg (Rat.mul_nonneg (Rat.le_of_lt (Rat.inv_pos.mpr ha))
    (Rat.le_of_lt (Rat.inv_pos.mpr ha))) (Rat.le_of_lt (Rat.inv_pos.mpr ha))
  radius := ⟨1,by decide⟩
  firstOrder := by
    intro u v hu huv _ _
    have hu0 : 0<u := by grind only
    have hv0 : 0<v := by grind only
    have bu := inverse_bounds a u ha hu
    have bv := inverse_bounds a v ha (Rat.le_trans hu (Rat.le_of_lt huv))
    have cu := Rat.mul_inv_cancel u (Rat.ne_of_gt hu0)
    have cv := Rat.mul_inv_cancel v (Rat.ne_of_gt hv0)
    have h0 : 0≤v-u := by grind only
    have hn := Rat.mul_nonneg (Rat.mul_nonneg (Rat.le_of_lt bu.1) (Rat.le_of_lt bu.1)) (Rat.le_of_lt bv.1)
    have hb := rat_mul_le_mul_of_nonneg
      (Rat.mul_nonneg (Rat.le_of_lt bu.1) (Rat.le_of_lt bu.1))
      (rat_mul_le_mul_of_nonneg (Rat.le_of_lt bu.1) bu.2 (Rat.le_of_lt bu.1) bu.2)
      (Rat.le_of_lt bv.1) bv.2
    have he : v⁻¹-u⁻¹-(v-u)*(-(u⁻¹*u⁻¹))=(v-u)*(v-u)*(u⁻¹*u⁻¹*v⁻¹) := by
      grind [Rat.mul_comm]
    have hm := Rat.mul_le_mul_of_nonneg_left hb (Rat.mul_nonneg h0 h0)
    have hp := Rat.mul_nonneg (Rat.mul_nonneg h0 h0) hn
    apply small_of_samples _ _ 0
    intro m hm0 s hs
    change qabs (1/v-1/u-(v-u)*(-(1/u)*(1/u)))≤(a⁻¹*a⁻¹*a⁻¹)*(v-u)*(v-u)
    simp only [Rat.div_def,Rat.one_mul]
    rw [show -(u⁻¹)*u⁻¹= -(u⁻¹*u⁻¹) by grind only,he,qabs_eq_self_of_nonneg hp]
    grind only
  variation := 2*(a⁻¹*a⁻¹*a⁻¹)
  variation_nonnegative := Rat.mul_nonneg (by decide)
    (Rat.mul_nonneg (Rat.mul_nonneg (Rat.le_of_lt (Rat.inv_pos.mpr ha))
      (Rat.le_of_lt (Rat.inv_pos.mpr ha))) (Rat.le_of_lt (Rat.inv_pos.mpr ha)))
  lipschitz := by
    intro u v hu huv _
    have hu0 : 0<u := by grind only
    have hv0 : 0<v := by grind only
    have bu := inverse_bounds a u ha hu
    have bv := inverse_bounds a v ha (Rat.le_trans hu huv)
    have cu := Rat.mul_inv_cancel u (Rat.ne_of_gt hu0)
    have cv := Rat.mul_inv_cancel v (Rat.ne_of_gt hv0)
    have h0 : 0≤v-u := by grind only
    have bp := rat_mul_le_mul_of_nonneg (Rat.le_of_lt bu.1) bu.2 (Rat.le_of_lt bv.1) bv.2
    have bs : u⁻¹+v⁻¹≤2*a⁻¹ := by grind only
    have bs0 : 0≤u⁻¹+v⁻¹ := by grind only
    have hb := rat_mul_le_mul_of_nonneg
      (Rat.mul_nonneg (Rat.le_of_lt bu.1) (Rat.le_of_lt bv.1)) bp bs0 bs
    have hn := Rat.mul_nonneg (Rat.mul_nonneg (Rat.le_of_lt bu.1) (Rat.le_of_lt bv.1)) bs0
    have he : -(v⁻¹*v⁻¹)-(-(u⁻¹*u⁻¹))=(v-u)*(u⁻¹*v⁻¹)*(u⁻¹+v⁻¹) := by
      grind [Rat.mul_comm]
    have hm := Rat.mul_le_mul_of_nonneg_left hb h0
    have hp : 0≤(v-u)*(u⁻¹*v⁻¹)*(u⁻¹+v⁻¹) :=
      Rat.mul_nonneg (Rat.mul_nonneg h0 (Rat.mul_nonneg (Rat.le_of_lt bu.1) (Rat.le_of_lt bv.1))) bs0
    apply small_of_samples _ _ 0
    intro m hm0 s hs
    change qabs ((-(1/v)*(1/v))-(-(1/u)*(1/u)))≤(2*(a⁻¹*a⁻¹*a⁻¹))*(v-u)
    simp only [Rat.div_def,Rat.one_mul]
    rw [show -(v⁻¹)*v⁻¹= -(v⁻¹*v⁻¹) by grind only,
      show -(u⁻¹)*u⁻¹= -(u⁻¹*u⁻¹) by grind only,he,qabs_eq_self_of_nonneg hp]
    grind only

end ComputableAnalysis.FTCRealCalculus
