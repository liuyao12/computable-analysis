import ComputableAnalysis.ParametrizedLimits
import ComputableAnalysis.IntegralBoundsComparison

/-! A supplied sequence of genuine finite bounds with shrinking gaps constructs
an integral by finite prefix intersections. This is one sufficient construction
route, and does not require a pre-existing integral value. -/
namespace ComputableAnalysis.BoundsQuadrature
open Integral RawLimit
set_option maxHeartbeats 1000000

def box {F : FunctionOnInterval} (tests : Nat → Bounds F) (n : Nat) : QInterval :=
  ⟨(tests n).lowerSum,(tests n).upperSum⟩

def raw (F : FunctionOnInterval) (tests : Nat → Bounds F) : RealRaw :=
  prefixRaw (box tests)

private theorem box_cross (F : FunctionOnInterval) (tests : Nat → Bounds F) (n m : Nat) :
    (box tests n).lo≤
      (box tests m).hi :=
  Bounds.lowerSum_le_upperSum _ _

private theorem prefix_cross (B : Nat → QInterval)
    (cross : ∀ n m,(B n).lo≤(B m).hi) (n m : Nat) :
    (prefixCompute B n).lo≤(prefixCompute B m).hi := by
  have left : ∀ n m,(prefixCompute B n).lo≤(B m).hi := by
    intro n m
    induction n with
    | zero => exact cross 0 m
    | succ n ih =>
      have hn := cross (n+1) m
      dsimp [prefixCompute,QInterval.intersection,maxRat2]
      grind
  induction m with
  | zero => exact left n 0
  | succ m ih =>
    have hn := left n (m+1)
    dsimp [prefixCompute,QInterval.intersection,minRat]
    grind

private theorem prefix_tests (F : FunctionOnInterval) (tests : Nat → Bounds F) (A : Bounds F) (n : Nat) :
    A.lowerSum≤((raw F tests).compute n).hi ∧
      ((raw F tests).compute n).lo≤A.upperSum := by
  induction n with
  | zero => exact ⟨Bounds.lowerSum_le_upperSum A _,Bounds.lowerSum_le_upperSum _ A⟩
  | succ n ih =>
    have h1 : A.lowerSum≤(box tests (n+1)).hi :=
      Bounds.lowerSum_le_upperSum A _
    have h2 : (box tests (n+1)).lo≤A.upperSum :=
      Bounds.lowerSum_le_upperSum _ A
    change A.lowerSum≤(QInterval.intersection ((raw F tests).compute n)
      (box tests (n+1))).hi ∧
      (QInterval.intersection ((raw F tests).compute n)
      (box tests (n+1))).lo≤A.upperSum
    dsimp [QInterval.intersection,maxRat2,minRat]
    constructor <;> grind

theorem valid (F : FunctionOnInterval) (tests : Nat → Bounds F)
    (shrink : ShrinksToZero (fun n => (tests n).upperSum-(tests n).lowerSum)) :
    (raw F tests).Valid := by
  have order (n : Nat) : ((raw F tests).compute n).lo≤((raw F tests).compute n).hi :=
    prefix_cross _ (box_cross F tests) n n
  refine ⟨?_,?_,?_⟩
  · intro n
    have := order n
    dsimp [QInterval.width]
    grind only
  · intro n m hnm
    induction hnm with
    | refl => exact ⟨Rat.le_refl,order n,Rat.le_refl⟩
    | @step m hnm ih =>
      have hs := QInterval.intersection_contained_left ((raw F tests).compute m)
        (box tests (m+1))
      exact ⟨Rat.le_trans ih.1 hs.1,order (m+1),Rat.le_trans hs.2 ih.2.2⟩
  · intro eps
    obtain ⟨N,hN⟩ := shrink eps
    refine ⟨N,?_⟩
    intro n hn
    have hc := prefix_current (box tests) n
    have he := hN n hn
    change (box tests n).hi-(box tests n).lo≤eps.val at he
    change ((raw F tests).compute n).hi-((raw F tests).compute n).lo≤eps.val
    change (box tests n).lo≤((raw F tests).compute n).lo ∧
      ((raw F tests).compute n).hi≤(box tests n).hi at hc
    grind only

theorem hasIntegral (F : FunctionOnInterval) (tests : Nat → Bounds F)
    (shrink : ShrinksToZero (fun n => (tests n).upperSum-(tests n).lowerSum)) :
    HasIntegral F (raw F tests) := by
  refine ⟨valid F tests shrink,fun A => prefix_tests F tests A,?_⟩
  intro eps
  obtain ⟨N,hN⟩ := shrink eps
  exact ⟨tests N,hN N (Nat.le_refl _)⟩


end ComputableAnalysis.BoundsQuadrature
