import ComputableAnalysis.EulerImaginaryFinite

/-! A geometric pi sampler whose precision is selected by the Euler
computation, independently of the trigonometric sampler's faster schedule. -/
namespace ComputableAnalysis.EulerImaginary
open ComputableCoefficient RealApproximationOrder

def numericalPi : RealRaw := RealRaw.scaleRat 4 GeometricTrig.unitArea

theorem numericalPi_valid : numericalPi.Valid := RealRaw.scaleRat_valid GeometricTrig.unitArea_valid

theorem numericalPi_equiv : numericalPi.Equiv GeometricTrig.pi :=
  RealRaw.scaleRat_equiv (RealRaw.schedule_equiv GeometricTrig.unitArea GeometricTrig.unitArea_valid GeometricTrig.areaSchedule)

def numericalPiValue : Value := parameter numericalPi numericalPi_valid

def numericalSlope (c : Bool) (S C : Value) : Value :=
  Value.mul numericalPiValue (if c then Value.neg S else C)

def numericalState (h : Rat) : Nat → Bool → Value
  | 0 => fun c => Value.rational (if c then 1 else 0)
  | k+1 =>
    let previous := numericalState h k
    fun c => Value.add (previous c) (scale h (numericalSlope c (previous false) (previous true)))

theorem numericalState_equiv (h : Rat) (k : Nat) : ∀ c,
    (numericalState h k c).real.preferred.Equiv (state h k c).real.preferred := by
  induction k with
  | zero => intro c; exact RealRaw.equiv_refl _ (Value.rational _).real.valid
  | succ k ih =>
    intro c
    have Hs : (numericalSlope c (numericalState h k false) (numericalState h k true)).real.preferred.Equiv
        (GeometricTrig.pairSlope c (state h k false) (state h k true)).real.preferred := by
      cases c
      · exact RealRaw.mul_equiv numericalPi_valid GeometricTrig.pi_valid
          (numericalState h k true).real.valid (state h k true).real.valid numericalPi_equiv (ih true)
      · exact RealRaw.mul_equiv numericalPi_valid GeometricTrig.pi_valid
          (RealRaw.neg_valid (numericalState h k false).real.valid) (RealRaw.neg_valid (state h k false).real.valid)
          numericalPi_equiv (RealRaw.neg_equiv (ih false))
    exact RealRaw.add_equiv (numericalState h k c).real.valid (state h k c).real.valid
      (RealRaw.scaleRat_valid (numericalSlope c (numericalState h k false) (numericalState h k true)).real.valid)
      (RealRaw.scaleRat_valid (GeometricTrig.pairSlope c (state h k false) (state h k true)).real.valid)
      (ih c) (RealRaw.scaleRat_equiv Hs)

end ComputableAnalysis.EulerImaginary
