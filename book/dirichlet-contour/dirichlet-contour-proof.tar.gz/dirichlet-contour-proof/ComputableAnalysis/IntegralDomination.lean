import ComputableAnalysis.LipschitzQuadrature
import ComputableAnalysis.RealValueProductOrder

/-! Domination for independently sampled proper integrals. -/
namespace ComputableAnalysis.LipschitzQuadrature
open ComputableCoefficient RealApproximationOrder FTCRealOrder FTCRealCalculus
set_option maxHeartbeats 800000

theorem Data.suffix_small_nonnegative {f : Rat → Value} {a b : Rat} (D : Data f a b)
    (u B : Rat) (hau : a≤u) (hub : u≤b) (hB : 0≤B) (hb : Small D.value B)
    (positive : ∀ t,a≤t → t≤b → LE (Value.rational 0) (f t)) :
    Small (D.restrict u b hau hub Rat.le_refl).value B := by
  let L := D.restrict a u Rat.le_refl hau hub
  let R := D.restrict u b hau hub Rat.le_refl
  have hL := L.hasIntegral.nonnegative (by intro t ht n; exact positive t ht.1 (Rat.le_trans ht.2 hub) 0 n)
  have hR := R.hasIntegral.nonnegative (by intro t ht n; exact positive t (Rat.le_trans hau ht.1) ht.2 0 n)
  have sum := L.append R D
  have A := le_add (x := Value.rational 0) (y := L.value) (X := R.value) (Y := R.value) hL (RealRaw.le_refl R.value.real.preferred R.value.real.valid)
  have A' : LE R.value (Value.add L.value R.value) := by
    apply le_congr (x := Value.add (Value.rational 0) R.value) (y := Value.add L.value R.value) A
    · apply arithmetic_identity; intro s; simp only [Value.add,Value.rational]; grind only
    · exact RealRaw.equiv_refl _ (Value.add L.value R.value).real.valid
  constructor
  · intro i j
    have H := hR 0 j
    change 0≤(R.integral.compute j).hi at H
    change -B≤(R.integral.compute j).hi
    grind only
  · exact RealRaw.le_trans D.value.real.valid
      (RealRaw.le_trans (Value.add L.value R.value).real.valid A'
        (RealRaw.le_of_equiv (Value.add L.value R.value).real.valid D.value.real.valid (RealRaw.equiv_symm sum))) hb.2

theorem Data.dominated {f g : Rat → Value} {a b : Rat} (D : Data f a b) (E : Data g a b)
    (B : Rat) (bound : Small E.value B)
    (lower : ∀ t,a≤t → t≤b → LE (Value.neg (g t)) (f t))
    (upper : ∀ t,a≤t → t≤b → LE (f t) (g t)) : Small D.value B := by
  have H := D.hasIntegral.mono E.hasIntegral rfl rfl (by intro t ht _; exact upper t ht.1 ht.2)
  have N := E.neg.hasIntegral.mono D.hasIntegral rfl rfl (by intro t ht _; exact lower t ht.1 ht.2)
  have negE : E.neg.value.real.preferred.Equiv (Value.neg E.value).real.preferred := E.neg_identity
  constructor
  · exact RealRaw.le_trans E.neg.value.real.valid
      (RealRaw.le_trans (Value.neg E.value).real.valid bound.neg.1
        (RealRaw.le_of_equiv (Value.neg E.value).real.valid E.neg.value.real.valid (RealRaw.equiv_symm negE))) N
  · exact RealRaw.le_trans E.value.real.valid H bound.2

end ComputableAnalysis.LipschitzQuadrature
