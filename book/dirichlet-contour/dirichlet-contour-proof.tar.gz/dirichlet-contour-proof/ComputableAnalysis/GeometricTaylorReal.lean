import ComputableAnalysis.GeometricTaylorFTC

/-! The FTC remainder on arbitrary valid represented real inputs. Rational
geometric samplers remain primary; whole-bracket polynomial images and the
geometric extension carry the proved finite inequality to represented inputs. -/
namespace ComputableAnalysis.GeometricTaylorReal
open ComputableCoefficient RealApproximationOrder RawLimit GeometricTrig
open TaylorPolynomialValues RationalMajorant
set_option maxHeartbeats 700000

def geometricValue (cosine : Bool) (X : Value) : Value :=
  parameter (evaluate cosine X.real.preferred) (at_valid cosine X.real.valid)

def residual (cosine : Bool) (X : Value) (N : Nat) : Value :=
  sub (geometricValue cosine X) (sumPrefix cosine (angular X) N)

def inputRadius (X : Value) : Rat :=
  qabs ((BracketDerivative.enlarged X.real.preferred).compute 0).lo+
    qabs ((BracketDerivative.enlarged X.real.preferred).compute 0).hi

def bound (X : Value) : Rat := 8*inputRadius X

theorem bound_nonnegative (X : Value) : 0≤bound X :=
  Rat.mul_nonneg (by decide +kernel) (Rat.add_nonneg (qabs_nonneg _) (qabs_nonneg _))

theorem residual_congr {X Y : Value} (h : X.real.preferred.Equiv Y.real.preferred) (cosine : Bool) (N : Nat) :
    (residual cosine X N).real.preferred.Equiv (residual cosine Y N).real.preferred :=
  RealRaw.sub_equiv (geometricValue cosine X).real.valid (geometricValue cosine Y).real.valid
    (sumPrefix cosine (angular X) N).real.valid (sumPrefix cosine (angular Y) N).real.valid
    (at_congr cosine X.real.valid Y.real.valid h) (partial_congr (angular_congr h) N cosine)

theorem rational_image (A : RealRaw) (hA : A.Valid) (cosine : Bool) (N n : Nat) (q : Rat)
    (hq : (A.compute n).lo≤q ∧ q≤(A.compute n).hi) :
    InInterval (sub (valueFor cosine q) (sumPrefix cosine (angular (Value.rational q)) N)).real.preferred
      ((residual cosine (parameter A hA) N).real.compute n) := by
  have hf : InInterval (sample cosine q) ((evaluate cosine A).compute n) := by
    have h := LipschitzRealExtension.covers (sample_valid cosine) (L := 32) (by decide +kernel)
      (sample_lipschitz cosine) hA n hq
    cases cosine <;> exact h
  have hp := partial_image (angular_image hA q n hq) N cosine
  have h := interval_sub hf hp
  change InInterval ((valueFor cosine q).real.preferred-
    (sumPrefix cosine (angular (Value.rational q)) N).real.preferred) _
  rw [valueFor_raw]
  exact h

private theorem factorial_mono {C D : Rat} (hC : 0≤C) (hCD : C≤D) (N : Nat) :
    factorialTailTerm C N≤factorialTailTerm D N := by
  have powers : C^N≤D^N := by
    induction N with
    | zero => simp only [Rat.pow_zero,Rat.le_refl]
    | succ n ih =>
      rw [Rat.pow_succ,Rat.pow_succ]
      exact rat_mul_le_mul_of_nonneg (Rat.pow_nonneg hC) ih hC hCD
  exact Rat.mul_le_mul_of_nonneg_right powers (Rat.le_of_lt (Rat.inv_pos.mpr (factorialRat_pos N)))

theorem remainder_bound (cosine : Bool) (X : Value) (N : Nat) :
    Small (residual cosine X N) (factorialTailTerm (bound X) N) := by
  let A := BracketDerivative.enlarged X.real.preferred
  have hA : A.Valid := BracketDerivative.enlarged_valid X.real.valid
  let Y := parameter A hA
  let E := factorialTailTerm (bound X) N
  have rational_bound (q : Rat) (n : Nat) (hq : (A.compute n).lo≤q ∧ q≤(A.compute n).hi) :
      Small (sub (valueFor cosine q) (sumPrefix cosine (angular (Value.rational q)) N)) E := by
    have nest := hA.2.1 0 n (Nat.zero_le _)
    have hlo := neg_qabs_le_self (A.compute 0).lo
    have hhi := self_le_qabs (A.compute 0).hi
    have hL := qabs_nonneg (A.compute 0).lo
    have hR := qabs_nonneg (A.compute 0).hi
    have hr : qabs q≤inputRadius X := by
      apply qabs_le_of_neg_le_le
      · change -(qabs (A.compute 0).lo+qabs (A.compute 0).hi)≤q
        grind only
      · change q≤qabs (A.compute 0).lo+qabs (A.compute 0).hi
        grind only
    have hm : GeometricFTCData.magnitude q≤bound X := Rat.mul_le_mul_of_nonneg_left hr (by decide +kernel)
    exact (GeometricTaylorFTC.rational_remainder q N cosine).mono
      (factorial_mono (Rat.mul_nonneg (by decide +kernel) (qabs_nonneg q)) hm N)
  have H : Small (residual cosine Y N) E := by
    constructor
    · intro i j
      let q := (A.compute j).lo
      have hq : (A.compute j).lo≤q ∧ q≤(A.compute j).hi :=
        ⟨Rat.le_refl,RealRaw.interval_order_of_valid _ hA j⟩
      have hb := (rational_bound q j hq).1
      have hc := (rational_image A hA cosine N j q hq).2
      exact RealRaw.le_trans (sub (valueFor cosine q) (sumPrefix cosine (angular (Value.rational q)) N)).real.valid hb hc 0 0
    · intro i j
      let q := (A.compute i).lo
      have hq : (A.compute i).lo≤q ∧ q≤(A.compute i).hi :=
        ⟨Rat.le_refl,RealRaw.interval_order_of_valid _ hA i⟩
      have hb := (rational_bound q i hq).2
      have hc := (rational_image A hA cosine N i q hq).1
      exact RealRaw.le_trans (sub (valueFor cosine q) (sumPrefix cosine (angular (Value.rational q)) N)).real.valid hc hb 0 0
  apply H.congr
  exact residual_congr (BracketDerivative.enlarged_equiv X.real.valid) cosine N

end ComputableAnalysis.GeometricTaylorReal
