import ComputableAnalysis.FTCRealCalculus

/-! A quantitative FTC step from convex supporting increments and a proved
Lipschitz bound for the supplied derivative. -/
namespace ComputableAnalysis.FTCRealCalculus
open ComputableCoefficient RealApproximationOrder FTCRealOrder
set_option maxHeartbeats 600000

/-- Supporting increments are finite order data, with no integral identity
in their hypotheses. Lipschitz shrinking supplies the quadratic error. -/
def Step.ofSupportingIncrements (f d : Rat → Value) (a b K : Rat) (hK : 0≤K)
    (lip : LipschitzIntegralBounds.Lipschitz d a b K)
    (supports : ∀ u v,a≤u → u<v → v≤b →
      LE (RealApproximationOrder.scale (v-u) (d u)) (sub (f v) (f u)) ∧
      LE (sub (f v) (f u)) (RealApproximationOrder.scale (v-u) (d v))) : Step f d a b where
  error := K
  error_nonnegative := hK
  radius := ⟨1,by decide⟩
  variation := K
  variation_nonnegative := hK
  lipschitz := lip
  firstOrder := by
    intro u v hu huv hv _
    let L := RealApproximationOrder.scale (v-u) (d u)
    let I := sub (f v) (f u)
    let E := sub I L
    have hh : 0≤v-u := Rat.le_of_lt (by grind only)
    have sup := supports u v hu huv hv
    have self : LE (Value.neg L) (Value.neg L) := RealRaw.le_refl _ (Value.neg L).real.valid
    have lower := le_add sup.1 self
    have upper := le_add sup.2 self
    have eL : (Value.add L (Value.neg L)).real.preferred.Equiv (Value.rational 0).real.preferred := by
      apply arithmetic_identity; intro s; simp only [Value.add,Value.neg,Value.rational]; grind only
    have eI : (Value.add I (Value.neg L)).real.preferred.Equiv E.real.preferred := by
      apply arithmetic_identity; intro s; simp only [E,Value.add,Value.neg,sub]; grind only
    have eU : (Value.add (RealApproximationOrder.scale (v-u) (d v)) (Value.neg L)).real.preferred.Equiv
        (RealApproximationOrder.scale (v-u) (sub (d v) (d u))).real.preferred := by
      apply arithmetic_identity; intro s; simp only [Value.add,Value.neg,sub,RealApproximationOrder.scale,L]; grind only
    have low := le_congr lower eL eI
    have high := le_congr upper eI eU
    have hd := le_scale (x := sub (d v) (d u)) (y := Value.rational (K*(v-u)))
      (lip u v hu (Rat.le_of_lt huv) hv).2 hh
    have hQ : LE (RealApproximationOrder.scale (v-u) (Value.rational (K*(v-u)))) (Value.rational (K*(v-u)*(v-u))) := by
      apply RealRaw.le_of_equiv (y := RealRaw.ofRat (K*(v-u)*(v-u))) (RealApproximationOrder.scale (v-u) (Value.rational (K*(v-u)))).real.valid
        (RealRaw.ofRat_valid _)
      apply arithmetic_identity _ (Value.rational (K*(v-u)*(v-u)))
      intro s
      simp only [RealApproximationOrder.scale,Value.rational]
      grind only
    have hb : 0≤K*(v-u)*(v-u) := Rat.mul_nonneg (Rat.mul_nonneg hK hh) hh
    constructor
    · exact RealRaw.le_trans (y := RealRaw.ofRat 0) (RealRaw.ofRat_valid 0) (fun _ _ => by change -(K*(v-u)*(v-u))≤0; grind only) low
    · exact RealRaw.le_trans (RealApproximationOrder.scale (v-u) (sub (d v) (d u))).real.valid high
        (RealRaw.le_trans (RealApproximationOrder.scale (v-u) (Value.rational (K*(v-u)))).real.valid hd hQ)

end ComputableAnalysis.FTCRealCalculus
