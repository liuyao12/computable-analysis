import ComputableAnalysis.ArctanPositiveFTC
import ComputableAnalysis.FTCFromSupportingSlopes
import ComputableAnalysis.FTCRealReciprocal

/-! The geometric reciprocal arctangent chart, justified by transformed
supporting secants. No chain-rule existence axiom or power series is used. -/
namespace ComputableAnalysis.ArctanReciprocalFTC
open ComputableCoefficient RealApproximationOrder FTCRealOrder FTCRealCalculus
open ArctanGeometry ArctanPositiveFTC LipschitzQuadrature
set_option maxHeartbeats 800000

theorem inverse_unit (q : Rat) (hq : 1≤q) : 0≤q⁻¹ ∧ q⁻¹≤1 := by
  have hq0 : 0<q := by grind only
  have H := QInterval.one_div_le_one_div_of_pos (show (0:Rat)<1 by decide +kernel) hq
  constructor
  · exact Rat.le_of_lt (Rat.inv_pos.mpr hq0)
  · simpa only [Rat.div_def,Rat.one_mul,show (1:Rat)⁻¹=1 by decide +kernel] using H

theorem kernel_inverse (q : Rat) (hq : 0<q) : integralKernel q⁻¹=q*q*integralKernel q := by
  have Q := Rat.mul_inv_cancel q (Rat.ne_of_gt hq)
  have U := Rat.mul_inv_cancel (1+q*q) (Rat.ne_of_gt (RationalCircle.Stage.one_add_square_pos q))
  have V := Rat.mul_inv_cancel (1+q⁻¹*q⁻¹) (Rat.ne_of_gt (RationalCircle.Stage.one_add_square_pos q⁻¹))
  simp only [integralKernel,Rat.div_def,Rat.one_mul]
  grind only

theorem transformed_bounds (u v : Rat) (hu : 1≤u) (huv : u≤v) :
    (v-u)*integralKernel v≤(u⁻¹-v⁻¹)*integralKernel u⁻¹ ∧
    (u⁻¹-v⁻¹)*integralKernel v⁻¹≤(v-u)*integralKernel u := by
  have hv : 1≤v := Rat.le_trans hu huv
  have u0 : 0<u := by grind only
  have v0 : 0<v := by grind only
  have uv1 : 1≤u*v := by have H := rat_mul_le_mul_of_nonneg (by decide +kernel : (0:Rat)≤1) hu (by decide +kernel : (0:Rat)≤1) hv; simpa only [Rat.one_mul] using H
  have P := Rat.mul_nonneg (Rat.mul_nonneg (by grind only : 0≤v-u) (by grind only : 0≤v-u)) (show 0≤u*v-1 by grind only)
  have Pu := Rat.mul_nonneg P (Rat.le_of_lt u0)
  have Pv := Rat.mul_nonneg P (Rat.le_of_lt v0)
  have uc := Rat.mul_inv_cancel u (Rat.ne_of_gt u0)
  have vc := Rat.mul_inv_cancel v (Rat.ne_of_gt v0)
  have U := RationalCircle.Stage.one_add_square_pos u
  have V := RationalCircle.Stage.one_add_square_pos v
  have Uc := Rat.mul_inv_cancel (1+u*u) (Rat.ne_of_gt U)
  have Vc := Rat.mul_inv_cancel (1+v*v) (Rat.ne_of_gt V)
  rw [kernel_inverse u u0,kernel_inverse v v0]
  have Dpos := Rat.mul_pos (Rat.mul_pos (Rat.mul_pos u0 v0) U) V
  have L0 : ((v-u)*(1+v*v)⁻¹)*(u*v*(1+u*u)*(1+v*v))=(v-u)*u*v*(1+u*u) := by grind only
  have L1 : ((u⁻¹-v⁻¹)*(u*u*(1+u*u)⁻¹))*(u*v*(1+u*u)*(1+v*v))=(v-u)*u*u*(1+v*v) := by grind only
  have R0 : ((u⁻¹-v⁻¹)*(v*v*(1+v*v)⁻¹))*(u*v*(1+u*u)*(1+v*v))=(v-u)*v*v*(1+u*u) := by grind only
  have R1 : ((v-u)*(1+u*u)⁻¹)*(u*v*(1+u*u)*(1+v*v))=(v-u)*u*v*(1+v*v) := by grind only
  constructor
  · apply Rat.le_of_mul_le_mul_right (c := u*v*(1+u*u)*(1+v*v)) _ Dpos
    simp only [integralKernel,Rat.div_def,Rat.one_mul]
    rw [L0,L1]
    grind only
  · apply Rat.le_of_mul_le_mul_right (c := u*v*(1+u*u)*(1+v*v)) _ Dpos
    simp only [integralKernel,Rat.div_def,Rat.one_mul]
    rw [R0,R1]
    grind only

def reciprocalAtan (q : Rat) : Value := atan q⁻¹

def inverseStep (R : Rat) : Step reciprocalAtan (fun t => Value.neg (kernel t)) 1 R := by
  apply Step.ofSupportingIncrements reciprocalAtan (fun t => Value.neg (kernel t)) 1 R 2 (by decide +kernel)
  · intro u v hu huv hv
    have H := (kernel_lipschitz 1 R (by decide +kernel) u v hu huv hv).neg
    apply H.congr
    apply arithmetic_identity; intro s; simp only [Value.neg,sub]; grind only
  · intro u v hu huv hv
    have v1 : 1≤v := by grind only
    have invOrd : v⁻¹≤u⁻¹ := by
      have H := QInterval.one_div_le_one_div_of_pos (show 0<u by grind only) (Rat.le_of_lt huv)
      simpa only [Rat.div_def,Rat.one_mul] using H
    have H := increment v⁻¹ u⁻¹ (inverse_unit v v1).1 invOrd (inverse_unit u hu).2
    have B := transformed_bounds u v hu (Rat.le_of_lt huv)
    have Nlower := RealRaw.le_neg_le_neg H.2
    have Nupper := RealRaw.le_neg_le_neg H.1
    have lower : LE (Value.rational (-((v-u)*integralKernel u)))
        (Value.neg (sub (atan u⁻¹) (atan v⁻¹))) := by
      have L : LE (Value.rational (-((v-u)*integralKernel u)))
          (Value.neg (Value.rational ((u⁻¹-v⁻¹)*integralKernel v⁻¹))) := by
        intro i j; change -((v-u)*integralKernel u)≤ -((u⁻¹-v⁻¹)*integralKernel v⁻¹); grind only
      exact RealRaw.le_trans (Value.neg (Value.rational ((u⁻¹-v⁻¹)*integralKernel v⁻¹))).real.valid L Nlower
    have upper : LE (Value.neg (sub (atan u⁻¹) (atan v⁻¹))) (Value.rational (-((v-u)*integralKernel v))) := by
      have L : LE (Value.neg (Value.rational ((u⁻¹-v⁻¹)*integralKernel u⁻¹)))
          (Value.rational (-((v-u)*integralKernel v))) := by
        intro i j; change -((u⁻¹-v⁻¹)*integralKernel u⁻¹)≤ -((v-u)*integralKernel v); grind only
      exact RealRaw.le_trans (Value.neg (Value.rational ((u⁻¹-v⁻¹)*integralKernel u⁻¹))).real.valid Nupper L
    have alg : Same (Value.neg (sub (atan u⁻¹) (atan v⁻¹))) (sub (reciprocalAtan v) (reciprocalAtan u)) := by
      apply arithmetic_identity; intro s; simp only [reciprocalAtan,sub,Value.neg]; grind only
    constructor
    · apply le_congr (x := Value.rational (-((v-u)*integralKernel u)))
        (y := Value.neg (sub (atan u⁻¹) (atan v⁻¹))) lower
      · apply arithmetic_identity; intro s; simp only [Value.rational,scale,Value.neg,kernel]; grind only
      · exact alg
    · apply le_congr (x := Value.neg (sub (atan u⁻¹) (atan v⁻¹)))
        (y := Value.rational (-((v-u)*integralKernel v))) upper
      · exact alg
      · apply arithmetic_identity; intro s; simp only [Value.rational,scale,Value.neg,kernel]; grind only

def step (R : Rat) : Step (fun t => Value.neg (reciprocalAtan t)) kernel 1 R := by
  apply ((inverseStep R).scale (-1)).congr
  · intro t; apply arithmetic_identity; intro s; simp only [scale,Value.neg]; grind only
  · intro t; apply arithmetic_identity; intro s; simp only [scale,Value.neg]; grind only

end ComputableAnalysis.ArctanReciprocalFTC
