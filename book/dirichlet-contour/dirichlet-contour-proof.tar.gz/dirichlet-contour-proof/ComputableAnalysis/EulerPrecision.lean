import ComputableAnalysis.Basic

/-! Executable finite precision search. Existence is erased termination
evidence; the runtime tests successive natural stages. -/
namespace ComputableAnalysis.EulerPrecision

private def Next (p : Nat → Prop) (m n : Nat) : Prop := m=n+1 ∧ ¬p n

private theorem accessible (p : Nat → Prop) (n d : Nat) (hp : p (n+d)) : Acc (Next p) n := by
  induction d generalizing n with
  | zero =>
    apply Acc.intro
    intro m hm
    exact False.elim (hm.2 (by simpa only [Nat.add_zero] using hp))
  | succ d ih =>
    apply Acc.intro
    intro m hm
    rw [hm.1]
    apply ih
    simpa only [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using hp

private def walk (p : Nat → Prop) [DecidablePred p] (n : Nat) (ha : Acc (Next p) n) : Nat :=
  ha.rec (motive := fun _ _ => Nat) (fun k _ recur => if hk : p k then k else recur (k+1) ⟨rfl,hk⟩)

private theorem walk_spec (p : Nat → Prop) [DecidablePred p] (n : Nat) (ha : Acc (Next p) n) :
    p (walk p n ha) := by
  induction ha with
  | intro n next ih =>
    change p (if hn : p n then n else walk p (n+1) (next (n+1) ⟨rfl,hn⟩))
    split
    · assumption
    · exact ih (n+1) ⟨rfl,by assumption⟩

private theorem initial_accessible (p : Nat → Prop) (hp : ∃ n,p n) : Acc (Next p) 0 := by
  obtain ⟨n,hn⟩ := hp
  exact accessible p 0 n (by simpa only [Nat.zero_add] using hn)

def first (p : Nat → Prop) [DecidablePred p] (hp : ∃ n,p n) : Nat :=
  walk p 0 (initial_accessible p hp)

theorem first_spec (p : Nat → Prop) [DecidablePred p] (hp : ∃ n,p n) : p (first p hp) :=
  walk_spec p 0 _

end ComputableAnalysis.EulerPrecision
