import ComputableAnalysis.FTCRealCalculus

/-! Positive rational changes of the input coordinate for supplied actual
FTC steps. The value and derivative computations retain their source functions. -/
namespace ComputableAnalysis.FTCRealCalculus
open ComputableCoefficient RealApproximationOrder FTCRealOrder
set_option maxHeartbeats 500000

def Step.reparametrize {f d : Rat → Value} {l r : Rat} (S : Step f d l r)
    (c a b : Rat) (hc : 0<c) (hl : l≤c*a) (hr : c*b≤r) :
    Step (fun t => f (c*t)) (fun t => RealApproximationOrder.scale c (d (c*t))) a b where
  error := S.error*c*c
  error_nonnegative := Rat.mul_nonneg (Rat.mul_nonneg S.error_nonnegative (Rat.le_of_lt hc)) (Rat.le_of_lt hc)
  radius := ⟨S.radius.val/c,by
    rw [Rat.div_def]
    exact Rat.mul_pos S.radius.property (Rat.inv_pos.mpr hc)⟩
  firstOrder := by
    intro u v hu huv hv hs
    have cu : l≤c*u := by
      have H := Rat.mul_le_mul_of_nonneg_left hu (Rat.le_of_lt hc); grind only
    have cv : c*v≤r := by
      have H := Rat.mul_le_mul_of_nonneg_left hv (Rat.le_of_lt hc); grind only
    have uv : c*u<c*v := by
      have H := Rat.mul_pos hc (show 0<v-u by grind only); grind only
    have hsize : c*v-c*u≤S.radius.val := by
      have H := Rat.mul_le_mul_of_nonneg_left hs (Rat.le_of_lt hc)
      change c*(v-u)≤c*(S.radius.val/c) at H
      rw [Rat.mul_comm c (S.radius.val/c),Rat.div_mul_cancel (Rat.ne_of_gt hc)] at H
      grind only
    have H := S.firstOrder (c*u) (c*v) cu uv cv hsize
    have eq : S.error*(c*v-c*u)*(c*v-c*u)=(S.error*c*c)*(v-u)*(v-u) := by grind only
    rw [eq] at H
    apply H.congr
    apply arithmetic_identity; intro s; simp only [sub,RealApproximationOrder.scale]; grind only
  variation := c*S.variation*c
  variation_nonnegative := Rat.mul_nonneg (Rat.mul_nonneg (Rat.le_of_lt hc) S.variation_nonnegative) (Rat.le_of_lt hc)
  lipschitz := by
    intro u v hu huv hv
    have cu : l≤c*u := by
      have H := Rat.mul_le_mul_of_nonneg_left hu (Rat.le_of_lt hc); grind only
    have cv : c*v≤r := by
      have H := Rat.mul_le_mul_of_nonneg_left hv (Rat.le_of_lt hc); grind only
    have uv : c*u≤c*v := Rat.mul_le_mul_of_nonneg_left huv (Rat.le_of_lt hc)
    have H := (S.lipschitz (c*u) (c*v) cu uv cv).scale_nonnegative (Rat.le_of_lt hc)
    have eq : c*(S.variation*(c*v-c*u))=(c*S.variation*c)*(v-u) := by grind only
    rw [eq] at H
    apply H.congr
    apply arithmetic_identity; intro s; simp only [sub,RealApproximationOrder.scale]; grind only

end ComputableAnalysis.FTCRealCalculus
