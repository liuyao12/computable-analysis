import ComputableAnalysis.EulerImaginaryFinite
import ComputableAnalysis.EulerImaginaryNumerics
import ComputableAnalysis.EulerBoxLimit
import ComputableAnalysis.EulerPrecision

/-! Certified imaginary-coefficient Euler computations. Runtime interval
states depend on pi and rational arithmetic, never on sine/cosine evaluation. -/
namespace ComputableAnalysis.EulerImaginary
open ComputableCoefficient RealApproximationOrder
set_option maxHeartbeats 2500000

private def constantBox (I : QInterval) : RealRaw where
  compute _ := I

def addInterval (I J : QInterval) : QInterval :=
  (RealRaw.add (constantBox I) (constantBox J)).compute 0
def negateInterval (I : QInterval) : QInterval :=
  (RealRaw.neg (constantBox I)).compute 0
def multiplyInterval (I J : QInterval) : QInterval :=
  (RealRaw.mul (constantBox I) (constantBox J)).compute 0
def scaleInterval (h : Rat) (I : QInterval) : QInterval :=
  (RealRaw.scaleRat h (constantBox I)).compute 0

/-- Iterating interval pairs shares each previous state. This avoids evaluating
the recursively represented expression tree separately for each coordinate. -/
def boxLoop (h : Rat) (P : QInterval) : Nat → QInterval × QInterval
  | 0 => (⟨1,1⟩,⟨0,0⟩)
  | k+1 =>
    let previous := boxLoop h P k
    (addInterval previous.1 (scaleInterval h (multiplyInterval P (negateInterval previous.2))),
     addInterval previous.2 (scaleInterval h (multiplyInterval P previous.1)))

def boxes (h : Rat) (k m : Nat) : QInterval × QInterval :=
  boxLoop h (numericalPi.compute m) k

theorem boxes_eq (h : Rat) (k m : Nat) :
    (boxes h k m).1=((numericalState h k true).real.preferred.compute m) ∧
      (boxes h k m).2=((numericalState h k false).real.preferred.compute m) := by
  induction k with
  | zero => exact ⟨rfl,rfl⟩
  | succ k ih =>
    simp only [boxes,boxLoop] at ih ⊢
    rw [ih.1,ih.2]
    exact ⟨rfl,rfl⟩

def acceptable (h : Rat) (k : Nat) (eps : Rat) (m : Nat) : Prop :=
  let B := boxes h k m
  B.1.width≤eps ∧ B.2.width≤eps

instance (h : Rat) (k : Nat) (eps : Rat) : DecidablePred (acceptable h k eps) := by
  intro m
  unfold acceptable
  infer_instance

theorem exists_precision (h : Rat) (k : Nat) (eps : Rat) (heps : 0<eps) :
    ∃ m,acceptable h k eps m := by
  obtain ⟨A,hA⟩ := (numericalState h k true).real.valid.2.2 ⟨eps,heps⟩
  obtain ⟨B,hB⟩ := (numericalState h k false).real.valid.2.2 ⟨eps,heps⟩
  refine ⟨max A B,?_⟩
  change (boxes h k (max A B)).1.width≤eps ∧ (boxes h k (max A B)).2.width≤eps
  rw [(boxes_eq h k (max A B)).1,(boxes_eq h k (max A B)).2]
  exact ⟨hA _ (Nat.le_max_left _ _),hB _ (Nat.le_max_right _ _)⟩

def precision (h : Rat) (k : Nat) (eps : Rat) (heps : 0<eps) : Nat :=
  EulerPrecision.first (acceptable h k eps) (exists_precision h k eps heps)

theorem precision_spec (h : Rat) (k : Nat) (eps : Rat) (heps : 0<eps) :
    acceptable h k eps (precision h k eps heps) := EulerPrecision.first_spec _ _

def selectedPrecision (q : Rat) (n : Nat) : Nat :=
  precision (stepSize q n) (mesh q n) (numericalTolerance n) (tolerance_positive n)

def selectedBox (q : Rat) (n : Nat) (c : Bool) : QInterval :=
  let B := boxes (stepSize q n) (mesh q n) (selectedPrecision q n)
  if c then B.1 else B.2

def centers (q : Rat) (n : Nat) : QComplex :=
  ⟨(selectedBox q n true).midpoint,(selectedBox q n false).midpoint⟩

theorem selectedBox_eq (q : Rat) (n : Nat) (c : Bool) :
    selectedBox q n c=(numericalState (stepSize q n) (mesh q n) c).real.preferred.compute (selectedPrecision q n) := by
  cases c
  · exact (boxes_eq _ _ _).2
  · exact (boxes_eq _ _ _).1

theorem selected_width (q : Rat) (n : Nat) (c : Bool) :
    (selectedBox q n c).width≤numericalTolerance n := by
  have H := precision_spec (stepSize q n) (mesh q n) (numericalTolerance n) (tolerance_positive n)
  cases c
  · exact H.2
  · exact H.1

theorem center_coordinate (q : Rat) (n : Nat) (c : Bool) :
    EulerBoxLimit.coordinate (centers q n) c=(selectedBox q n c).midpoint := by
  cases c <;> rfl

/-- The numerical pi/evaluation error is certified independently of the ODE
mesh error. Both coordinate interval widths are checked by the runtime search. -/
theorem point_vs_numericalState (q : Rat) (n : Nat) (c : Bool) :
    Small (sub (numericalState (stepSize q n) (mesh q n) c)
      (Value.rational (EulerBoxLimit.coordinate (centers q n) c))) (numericalTolerance n) := by
  let V := numericalState (stepSize q n) (mesh q n) c
  let m := selectedPrecision q n
  apply small_of_samples _ _ (V.observation m)
  intro k hk s hs
  have H := V.encloses m k hk s hs
  have Ho := RealRaw.interval_order_of_valid V.real.preferred V.real.valid m
  have Hmid := QInterval.qabs_sub_midpoint_le_width Ho H.1 H.2
  have Hw := selected_width q n c
  rw [selectedBox_eq] at Hw
  change qabs (V.sample s-EulerBoxLimit.coordinate (centers q n) c)≤numericalTolerance n
  rw [center_coordinate,selectedBox_eq]
  exact Rat.le_trans Hmid Hw

theorem point_vs_state (q : Rat) (n : Nat) (c : Bool) :
    Small (sub (state (stepSize q n) (mesh q n) c)
      (Value.rational (EulerBoxLimit.coordinate (centers q n) c))) (numericalTolerance n) := by
  apply (point_vs_numericalState q n c).congr
  exact RealRaw.sub_equiv (numericalState (stepSize q n) (mesh q n) c).real.valid
    (state (stepSize q n) (mesh q n) c).real.valid (RealRaw.ofRat_valid _) (RealRaw.ofRat_valid _)
    (numericalState_equiv _ _ c) (RealRaw.equiv_refl (RealRaw.ofRat _) (RealRaw.ofRat_valid _))

theorem total_error (q : Rat) (n : Nat) (c : Bool) :
    Small (sub (Value.rational (EulerBoxLimit.coordinate (centers q n) c))
      (GeometricTrig.valueFor c q)) (EulerBoxLimit.allowance n) := by
  have Hpoint := point_vs_state q n c
  have Hode := (terminal_error q n c).mono (mesh_error_bound q n)
  have H := Hpoint.neg.add Hode
  have he : numericalTolerance n+numericalTolerance n=EulerBoxLimit.allowance n := by
    dsimp [numericalTolerance,EulerBoxLimit.allowance]
    grind [Rat.div_def]
  rw [he] at H
  apply H.congr
  apply arithmetic_identity
  intro s
  simp only [sub,Value.add,Value.neg,Value.rational]
  grind only

theorem center_bounds (q : Rat) (n : Nat) (c : Bool) :
    EulerBoxLimit.CenterBounds (GeometricTrig.sample c q)
      (EulerBoxLimit.coordinate (centers q n) c) (EulerBoxLimit.allowance n) := by
  have H := total_error q n c
  constructor
  · intro i j
    have Hhi := H.2 j 0
    change EulerBoxLimit.coordinate (centers q n) c-
      ((GeometricTrig.valueFor c q).real.preferred.compute j).hi≤EulerBoxLimit.allowance n at Hhi
    rw [GeometricTrig.valueFor_raw] at Hhi
    change EulerBoxLimit.coordinate (centers q n) c-EulerBoxLimit.allowance n≤((GeometricTrig.sample c q).compute j).hi
    grind only
  · intro j i
    have Hlo := H.1 0 j
    change -EulerBoxLimit.allowance n≤EulerBoxLimit.coordinate (centers q n) c-
      ((GeometricTrig.valueFor c q).real.preferred.compute j).lo at Hlo
    rw [GeometricTrig.valueFor_raw] at Hlo
    change ((GeometricTrig.sample c q).compute j).lo≤EulerBoxLimit.coordinate (centers q n) c+EulerBoxLimit.allowance n
    grind only

/-- The normalized imaginary exponential, constructed by numerical Euler
steps for the equation with coefficient i*pi. -/
def sample (q : Rat) : ComplexRaw := EulerBoxLimit.limit (centers q)

theorem sample_valid (q : Rat) : (sample q).Valid :=
  EulerBoxLimit.valid (centers q) (fun c => GeometricTrig.sample c q)
    (fun c => GeometricTrig.sample_valid c q) (fun c n => center_bounds q n c)

theorem realPart_agrees (q : Rat) : (sample q).realPart.Equiv (GeometricTrig.cos q) :=
  EulerBoxLimit.realPart_equiv (centers q) (fun c => GeometricTrig.sample c q) (fun c n => center_bounds q n c)

theorem imagPart_agrees (q : Rat) : (sample q).imagPart.Equiv (GeometricTrig.sin q) :=
  EulerBoxLimit.imagPart_equiv (centers q) (fun c => GeometricTrig.sample c q) (fun c n => center_bounds q n c)

def coordinateSample (c : Bool) (q : Rat) : RealRaw :=
  if c then (sample q).realPart else (sample q).imagPart

theorem coordinateSample_valid (c : Bool) (q : Rat) : (coordinateSample c q).Valid := by
  cases c
  · exact ComplexRaw.imagPart_valid (sample_valid q)
  · exact ComplexRaw.realPart_valid (sample_valid q)

theorem coordinateSample_agrees (c : Bool) (q : Rat) :
    (coordinateSample c q).Equiv (GeometricTrig.sample c q) := by
  cases c
  · exact imagPart_agrees q
  · exact realPart_agrees q

theorem coordinateSample_width (c : Bool) (q : Rat) (n : Nat) :
    ((coordinateSample c q).compute n).width≤4/((n+1:Nat):Rat) := by
  cases c
  · exact (EulerBoxLimit.widths (centers q) n).2
  · exact (EulerBoxLimit.widths (centers q) n).1

end ComputableAnalysis.EulerImaginary
