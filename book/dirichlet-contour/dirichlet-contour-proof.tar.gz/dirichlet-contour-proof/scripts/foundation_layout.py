#!/usr/bin/env python3
"""Maintain the source/build boundary; this is an import audit, not a proof audit.

The explicit manifest is authoritative after the initial split. Module names
and source bytes are preserved by rename. No theorem is inferred from its name.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "foundation" / "modules.json"
COMPANION = ROOT / "subprojects" / "special-topics"


def without_comments(text: str) -> str:
    """Remove nested Lean comments, preserving strings and line breaks."""
    out, i, depth, string = [], 0, 0, False
    while i < len(text):
        pair = text[i:i + 2]
        if depth:
            if pair == "/-":
                depth += 1
                i += 2
            elif pair == "-/":
                depth -= 1
                i += 2
            else:
                out.append("\n" if text[i] == "\n" else " ")
                i += 1
        elif string:
            out.append(text[i])
            if text[i] == "\\" and i + 1 < len(text):
                out.append(text[i + 1])
                i += 2
            else:
                if text[i] == '"':
                    string = False
                i += 1
        elif pair == "/-":
            depth = 1
            out.append(" ")
            i += 2
        elif pair == "--":
            end = text.find("\n", i)
            i = len(text) if end == -1 else end
        else:
            string = text[i] == '"'
            out.append(text[i])
            i += 1
    return "".join(out)


def imports(text: str) -> list[str]:
    # Lean imports form the header, before any declarations. Accept multiple
    # module names per command and import lines following a module header.
    lines = without_comments(text).splitlines()
    result: list[str] = []
    for line in lines:
        line = line.strip()
        if not line or line in ("module", "prelude"):
            continue
        match = re.fullmatch(r"(?:(?:public|private|meta)\s+)*import\s+(.+)", line)
        if not match:
            break
        result.extend(name for name in match[1].split() if name != "all")
    return result


def module_name(path: Path) -> str | None:
    parts = path.with_suffix("").parts
    return ".".join(parts) if all(p.isidentifier() for p in parts) else None


def reason(name: str) -> str | None:
    leaf = name.rsplit(".", 1)[-1]
    if any(part in name for part in (
        ".RiemannHilbert", ".ModularForms", ".AlgebraicODE", ".DirichletL", ".PDE"
    )) or any(part in leaf for part in ("Hydrogen", "Dirac", "Spinor", "Pauli", "Coulomb", "Thomas")):
        return "specialized-topic"
    if leaf in ("Distribution", "BoundaryValue"):
        return "legacy-model"
    if any(part in leaf for part in ("Example", "Playground", "Wiedijk", "FirstYearCalculus", "Blueprint", "Benchmark")):
        return "pedagogical-or-worked-example"
    if leaf.startswith(("FiniteStirling", "FiniteBasel", "FiniteBirthday", "FiniteBertrand", "FinitePell", "FinitePrime", "FiniteDecimal", "FiniteDigit", "FiniteDerangement", "FiniteSubsetCount", "FiniteInclusionExclusion")):
        return "pedagogical-or-worked-example"
    if leaf in ("Basel", "BaselFiniteComparison", "BaselFiniteStrengthening", "BaselTargetContainment", "GaussSeventeen", "Nilakantha", "IntegrationByPartsPi", "LogarithmicPi", "ReciprocalQuarticPi"):
        return "pedagogical-or-worked-example"
    return None


def lake_config(name: str, modules: list[str], dependency: bool = False) -> str:
    text = f'name = "{name}"\nversion = "0.1.0"\ndefaultTargets = ["{name}"]\n\n'
    if dependency:
        # Lean resolves all modules under a root namespace from its first
        # search-path directory. Both disjoint packages retain the same root.
        text += '# Share generated artifacts for the preserved Lean namespace.\n'
        text += 'buildDir = "../../.lake/build"\n\n'
    text += '# Generated from foundation/modules.json by scripts/foundation_layout.py.\n'
    text += '# Empty roots and explicit globs prevent ownership of the other package\'s modules.\n'
    text += f'[[lean_lib]]\nname = "{name}"\nroots = []\nglobs = [\n'
    text += "".join(f'  "{n}",\n' for n in modules)
    text += "]\n"
    if dependency:
        text += '\n[[require]]\nname = "ComputableAnalysis"\npath = "../.."\n'
    return text


def configure(data: dict) -> None:
    core = sorted(set(data["foundationModules"] + ["ComputableAnalysis"]))
    topics = sorted({row["module"] for row in data["companionFiles"] if row["module"]} | {"ComputableAnalysisTopics"})
    (ROOT / "lakefile.toml").write_text(lake_config("ComputableAnalysis", core))
    (COMPANION / "lakefile.toml").write_text(lake_config("ComputableAnalysisTopics", topics, True))


def audit(data: dict) -> list[str]:
    errors: list[str] = []
    core = set(data["foundationModules"]) | {"ComputableAnalysis"}
    companion = {row["module"] for row in data["companionFiles"] if row["module"]}
    if core & companion:
        errors.append("Modules belong to both packages: " + str(sorted(core & companion)))
    for name in sorted(core):
        path = ROOT / (name.replace(".", "/") + ".lean")
        if not path.is_file():
            errors.append(f"Missing foundation source: {name}")
            continue
        for dep in imports(path.read_text()):
            if dep.startswith("ComputableAnalysis.") and dep not in core:
                errors.append(f"Foundation imports outside its package: {name} -> {dep}")
            if dep == "Mathlib" or dep.startswith("Mathlib."):
                errors.append(f"Foundation imports Mathlib: {name} -> {dep}")
    expected_core = {n.replace(".", "/") + ".lean" for n in core if n != "ComputableAnalysis"}
    actual_core = {str(p.relative_to(ROOT)) for p in (ROOT / "ComputableAnalysis").rglob("*.lean")}
    if expected_core != actual_core:
        errors.append("Unregistered or absent foundation sources: " + str(sorted(expected_core ^ actual_core)))
    for row in data["companionFiles"]:
        if not (COMPANION / row["path"]).is_file():
            errors.append("Missing companion source: " + row["path"])
    if (ROOT / "lakefile.toml").read_text() != lake_config("ComputableAnalysis", sorted(core)):
        errors.append("Root lakefile differs from the manifest; run --configure")
    topics = sorted(companion | {"ComputableAnalysisTopics"})
    if (COMPANION / "lakefile.toml").read_text() != lake_config("ComputableAnalysisTopics", topics, True):
        errors.append("Companion lakefile differs from the manifest; run --configure")
    return errors


def split() -> None:
    if MANIFEST.exists():
        raise SystemExit("Already split; edit the explicit manifest to promote modules.")
    files = sorted((ROOT / "ComputableAnalysis").rglob("*.lean"))
    graph, rows, core = {}, {}, set()
    for path in files:
        rel = path.relative_to(ROOT)
        name = module_name(rel)
        row = {"path": str(rel), "module": name}
        rows[str(rel)] = row
        why = reason(name) if name else "historical-source-copy"
        if why:
            row["reason"] = why
        elif path.stat().st_flags & 0x40000000:
            row["reason"] = "support-awaiting-source-audit"
        else:
            graph[name] = imports(path.read_text())
            core.add(name)
    while True:
        bad = {name: next(dep for dep in graph[name] if dep.startswith("ComputableAnalysis.") and dep not in core)
               for name in core if any(dep.startswith("ComputableAnalysis.") and dep not in core for dep in graph[name])}
        if not bad:
            break
        core.difference_update(bad)
        for name, dep in bad.items():
            rows[name.replace(".", "/") + ".lean"].update(reason="support-awaiting-decoupling", dependency=dep)
    moved = [row for row in rows.values() if row["module"] not in core]
    # Rename preserves contents, permissions, and unhydrated cloud files. Check
    # inode/size for every move without reading or rewriting their mathematics.
    for row in moved:
        src, dst = ROOT / row["path"], COMPANION / row["path"]
        if dst.exists():
            raise SystemExit(f"Refusing to overwrite {dst}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        before = src.stat()
        src.rename(dst)
        after = dst.stat()
        assert (before.st_ino, before.st_size) == (after.st_ino, after.st_size)
    legacy = COMPANION / "ComputableAnalysis" / "LegacyCatalogue.lean"
    legacy.parent.mkdir(parents=True, exist_ok=True)
    (ROOT / "ComputableAnalysis.lean").rename(legacy)
    moved.append({"path": "ComputableAnalysis/LegacyCatalogue.lean", "module": "ComputableAnalysis.LegacyCatalogue", "reason": "legacy-all-topics-entry-point"})
    for path in sorted((ROOT / "ComputableAnalysis").rglob("*"), reverse=True):
        if path.is_dir() and not any(path.iterdir()):
            path.rmdir()
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    data = {"schemaVersion": 1, "note": "Import/build classification, not a semantic or kernel audit. Support awaiting promotion remains reusable in the companion.", "foundationModules": sorted(core), "companionFiles": moved}
    MANIFEST.write_text(json.dumps(data, indent=2) + "\n")
    (ROOT / "ComputableAnalysis.lean").write_text("/-! Public foundation; specialized and pedagogical modules live in the companion. -/\n" + "".join(f"import {name}\n" for name in sorted(core)))
    (COMPANION / "ComputableAnalysisTopics.lean").write_text("import ComputableAnalysis.LegacyCatalogue\n\n/-! Opt-in catalogue of specialized topics, examples, and support awaiting promotion. -/\n")
    (COMPANION / "lean-toolchain").write_bytes((ROOT / "lean-toolchain").read_bytes())
    configure(data)
    print(f"Foundation: {len(core)} modules; companion: {len(moved)} source files. Source names and bytes preserved.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--split", action="store_true", help="Initial, one-time source relocation")
    parser.add_argument("--configure", action="store_true", help="Regenerate both Lake configurations")
    args = parser.parse_args()
    if args.split:
        split()
    data = json.loads(MANIFEST.read_text())
    if args.configure:
        configure(data)
    errors = audit(data)
    if errors:
        raise SystemExit("\n".join(errors))
    print(f"Import boundary OK: {len(data['foundationModules'])} foundation modules, no companion or Mathlib imports.")


if __name__ == "__main__":
    main()
