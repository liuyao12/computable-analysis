import ComputableAnalysis.DirichletIntegral.ContourEvaluation
import Lean
open Lean Elab Command
open ComputableAnalysis ComputableCoefficient RealApproximationOrder LipschitzQuadrature

#print axioms DirichletIntegral.ContourEvaluation.integral_eq_pi_half
#print axioms DirichletIntegral.ContourEvaluation.error_bound
#print axioms DirichletIntegral.ContourFunction.boundary_converges_zero
#print axioms LipschitzQuadrature.Data.midpoint_error

-- Ordinary definitions retain executable computations.
def contourMapProgram := DirichletIntegral.ContourFunction.function (1:Rat)
def midpointProgram := midpointPrefix (fun t => Value.rational t) 0 1 4 4
#eval (midpointProgram.real.compute 0).lo
#eval (midpointProgram.real.compute 0).hi
example : (midpointProgram.real.compute 0).lo=(1:Rat)/2 ∧ (midpointProgram.real.compute 0).hi=(1:Rat)/2 := by decide +kernel

run_cmd do
  let env ← getEnv
  let root := `ComputableAnalysis.DirichletIntegral.ContourEvaluation.integral_eq_pi_half
  let mut todo := [root]
  let mut seen : Std.HashSet Name := {}
  let mut axioms : Array Name := #[]
  while !todo.isEmpty do
    let n := todo.head!
    todo := todo.tail!
    if seen.contains n then continue
    seen := seen.insert n
    let some info := env.find? n | throwError "Missing dependency: {n}"
    if info matches .axiomInfo _ then axioms := axioms.push n
    todo := info.type.getUsedConstants.toList ++ todo
    if let some value := info.value? true then todo := value.getUsedConstants.toList ++ todo
  let forbidden := seen.toArray.filter fun n =>
    let s := n.toString
    s.startsWith "ComputableAnalysis.DirichletIntegral.Parameter" ||
    s.startsWith "ComputableAnalysis.DirichletIntegral.FeynmanValue" ||
    s.startsWith "ComputableAnalysis.DirichletIntegral.Evaluation." ||
    s.startsWith "ComputableAnalysis.DirichletIntegral.Damping" ||
    s.startsWith "ComputableAnalysis.DirichletIntegral.Laplace" ||
    s == "Real" || s == "Complex" || s.startsWith "Mathlib."
  unless forbidden.isEmpty do throwError "Forbidden dependencies: {forbidden}"
  let allowed := [`propext, `Classical.choice, `Quot.sound]
  for a in axioms do unless allowed.contains a do throwError "Unexpected axiom: {a}"
  logInfo m!"PASS: {seen.size} declarations; no parameter/Feynman/damping/Laplace or ambient Real/Complex dependencies; standard logical axioms only."
