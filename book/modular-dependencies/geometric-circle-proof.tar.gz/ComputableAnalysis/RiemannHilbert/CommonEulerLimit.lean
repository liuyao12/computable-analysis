import ComputableAnalysis.RiemannHilbert.SeriesLimitLaws

/-! Uniqueness from a common, justified finite Euler computation. This law
does not assume equality of the supplied values. In an ODE application each
error estimate must be constructed from its solution residual and stability. -/
namespace ComputableAnalysis.RiemannHilbert.CommonEulerLimit
open ComplexRaw FunctionTheory SeriesLimitLaws

structure Evidence (mesh : Nat → ComplexRaw) (rate : Nat → Rat) (value : {z : ComplexRaw // z.Valid}) where
  constant : Rat
  nonnegative : 0 ≤ constant
  error : ∀ n, Small (sub value.val (mesh n)) (constant * rate n)

theorem unique (mesh : Nat → ComplexRaw) (valid : ∀ n, (mesh n).Valid)
    (rate : Nat → Rat) (shrinking : ShrinksToZero rate) (u v : {z : ComplexRaw // z.Valid})
    (hu : Evidence mesh rate u) (hv : Evidence mesh rate v) : u.val.Equiv v.val := by
  apply equiv_of_small_sub_zero
  apply small_closed (sub u.val v.val) 0
    (fun n => (hu.constant + hv.constant) * rate n)
    (shrinks_scale rate shrinking _ (Rat.add_nonneg hu.nonnegative hv.nonnegative))
  intro n
  have hb := LocalODE.small_add (hu.error n)
    (RepresentedCauchySum.small_sub_symm _ _ _ (hv.error n))
  have he : (add (sub u.val (mesh n)) (sub (mesh n) v.val)).Equiv (sub u.val v.val) := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := add_valid (sub_valid u.property (valid n)) (sub_valid (valid n) v.property))
      (hright := sub_valid u.property v.property)
    change (ComplexRawQuotient.ofRaw u.val u.property - ComplexRawQuotient.ofRaw (mesh n) (valid n)) +
      (ComplexRawQuotient.ofRaw (mesh n) (valid n) - ComplexRawQuotient.ofRaw v.val v.property) =
      ComplexRawQuotient.ofRaw u.val u.property - ComplexRawQuotient.ofRaw v.val v.property
    grind only
  have h := Small.congr
    (add_valid (sub_valid u.property (valid n)) (sub_valid (valid n) v.property))
    (sub_valid u.property v.property) he hb
  apply h.mono
  grind only

end ComputableAnalysis.RiemannHilbert.CommonEulerLimit
