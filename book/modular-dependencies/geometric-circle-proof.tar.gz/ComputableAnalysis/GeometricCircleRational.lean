import ComputableAnalysis.ElementaryCircleAngle

/-! Rational stereographic coordinates are the primary geometric circle
object. Sector angles are geometric coordinate add-ons, computed from areas.
Reflection and reciprocal charts cover every rational slope. -/
namespace ComputableAnalysis.GeometricCircleRational
open ComplexRaw RiemannHilbert ElementaryCircleAngle GeometricRotationODE
set_option maxHeartbeats 400000

def oneSlope : UnitSlope := ⟨1,by decide +kernel,by decide +kernel⟩

def reciprocalSlope (t : Rat) (ht : 1 < t) : UnitSlope where
  val := t⁻¹
  nonnegative := Rat.le_of_lt (Rat.inv_pos.mpr (by grind only))
  le_one := by
    have hn := Rat.le_of_lt (Rat.inv_pos.mpr (show 0 < t by grind only))
    have hm := Rat.mul_le_mul_of_nonneg_right (Rat.le_of_lt ht) hn
    have hc := Rat.mul_inv_cancel t (by grind only)
    grind only

def positiveAngle (t : Rat) (ht : 0 ≤ t) : RealRaw :=
  if h : t ≤ 1 then twiceArctangent ⟨t,ht,h⟩
  else RealRaw.sub (RealRaw.scaleRat 2 (twiceArctangent oneSlope))
    (twiceArctangent (reciprocalSlope t (by grind only)))

theorem positiveAngle_valid (t : Rat) (ht : 0 ≤ t) : (positiveAngle t ht).Valid := by
  unfold positiveAngle
  split
  · exact twiceArctangent_valid _
  · exact RealRaw.sub_valid (RealRaw.scaleRat_valid (twiceArctangent_valid _))
      (twiceArctangent_valid _)

def angle (t : Rat) : RealRaw :=
  if h : 0 ≤ t then positiveAngle t h
  else RealRaw.neg (positiveAngle (-t) (by grind only))

theorem angle_valid (t : Rat) : (angle t).Valid := by
  unfold angle
  split
  · exact positiveAngle_valid _ _
  · exact RealRaw.neg_valid (positiveAngle_valid _ _)

/-- Primary computations have rational inputs and exact rational outputs. -/
def sine (t : Rat) : RealRaw := RationalCircle.Trigonometry.sinRaw t
def cosine (t : Rat) : RealRaw := RationalCircle.Trigonometry.cosRaw t

theorem sine_valid (t : Rat) : (sine t).Valid := RealRaw.ofRat_valid _
theorem cosine_valid (t : Rat) : (cosine t).Valid := RealRaw.ofRat_valid _

theorem point_neg (t : Rat) : pointComplex (-t) = QComplex.conj (pointComplex t) := by
  change (⟨RationalCircle.Trigonometry.cos (-t),RationalCircle.Trigonometry.sin (-t)⟩ : QComplex) = _
  rw [RationalCircle.Trigonometry.cos_neg,RationalCircle.Trigonometry.sin_neg]
  rfl

theorem point_reciprocal (t : Rat) (ht : t ≠ 0) :
    pointComplex t = QComplex.neg (QComplex.conj (pointComplex t⁻¹)) := by
  have hc := Rat.mul_inv_cancel t ht
  have hd : 1+t*t ≠ 0 := by
    have h := RationalCircle.Stage.one_add_square_pos t
    grind only
  have he : 1+t⁻¹*t⁻¹ ≠ 0 := by
    have h := RationalCircle.Stage.one_add_square_pos t⁻¹
    grind only
  have hdi := Rat.mul_inv_cancel (1+t*t) hd
  have hei := Rat.mul_inv_cancel (1+t⁻¹*t⁻¹) he
  simp only [pointComplex,RationalCircle.Stage.point,QComplex.neg,QComplex.conj,Rat.div_def]
  congr 1 <;> grind only

end ComputableAnalysis.GeometricCircleRational
