import ComputableAnalysis.ElementaryCircleAngle
import ComputableAnalysis.GeometricCircleRational
import ComputableAnalysis.ElementarySineODEComparison
import ComputableAnalysis.RiemannHilbert.CommonEulerLimit

/-! Independent geometric circle and sine power series. The primary geometric
object has rational stereographic inputs. Its sector angle is computed from
polygonal areas; exponential is used only as an intermediate ODE solution. -/
namespace ComputableAnalysis.GeometricCircleODEComparison
open ComplexRaw FunctionTheory RiemannHilbert SeriesLimitLaws ModularForms DomainFunctions
open ElementaryCircleAngle GeometricRotationODE ElementarySineODE
set_option maxHeartbeats 2000000

def endpointMesh (t : UnitSlope) (n : Nat) : ComplexRaw :=
  ofQComplex (ElementaryCircleAngle.mesh t (geometricConvergenceMesh n) (geometricConvergenceMesh n + 1))

def geometricPoint (t : Rat) : Scalar := ⟨ofQComplex (pointComplex t),ofQComplex_valid _⟩

def geometricSolutionEvidence (t : UnitSlope) :
    CommonEulerLimit.Evidence (endpointMesh t) geometricEulerEndpointRate (geometricPoint t.val) where
  constant := 1
  nonnegative := by decide +kernel
  error n := by
    simpa only [Rat.one_mul,geometricPoint,endpointMesh] using
      RepresentedCauchySum.small_sub_symm _ _ _ (mesh_endpoint_small t n)

/-- The second solution is certified by its angular rectangle convergence and
its local exponential remainder, propagated along the *same* Euler mesh. No
previous geometric/exponential agreement theorem is used here. -/
def analyticSolutionEvidence (t : UnitSlope) :
    CommonEulerLimit.Evidence (endpointMesh t) geometricEulerEndpointRate
      (entireExponentialValue (imaginaryAngle t)) where
  constant := exponentialQuadraticConstant geometricFactorRadius + geometricExponentialErrorScale
  nonnegative := Rat.add_nonneg (exponentialQuadraticConstant_nonnegative _)
    geometricExponentialErrorScale_nonnegative
  error n := by
    let j := geometricConvergenceMesh n
    let p := product t j (j+1)
    let f := (entireExponentialValue (imaginaryAngle t)).val
    let q := endpointMesh t n
    have hp := product_valid t j (j+1)
    have hq := ofQComplex_valid (ElementaryCircleAngle.mesh t j (j+1))
    have ha := Small.congr
      (sub_valid (entireExponentialValue (angleScalar t j (j+1))).property
        (entireExponentialValue (imaginaryAngle t)).property)
      (sub_valid hp (entireExponentialValue (imaginaryAngle t)).property)
      (FunctionTheory.sub_congr (equiv_symm (product_angle t j (j+1)))
        (equiv_refl _ (entireExponentialValue (imaginaryAngle t)).property))
      (angle_exponential_target_error t j)
    have hb := LocalODE.small_add (RepresentedCauchySum.small_sub_symm _ _ _ ha)
      (product_endpoint_error t n)
    have he : (add (sub f p) (sub p q)).Equiv (sub f q) := by
      apply ComplexRawQuotient.equiv_of_ofRaw_eq
        (hleft := add_valid (sub_valid (entireExponentialValue _).property hp) (sub_valid hp hq))
        (hright := sub_valid (entireExponentialValue _).property hq)
      change (ComplexRawQuotient.ofRaw f (entireExponentialValue _).property -
        ComplexRawQuotient.ofRaw p hp) + (ComplexRawQuotient.ofRaw p hp -
        ComplexRawQuotient.ofRaw q hq) = ComplexRawQuotient.ofRaw f (entireExponentialValue _).property -
        ComplexRawQuotient.ofRaw q hq
      grind only
    have hc := Small.congr
      (add_valid (sub_valid (entireExponentialValue _).property hp) (sub_valid hp hq))
      (sub_valid (entireExponentialValue _).property hq) he hb
    apply hc.mono
    have hpos := Rat.le_of_lt (geometricMeshStep_positive j)
    have hconst := exponentialQuadraticConstant_nonnegative geometricFactorRadius
    have hm := Rat.mul_nonneg hconst hpos
    unfold geometricExponentialEndpointRate geometricEulerEndpointRate
    dsimp [j] at *
    grind only

theorem geometric_rotation_ode_unique (t : UnitSlope) :
    (entireExponentialValue (imaginaryAngle t)).val.Equiv (geometricPoint t.val).val :=
  CommonEulerLimit.unique (endpointMesh t) (fun _ => ofQComplex_valid _)
    geometricEulerEndpointRate geometricEulerEndpointRate_shrinks _ _
    (analyticSolutionEvidence t) (geometricSolutionEvidence t)

private theorem rationalProduct (p q : QComplex) :
    (mul (ofQComplex p) (ofQComplex q)).Equiv (ofQComplex (QComplex.mul p q)) :=
  equiv_trans (mul_valid (ofQComplex_valid _) (ofQComplex_valid _))
    (qcomplexLeftMul_valid p (ofQComplex_valid q)) (ofQComplex_valid _)
    (equiv_symm (qcomplexLeftMul_equiv_mul_ofQComplex p (ofQComplex_valid q)))
    (qcomplexLeftMul_ofQComplex p q)

def angleRotation (x : RealRaw) (hx : x.Valid) : Scalar :=
  entireExponentialValue ⟨imaginaryAxis x,imaginaryAxis_valid hx⟩

private theorem axis_neg (x : RealRaw) (hx : x.Valid) :
    (imaginaryAxis (RealRaw.neg x)).Equiv (conj (imaginaryAxis x)) := by
  intro n
  apply (compareAt_overlap_iff _ _ n n).mpr
  have ho := RealRaw.interval_order_of_valid x hx n
  simp only [imaginaryAxis,mulI,ofRealRaw,RealRaw.neg,RealRaw.negCompute,
    conj,QBox.conj,QBox.Overlaps,QComplex.le_def,Rat.neg_zero]
  constructor <;> constructor <;> grind only

private theorem rotation_neg (x : RealRaw) (hx : x.Valid) :
    (angleRotation (RealRaw.neg x) (RealRaw.neg_valid hx)).val.Equiv
      (conj (angleRotation x hx).val) :=
  equiv_trans (angleRotation _ _).property (entireExponentialValue
    (exponentialConjugateInput ⟨imaginaryAxis x,imaginaryAxis_valid hx⟩)).property
    (conj_valid _ (angleRotation x hx).property)
    (entireExponentialValue_congr _ _ (axis_neg x hx))
    (equiv_symm (entireExponential_conjugation _))

private theorem rotation_sub (x y : RealRaw) (hx : x.Valid) (hy : y.Valid) :
    (angleRotation (RealRaw.sub x y) (RealRaw.sub_valid hx hy)).val.Equiv
      (mul (angleRotation x hx).val (conj (angleRotation y hy).val)) := by
  let p : Scalar := ⟨imaginaryAxis x,imaginaryAxis_valid hx⟩
  let q := exponentialConjugateInput (⟨imaginaryAxis y,imaginaryAxis_valid hy⟩ : Scalar)
  let sum : Scalar := ⟨add p.val q.val,add_valid p.property q.property⟩
  have hi : (imaginaryAxis (RealRaw.sub x y)).Equiv sum.val := by
    intro n
    apply (compareAt_overlap_iff _ _ n n).mpr
    have ho := RealRaw.interval_order_of_valid x hx n
    have hp := RealRaw.interval_order_of_valid y hy n
    simp only [sum,p,q,exponentialConjugateInput,imaginaryAxis,mulI,ofRealRaw,
      RealRaw.sub,RealRaw.subCompute,RealRaw.neg,RealRaw.negCompute,RealRaw.add,RealRaw.addCompute,
      conj,add,QBox.conj,QBox.add,QComplex.add,QBox.Overlaps,QComplex.le_def,
      Rat.neg_zero,Rat.zero_add]
    constructor <;> constructor <;> grind only
  exact equiv_trans (angleRotation _ _).property (entireExponentialValue sum).property
    (mul_valid (angleRotation x hx).property (conj_valid _ (angleRotation y hy).property))
    (entireExponentialValue_congr _ _ hi)
    (equiv_trans (entireExponentialValue sum).property
      (mul_valid (entireExponentialValue p).property (entireExponentialValue q).property)
      (mul_valid (angleRotation x hx).property (conj_valid _ (angleRotation y hy).property))
      (equiv_symm (entireExponential_addition p q))
      (mul_equiv (angleRotation x hx).property (angleRotation x hx).property
        (entireExponentialValue q).property (conj_valid _ (angleRotation y hy).property)
        (equiv_refl _ (angleRotation x hx).property)
        (equiv_symm (entireExponential_conjugation _))))

private theorem positive_rotation (t : Rat) (ht : 0 ≤ t) :
    (angleRotation (GeometricCircleRational.positiveAngle t ht)
      (GeometricCircleRational.positiveAngle_valid t ht)).val.Equiv (geometricPoint t).val := by
  by_cases h : t ≤ 1
  · simpa only [GeometricCircleRational.positiveAngle,dif_pos h,angleRotation,imaginaryAngle] using
      geometric_rotation_ode_unique ⟨t,ht,h⟩
  · let u := GeometricCircleRational.reciprocalSlope t (show 1<t by grind only)
    simp only [GeometricCircleRational.positiveAngle,dif_neg h]
    let v := GeometricCircleRational.oneSlope
    let x := twiceArctangent v
    let y := twiceArctangent u
    have hv := geometric_rotation_ode_unique v
    have hu := geometric_rotation_ode_unique u
    change (angleRotation x (twiceArctangent_valid v)).val.Equiv (geometricPoint 1).val at hv
    change (angleRotation y (twiceArctangent_valid u)).val.Equiv (geometricPoint u.val).val at hu
    have hd := ElementaryAngleAlgebra.exponential_double x (twiceArctangent_valid v)
    have hprod := mul_equiv (angleRotation x (twiceArctangent_valid v)).property (geometricPoint 1).property
      (angleRotation x (twiceArctangent_valid v)).property (geometricPoint 1).property hv hv
    have hhalf : (angleRotation (RealRaw.scaleRat 2 x) (RealRaw.scaleRat_valid (twiceArctangent_valid v))).val.Equiv
        (ofQComplex ⟨-1,0⟩) :=
      equiv_trans (angleRotation _ _).property
        (mul_valid (angleRotation x (twiceArctangent_valid v)).property (angleRotation x (twiceArctangent_valid v)).property)
        (ofQComplex_valid _) hd
        (equiv_trans (mul_valid (angleRotation x (twiceArctangent_valid v)).property (angleRotation x (twiceArctangent_valid v)).property)
          (mul_valid (geometricPoint 1).property (geometricPoint 1).property) (ofQComplex_valid _)
          hprod (by
            simpa only [geometricPoint,pointComplex_one,
              show QComplex.mul RotationSeries.imaginaryUnit RotationSeries.imaginaryUnit = ⟨-1,0⟩ by decide +kernel]
              using rationalProduct RotationSeries.imaginaryUnit RotationSeries.imaginaryUnit))
    have hs := rotation_sub (RealRaw.scaleRat 2 x) y
      (RealRaw.scaleRat_valid (twiceArctangent_valid v)) (twiceArctangent_valid u)
    have hc : (conj (ofQComplex (pointComplex u.val))).Equiv (ofQComplex (QComplex.conj (pointComplex u.val))) := by
      intro n
      apply (compareAt_overlap_iff _ _ n n).mpr
      exact ⟨⟨Rat.le_refl,Rat.le_refl⟩,⟨Rat.le_refl,Rat.le_refl⟩⟩
    have hneg := equiv_trans (conj_valid _ (angleRotation y (twiceArctangent_valid u)).property)
      (conj_valid _ (geometricPoint u.val).property) (ofQComplex_valid _)
      (conj_equiv hu) hc
    have hm := mul_equiv (angleRotation (RealRaw.scaleRat 2 x) (RealRaw.scaleRat_valid (twiceArctangent_valid v))).property (ofQComplex_valid ⟨-1,0⟩)
      (conj_valid _ (angleRotation y (twiceArctangent_valid u)).property) (ofQComplex_valid _) hhalf hneg
    have he : QComplex.mul (⟨-1,0⟩ : QComplex) (QComplex.conj (pointComplex u.val)) = pointComplex t := by
      rw [GeometricCircleRational.point_reciprocal t (by grind only)]
      change QComplex.mul ⟨-1,0⟩ (QComplex.conj (pointComplex t⁻¹)) = _
      simp only [QComplex.mul,QComplex.neg,QComplex.conj]
      congr 1 <;> grind only
    have hf := rationalProduct ⟨-1,0⟩ (QComplex.conj (pointComplex u.val))
    rw [he] at hf
    exact equiv_trans (angleRotation _ _).property
      (mul_valid (angleRotation (RealRaw.scaleRat 2 x) (RealRaw.scaleRat_valid (twiceArctangent_valid v))).property (conj_valid _ (angleRotation y (twiceArctangent_valid u)).property))
      (geometricPoint t).property hs
      (equiv_trans (mul_valid (angleRotation (RealRaw.scaleRat 2 x) (RealRaw.scaleRat_valid (twiceArctangent_valid v))).property (conj_valid _ (angleRotation y (twiceArctangent_valid u)).property))
        (mul_valid (ofQComplex_valid ⟨-1,0⟩) (ofQComplex_valid _)) (geometricPoint t).property hm hf)

/-- All rational slopes, including reciprocal and reflected charts. The angle
algorithm contains geometric areas and rational arithmetic only. -/
theorem geometric_rotation_all_rational (t : Rat) :
    (angleRotation (GeometricCircleRational.angle t) (GeometricCircleRational.angle_valid t)).val.Equiv
      (geometricPoint t).val := by
  by_cases h : 0 ≤ t
  · simpa only [GeometricCircleRational.angle,dif_pos h] using positive_rotation t h
  · have hn : 0 ≤ -t := by grind only
    have he := rotation_neg (GeometricCircleRational.positiveAngle (-t) hn)
      (GeometricCircleRational.positiveAngle_valid (-t) hn)
    have hg := conj_equiv (positive_rotation (-t) hn)
    have hc : (conj (geometricPoint (-t)).val).Equiv (geometricPoint t).val := by
      change (conj (ofQComplex (pointComplex (-t)))).Equiv (ofQComplex (pointComplex t))
      rw [GeometricCircleRational.point_neg]
      intro n
      apply (compareAt_overlap_iff _ _ n n).mpr
      simp only [conj,ofQComplex,QBox.conj,QBox.point,QComplex.conj,Rat.neg_neg,QBox.Overlaps,QComplex.le_def]
      exact ⟨⟨Rat.le_refl,Rat.le_refl⟩,⟨Rat.le_refl,Rat.le_refl⟩⟩
    simpa only [GeometricCircleRational.angle,dif_neg h] using
      equiv_trans (angleRotation _ _).property
        (conj_valid _ (angleRotation (GeometricCircleRational.positiveAngle (-t) hn) _).property)
        (geometricPoint t).property he
        (equiv_trans (conj_valid _ (angleRotation (GeometricCircleRational.positiveAngle (-t) hn) _).property)
          (conj_valid _ (geometricPoint (-t)).property) (geometricPoint t).property hg hc)

private theorem imaginary_product (x : RealRaw) (hx : x.Valid) :
    (mul iScalar.val (ofRealRaw x)).Equiv (imaginaryAxis x) := by
  intro n
  let p : QComplex := ⟨(x.compute n).midpoint,0⟩
  have hp := QInterval.midpoint_mem (RealRaw.interval_order_of_valid x hx n)
  have hm := QBox.mul_contains (A := QBox.point ⟨0,1⟩) (B := (ofRealRaw x).compute n)
    (z := ⟨0,1⟩) (w := p) (QComplex.le_refl _) (QComplex.le_refl _)
    (show ((ofRealRaw x).compute n).lo ≤ p from ⟨hp.1,Rat.le_refl⟩)
    (show p ≤ ((ofRealRaw x).compute n).hi from ⟨hp.2,Rat.le_refl⟩)
  have hq : QComplex.mul ⟨0,1⟩ p = ⟨0,p.re⟩ := by
    simp [p,QComplex.mul,Rat.sub_eq_add_neg,Rat.neg_zero,Rat.zero_mul,Rat.mul_zero,Rat.one_mul,Rat.zero_add,Rat.add_zero]
  rw [hq] at hm
  apply (compareAt_overlap_iff _ _ n n).mpr
  apply QBox.overlaps_of_common_point hm
  exact ⟨⟨by simp [imaginaryAxis,mulI,ofRealRaw],hp.1⟩,
    ⟨by simp [imaginaryAxis,mulI,ofRealRaw],hp.2⟩⟩

def radianAngle (t : Rat) : Scalar :=
  ⟨ofRealRaw (GeometricCircleRational.angle t),ofRealRaw_valid _ (GeometricCircleRational.angle_valid t)⟩

/-- Exact comparison of the independent rational circle construction and the
derived matrix-Taylor sine at its geometric sector angle. The two ODE steps
are common-mesh uniqueness for the variable-speed circle and whole-plane
oscillator uniqueness for the analytic solution. -/
theorem geometric_sine_powerSeries (t : Rat) :
    (ofRealRaw (GeometricCircleRational.sine t)).Equiv
      (powerSeriesExtension (radianAngle t)).val := by
  let x := GeometricCircleRational.angle t
  have hx := GeometricCircleRational.angle_valid t
  let z := radianAngle t
  have hi : (mul (positiveFrequency oneScalar).val z.val).Equiv (imaginaryAxis x) :=
    equiv_trans (mul_valid (positiveFrequency oneScalar).property z.property)
      (mul_valid iScalar.property z.property) (imaginaryAxis_valid hx)
      (mul_equiv (positiveFrequency oneScalar).property iScalar.property z.property z.property
        (mul_one_equiv iScalar.val iScalar.property) (equiv_refl _ z.property))
      (imaginary_product x hx)
  have hs := sine_at_real_angle oneScalar z x hx hi
  have hg : (ElementaryInverseBranches.sineAtAngle x hx).Equiv (GeometricCircleRational.sine t) :=
    imagPart_equiv (geometric_rotation_all_rational t)
  have hgeo := ofRealRaw_equiv_of_equiv (ElementaryInverseBranches.sineAtAngle_valid x hx)
    (GeometricCircleRational.sine_valid t) hg
  exact equiv_trans (ofRealRaw_valid _ (GeometricCircleRational.sine_valid t))
    ((sine oneScalar).eval z trivial).property (powerSeriesExtension z).property
    (equiv_symm (equiv_trans ((sine oneScalar).eval z trivial).property
      (ofRealRaw_valid _ (ElementaryInverseBranches.sineAtAngle_valid x hx))
      (ofRealRaw_valid _ (GeometricCircleRational.sine_valid t)) hs hgeo))
    (computations_agree_global oneScalar z 0)

/-- The irrational angle evaluation is an add-on justified by convergence of
the actual primary rational-complex power-series computation. -/
theorem geometric_sine_primary_converges (t : Rat) (eps : QPos) :
    ∃ N, ∀ n, N ≤ n → Small
      (sub (ElementaryPowerSeries.sineValue ((radianAngle t).val.compute n).center)
        (ofRealRaw (GeometricCircleRational.sine t))) eps.val := by
  obtain ⟨N,hN⟩ := powerSeries_primary_converges (radianAngle t) eps
  refine ⟨N,fun n hn => ?_⟩
  exact Small.congr
    (sub_valid (ElementaryPowerSeries.sineValue_valid _) (powerSeriesExtension _).property)
    (sub_valid (ElementaryPowerSeries.sineValue_valid _) (ofRealRaw_valid _ (GeometricCircleRational.sine_valid t)))
    (FunctionTheory.sub_congr (equiv_refl _ (ElementaryPowerSeries.sineValue_valid _))
      (equiv_symm (geometric_sine_powerSeries t))) (hN n hn)

/-- Comparison of primary values on an actual coordinate overlap. -/
theorem primary_agreement_on_overlap (t : Rat) (q : QComplex)
    (h : (ofQComplex q).Equiv (radianAngle t).val) :
    (ElementaryPowerSeries.sineValue q).Equiv (ofRealRaw (GeometricCircleRational.sine t)) :=
  equiv_trans (ElementaryPowerSeries.sineValue_valid _)
    (powerSeriesExtension ⟨ofQComplex q,ofQComplex_valid _⟩).property
    (ofRealRaw_valid _ (GeometricCircleRational.sine_valid t)) (powerSeries_primary_agrees q)
    (equiv_trans (powerSeriesExtension ⟨ofQComplex q,ofQComplex_valid _⟩).property
      (powerSeriesExtension (radianAngle t)).property (ofRealRaw_valid _ (GeometricCircleRational.sine_valid t))
      (powerSeriesExtension_congr _ _ h) (equiv_symm (geometric_sine_powerSeries t)))

end ComputableAnalysis.GeometricCircleODEComparison
