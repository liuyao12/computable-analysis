import ComputableAnalysis.ModularForms.LatticeJNormalizedFourier
import ComputableAnalysis.ModularForms.CMJDomain163

/-! Exact normalized Fourier identity for the actual CM lattice j value. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- The actual normalized weight-four Fourier value at the CM point. -/
def cmEisensteinFour163 : Scalar :=
  nomeEisensteinFour (nome.eval cmScalar163 cmPoint163_upper) (1/68719476736)
    (by decide +kernel) (by decide +kernel) nome_cm163_small_thirtySix_power

/-- The constructed CM j value satisfies its exact normalized Fourier identity. -/
theorem cmJValue163_normalized_fourier_product :
    (mul cmJValue163.val cmFourierDiscriminant163.val).Equiv
      (LocalODE.power cmEisensteinFour163.val 3) :=
  latticeJMap_normalized_fourier_product cmScalar163 latticeJMap_cm_domain (1/68719476736)
    (by decide +kernel) (by decide +kernel) nome_cm163_small_thirtySix_power

end ComputableAnalysis.ModularForms
