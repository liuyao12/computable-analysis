import ComputableAnalysis.RiemannHilbert.GeneralSeries

namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert

/-- The actual bounded-series sum admits a remainder using the bound of
the supplied point, rather than the larger construction disk. -/
theorem boundedSeries_point_remainder (c : Nat → ComplexRaw) (hc : ∀ n, (c n).Valid)
    (z : Scalar) (C K R r : Rat) (hC : 0≤C) (hK : 0≤K) (hR : 0≤R) (hr : 0≤r)
    (hb : ∀ n, Small (c n) (C*K^n)) (hzR : Small z.val R) (hzr : Small z.val r)
    (hlocal : 2*K*R≤(1:Rat)/2) (hpoint : 2*K*r≤(1:Rat)/2) (N : Nat) :
    Small (sub (BoundedSeries.sumValue c z.val hc z.property C K R)
      (BoundedSeries.valueBlock c z.val 0 N)) ((4*C*(2*K)^N)*r^N) := by
  have he := LocalODE.coefficientSum_congr_of_bounds c c z.val z.val hc hc z.property z.property
    (fun n => equiv_refl _ (hc n)) (equiv_refl _ z.property)
    C K R C K r hC hK hR hC hK hr hb hb hzR hzr hlocal hpoint
  have hs := BoundedSeries.sumValue_close_prefix c z.val hc z.property C K r hC hK hr hb hzr hpoint N
  have hvalid := BoundedSeries.sumValue_valid c z.val hc z.property C K R hC hK hR hb hzR hlocal
  have hvalidr := BoundedSeries.sumValue_valid c z.val hc z.property C K r hC hK hr hb hzr hpoint
  have ht := Small.congr
    (sub_valid hvalidr (BoundedSeries.valueBlock_valid c z.val hc z.property 0 N))
    (sub_valid hvalid (BoundedSeries.valueBlock_valid c z.val hc z.property 0 N))
    (FunctionTheory.sub_congr (equiv_symm he)
      (equiv_refl _ (BoundedSeries.valueBlock_valid c z.val hc z.property 0 N))) hs
  have htail : LocalODE.valueTail C K r N=(4*C*(2*K)^N)*r^N := by
    dsimp [LocalODE.valueTail]
    rw [LocalODE.rational_mul_pow]
    grind only
  rw [htail] at ht
  exact ht

end ComputableAnalysis.ModularForms
