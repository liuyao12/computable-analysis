import ComputableAnalysis.RiemannHilbert.GeneralSeries
import ComputableAnalysis.ModularForms.TauComplexTermBounds

namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert

theorem boundedSeries_integer_scaled_prefix (c : Nat → ComplexRaw) (hc : ∀ n, (c n).Valid)
    (q : Scalar) (t : Int) (N : Nat) :
    (BoundedSeries.valueBlock (fun n => scaleRat (t:Rat) (c n)) q.val 0 N).Equiv
      (scaleRat (t:Rat) (BoundedSeries.valueBlock c q.val 0 N)) := by
  induction N with
  | zero => exact equiv_symm (scaleRat_zero_equiv _)
  | succ N ih =>
    have hp := LocalODE.power_valid _ q.property N
    have hterm := ComplexRaw.scaleRat_mul_equiv (t:Rat) (c N) (LocalODE.power q.val N) (hc N) hp
    have hsum := add_equiv ih (equiv_symm hterm)
    have hdist := equiv_symm (ComplexRaw.scaleRat_add_equiv (t:Rat)
        (BoundedSeries.valueBlock c q.val 0 N) (mul (c N) (LocalODE.power q.val N))
        (BoundedSeries.valueBlock_valid c q.val hc q.property 0 N) (mul_valid (hc N) hp))
    simpa only [BoundedSeries.valueBlock,Nat.zero_add] using equiv_trans
      (add_valid (BoundedSeries.valueBlock_valid _ _ (fun n => scaleRat_valid (hc n)) q.property 0 N)
        (mul_valid (scaleRat_valid (hc N)) hp))
      (add_valid (scaleRat_valid (r := (t:Rat)) (BoundedSeries.valueBlock_valid c q.val hc q.property 0 N))
        (scaleRat_valid (r := (t:Rat)) (mul_valid (hc N) hp)))
      (scaleRat_valid (r := (t:Rat)) (add_valid (BoundedSeries.valueBlock_valid c q.val hc q.property 0 N)
        (mul_valid (hc N) hp))) hsum hdist

/-- Integer scaling commutes with actual bounded-series summation, with
the scaled majorant constructed from the integer's absolute value. -/
theorem boundedSeries_integer_scaling (c : Nat → ComplexRaw) (hc : ∀ n, (c n).Valid)
    (q : Scalar) (t : Int) (C K R : Rat) (hC : 0≤C) (hK : 0≤K) (hR : 0≤R)
    (hb : ∀ n, Small (c n) (C*K^n)) (hq : Small q.val R) (hl : 2*K*R≤(1:Rat)/2) :
    (BoundedSeries.sumValue (fun n => scaleRat (t:Rat) (c n)) q.val
      (fun n => scaleRat_valid (hc n)) q.property ((t.natAbs:Rat)*C) K R).Equiv
      (scaleRat (t:Rat) (BoundedSeries.sumValue c q.val hc q.property C K R)) := by
  let M : Rat := (t.natAbs:Rat)
  have hM : 0≤M := Rat.natCast_nonneg
  have hMC := Rat.mul_nonneg hM hC
  have hscaled (n : Nat) : Small (scaleRat (t:Rat) (c n)) ((M*C)*K^n) := by
    have hs := small_scale_integer (c n) (hc n) (C*K^n) (hb n) t
    simpa only [Rat.mul_assoc] using hs
  let A := BoundedSeries.sumValue (fun n => scaleRat (t:Rat) (c n)) q.val
    (fun n => scaleRat_valid (hc n)) q.property (M*C) K R
  let B := BoundedSeries.sumValue c q.val hc q.property C K R
  have hA := BoundedSeries.sumValue_valid _ _ (fun n => scaleRat_valid (hc n)) q.property
    (M*C) K R hMC hK hR hscaled hq hl
  have hB := BoundedSeries.sumValue_valid c q.val hc q.property C K R hC hK hR hb hq hl
  let E := LocalODE.valueTail (M*C) K R
  have hE : ShrinksToZero E := LocalODE.tail_bound_shrinks (M*C) (2*K*R) hMC
    (Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hK) hR) hl
  have hEn (N : Nat) : 0≤E N := Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hMC)
    (Rat.pow_nonneg (Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hK) hR))
  apply RepresentedCauchySum.unique
    (fun N => BoundedSeries.valueBlock (fun n => scaleRat (t:Rat) (c n)) q.val 0 N)
    (fun N => BoundedSeries.valueBlock_valid _ _ (fun n => scaleRat_valid (hc n)) q.property 0 N)
    (fun N => E N+E N) (RepresentedCauchySum.sum_shrinks _ _ hE hE)
    A (scaleRat (t:Rat) B) hA (scaleRat_valid hB)
  · intro N
    exact (BoundedSeries.sumValue_close_prefix _ _ (fun n => scaleRat_valid (hc n)) q.property
      (M*C) K R hMC hK hR hscaled hq hl N).mono (by have h := hEn N; grind only)
  · intro N
    have hs := small_scale_integer (sub B (BoundedSeries.valueBlock c q.val 0 N))
      (sub_valid hB (BoundedSeries.valueBlock_valid c q.val hc q.property 0 N))
      (LocalODE.valueTail C K R N)
      (BoundedSeries.sumValue_close_prefix c q.val hc q.property C K R hC hK hR hb hq hl N) t
    have he : (scaleRat (t:Rat) (sub B (BoundedSeries.valueBlock c q.val 0 N))).Equiv
        (sub (scaleRat (t:Rat) B) (BoundedSeries.valueBlock (fun n => scaleRat (t:Rat) (c n)) q.val 0 N)) := by
      apply ComplexRawQuotient.equiv_of_ofRaw_eq
        (hleft := scaleRat_valid (sub_valid hB (BoundedSeries.valueBlock_valid c q.val hc q.property 0 N)))
        (hright := sub_valid (scaleRat_valid hB)
          (BoundedSeries.valueBlock_valid _ _ (fun n => scaleRat_valid (hc n)) q.property 0 N))
      have hp := ComplexRawQuotient.ofRaw_eq_ofRaw
        (hleft := BoundedSeries.valueBlock_valid _ _ (fun n => scaleRat_valid (hc n)) q.property 0 N)
        (hright := scaleRat_valid (BoundedSeries.valueBlock_valid c q.val hc q.property 0 N))
        (boundedSeries_integer_scaled_prefix c hc q t N)
      let X := ComplexRawQuotient.ofRaw B hB
      let U := ComplexRawQuotient.ofRaw (BoundedSeries.valueBlock c q.val 0 N)
        (BoundedSeries.valueBlock_valid c q.val hc q.property 0 N)
      let V := ComplexRawQuotient.ofRaw
        (BoundedSeries.valueBlock (fun n => scaleRat (t:Rat) (c n)) q.val 0 N)
        (BoundedSeries.valueBlock_valid _ _ (fun n => scaleRat_valid (hc n)) q.property 0 N)
      change V=ComplexRawQuotient.scaleRat (t:Rat) U at hp
      change ComplexRawQuotient.scaleRat (t:Rat) (X-U)=ComplexRawQuotient.scaleRat (t:Rat) X-V
      rw [hp]
      change ComplexRawQuotient.scaleRat (t:Rat) (X+ -U)=
        ComplexRawQuotient.scaleRat (t:Rat) X+ -(ComplexRawQuotient.scaleRat (t:Rat) U)
      rw [ComplexRawQuotient.scaleRat_add]
      rw [ComplexRawQuotient.neg_eq_scaleRat_neg_one U,ComplexRawQuotient.scaleRat_scaleRat,
        ComplexRawQuotient.neg_scaleRat]
      congr 2
      grind only
    have ht := Small.congr
      (scaleRat_valid (sub_valid hB (BoundedSeries.valueBlock_valid c q.val hc q.property 0 N)))
      (sub_valid (scaleRat_valid hB) (BoundedSeries.valueBlock_valid _ _ (fun n => scaleRat_valid (hc n)) q.property 0 N)) he hs
    apply ht.mono
    have hid : M*LocalODE.valueTail C K R N=E N := by dsimp [E,LocalODE.valueTail]; grind only
    change M*LocalODE.valueTail C K R N≤E N+E N
    rw [hid]
    have h := hEn N
    grind only

end ComputableAnalysis.ModularForms
