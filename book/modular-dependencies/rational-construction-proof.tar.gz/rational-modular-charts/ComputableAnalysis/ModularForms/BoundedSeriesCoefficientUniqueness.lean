import ComputableAnalysis.ModularForms.BoundedSeriesPointRemainder
import ComputableAnalysis.ModularForms.RepresentedPolynomialCoefficientUniqueness

namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

theorem boundedSeries_prefix_polynomial (c : Nat → Scalar) (z : Scalar) (N : Nat) :
    (BoundedSeries.valueBlock (fun n => (c n).val) z.val 0 N).Equiv
      (representedCoefficientPolynomial c z N).val := by
  induction N with
  | zero => exact equiv_refl _ (ofQComplex_valid _)
  | succ N ih =>
    simp only [BoundedSeries.valueBlock,Nat.zero_add,representedCoefficientPolynomial]
    exact add_equiv ih (ComplexRaw.mul_comm_equiv (c N).val (LocalODE.power z.val N)
      (c N).property (LocalODE.power_valid _ z.property N))

/-- Equality of actual bounded-series values at all sufficiently small
positive rational steps determines every represented coefficient. -/
theorem boundedSeries_coefficients_unique (c d : Nat → Scalar)
    (C K R D L S : Rat) (hC : 0≤C) (hK : 0≤K) (hR : 0≤R)
    (hD : 0≤D) (hL : 0≤L) (hS : 0≤S)
    (hc : ∀ n, Small (c n).val (C*K^n)) (hd : ∀ n, Small (d n).val (D*L^n))
    (hlocal : 2*K*R≤(1:Rat)/2) (hlocald : 2*L*S≤(1:Rat)/2)
    (rho : QPos) (hrR : rho.val≤R) (hrS : rho.val≤S)
    (he : ∀ r : QPos, r.val≤rho.val →
      (BoundedSeries.sumValue (fun n => (c n).val) (realStep r).val (fun n => (c n).property)
        (realStep r).property C K R).Equiv
      (BoundedSeries.sumValue (fun n => (d n).val) (realStep r).val (fun n => (d n).property)
        (realStep r).property D L S)) :
    ∀ n, (c n).val.Equiv (d n).val := by
  let rate (A B : Rat) (m : Nat) := 4*A*(2*B)^(m+1)
  have rate_nonneg (A B : Rat) (hA : 0≤A) (hB : 0≤B) (m : Nat) : 0≤rate A B m :=
    Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hA)
      (Rat.pow_nonneg (Rat.mul_nonneg (by decide +kernel) hB))
  apply representedCoefficientPolynomial_coefficients_unique c d rho
    (fun m => rate C K m+rate D L m)
    (fun m => Rat.add_nonneg (rate_nonneg C K hC hK m) (rate_nonneg D L hD hL m))
  intro m r hr
  have hr0 := Rat.le_of_lt r.property
  have hrr := Rat.le_trans hr hrR
  have hrs := Rat.le_trans hr hrS
  have hcpoint := Rat.le_trans
    (Rat.mul_le_mul_of_nonneg_left hrr (Rat.mul_nonneg (by decide +kernel) hK)) hlocal
  have hdpoint := Rat.le_trans
    (Rat.mul_le_mul_of_nonneg_left hrs (Rat.mul_nonneg (by decide +kernel) hL)) hlocald
  have hvc := BoundedSeries.sumValue_valid (fun n => (c n).val) (realStep r).val
    (fun n => (c n).property) (realStep r).property C K R hC hK hR hc
    ((realStep_small r).mono hrr) hlocal
  have hvd := BoundedSeries.sumValue_valid (fun n => (d n).val) (realStep r).val
    (fun n => (d n).property) (realStep r).property D L S hD hL hS hd
    ((realStep_small r).mono hrs) hlocald
  have hpc := boundedSeries_point_remainder (fun n => (c n).val) (fun n => (c n).property)
    (realStep r) C K R r.val hC hK hR hr0 hc ((realStep_small r).mono hrr)
    (realStep_small r) hlocal hcpoint (m+1)
  have hpd := boundedSeries_point_remainder (fun n => (d n).val) (fun n => (d n).property)
    (realStep r) D L S r.val hD hL hS hr0 hd ((realStep_small r).mono hrs)
    (realStep_small r) hlocald hdpoint (m+1)
  let X : Scalar := ⟨_,hvc⟩
  let P := representedCoefficientPolynomial c (realStep r) (m+1)
  let Q := representedCoefficientPolynomial d (realStep r) (m+1)
  have hp := Small.congr
    (sub_valid hvc (BoundedSeries.valueBlock_valid _ _ (fun n => (c n).property) (realStep r).property 0 (m+1)))
    (sub_valid X.property P.property)
    (FunctionTheory.sub_congr (equiv_refl _ X.property) (boundedSeries_prefix_polynomial c (realStep r) (m+1))) hpc
  have hq := Small.congr
    (sub_valid hvd (BoundedSeries.valueBlock_valid _ _ (fun n => (d n).property) (realStep r).property 0 (m+1)))
    (sub_valid X.property Q.property)
    (FunctionTheory.sub_congr (equiv_symm (he r hr)) (boundedSeries_prefix_polynomial d (realStep r) (m+1))) hpd
  have hs := LocalODE.small_add (RepresentedCauchySum.small_sub_symm X.val P.val _ hp) hq
  have ht : (add (sub P.val X.val) (sub X.val Q.val)).Equiv (sub P.val Q.val) := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := add_valid (sub_valid P.property X.property) (sub_valid X.property Q.property))
      (hright := sub_valid P.property Q.property)
    let p := gridScalarValue P
    let q := gridScalarValue Q
    let x := gridScalarValue X
    change (p-x)+(x-q)=p-q
    grind only
  have hfinal := Small.congr
    (add_valid (sub_valid P.property X.property) (sub_valid X.property Q.property))
    (sub_valid P.property Q.property) ht hs
  simpa only [rate,Rat.add_mul] using hfinal

end ComputableAnalysis.ModularForms
