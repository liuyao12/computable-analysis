import ComputableAnalysis.ModularForms.Hecke41NormalizedContourPolynomial
import ComputableAnalysis.ModularForms.Hecke41ContourDerivativeBound

/-! Explicit bounds for every constructed actual contour coefficient. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def hecke41CoefficientDensityBound (S : QPos) (n : Nat) : Rat :=
  2*(2*(2*(2:Rat)^10000)*(2*(1/S.val))^(n+1))*S.val

theorem hecke41CoefficientDensityBound_nonneg (S : QPos) (n : Nat) :
    0≤hecke41CoefficientDensityBound S n := by
  have hi : 0≤1/S.val := by rw [Rat.div_def,Rat.one_mul]; exact Rat.le_of_lt (Rat.inv_pos.mpr S.property)
  unfold hecke41CoefficientDensityBound
  exact Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel)
    (Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel)
      (Rat.mul_nonneg (by decide +kernel) (Rat.pow_nonneg (by decide +kernel))))
      (Rat.pow_nonneg (Rat.mul_nonneg (by decide +kernel) hi)))) (Rat.le_of_lt S.property)

theorem hecke41ReciprocalCoefficientDensity_bound (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (S : QPos)
    (hg : S.val≤(hecke41NomeGeometricRadius a ha).val)
    (edge : HalfEdge) (u : Rat) (hu : 0≤u) (hu1 : u≤1) (n : Nat) :
    Small (hecke41ReciprocalCoefficientDensity k a ha S hg edge u hu hu1 n).val
      (hecke41CoefficientDensityBound S n) := by
  let q := rationalRectangleScalar (QComplex.scaleRat S.val (point edge u))
  let f := (hecke41NomeDescended k 10000).eval (Centered.translate a q)
    (hecke41NomeGeometric_square_edge_domain a ha edge S hg u hu hu1)
  let inv := squarePointInverse S edge u
  have hi : 0≤1/S.val := by rw [Rat.div_def,Rat.one_mul]; exact Rat.le_of_lt (Rat.inv_pos.mpr S.property)
  have hP : 0≤(2*(1/S.val))^(n+1) := Rat.pow_nonneg (Rat.mul_nonneg (by decide +kernel) hi)
  have hD : 0≤2*(2:Rat)^10000 := Rat.mul_nonneg (by decide +kernel) (Rat.pow_nonneg (by decide +kernel))
  have hp := LocalODE.power_small inv.val inv.property (1/S.val) hi (squarePointInverse_small S edge u) (n+1)
  have hs := Small.mul f.property (LocalODE.power_valid inv.val inv.property (n+1)) hD hP
    (hecke41NomeDescended_pole_bound k (Centered.translate a q)
      (hecke41NomeGeometric_square_edge_domain a ha edge S hg u hu hu1)) hp
  have hv := Small.mul (scalarProduct f ⟨LocalODE.power inv.val (n+1),LocalODE.power_valid _ inv.property _⟩).property
    (rationalRectangleScalar (QComplex.scaleRat S.val (velocity edge))).property
    (Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hD) hP) (Rat.le_of_lt S.property)
    hs (scaledSquareVelocity_small S edge)
  dsimp only [hecke41ReciprocalCoefficientDensity,hecke41ReciprocalCoefficientSample,scalarProduct]
  dsimp only [scalarProduct] at hv
  dsimp only [hecke41CoefficientDensityBound]
  exact hv

theorem hecke41ReciprocalCoefficientEdgeValue_bound (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (S : QPos)
    (hg : S.val≤(hecke41NomeGeometricRadius a ha).val)
    (hd : S.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) (edge : HalfEdge) (n : Nat) :
    Small (hecke41ReciprocalCoefficientEdgeValue k a ha S hg hd edge n).val
      (hecke41CoefficientDensityBound S n) := by
  apply convergentScalar_bound _ (fun j => hecke41ReciprocalCoefficientDyadicAverage k a ha edge S hg n j)
  · intro j
    apply dyadicSampleAverage_bound
    intro u
    unfold hecke41ReciprocalCoefficientUnitSample
    split
    · rename_i hu
      exact hecke41ReciprocalCoefficientDensity_bound k a ha S hg edge u hu.1 hu.2 n
    · exact Small.zero (hecke41CoefficientDensityBound_nonneg S n)
  · intro eps
    obtain ⟨N,hN⟩ := hecke41ReciprocalCoefficientTail_shrinks k a ha S n eps
    exact ⟨N,fun j hj => (hecke41ReciprocalCoefficientEdgeLimit_sample_error k a ha edge S hg hd n j).mono (hN j hj)⟩

theorem hecke41ReciprocalCoefficientContourLimit_bound (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (S : QPos)
    (hg : S.val≤(hecke41NomeGeometricRadius a ha).val)
    (hd : S.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) (n : Nat) (es : List HalfEdge) :
    Small (hecke41ReciprocalCoefficientContourLimit k a ha S hg hd n es).val
      ((es.length:Rat)*hecke41CoefficientDensityBound S n) := by
  induction es with
  | nil =>
    change Small zero (0*_)
    rw [Rat.zero_mul]
    exact Small.zero Rat.le_refl
  | cons e es ih =>
    have hb := hecke41ReciprocalCoefficientEdgeValue_bound k a ha S hg hd e n
    have ho : Small (if e.upper then hecke41ReciprocalCoefficientEdgeValue k a ha S hg hd e n
        else scalarNeg (hecke41ReciprocalCoefficientEdgeValue k a ha S hg hd e n)).val
        (hecke41CoefficientDensityBound S n) := by
      split
      · exact hb
      · exact SeriesLimitLaws.small_neg hb
    have hs := LocalODE.small_add ho ih
    have he : hecke41CoefficientDensityBound S n+(es.length:Rat)*hecke41CoefficientDensityBound S n=
        (((e::es).length:Nat):Rat)*hecke41CoefficientDensityBound S n := by
      simp only [List.length_cons,Rat.natCast_add]
      grind only
    rw [he] at hs
    exact hs

theorem hecke41NormalizedContourCoefficient_bound (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (S : QPos)
    (hg : S.val≤(hecke41NomeGeometricRadius a ha).val)
    (hd : S.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) (n : Nat) (es : List HalfEdge) :
    Small (hecke41NormalizedContourCoefficient k a ha S hg hd es n).val
      (2*((es.length:Rat)*hecke41CoefficientDensityBound S n)*scalarBound cauchyNormalizationScalar) :=
  Small.mul (hecke41ReciprocalCoefficientContourLimit k a ha S hg hd n es).property
    cauchyNormalizationScalar.property
    (Rat.mul_nonneg Rat.natCast_nonneg (hecke41CoefficientDensityBound_nonneg S n))
    (Rat.le_of_lt (scalarBound_pos cauchyNormalizationScalar))
    (hecke41ReciprocalCoefficientContourLimit_bound k a ha S hg hd n es)
    (scalar_small cauchyNormalizationScalar)

end ComputableAnalysis.ModularForms
