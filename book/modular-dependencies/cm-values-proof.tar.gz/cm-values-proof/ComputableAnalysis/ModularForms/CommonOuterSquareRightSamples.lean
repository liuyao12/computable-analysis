import ComputableAnalysis.ModularForms.CommonOuterHalfEdgeConcatenation
import ComputableAnalysis.ModularForms.SquareFrameWeightedSides
import ComputableAnalysis.ModularForms.Hecke41KernelFrameTiles

/-! Outer Cartesian right-edge samples for an arbitrary supplied density. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem common_outer_right_sample (f : QComplex → Scalar) (R : QPos)
    (M k v : Nat) (hM : 0<M) :
    (rectangleGridVertical f (squareFrameTile R 3 k) M M v).val.Equiv
      (scaleRat (1/(2*(M:Rat)))
        (commonSquareEdgeDensity f ⟨.east,true⟩ (squareFrameOuterRadius R)
          (((k:Rat)-2+squareMidpointParameter M v)/2)).val) := by
  unfold rectangleGridVertical
  rw [squareFrame_outer_right_point R M k v hM,(squareFrameTile_grid_steps R M 3 k).2]
  change (scalarProduct (f (cartesianSquarePoint ⟨.east,true⟩ (2*R.val)
    (((k:Rat)-2+squareMidpointParameter M v)/2)))
    (rationalRectangleScalar ⟨0,R.val/(M:Rat)⟩)).val.Equiv _
  rw [cartesianSquarePoint_agreement]
  have hw : (⟨0,R.val/(M:Rat)⟩ : QComplex)=
      QComplex.scaleRat (1/(2*(M:Rat)))
        (QComplex.scaleRat (2*R.val) (velocity ⟨.east,true⟩)) := by
    simp only [velocity,rotation,orientation,↓reduceIte,QComplex.mul,QComplex.scaleRat,
      QComplex.mk.injEq,Rat.div_def,Rat.inv_mul_rev]
    constructor <;> grind only
  rw [hw]
  exact rationalWeightedSample_scale _ _ _

theorem common_outer_right_tile_average (f : QComplex → Scalar) (R : QPos)
    (M k : Nat) (hM : 0<M) :
    (squareFrameVerticalEdge f R M 4 k).val.Equiv
      (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.east,true⟩
        (squareFrameOuterRadius R) (((k:Rat)-2+u)/2)) M (1/(2*(M:Rat)))).val := by
  let density := fun v => commonSquareEdgeDensity f ⟨.east,true⟩
    (squareFrameOuterRadius R) (((k:Rat)-2+squareMidpointParameter M v)/2)
  let weighted := fun v => (⟨scaleRat (1/(2*(M:Rat))) (density v).val,
    scaleRat_valid (density v).property⟩ : Scalar)
  have hs : ∀ v, (rectangleGridVertical f (squareFrameTile R 4 k) M 0 v).val.Equiv
      (weighted v).val := by
    intro v
    rw [←squareFrameTile_shared_vertical_samples f R M 3 k v hM]
    exact common_outer_right_sample f R M k v hM
  exact equiv_trans (squareFrameVerticalEdge f R M 4 k).property
    (gridScalarSum M weighted).property
    (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.east,true⟩
      (squareFrameOuterRadius R) (((k:Rat)-2+u)/2)) M (1/(2*(M:Rat)))).property
    (gridScalarSum_congr M _ weighted hs)
    (gridScalarSum_scale (1/(2*(M:Rat))) density M)

theorem common_outer_right_upper_average (f : QComplex → Scalar) (R : QPos)
    (M : Nat) (hM : 0<M) :
    (scalarSum (squareFrameVerticalEdge f R M 4 2)
      (squareFrameVerticalEdge f R M 4 3)).val.Equiv
      (commonSquareKernelAverage f ⟨.east,true⟩ (squareFrameOuterRadius R) (2*M)).val := by
  have h0 := common_outer_right_tile_average f R M 2 hM
  have h1 := common_outer_right_tile_average f R M 3 hM
  have p0 (u : Rat) : (((2:Nat):Rat)-2+u)/2=u/2 := by
    change (2-2+u)/2=u/2
    grind only
  have p1 (u : Rat) : (((3:Nat):Rat)-2+u)/2=(1+u)/2 := by
    change (3-2+u)/2=(1+u)/2
    grind only
  have hr : 1/(2*(M:Rat))=1/((2*M:Nat):Rat) := by
    rw [Rat.natCast_mul]
    rfl
  simp only [p0,hr] at h0
  simp only [p1,hr] at h1
  exact equiv_trans (scalarSum (squareFrameVerticalEdge f R M 4 2)
    (squareFrameVerticalEdge f R M 4 3)).property
    (scalarSum
      (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.east,true⟩
        (squareFrameOuterRadius R) (u/2)) M (1/((2*M:Nat):Rat)))
      (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.east,true⟩
        (squareFrameOuterRadius R) ((1+u)/2)) M (1/((2*M:Nat):Rat)))).property
    (commonSquareKernelAverage f ⟨.east,true⟩ (squareFrameOuterRadius R) (2*M)).property
    (add_equiv h0 h1)
    (commonSquareKernelAverage_midpoint_split f ⟨.east,true⟩ (squareFrameOuterRadius R) M hM)

end ComputableAnalysis.ModularForms
