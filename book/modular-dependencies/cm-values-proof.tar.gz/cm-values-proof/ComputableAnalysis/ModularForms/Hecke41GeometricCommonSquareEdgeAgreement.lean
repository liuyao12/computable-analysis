import ComputableAnalysis.ModularForms.Hecke41GeometricKernelSquareSampler
import ComputableAnalysis.ModularForms.Hecke41CommonSquareEdgeAgreement
import ComputableAnalysis.ModularForms.Hecke41GeometricFiniteContour
import ComputableAnalysis.ModularForms.Hecke41SquareKernelContour
import ComputableAnalysis.ModularForms.RectangleDyadicBoundaryAgreement

/-! The common square sampler agrees with actual finite Hecke edge averages. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem hecke41GeometricCommonSquare_edge_sample_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (B S : QPos)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (hS : S.val≤B.val) (edge : HalfEdge) (u : Rat) (hu : 0≤u) (hu1 : u≤1) :
    (hecke41GeometricKernelSquareSample k a ha B hB (QComplex.scaleRat S.val (point edge u))).val.Equiv
      (scalarProduct ((hecke41NomeDescended k 10000).eval
        (Centered.translate a (rationalRectangleScalar (QComplex.scaleRat S.val (point edge u))))
        (hecke41NomeGeometric_square_edge_domain a ha edge S (Rat.le_trans hS hB) u hu hu1))
        (rationalSquaredKernel (QComplex.scaleRat S.val (point edge u)))).val := by
  let q := QComplex.scaleRat S.val (point edge u)
  have hb := (scaledSquarePoint_small edge S.val u (Rat.le_of_lt S.property) hu hu1).mono hS
  have hq : rationalRectangleContains (rationalKernelSquare B) q :=
    ⟨hb.1 0 0,hb.2.1 0 0,hb.2.2.1 0 0,hb.2.2.2 0 0⟩
  have hne := scaledSquarePoint_normSq_nonzero edge u S.val S.property
  let hz := hecke41GeometricKernelSquare_rational_domain k a ha B hB q hq hne
  have hs := hecke41GeometricKernelSquareSample_agreement k a ha B hB q hq hne hz
  have he := hecke41CauchyIntegrandMap_rational_agreement k a q hne hz
    (hecke41NomeGeometric_square_edge_domain a ha edge S (Rat.le_trans hS hB) u hu hu1)
  simp only [scalarProduct,rationalSquaredKernel]
  exact equiv_trans (hecke41GeometricKernelSquareSample k a ha B hB q).property
    ((hecke41CauchyIntegrandMap k a).eval (rationalRectangleScalar q) hz).property
    (mul_valid ((hecke41NomeDescended k 10000).eval
      (Centered.translate a (rationalRectangleScalar q))
      (hecke41NomeGeometric_square_edge_domain a ha edge S (Rat.le_trans hS hB) u hu hu1)).property
      (mul_valid (ofQComplex_valid _) (ofQComplex_valid _))) hs he

theorem hecke41GeometricCommonSquare_edge_average_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (B S : QPos)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (hS : S.val≤B.val) (edge : HalfEdge) (M : Nat) (hM : 0<M) :
    (commonSquareKernelAverage (hecke41GeometricKernelSquareSample k a ha B hB) edge S M).val.Equiv
      (hecke41GeometricFiniteEdgeAverage k a ha edge S (Rat.le_trans hS hB) M hM).val := by
  dsimp only [commonSquareKernelAverage,hecke41GeometricFiniteEdgeAverage]
  simp only [Rat.div_def,Rat.one_mul]
  apply scaleRat_equiv
  apply gridScalarSum_congr_on_indices
  intro j hj
  let u := squareMidpointParameter M j
  have hu := squareMidpointParameter_unit M j hM hj
  have he := hecke41GeometricCommonSquare_edge_sample_agreement k a ha B S hB hS edge u hu.1 hu.2
  have hg : (hecke41GeometricKernelGridSample k a ha edge S (Rat.le_trans hS hB) M hM j).val.Equiv
      (scalarProduct ((hecke41NomeDescended k 10000).eval
        (Centered.translate a (rationalRectangleScalar (QComplex.scaleRat S.val (point edge u))))
        (hecke41NomeGeometric_square_edge_domain a ha edge S (Rat.le_trans hS hB) u hu.1 hu.2))
        (rationalSquaredKernel (QComplex.scaleRat S.val (point edge u)))).val := by
    dsimp only [hecke41GeometricKernelGridSample,u]
    simp only [Nat.mod_eq_of_lt hj]
    exact equiv_refl _ (mul_valid ((hecke41NomeDescended k 10000).eval _
      (hecke41NomeGeometric_square_edge_domain a ha edge S (Rat.le_trans hS hB) _ hu.1 hu.2)).property
      (rationalSquaredKernel (QComplex.scaleRat S.val (point edge u))).property)
  have hh := equiv_trans
    (hecke41GeometricKernelSquareSample k a ha B hB (QComplex.scaleRat S.val (point edge u))).property
    (mul_valid ((hecke41NomeDescended k 10000).eval _
      (hecke41NomeGeometric_square_edge_domain a ha edge S (Rat.le_trans hS hB) u hu.1 hu.2)).property
      (rationalSquaredKernel (QComplex.scaleRat S.val (point edge u))).property)
    (hecke41GeometricKernelGridSample k a ha edge S (Rat.le_trans hS hB) M hM j).property
    he (equiv_symm hg)
  exact mul_equiv
    (hecke41GeometricKernelSquareSample k a ha B hB (QComplex.scaleRat S.val (point edge u))).property
    (hecke41GeometricKernelGridSample k a ha edge S (Rat.le_trans hS hB) M hM j).property
    (ofQComplex_valid _) (ofQComplex_valid _) hh (equiv_refl _ (ofQComplex_valid _))


theorem hecke41GeometricCommonSquare_edge_list_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (B S : QPos)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (hS : S.val≤B.val) (M : Nat) (hM : 0<M) (es : List HalfEdge) :
    (commonSquareKernelEdgeList (hecke41GeometricKernelSquareSample k a ha B hB) S M es).val.Equiv
      (hecke41GeometricFiniteContour k a ha S (Rat.le_trans hS hB) M hM es).val := by
  induction es with
  | nil => exact equiv_refl _ (ofQComplex_valid _)
  | cons e es ih =>
    have hv := hecke41GeometricCommonSquare_edge_average_agreement k a ha B S hB hS e M hM
    cases h : e.upper
    · simpa only [commonSquareKernelEdgeList,hecke41GeometricFiniteContour,h,
        Bool.false_eq_true,↓reduceIte,scalarSum,scalarNeg] using add_equiv (neg_equiv hv) ih
    · simpa only [commonSquareKernelEdgeList,hecke41GeometricFiniteContour,h,
        ↓reduceIte,scalarSum] using add_equiv hv ih

end ComputableAnalysis.ModularForms
