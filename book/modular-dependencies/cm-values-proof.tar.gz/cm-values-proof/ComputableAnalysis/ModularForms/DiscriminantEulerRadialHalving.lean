import ComputableAnalysis.ModularForms.DiscriminantEulerRadialContraction
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- Shrinking positive radial anchors give exact halving at the actual endpoint. -/
theorem discriminantEulerRadial_halving (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R S b B : Rat) (hR : 0<R) (hS : 0≤S) (hb : 0<b) (hB : 0<B)
    (hqr : Small q.val R) (hi : Small (RepresentedReciprocal.inverse q hq).val S)
    (hs : b*R≤(1:Rat)/65536) (hshort : 3072*(b*R)≤(1:Rat)/2)
    (a : Nat → Rat) (ha : ∀ N, 0<a N) (hab : ∀ N, a N≤b) (hlim : ShrinksToZero a)
    (hbound : ∀ N u, Small (discriminantEulerRadialValues q hq R (a N) b
      (Rat.le_of_lt hR) (ha N) (hab N) hqr hs u).val B) :
    ∃ hz : discriminantEulerDividedMap.domain (rationalScaledScalar b q),
      Small (discriminantEulerDividedMap.eval (rationalScaledScalar b q) hz).val (B/2) := by
  let hz : discriminantEulerDividedMap.domain (rationalScaledScalar b q) :=
    ⟨rationalScaledScalar_nonzero b (Rat.ne_of_gt hb) q hq,
      rationalScaledScalar_nomeDomain q R b (Rat.le_of_lt hR) (Rat.le_of_lt hb) hqr hs⟩
  refine ⟨hz,?_⟩
  have hc : 0≤21072*S*R*R := Rat.mul_nonneg (Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hS)
    (Rat.le_of_lt hR)) (Rat.le_of_lt hR)
  apply SeriesLimitLaws.small_closed _ (B/2) (fun N => 21072*S*R*R*a N)
    (SeriesLimitLaws.shrinks_scale a hlim (21072*S*R*R) hc)
  intro N
  let W : QPos := ⟨b*R,Rat.mul_pos hb hR⟩
  have hw : (b-a N)*R≤W.val := by
    have hm := Rat.mul_nonneg (Rat.le_of_lt (ha N)) (Rat.le_of_lt hR)
    change (b-a N)*R≤b*R
    grind only
  exact discriminantEulerRadial_contraction q hq R S (a N) b B (Rat.le_of_lt hR) hS
    (ha N) (hab N) hB hqr hi hs W hw hshort (hbound N)
/-- First exact halving uses the already proved uniform radial bound. -/
theorem discriminantEulerRadial_initial_halving (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R S b : Rat) (hR : 0<R) (hS : 0<S) (hb : 0<b)
    (hqr : Small q.val R) (hi : Small (RepresentedReciprocal.inverse q hq).val S)
    (hs : b*R≤(1:Rat)/65536) (hshort : 3072*(b*R)≤(1:Rat)/2)
    (a : Nat → Rat) (ha : ∀ N, 0<a N) (hab : ∀ N, a N≤b) (hlim : ShrinksToZero a) :
    ∃ hz : discriminantEulerDividedMap.domain (rationalScaledScalar b q),
      Small (discriminantEulerDividedMap.eval (rationalScaledScalar b q) hz).val ((21072*S*R*R*b)/2) := by
  apply discriminantEulerRadial_halving q hq R S b _ hR (Rat.le_of_lt hS) hb
    (Rat.mul_pos (Rat.mul_pos (Rat.mul_pos (Rat.mul_pos (by decide +kernel) hS) hR) hR) hb)
    hqr hi hs hshort a ha hab hlim
  intro N
  exact discriminantEulerRadialValues_bound q hq R S (a N) b (Rat.le_of_lt hR)
    (Rat.le_of_lt hS) (ha N) (hab N) hqr hi hs
end ComputableAnalysis.ModularForms
