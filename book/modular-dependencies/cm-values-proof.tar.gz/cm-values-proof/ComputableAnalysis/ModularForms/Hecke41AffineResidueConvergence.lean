import ComputableAnalysis.ModularForms.RepresentedResidueConvergence
import ComputableAnalysis.ModularForms.Hecke41AffineFiniteResidue
import ComputableAnalysis.ModularForms.SquareResidueNormalization

/-! Actual affine Hecke contours converge to the normalized derivative residue. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem hecke41AffineSquareContour_converges (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (eps : QPos) :
    ∃ N, ∀ n, N≤n → Small
      (sub (scalarProduct ((hecke41NomeDescended_holomorphic k 10000).derivative a ha)
        ⟨twoPiI,twoPiI_valid⟩).val
        (hecke41FiniteAffineContour k a ha R hR (2^n)
          (Nat.pow_pos (by decide +kernel)) PDE.CauchyContour.square).val) eps.val := by
  let d := (hecke41NomeDescended_holomorphic k 10000).derivative a ha
  obtain ⟨N,hN⟩ := suppliedDerivativeResidue_converges d eps
  refine ⟨N, ?_⟩
  intro n hn
  have he := FunctionTheory.sub_congr
    (equiv_refl _ (scalarProduct d ⟨twoPiI,twoPiI_valid⟩).property)
    (equiv_symm (hecke41AffineSquare_finite_residue k a ha R hR (2^n)
      (Nat.pow_pos (by decide +kernel))))
  exact Small.congr
    (sub_valid (scalarProduct d ⟨twoPiI,twoPiI_valid⟩).property
      (scalarProduct d (squareResidueMidpointSum (2^n))).property)
    (sub_valid (scalarProduct d ⟨twoPiI,twoPiI_valid⟩).property
      (hecke41FiniteAffineContour k a ha R hR (2^n)
        (Nat.pow_pos (by decide +kernel)) PDE.CauchyContour.square).property)
    he (hN n hn)

end ComputableAnalysis.ModularForms
