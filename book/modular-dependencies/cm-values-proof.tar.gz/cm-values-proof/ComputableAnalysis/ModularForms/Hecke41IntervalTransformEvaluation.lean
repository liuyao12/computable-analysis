import ComputableAnalysis.ModularForms.IntegerPolynomialIntervalEvaluation
import ComputableAnalysis.ModularForms.Hecke41IntervalTransformPackedData

namespace ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct
open RiemannHilbert

private theorem quotient_length : hecke41DiagonalCandidateQuotient.length=81 := by decide +kernel

/-- Exact evaluation of the checked quotient transform at arbitrary valid
represented values satisfying the interval substitution relation. -/
theorem hecke41IntervalTransform_class (T X : ScalarAlgebra.Value)
    (h : (1+T)*X=(-2305843009213693952:Int)+
      (-144115188075854872:Int)*T) :
    integerPolynomialClass hecke41IntervalTransformCandidate T=
      (1+T)^80*integerPolynomialClass hecke41DiagonalCandidateQuotient X := by
  rw [← hecke41IntervalTransform_checked,
    integerPolynomialIntervalTransform_class _ _ _ T X h,quotient_length]

end ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct
