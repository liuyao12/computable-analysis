import ComputableAnalysis.ModularForms.IntegerAffineHeckePrefix41

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- Actual finite product of a supplied family of valid represented values. -/
def scalarListProduct41 {α : Type} (f : α → Scalar) : List α → ComplexRaw
  | [] => one
  | i::is => mul (f i).val (scalarListProduct41 f is)

theorem scalarListProduct41_valid {α : Type} (f : α → Scalar) (is : List α) :
    (scalarListProduct41 f is).Valid := by
  induction is with
  | nil => exact ofQComplex_valid _
  | cons i is ih => exact mul_valid (f i).property ih

/-- Executable amplification of a uniform factor error. -/
def scalarProductSensitivity41 (H : Rat) : Nat → Rat
  | 0 => 0
  | n+1 => 2*(2*H)^n+2*H*scalarProductSensitivity41 H n

theorem scalarProductSensitivity41_nonnegative (H : Rat) (hH : 0≤H) (n : Nat) :
    0≤scalarProductSensitivity41 H n := by
  induction n with
  | zero => exact Rat.le_refl
  | succ n ih =>
    exact Rat.add_nonneg
      (Rat.mul_nonneg (by decide) (Rat.pow_nonneg (Rat.mul_nonneg (by decide) hH)))
      (Rat.mul_nonneg (Rat.mul_nonneg (by decide) hH) ih)

theorem scalarUnit41_small : Small one 1 := by
  refine ⟨?_,?_,?_,?_⟩
  · intro n m; change (-1:Rat)≤1; decide +kernel
  · intro n m; change (1:Rat)≤1; decide +kernel
  · intro n m; change (-1:Rat)≤0; decide +kernel
  · intro n m; change (0:Rat)≤1; decide +kernel

/-- Uniform factor bounds construct a finite product bound. -/
theorem scalarListProduct41_bound {α : Type} (f : α → Scalar) (is : List α)
    (H : Rat) (hH : 0≤H) (h : ∀ i∈is, Small (f i).val H) :
    Small (scalarListProduct41 f is) ((2*H)^is.length) := by
  induction is with
  | nil => simpa only [scalarListProduct41,List.length_nil,Rat.pow_zero] using scalarUnit41_small
  | cons i is ih =>
    have hi := h i (by simp)
    have ht := ih (fun j hj => h j (by simp [hj]))
    have hm := Small.mul (f i).property (scalarListProduct41_valid f is) hH
      (Rat.pow_nonneg (Rat.mul_nonneg (by decide) hH)) hi ht
    simpa only [scalarListProduct41,List.length_cons,Rat.pow_succ,Rat.mul_assoc,Rat.mul_comm] using hm

/-- Constructed finite-product error from actual factor bounds and errors. -/
theorem scalarListProduct41_difference_bound {α : Type} (f g : α → Scalar) (is : List α)
    (H E : Rat) (hH : 0≤H) (hE : 0≤E)
    (hf : ∀ i∈is, Small (f i).val H) (hg : ∀ i∈is, Small (g i).val H)
    (he : ∀ i∈is, Small (sub (f i).val (g i).val) E) :
    Small (sub (scalarListProduct41 f is) (scalarListProduct41 g is))
      (E*scalarProductSensitivity41 H is.length) := by
  induction is with
  | nil =>
    have hz : zero.Equiv (sub one one) := by
      apply ComplexRawQuotient.equiv_of_ofRaw_eq
        (hleft := ofQComplex_valid _) (hright := sub_valid (ofQComplex_valid _) (ofQComplex_valid _))
      change (0 : ScalarAlgebra.Value)=1-1
      grind only
    exact Small.congr (ofQComplex_valid _) (sub_valid (ofQComplex_valid _) (ofQComplex_valid _)) hz
      (Small.zero (by change 0≤E*0; grind only))
  | cons i is ih =>
    have hft : ∀ j∈is, Small (f j).val H := fun j hj => hf j (by simp [hj])
    have hgt : ∀ j∈is, Small (g j).val H := fun j hj => hg j (by simp [hj])
    have het : ∀ j∈is, Small (sub (f j).val (g j).val) E := fun j hj => he j (by simp [hj])
    have hp := scalarListProduct41_bound f is H hH hft
    have hd := ih hft hgt het
    have h₁ := Small.mul (sub_valid (f i).property (g i).property)
      (scalarListProduct41_valid f is) hE
      (Rat.pow_nonneg (Rat.mul_nonneg (by decide) hH)) (he i (by simp)) hp
    have h₂ := Small.mul (g i).property
      (sub_valid (scalarListProduct41_valid f is) (scalarListProduct41_valid g is))
      hH (Rat.mul_nonneg hE (scalarProductSensitivity41_nonnegative H hH is.length))
      (hg i (by simp)) hd
    have hb := LocalODE.small_add h₁ h₂
    have hid : (add (mul (sub (f i).val (g i).val) (scalarListProduct41 f is))
        (mul (g i).val (sub (scalarListProduct41 f is) (scalarListProduct41 g is)))).Equiv
        (sub (scalarListProduct41 f (i::is)) (scalarListProduct41 g (i::is))) := by
      apply ComplexRawQuotient.equiv_of_ofRaw_eq
        (hleft := add_valid
          (mul_valid (sub_valid (f i).property (g i).property) (scalarListProduct41_valid f is))
          (mul_valid (g i).property (sub_valid (scalarListProduct41_valid f is) (scalarListProduct41_valid g is))))
        (hright := sub_valid (scalarListProduct41_valid f (i::is)) (scalarListProduct41_valid g (i::is)))
      let A := ComplexRawQuotient.ofRaw (f i).val (f i).property
      let B := ComplexRawQuotient.ofRaw (g i).val (g i).property
      let P := ComplexRawQuotient.ofRaw (scalarListProduct41 f is) (scalarListProduct41_valid f is)
      let Q := ComplexRawQuotient.ofRaw (scalarListProduct41 g is) (scalarListProduct41_valid g is)
      change (A-B)*P+B*(P-Q)=A*P-B*Q
      grind only
    have hout := Small.congr
      (add_valid
        (mul_valid (sub_valid (f i).property (g i).property) (scalarListProduct41_valid f is))
        (mul_valid (g i).property (sub_valid (scalarListProduct41_valid f is) (scalarListProduct41_valid g is))))
      (sub_valid (scalarListProduct41_valid f (i::is)) (scalarListProduct41_valid g (i::is))) hid hb
    have hrat : 2*E*(2*H)^is.length+2*H*(E*scalarProductSensitivity41 H is.length)=
        E*scalarProductSensitivity41 H (i::is).length := by
      simp only [List.length_cons,scalarProductSensitivity41]
      grind only
    rw [hrat] at hout
    exact hout

end ComputableAnalysis.ModularForms
