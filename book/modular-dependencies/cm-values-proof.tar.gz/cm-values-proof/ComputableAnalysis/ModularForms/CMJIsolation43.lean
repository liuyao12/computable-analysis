import ComputableAnalysis.ModularForms.CMJAnalyticBounds43
import ComputableAnalysis.ModularForms.CMJFactor43
import ComputableAnalysis.ModularForms.PositiveReciprocalAgreement

namespace ComputableAnalysis.ModularForms

/-- Actual positive denominator for the interval substitution at the CM coordinate. -/
def cmJIsolationDenominator43 : RealRaw :=
  RealRaw.sub (RealRaw.ofRat (-750000000)) cmJValue43.val.realPart

theorem cmJIsolationDenominator43_valid : cmJIsolationDenominator43.Valid :=
  RealRaw.sub_valid (RealRaw.ofRat_valid _) (ComplexRaw.realPart_valid cmJValue43.property)

/-- Quantitative denominator separation is proved from the actual CM estimate. -/
theorem cmJIsolationDenominator43_lower :
    (RealRaw.ofRat 255).Le cmJIsolationDenominator43 := by
  intro n m
  have h := cmJValue43_real_isolation_upper_margin m 0
  change (cmJValue43.val.realPart.compute m).lo≤(-750000255:Rat) at h
  change (255:Rat)≤(-750000000:Rat)-(cmJValue43.val.realPart.compute m).lo
  grind only

/-- A positive interval stage is obtained constructively from validity and the margin. -/
theorem cmJIsolationDenominator43_positive : cmJIsolationDenominator43.Pos := by
  obtain ⟨N,hN⟩ := cmJIsolationDenominator43_valid.2.2 (⟨1,by decide +kernel⟩ : QPos)
  have hw := hN N (Nat.le_refl N)
  have hl := cmJIsolationDenominator43_lower 0 N
  change (255:Rat)≤(cmJIsolationDenominator43.compute N).hi at hl
  unfold QInterval.width at hw
  refine ⟨N,?_⟩
  change 0<(cmJIsolationDenominator43.compute N).lo
  grind only

end ComputableAnalysis.ModularForms

namespace ComputableAnalysis.ModularForms

def cmJIsolationNumerator43 : RealRaw :=
  RealRaw.sub cmJValue43.val.realPart (RealRaw.ofRat (-1500000000))

theorem cmJIsolationNumerator43_valid : cmJIsolationNumerator43.Valid :=
  RealRaw.sub_valid (ComplexRaw.realPart_valid cmJValue43.property) (RealRaw.ofRat_valid _)

theorem cmJIsolationNumerator43_nonnegative :
    (RealRaw.ofRat 0).Le cmJIsolationNumerator43 := by
  intro n m
  have h := cmJValue43_real_isolation_bounds.1 0 m
  change (-1500000000:Rat)≤(cmJValue43.val.realPart.compute m).hi at h
  change (0:Rat)≤(cmJValue43.val.realPart.compute m).hi-(-1500000000:Rat)
  grind only

def cmJIsolationInverse43 : RealRaw := RealRaw.positiveReciprocal cmJIsolationDenominator43 255

theorem cmJIsolationInverse43_valid : cmJIsolationInverse43.Valid :=
  RealRaw.positiveReciprocal_valid _ _ cmJIsolationDenominator43_valid (by decide +kernel)
    (fun n => cmJIsolationDenominator43_lower 0 n)

theorem cmJIsolationInverse43_nonnegative :
    (RealRaw.ofRat 0).Le cmJIsolationInverse43 := by
  intro n m
  rw [show cmJIsolationInverse43=RealRaw.positiveReciprocal cmJIsolationDenominator43 255 by rfl,
    RealRaw.positiveReciprocal_compute _ _ (by decide +kernel) m]
  change (0:Rat)≤1/maxRat2 (cmJIsolationDenominator43.compute m).lo 255
  have h : (0:Rat)<maxRat2 (cmJIsolationDenominator43.compute m).lo 255 := by
    unfold maxRat2; split <;> grind only
  rw [Rat.div_def]
  exact Rat.mul_nonneg (by decide +kernel) (Rat.le_of_lt (Rat.inv_pos.mpr h))

/-- Actual executable parameter for the CM interval substitution. -/
def cmJIsolationParameter43 : RealRaw := RealRaw.mul cmJIsolationNumerator43 cmJIsolationInverse43

theorem cmJIsolationParameter43_valid : cmJIsolationParameter43.Valid :=
  RealRaw.mul_valid cmJIsolationNumerator43_valid cmJIsolationInverse43_valid

/-- The actual constructed parameter is nonnegative on the full represented domain. -/
theorem cmJIsolationParameter43_nonnegative :
    (RealRaw.ofRat 0).Le cmJIsolationParameter43 := by
  intro n m
  have hn := cmJIsolationNumerator43_nonnegative 0 m
  have hi := cmJIsolationInverse43_nonnegative 0 m
  change (0:Rat)≤(cmJIsolationNumerator43.compute m).hi at hn
  change (0:Rat)≤(cmJIsolationInverse43.compute m).hi at hi
  have ho := QBox.mulRealInterval_contains
    (RealRaw.interval_order_of_valid _ cmJIsolationNumerator43_valid m)
    (Rat.le_refl : (cmJIsolationNumerator43.compute m).hi≤(cmJIsolationNumerator43.compute m).hi)
    (RealRaw.interval_order_of_valid _ cmJIsolationInverse43_valid m)
    (Rat.le_refl : (cmJIsolationInverse43.compute m).hi≤(cmJIsolationInverse43.compute m).hi)
  change (0:Rat)≤(QBox.mulRealInterval (cmJIsolationNumerator43.compute m).lo
    (cmJIsolationNumerator43.compute m).hi (cmJIsolationInverse43.compute m).lo
    (cmJIsolationInverse43.compute m).hi).hi
  exact Rat.le_trans (Rat.mul_nonneg hn hi) ho.2

/-- The clipped reciprocal agrees exactly with the inverse role required by
this concrete denominator, using its proved margin. -/
theorem cmJIsolationInverse43_product_identity :
    (RealRaw.mul cmJIsolationDenominator43 cmJIsolationInverse43).Equiv RealRaw.one :=
  positiveReciprocal_mul_identity _ cmJIsolationDenominator43_valid 255
    (by decide +kernel) cmJIsolationDenominator43_lower

end ComputableAnalysis.ModularForms

namespace ComputableAnalysis.ModularForms
open RiemannHilbert

/-- Exact affine relation for the actual executable CM interval parameter. -/
theorem cmJIsolationParameter43_substitution :
    let T := realAxisClass cmJIsolationParameter43 cmJIsolationParameter43_valid
    let X := realAxisClass cmJValue43.val.realPart (ComplexRaw.realPart_valid cmJValue43.property)
    (1+T)*X=((-1500000000:Int):ScalarAlgebra.Value)+
      ((-750000000:Int):ScalarAlgebra.Value)*T := by
  dsimp only
  have hN : realAxisClass cmJIsolationNumerator43 cmJIsolationNumerator43_valid=
      realAxisClass cmJValue43.val.realPart (ComplexRaw.realPart_valid cmJValue43.property)-
        ((-1500000000:Int):ScalarAlgebra.Value) := by
    unfold cmJIsolationNumerator43
    have hc := realAxisClass_int (-1500000000)
    rw [show ((-1500000000:Int):Rat)=(-1500000000:Rat) by decide +kernel] at hc
    rw [realAxisClass_sub cmJValue43.val.realPart (RealRaw.ofRat (-1500000000))
      (ComplexRaw.realPart_valid cmJValue43.property) (RealRaw.ofRat_valid _),
      hc]
  have hD : realAxisClass cmJIsolationDenominator43 cmJIsolationDenominator43_valid=
      ((-750000000:Int):ScalarAlgebra.Value)-
        realAxisClass cmJValue43.val.realPart (ComplexRaw.realPart_valid cmJValue43.property) := by
    unfold cmJIsolationDenominator43
    have hc := realAxisClass_int (-750000000)
    rw [show ((-750000000:Int):Rat)=(-750000000:Rat) by decide +kernel] at hc
    rw [realAxisClass_sub (RealRaw.ofRat (-750000000)) cmJValue43.val.realPart
      (RealRaw.ofRat_valid _) (ComplexRaw.realPart_valid cmJValue43.property),
      hc]
  have hI := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := ComplexRaw.ofRealRaw_valid _
      (RealRaw.mul_valid cmJIsolationDenominator43_valid cmJIsolationInverse43_valid))
    (hright := ComplexRaw.ofRealRaw_valid RealRaw.one (RealRaw.ofRat_valid 1))
    (ComplexRaw.ofRealRaw_equiv_of_equiv (y := RealRaw.one)
      (RealRaw.mul_valid cmJIsolationDenominator43_valid cmJIsolationInverse43_valid)
      (RealRaw.ofRat_valid 1) cmJIsolationInverse43_product_identity)
  change realAxisClass (RealRaw.mul cmJIsolationDenominator43 cmJIsolationInverse43)
      (RealRaw.mul_valid cmJIsolationDenominator43_valid cmJIsolationInverse43_valid)=
      realAxisClass RealRaw.one (RealRaw.ofRat_valid 1) at hI
  rw [realAxisClass_mul _ _ cmJIsolationDenominator43_valid cmJIsolationInverse43_valid,hD] at hI
  have hOne : realAxisClass RealRaw.one (RealRaw.ofRat_valid 1)=(1:ScalarAlgebra.Value) := by
    have h := realAxisClass_int 1
    change realAxisClass RealRaw.one (RealRaw.ofRat_valid 1)=((1:Int):ScalarAlgebra.Value) at h
    rw [h]; grind only
  rw [hOne] at hI
  have hT : realAxisClass cmJIsolationParameter43 cmJIsolationParameter43_valid=
      (realAxisClass cmJValue43.val.realPart (ComplexRaw.realPart_valid cmJValue43.property)-
        ((-1500000000:Int):ScalarAlgebra.Value))*
      realAxisClass cmJIsolationInverse43 cmJIsolationInverse43_valid := by
    change realAxisClass (RealRaw.mul cmJIsolationNumerator43 cmJIsolationInverse43)
      (RealRaw.mul_valid cmJIsolationNumerator43_valid cmJIsolationInverse43_valid)=_
    rw [realAxisClass_mul _ _ cmJIsolationNumerator43_valid cmJIsolationInverse43_valid,hN]
  rw [hT]
  grind only

end ComputableAnalysis.ModularForms

namespace ComputableAnalysis.ModularForms
open RiemannHilbert

theorem cmJValue43_quotient_nonzero :
    integerPolynomialClass hecke41DiagonalQuotient43
      (ComplexRawQuotient.ofRaw cmJValue43.val cmJValue43.property)≠0 := by
  have he : ComplexRawQuotient.ofRaw cmJValue43.val cmJValue43.property=
      realAxisClass cmJValue43.val.realPart (ComplexRaw.realPart_valid cmJValue43.property) :=
    ComplexRawQuotient.ofRaw_eq_ofRaw cmJValue43_real_embedding
  rw [he]
  exact hecke41Quotient43_nonzero_of_substitution cmJIsolationParameter43
    cmJIsolationParameter43_valid cmJIsolationParameter43_nonnegative _ cmJIsolationParameter43_substitution

end ComputableAnalysis.ModularForms
