import ComputableAnalysis.ModularForms.CMExponentialAgreement163
import ComputableAnalysis.ModularForms.CMIntegerGrowthDeficit163

/-! Unconditional CM exponential bounds through the current function API.
The analytic agreement is proved separately; the actual checked CM integer
identity supplies the arithmetic evidence here. -/
namespace ComputableAnalysis.ModularForms.EC163
open ExponentialComputations

/-- The full arithmetic corollary for every registered exponential and
 every equivalent represented name of the irrational argument. -/
theorem deficit_bounds (f : Implementation) (x : RealInput)
    (hx : x.val.Equiv input.val) :
    (RealRaw.ofRat (1/100000000000000)).Le (deficit f x) ∧
      (deficit f x).Le (RealRaw.ofRat (9/10000000000000)) :=
  deficit_bounds_of_cm_value f x hx cmJValue163_exact_value

/-- The statement directly in terms of the current real exponential. -/
theorem exp_bounds :
    let d := RealRaw.add (RealRaw.ofRat 262537412640768744) (RealRaw.neg (exp input).val)
    (RealRaw.ofRat (1/100000000000000)).Le d ∧ d.Le (RealRaw.ofRat (9/10000000000000)) :=
  deficit_bounds powerSeries input (RealRaw.equiv_refl _ input.property)

theorem compoundInterest_bounds :
    (RealRaw.ofRat (1/100000000000000)).Le (deficit compoundInterest input) ∧
      (deficit compoundInterest input).Le (RealRaw.ofRat (9/10000000000000)) :=
  deficit_bounds compoundInterest input (RealRaw.equiv_refl _ input.property)

theorem linearODE_bounds :
    (RealRaw.ofRat (1/100000000000000)).Le (deficit linearODE input) ∧
      (deficit linearODE input).Le (RealRaw.ofRat (9/10000000000000)) :=
  deficit_bounds linearODE input (RealRaw.equiv_refl _ input.property)

end ComputableAnalysis.ModularForms.EC163
