import ComputableAnalysis.ModularForms.CommonOuterHalfEdgeConcatenation
import ComputableAnalysis.ModularForms.SquareFrameWeightedSides
import ComputableAnalysis.ModularForms.Hecke41KernelFrameTiles

/-! Outer Cartesian top-edge samples for an arbitrary supplied density. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem common_outer_top_sample (f : QComplex → Scalar) (R : QPos)
    (M k v : Nat) (hM : 0<M) :
    (rectangleGridHorizontal f (squareFrameTile R k 3) M v M).val.Equiv
      (scaleRat (-1/(2*(M:Rat)))
        (commonSquareEdgeDensity f ⟨.north,true⟩ (squareFrameOuterRadius R)
          ((2-(k:Rat)-squareMidpointParameter M v)/2)).val) := by
  unfold rectangleGridHorizontal
  rw [squareFrame_outer_top_point R M k v hM,(squareFrameTile_grid_steps R M k 3).1]
  change (scalarProduct (f (cartesianSquarePoint ⟨.north,true⟩ (2*R.val)
    ((2-(k:Rat)-squareMidpointParameter M v)/2)))
    (rationalRectangleScalar ⟨R.val/(M:Rat),0⟩)).val.Equiv _
  rw [cartesianSquarePoint_agreement]
  have hw : (⟨R.val/(M:Rat),0⟩ : QComplex)=
      QComplex.scaleRat (-1/(2*(M:Rat)))
        (QComplex.scaleRat (2*R.val) (velocity ⟨.north,true⟩)) := by
    simp only [velocity,rotation,orientation,↓reduceIte,QComplex.mul,QComplex.scaleRat,
      QComplex.mk.injEq,Rat.div_def,Rat.inv_mul_rev]
    constructor <;> grind only
  rw [hw]
  exact rationalWeightedSample_scale _ _ _

theorem common_outer_top_tile_average (f : QComplex → Scalar) (R : QPos)
    (M k : Nat) (hM : 0<M) :
    (squareFrameHorizontalEdge f R M k 4).val.Equiv
      (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.north,true⟩
        (squareFrameOuterRadius R) ((2-(k:Rat)-u)/2)) M (-1/(2*(M:Rat)))).val := by
  let density := fun v => commonSquareEdgeDensity f ⟨.north,true⟩
    (squareFrameOuterRadius R) ((2-(k:Rat)-squareMidpointParameter M v)/2)
  let weighted := fun v => (⟨scaleRat (-1/(2*(M:Rat))) (density v).val,
    scaleRat_valid (density v).property⟩ : Scalar)
  have hs : ∀ v, (rectangleGridHorizontal f (squareFrameTile R k 4) M v 0).val.Equiv
      (weighted v).val := by
    intro v
    rw [←squareFrameTile_shared_horizontal_samples f R M k 3 v hM]
    exact common_outer_top_sample f R M k v hM
  exact equiv_trans (squareFrameHorizontalEdge f R M k 4).property
    (gridScalarSum M weighted).property
    (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.north,true⟩
      (squareFrameOuterRadius R) ((2-(k:Rat)-u)/2)) M (-1/(2*(M:Rat)))).property
    (gridScalarSum_congr M _ weighted hs)
    (gridScalarSum_scale (-1/(2*(M:Rat))) density M)

end ComputableAnalysis.ModularForms
