import ComputableAnalysis.ModularForms.Hecke41CuspExponentialMajorant

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory
set_option maxRecDepth 8192

private theorem power_le_one (a : Rat) (ha : 0≤a) (hu : a≤1) (n : Nat) : a^n≤1 := by
  induction n with
  | zero => simp
  | succ n ih =>
      rw [Rat.pow_succ]
      have h := Rat.mul_le_mul_of_nonneg_right ih ha
      grind only

private theorem power_swap (a : Rat) (m n : Nat) : (a^m)^n=(a^n)^m := by
  rw [rational_power_power,rational_power_power,Nat.mul_comm]

private theorem decay_ratio_bound :
    0≤(1/((2:Rat)^1800))^10000*hecke41CuspCoefficientMajorant^42 ∧
      (1/((2:Rat)^1800))^10000*hecke41CuspCoefficientMajorant^42≤1 := by
  let A : Rat := 2^1800
  let D := hecke41CuspCoefficientMajorant
  have hA : 0<A := Rat.pow_pos (by decide +kernel)
  have hD : 0<D := Rat.pow_pos (by decide +kernel)
  have hnum : D^42≤A^10000 := by
    change ((2:Rat)^400010)^42≤((2:Rat)^1800)^10000
    rw [rational_power_power,rational_power_power]
    have he : (1800:Nat)*10000=400010*42+1199580 := by decide +kernel
    rw [he,rational_power_add]
    have h := Rat.mul_le_mul_of_nonneg_left (rational_power_ge_one 2 (by decide +kernel) 1199580)
      (Rat.pow_nonneg (show (0:Rat)≤2 by decide +kernel) (n := 400010*42))
    simpa only [Rat.mul_one] using h
  have hr : 0≤1/A := by rw [Rat.div_def,Rat.one_mul]; exact Rat.le_of_lt (Rat.inv_pos.mpr hA)
  have hp : 0≤(1/A)^10000 := Rat.pow_nonneg hr
  refine ⟨Rat.mul_nonneg hp (Rat.pow_nonneg (Rat.le_of_lt hD)),?_⟩
  have hm := Rat.mul_le_mul_of_nonneg_left hnum hp
  have hunit : (1/A)^10000*A^10000=1 := by
    rw [← rational_reciprocal_power A hA]
    rw [Rat.div_def,Rat.one_mul]
    exact Rat.inv_mul_cancel _ (Rat.ne_of_gt (Rat.pow_pos hA))
  rw [hunit] at hm
  exact hm

/-- The nome-weighted rational coefficient bound is uniformly bounded,
independently of the band index. -/
theorem hecke41Cusp_weighted_bound_uniform (n : Nat) :
    2*((2*hecke41InputNomeRadius n)^10000)*hecke41CuspCoefficientBound n≤2*(2:Rat)^10000 := by
  let A : Rat := 2^1800
  let D := hecke41CuspCoefficientMajorant
  let R : Rat := (1/A)^10000*D^42
  have hA : 0<A := Rat.pow_pos (by decide +kernel)
  have he : 2*((2*hecke41InputNomeRadius n)^10000)*((D^(n+1))^42)=
      2*(2:Rat)^10000*R^(n+1) := by
    unfold hecke41InputNomeRadius
    rw [rational_reciprocal_power _ hA,rational_power_product,power_swap _ (n+1) 10000,
      power_swap D (n+1) 42]
    dsimp only [R]
    rw [rational_power_product]
    grind only
  have hr : 0≤hecke41InputNomeRadius n := by
    unfold hecke41InputNomeRadius
    rw [Rat.div_def,Rat.one_mul]
    exact Rat.le_of_lt (Rat.inv_pos.mpr (Rat.pow_pos hA))
  have hm := Rat.mul_le_mul_of_nonneg_left (hecke41CuspCoefficientBound_majorant n)
    (Rat.mul_nonneg (show (0:Rat)≤2 by decide +kernel) (Rat.pow_nonneg
      (Rat.mul_nonneg (show (0:Rat)≤2 by decide +kernel) hr) (n := 10000)))
  have hp := power_le_one R decay_ratio_bound.1 decay_ratio_bound.2 (n+1)
  have hf := Rat.mul_le_mul_of_nonneg_left hp (Rat.mul_nonneg
    (show (0:Rat)≤2 by decide +kernel) (Rat.pow_nonneg (show (0:Rat)≤2 by decide +kernel) (n := 10000)))
  rw [he] at hm
  exact Rat.le_trans hm (by simpa only [Rat.mul_one] using hf)

/-- Actual coefficients multiplied by the fixed 10000th nome power are
uniformly bounded across the full checked cusp family. -/
theorem hecke41PolynomialCoefficient_fixed_nome_bound (k n : Nat) (z : Scalar)
    (hz : InUpperHalfPlane z.val)
    (hl : (RealRaw.ofRat (300*((n+1:Nat):Rat))).Le z.val.imagPart)
    (hu : z.val.imagPart.Le (RealRaw.ofRat (301*((n+1:Nat):Rat)))) :
    Small (mul (LocalODE.power (nome.eval z hz).val 10000)
      ((hecke41PolynomialCoefficient k).value z (hecke41CommonDomain_cusp_family n z hz hl hu)).val)
      (2*(2:Rat)^10000) :=
  (hecke41PolynomialCoefficient_nome_weighted k n 10000 z hz hl hu).mono
    (hecke41Cusp_weighted_bound_uniform n)

/-- Uniform finite pole-growth control above the fixed high-cusp threshold.
No band, nome schedule, or coefficient bounds are required from callers. -/
theorem hecke41PolynomialCoefficient_high_cusp_pole_bound (k : Nat) (z : Scalar)
    (hz : InUpperHalfPlane z.val) (hl : (RealRaw.ofRat 90600).Le z.val.imagPart) :
    Small (mul (LocalODE.power (nome.eval z hz).val 10000)
      ((hecke41PolynomialCoefficient k).value z (hecke41CommonDomain_high_cusp z hz hl)).val)
      (2*(2:Rat)^10000) := by
  obtain ⟨n,hlo,hhi⟩ := real_high_cusp_band z.val.imagPart (imagPart_valid z.property) hl
  exact hecke41PolynomialCoefficient_fixed_nome_bound k n z hz hlo hhi

end ComputableAnalysis.ModularForms
