import ComputableAnalysis.ModularForms.CuspPowerGuards

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

private theorem pow_product (a b : Rat) (n : Nat) : (a*b)^n=a^n*b^n := by
  induction n with
  | zero => simp
  | succ n ih => simp only [Rat.pow_succ,ih]; grind

/-- An unbounded family of cusp bands, with all internal exponential
estimates and discriminant guards constructed. -/
theorem hecke41CommonDomain_cusp_family (n : Nat) (z : Scalar) (hz : InUpperHalfPlane z.val)
    (hl : (RealRaw.ofRat (300*((n+1:Nat):Rat))).Le z.val.imagPart)
    (hu : z.val.imagPart.Le (RealRaw.ofRat (301*((n+1:Nat):Rat)))) : hecke41CommonDomain z := by
  let K : Rat := ((n+1:Nat):Rat)
  have hK : 0<K := by
    dsimp [K]
    exact_mod_cast Nat.zero_lt_succ n
  have guards (i : Fin 42) := cusp_power_guards (hecke41CuspL i) (hecke41CuspB i)
    (hecke41Cusp_guards i).1 (hecke41Cusp_guards i).2.1
    (hecke41Cusp_guards i).2.2.1 (hecke41Cusp_guards i).2.2.2 n
  apply hecke41CommonDomain_of_rational_height z hz (300*K) (301*K) (K/2)
    (Rat.mul_pos (by decide +kernel) hK) (by grind) (by grind) hl hu
    (fun i => K*(hecke41CuspLowerExponent i:Rat)) (fun i => K*(hecke41CuspUpperExponent i:Rat))
    (fun i => (hecke41CuspL i)^(n+1)) (fun i => (hecke41CuspB i)^(n+1))
  · intro i
    have hi : 0<(hecke41CuspLowerExponent i:Rat) := by
      unfold hecke41CuspLowerExponent; split <;> decide +kernel
    exact Rat.mul_pos hK hi
  · intro i; exact (guards i).1
  · intro i; exact (guards i).2.1
  · intro i
    by_cases hi : i.val=41
    · simp only [hecke41CuspLowerExponent,hecke41HeightFactor,if_pos hi]
      have hcast : ((77000:Nat):Rat)=77000 := by decide +kernel
      rw [hcast]; grind
    · simp only [hecke41CuspLowerExponent,hecke41HeightFactor,if_neg hi]
      have hcast : ((45:Nat):Rat)=45 := by decide +kernel
      rw [hcast]; grind
  · intro i
    by_cases hi : i.val=41
    · simp only [hecke41CuspUpperExponent,hecke41HeightFactor,if_pos hi]
      have hcast : ((158000:Nat):Rat)=158000 := by decide +kernel
      rw [hcast]; grind
    · simp only [hecke41CuspUpperExponent,hecke41HeightFactor,if_neg hi]
      have hcast : ((96:Nat):Rat)=96 := by decide +kernel
      rw [hcast]; grind
  · intro i; exact (guards i).2.2.1
  · intro i; exact (guards i).2.2.2
  · intro i
    exact entireExponential_rational_nat_power_lower (hecke41CuspLowerExponent i:Rat)
      (hecke41CuspL i) (n+1) (Rat.le_of_lt (hecke41Cusp_guards i).1) (hecke41Cusp_lower_exponential i)
  · intro i
    have ht : 0≤(hecke41CuspUpperExponent i:Rat) := by
      unfold hecke41CuspUpperExponent; split <;> decide +kernel
    have hb : 0≤hecke41CuspB i*hecke41CuspB i :=
      Rat.mul_nonneg (hecke41Cusp_guards i).2.1 (hecke41Cusp_guards i).2.1
    have h := entireExponential_rational_nat_power_upper (hecke41CuspUpperExponent i:Rat)
      (hecke41CuspB i*hecke41CuspB i) (n+1) ht hb (hecke41Cusp_upper_exponential i)
    rw [pow_product] at h
    exact h

end ComputableAnalysis.ModularForms
