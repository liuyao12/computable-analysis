import ComputableAnalysis.ModularForms.GlobalDiscriminantNonvanishing
import ComputableAnalysis.ModularForms.ModularQuotientRectangleBoundary

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

/-- A rectangle with positive rational lower height lies wholly in the represented upper half-plane. -/
theorem representedRectangle_upper (J : QInterval × QInterval) (hJ : 0 < J.2.lo)
    (z : Scalar) (hz : representedRectangleContains J z) : InUpperHalfPlane z.val := by
  let eps : QPos := ⟨J.2.lo / 2, by grind only⟩
  obtain ⟨N, hN⟩ := (imagPart_valid z.property).2.2 eps
  have hw := hN N (Nat.le_refl N)
  have hh := hz.2.2.1 0 N
  change J.2.lo ≤ (z.val.imagPart.compute N).hi at hh
  change (z.val.imagPart.compute N).hi - (z.val.imagPart.compute N).lo ≤ J.2.lo / 2 at hw
  refine ⟨N, ?_⟩
  change 0 < (z.val.imagPart.compute N).lo
  grind only

/-- Global nonvanishing constructs the actual j domain on every upper-plane rectangle. -/
theorem latticeJMap_upper_rectangle_domain (J : QInterval × QInterval) (hJ : 0 < J.2.lo)
    (z : Scalar) (hz : representedRectangleContains J z) : latticeJMap.domain z :=
  latticeJMap_global_domain z (representedRectangle_upper J hJ z hz)

/-- The actual quotient has its whole rectangle domain, without a denominator hypothesis. -/
theorem discriminantPrimeHeckeDifferenceQuotient_upper_rectangle_domain (p : Nat)
    (hpR : 0 < (p : Rat)) (J : QInterval × QInterval) (hJ : 0 < J.2.lo)
    (z : Scalar) (hz : representedRectangleContains J z) :
    (discriminantPrimeHeckeDifferenceQuotient p hpR).domain z :=
  discriminantPrimeHeckeDifferenceQuotient_global_domain p hpR z (representedRectangle_upper J hJ z hz)

/-- Genuine holomorphicity supplies a finite derivative-neighborhood cover on any upper-plane rectangle. -/
theorem discriminantPrimeHeckeDifferenceQuotient_upper_rectangle_cover (p : Nat)
    (hpR : 0 < (p : Rat)) (J : QInterval × QInterval) (hJ : 0 < J.2.lo)
    (hX : J.1.lo ≤ J.1.hi) (hY : J.2.lo ≤ J.2.hi) (eps : QPos) :
    DomainRectangleNeighborhoodCover (discriminantPrimeHeckeDifferenceQuotient p hpR)
      (discriminantPrimeHeckeDifferenceQuotient_holomorphic p hpR) eps J :=
  domain_rectangle_neighborhood_cover _ _ eps J hX hY
    (discriminantPrimeHeckeDifferenceQuotient_upper_rectangle_domain p hpR J hJ)

/-- Actual weighted boundary sums converge to zero on arbitrary upper-plane rectangles. -/
theorem discriminantPrimeHeckeDifferenceQuotient_upper_rectangle_boundary_zero (p : Nat)
    (hpR : 0 < (p : Rat)) (J : QInterval × QInterval) (hJ : 0 < J.2.lo)
    (hX : J.1.lo ≤ J.1.hi) (hY : J.2.lo ≤ J.2.hi) (eps : QPos) :
    ∃ N, ∀ n, N ≤ n → Small
      (holomorphicRectangleGridBoundary (discriminantPrimeHeckeDifferenceQuotient p hpR)
        (discriminantPrimeHeckeDifferenceQuotient_holomorphic p hpR) J
        (discriminantPrimeHeckeDifferenceQuotient_upper_rectangle_domain p hpR J hJ) n).val eps.val :=
  holomorphicRectangleGridBoundary_converges_zero _ _ J
    (discriminantPrimeHeckeDifferenceQuotient_upper_rectangle_domain p hpR J hJ) hX hY eps

end ComputableAnalysis.ModularForms
