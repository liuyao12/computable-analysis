import ComputableAnalysis.ModularForms.WeightedLambertSeries

/-! Actual cubic and quintic Lambert sums at the CM nome of discriminant 163. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

def cmNomeRadius163 : Rat := 1/16777216

theorem cmNomeRadius163_nonneg : 0≤cmNomeRadius163 := by decide +kernel

theorem cmNomeRadius163_local : 4*cmNomeRadius163≤(1:Rat)/2 := by decide +kernel

theorem cmLambertRatio163_cubic : weightedLambertRatio cmNomeRadius163 3≤(1:Rat)/2 :=
  by decide +kernel

theorem cmLambertRatio163_quintic : weightedLambertRatio cmNomeRadius163 5≤(1:Rat)/2 :=
  by decide +kernel

def cmLambertCubic163 : ComplexRaw :=
  weightedLambertSum (nome.eval cmScalar163 cmPoint163_upper) cmNomeRadius163 3
    cmNomeRadius163_nonneg cmNomeRadius163_local nome_cm163_small_power

def cmLambertQuintic163 : ComplexRaw :=
  weightedLambertSum (nome.eval cmScalar163 cmPoint163_upper) cmNomeRadius163 5
    cmNomeRadius163_nonneg cmNomeRadius163_local nome_cm163_small_power

theorem cmLambertCubic163_valid : cmLambertCubic163.Valid :=
  weightedLambertSum_valid (nome.eval cmScalar163 cmPoint163_upper) cmNomeRadius163 3
    cmNomeRadius163_nonneg cmNomeRadius163_local nome_cm163_small_power cmLambertRatio163_cubic

theorem cmLambertQuintic163_valid : cmLambertQuintic163.Valid :=
  weightedLambertSum_valid (nome.eval cmScalar163 cmPoint163_upper) cmNomeRadius163 5
    cmNomeRadius163_nonneg cmNomeRadius163_local nome_cm163_small_power cmLambertRatio163_quintic

theorem cmLambertCubic163_bound : Small cmLambertCubic163 (1/524288) := by
  have h := weightedLambertSum_bound (nome.eval cmScalar163 cmPoint163_upper) cmNomeRadius163 3
    cmNomeRadius163_nonneg cmNomeRadius163_local nome_cm163_small_power cmLambertRatio163_cubic
  rw [show (4:Rat)*(8*cmNomeRadius163)=1/524288 by decide +kernel] at h
  exact h

theorem cmLambertQuintic163_bound : Small cmLambertQuintic163 (1/524288) := by
  have h := weightedLambertSum_bound (nome.eval cmScalar163 cmPoint163_upper) cmNomeRadius163 5
    cmNomeRadius163_nonneg cmNomeRadius163_local nome_cm163_small_power cmLambertRatio163_quintic
  rw [show (4:Rat)*(8*cmNomeRadius163)=1/524288 by decide +kernel] at h
  exact h

end ComputableAnalysis.ModularForms
