import ComputableAnalysis.ModularForms.CMExponentialSharpUpperBound163
import ComputableAnalysis.ModularForms.CMExponentialSharpLowerBound163

namespace ComputableAnalysis.ModularForms

/-- A convenient exact upper bound for growth, leaving room for the
constant and Laurent error in the CM root-isolation interval. -/
theorem cmGrowthValue163_isolation_upper :
    cmGrowthValue163.Le (RealRaw.ofRat 2305843009213693000) := by
  intro n m
  have h := cmGrowthExponential163_upper_sharp_power n 0
  change (cmGrowthValue163.compute n).lo≤((11/4:Rat)^41) at h
  exact Rat.le_trans h (show ((11/4:Rat)^41)≤2305843009213693000 by decide +kernel)

/-- The lower endpoint magnitude used by the checked interval transform. -/
theorem cmGrowthValue163_isolation_lower :
    (RealRaw.ofRat 144115188075855872).Le cmGrowthValue163 :=
  cmGrowthExponential163_lower_fiftySeven_power

end ComputableAnalysis.ModularForms
