import ComputableAnalysis.ModularForms.RationalPowerComparison

namespace ComputableAnalysis.ModularForms
set_option maxRecDepth 8192
set_option maxHeartbeats 4000000

def hecke41CuspJMajorant : Rat := 2^400000

def hecke41CuspCoefficientMajorant : Rat := 2^400010

private theorem base_B_bounds (i : Fin 42) : 1≤hecke41CuspB i ∧ hecke41CuspB i≤(2:Rat)^158000 := by
  by_cases hi : i.val=41
  · simp only [hecke41CuspB,hecke41CuspUpperExponent,if_pos hi]; decide +kernel
  · simp only [hecke41CuspB,hecke41CuspUpperExponent,if_neg hi]; decide +kernel

/-- A common exponential majorant for the actual point-specific cusp size bounds. -/
theorem hecke41CuspJBound_majorant (n : Nat) (i : Fin 42) :
    hecke41CuspJBound n i≤hecke41CuspJMajorant^(n+1) := by
  let A : Rat := 2^158000
  let b := hecke41CuspFamilyB n i
  let r := 1/hecke41CuspFamilyL n i
  have hbp : 1≤b := rational_power_ge_one _ (base_B_bounds i).1 _
  have hb : 0≤b := by grind
  have hbound : b≤A^(n+1) := rational_power_mono _ _ (hecke41Cusp_guards i).2.1 (base_B_bounds i).2 _
  have guards := cusp_power_guards (hecke41CuspL i) (hecke41CuspB i)
    (hecke41Cusp_guards i).1 (hecke41Cusp_guards i).2.1
    (hecke41Cusp_guards i).2.2.1 (hecke41Cusp_guards i).2.2.2 n
  have hr : 0≤r := by
    dsimp [r]; rw [Rat.div_def,Rat.one_mul]; exact Rat.le_of_lt (Rat.inv_pos.mpr guards.1)
  have hr₁ : r≤1 := by have h := guards.2.2.1; change r≤(1:Rat)/65536 at h; grind only
  have hr₂ : r*r≤r := by have h := Rat.mul_le_mul_of_nonneg_left hr₁ hr; simpa using h
  have hr₃ : r*r*r≤1 := by
    have h := Rat.mul_le_mul_of_nonneg_right hr₂ hr
    grind only
  have hb₂ : b≤b*b := by have h := Rat.mul_le_mul_of_nonneg_right hbp hb; simpa using h
  have hbb : 0≤b*b := Rat.mul_nonneg hb hb
  have he := Rat.mul_le_mul_of_nonneg_right hr₃ (Rat.mul_nonneg (show (0:Rat)≤512000000 by decide +kernel) hbb)
  have hcoarse : hecke41CuspJBound n i≤512000745*b*b := by
    change b+744+512000000*r*r*r*b*b≤512000745*b*b
    grind only
  have hAp : 0≤A^(n+1) := Rat.pow_nonneg (show 0≤A by dsimp [A]; exact Rat.pow_nonneg (by decide +kernel))
  have hmul₁ := Rat.mul_le_mul_of_nonneg_right hbound hb
  have hmul₂ := Rat.mul_le_mul_of_nonneg_left hbound hAp
  have hbbound : b*b≤A^(n+1)*A^(n+1) := Rat.le_trans hmul₁ hmul₂
  have hcoef := Rat.mul_le_mul_of_nonneg_left hbbound (show (0:Rat)≤512000745 by decide +kernel)
  have hc := rational_power_ge_base 512000745 (by decide +kernel) n
  have hfactor := Rat.mul_le_mul_of_nonneg_right hc (Rat.mul_nonneg hAp hAp)
  have hbase : (512000745:Rat)*A*A≤hecke41CuspJMajorant := by decide +kernel
  have hp := rational_power_mono _ _ (show 0≤(512000745:Rat)*A*A by
    have ha : 0≤A := Rat.pow_nonneg (by decide +kernel)
    exact Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) ha) ha) hbase (n+1)
  rw [rational_power_product,rational_power_product] at hp
  grind only

private theorem sum_bound (xs : List Rat) (R : Rat) (h : ∀ x∈xs,x≤R) : xs.sum≤(xs.length:Rat)*R := by
  induction xs with
  | nil => simp
  | cons a xs ih =>
      have ha := h a (by simp)
      have ht := ih (fun x hx => h x (by simp [hx]))
      simp only [List.sum_cons,List.length_cons]
      have hc : ((xs.length+1:Nat):Rat)=(xs.length:Rat)+1 := by simp
      rw [hc]
      grind only

/-- Uniform exponential growth bound on every cusp coefficient bound. -/
theorem hecke41CuspCoefficientBound_majorant (n : Nat) :
    hecke41CuspCoefficientBound n≤(hecke41CuspCoefficientMajorant^(n+1))^42 := by
  have hs := sum_bound (List.ofFn (hecke41CuspJBound n)) (hecke41CuspJMajorant^(n+1)) (by
    intro x hx; obtain ⟨i,hi⟩ := List.mem_ofFn.mp hx; subst x; exact hecke41CuspJBound_majorant n i)
  simp only [List.length_ofFn,show ((42:Nat):Rat)=42 by decide +kernel] at hs
  have hD : 1≤hecke41CuspJMajorant := by decide +kernel
  have hDp := rational_power_ge_one _ hD (n+1)
  have h85 := rational_power_ge_base 85 (by decide +kernel) n
  have hbase : (85:Rat)*hecke41CuspJMajorant≤hecke41CuspCoefficientMajorant := by decide +kernel
  have hp := rational_power_mono _ _ (show 0≤(85:Rat)*hecke41CuspJMajorant by grind only) hbase (n+1)
  rw [rational_power_product] at hp
  have hmul := Rat.mul_le_mul_of_nonneg_right h85 (show 0≤hecke41CuspJMajorant^(n+1) by grind only)
  have hpre : 1+2*(List.ofFn (hecke41CuspJBound n)).sum≤hecke41CuspCoefficientMajorant^(n+1) := by grind only
  have hsum : 0≤(List.ofFn (hecke41CuspJBound n)).sum := by
    have all (xs : List Rat) (h : ∀ x∈xs,0≤x) : 0≤xs.sum := by
      induction xs with
      | nil => simp
      | cons a xs ih =>
          have ha := h a (by simp); have ht := ih (fun x hx => h x (by simp [hx]))
          simp only [List.sum_cons]; grind only
    exact all _ (by intro x hx; obtain ⟨i,hi⟩ := List.mem_ofFn.mp hx; subst x; exact hecke41CuspJBound_nonneg n i)
  exact rational_power_mono _ _ (by grind only) hpre 42

end ComputableAnalysis.ModularForms
