import ComputableAnalysis.ModularForms.DiscriminantEulerRadialContinuity
import ComputableAnalysis.ModularForms.DiscriminantEulerSegmentContraction
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- Contraction on the actual radial segment, with all segment evidence constructed. -/
theorem discriminantEulerRadial_contraction (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R S a b B : Rat) (hR : 0≤R) (hS : 0≤S) (ha : 0<a) (hab : a≤b) (hB : 0<B)
    (hqr : Small q.val R) (hi : Small (RepresentedReciprocal.inverse q hq).val S)
    (hs : b*R≤(1:Rat)/65536) (W : QPos) (hW : (b-a)*R≤W.val)
    (hshort : 3072*W.val≤(1:Rat)/2)
    (hb : ∀ u, Small (discriminantEulerRadialValues q hq R a b hR ha hab hqr hs u).val B) :
    Small (discriminantEulerDividedMap.eval (rationalScaledScalar b q)
      ⟨rationalScaledScalar_nonzero b (by
          have hh : 0<b := by grind only
          exact Rat.ne_of_gt hh) q hq,
        rationalScaledScalar_nomeDomain q R b hR (Rat.le_trans (Rat.le_of_lt ha) hab) hqr hs⟩).val
      (B/2+21072*S*R*R*a) := by
  have hbpos : 0<b := by grind only
  have has : a*R≤(1:Rat)/65536 := Rat.le_trans (Rat.mul_le_mul_of_nonneg_right hab hR) hs
  let p := rationalScaledScalar a q
  let z := rationalScaledScalar b q
  let hp : discriminantEulerDividedMap.domain p :=
    ⟨rationalScaledScalar_nonzero a (Rat.ne_of_gt ha) q hq,rationalScaledScalar_nomeDomain q R a hR (Rat.le_of_lt ha) hqr has⟩
  let hz : discriminantEulerDividedMap.domain z :=
    ⟨rationalScaledScalar_nonzero b (Rat.ne_of_gt hbpos) q hq,rationalScaledScalar_nomeDomain q R b hR (Rat.le_of_lt hbpos) hqr hs⟩
  have he := discriminantEulerDividedMap_radial_decay q hq R S a hR hS ha hqr hi has
  exact discriminantEulerDividedMap_segment_contraction p z hp hz W B (21072*S*R*R*a) hB
    (representedRadialSegment_puncturedDomain q hq R a b hR ha hab hqr hs)
    ((rationalRadialSegment_displacement_bound q R a b hab hqr).mono hW) hb he hshort
/-- First concrete contraction from the proved whole-segment radial bound. -/
theorem discriminantEulerRadial_initial_contraction (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R S a b : Rat) (hR : 0<R) (hS : 0<S) (ha : 0<a) (hab : a≤b)
    (hqr : Small q.val R) (hi : Small (RepresentedReciprocal.inverse q hq).val S)
    (hs : b*R≤(1:Rat)/65536) (W : QPos) (hW : (b-a)*R≤W.val)
    (hshort : 3072*W.val≤(1:Rat)/2) :
    ∃ hz : discriminantEulerDividedMap.domain (rationalScaledScalar b q),
      Small (discriminantEulerDividedMap.eval (rationalScaledScalar b q) hz).val
        ((21072*S*R*R*b)/2+21072*S*R*R*a) := by
  have hb : 0<b := by grind only
  refine ⟨⟨rationalScaledScalar_nonzero b (Rat.ne_of_gt hb) q hq,
    rationalScaledScalar_nomeDomain q R b (Rat.le_of_lt hR) (Rat.le_of_lt hb) hqr hs⟩,?_⟩
  exact discriminantEulerRadial_contraction q hq R S a b (21072*S*R*R*b)
    (Rat.le_of_lt hR) (Rat.le_of_lt hS) ha hab
    (Rat.mul_pos (Rat.mul_pos (Rat.mul_pos (Rat.mul_pos (by decide +kernel) hS) hR) hR) hb)
    hqr hi hs W hW hshort
    (discriminantEulerRadialValues_bound q hq R S a b (Rat.le_of_lt hR) (Rat.le_of_lt hS) ha hab hqr hi hs)
end ComputableAnalysis.ModularForms
