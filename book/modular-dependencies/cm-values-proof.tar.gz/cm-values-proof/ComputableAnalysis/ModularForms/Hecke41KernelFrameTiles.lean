import ComputableAnalysis.ModularForms.Hecke41KernelBoundaryVanishing
import ComputableAnalysis.ModularForms.Hecke41KernelSampleOverlap
import ComputableAnalysis.ModularForms.PuncturedSquareFrameTiles

/-! Actual Hecke kernel boundaries on the twelve tiles of a small square frame. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

def squareFrameOuterRadius (R : QPos) : QPos :=
  ⟨2*R.val,Rat.mul_pos (by decide +kernel) R.property⟩

theorem squareFrameInterval_outer_bounds (R : QPos) (j : Nat) (hj : j<4) :
    -(squareFrameOuterRadius R).val≤(squareFrameInterval R j).lo ∧
      (squareFrameInterval R j).hi≤(squareFrameOuterRadius R).val := by
  have h0 : 0≤(j:Rat) := Rat.natCast_nonneg
  have h4 := Rat.natCast_le_natCast.mpr (show j+1≤4 by omega)
  rw [Rat.natCast_add] at h4
  have hr := Rat.le_of_lt R.property
  have hl := Rat.mul_nonneg h0 hr
  have hu := Rat.mul_le_mul_of_nonneg_right h4 hr
  change (j:Rat)+1≤4 at h4
  change -(2*R.val)≤ -2*R.val+(j:Rat)*R.val ∧
    -2*R.val+((j+1:Nat):Rat)*R.val≤2*R.val
  rw [Rat.natCast_add]
  change _ ∧ -2*R.val+((j:Rat)+1)*R.val≤2*R.val
  constructor <;> grind only

def hecke41KernelFrameTileBoundary (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : (squareFrameOuterRadius R).val≤
      ((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (j l : Nat) (h : squareFrameTileIndex j l) (n : Nat) : Scalar :=
  hecke41KernelGridBoundary k a ha (squareFrameTile R j l) R (squareFrameOuterRadius R)
    (squareFrameTile_separated R j l h)
    (squareFrameInterval_outer_bounds R j h.1).1 (squareFrameInterval_outer_bounds R j h.1).2
    (squareFrameInterval_outer_bounds R l h.2.1).1 (squareFrameInterval_outer_bounds R l h.2.1).2 hR n

theorem hecke41KernelFrameTileBoundary_converges_zero (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : (squareFrameOuterRadius R).val≤
      ((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (j l : Nat) (h : squareFrameTileIndex j l) (eps : QPos) :
    ∃ N, ∀ n, N≤n → Small (hecke41KernelFrameTileBoundary k a ha R hR j l h n).val eps.val :=
  hecke41KernelGridBoundary_converges_zero k a ha (squareFrameTile R j l) R (squareFrameOuterRadius R)
    (squareFrameTile_separated R j l h)
    (squareFrameInterval_outer_bounds R j h.1).1 (squareFrameInterval_outer_bounds R j h.1).2
    (squareFrameInterval_outer_bounds R l h.2.1).1 (squareFrameInterval_outer_bounds R l h.2.1).2 hR
    (squareFrameTile_ordered R j l).1 (squareFrameTile_ordered R j l).2 eps

theorem hecke41KernelFrameTiles_uniform_depth (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : (squareFrameOuterRadius R).val≤
      ((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val) (eps : QPos) :
    ∃ N, ∀ n, N≤n → ∀ j l, ∀ h : squareFrameTileIndex j l,
      Small (hecke41KernelFrameTileBoundary k a ha R hR j l h n).val eps.val := by
  have h : ∀ j, j<4 → ∃ N, ∀ n, N≤n → ∀ l, l<4 →
      ∀ hf : squareFrameTileIndex j l,
      Small (hecke41KernelFrameTileBoundary k a ha R hR j l hf n).val eps.val := by
    intro j hj
    apply finite_eventual_depth
    intro l hl
    by_cases hf : squareFrameTileIndex j l
    · obtain ⟨N,hN⟩ := hecke41KernelFrameTileBoundary_converges_zero k a ha R hR j l hf eps
      exact ⟨N,fun n hn _ => hN n hn⟩
    · exact ⟨0,by intro n hn hh; exact False.elim (hf hh)⟩
  obtain ⟨N,hN⟩ := finite_eventual_depth _ 4 h
  exact ⟨N,fun n hn j l hf => hN n hn j hf.1 l hf.2.1 hf⟩

end ComputableAnalysis.ModularForms
