import ComputableAnalysis.ModularForms.Hecke41SquareKernelRefinement
import ComputableAnalysis.ModularForms.DyadicSampleBlockAgreement
import ComputableAnalysis.ModularForms.CartesianHalfEdgeSums

/-! Exact recursive-to-flat midpoint sampling, including the actual Hecke kernel. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem dyadicSampleAverage_weightedMidpoint_agreement (f : Rat → Scalar) (n : Nat) :
    (dyadicSampleAverage f ⟨0,1⟩ n).val.Equiv
      (weightedMidpointSum f (2^n) (1/((2^n:Nat):Rat))).val := by
  have hd := dyadicSampleAverage_block f n
  have hg := gridScalarSum_block_agreement
    (fun j => f (squareMidpointParameter (2^n) j)) 0 (2^n)
  simp only [Nat.zero_add] at hg
  have hs := scaleRat_equiv (r := ((2^n:Nat):Rat)⁻¹) hg
  have ht := equiv_trans
    (dyadicSampleAverage f ⟨0,1⟩ n).property
    (scaleRat_valid (ScalarSeries.block_valid _ (fun j => (f _).property) 0 (2^n)))
    (scaleRat_valid (gridScalarSum (2^n) (fun j => f (squareMidpointParameter (2^n) j))).property)
    hd (equiv_symm hs)
  simpa only [weightedMidpointSum,Rat.div_def,Rat.one_mul] using ht

theorem hecke41SquareKernelDyadicAverage_flat_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) (n : Nat) :
    (hecke41SquareKernelDyadicAverage k a ha edge R hR n).val.Equiv
      (weightedMidpointSum (hecke41SquareKernelUnitSample k a ha edge R hR)
        (2^n) (1/((2^n:Nat):Rat))).val :=
  dyadicSampleAverage_weightedMidpoint_agreement _ n

end ComputableAnalysis.ModularForms
