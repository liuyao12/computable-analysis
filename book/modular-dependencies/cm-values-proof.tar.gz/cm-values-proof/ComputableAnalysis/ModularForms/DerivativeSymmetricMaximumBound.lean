import ComputableAnalysis.ModularForms.PerturbedAffineMaximum

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

/-- Genuine derivative remainders at two supplied domain points control the affine displacement
when the actual squared magnitudes at both points are bounded by the center. -/
theorem derivative_symmetric_maximum_bound (f : DomainFunctions.Map) (a d w : Scalar)
    (ha : f.domain a) (hf : HasDerivativeAt f a ha d) (eps H : QPos)
    (hH : H.val ≤ (hf.delta eps).val) (hw : Small w.val H.val)
    (hp : f.domain (Centered.translate a w))
    (hm : f.domain (Centered.translate a (scalarNeg w)))
    (hplus : (mul (f.eval (Centered.translate a w) hp).val
      (conj (f.eval (Centered.translate a w) hp).val)).realPart.Le
        (mul (f.eval a ha).val (conj (f.eval a ha).val)).realPart)
    (hminus : (mul (f.eval (Centered.translate a (scalarNeg w)) hm).val
      (conj (f.eval (Centered.translate a (scalarNeg w)) hm).val)).realPart.Le
        (mul (f.eval a ha).val (conj (f.eval a ha).val)).realPart) :
    let b := scalarProduct d w
    let B := scalarBound (f.eval a ha)+2*scalarBound d*H.val
    let E := eps.val*H.val
    (mul b.val (conj b.val)).realPart.Le (RealRaw.ofRat (2*E*(B+E)+2*B*E)) := by
  let A := f.eval a ha
  let b := scalarProduct d w
  let B := scalarBound A+2*scalarBound d*H.val
  let E := eps.val*H.val
  have hb : Small b.val (2*scalarBound d*H.val) := Small.mul d.property w.property
    (Rat.le_of_lt (scalarBound_pos d)) (Rat.le_of_lt H.property) (scalar_small d) hw
  have hBp : Small (add A.val b.val) B := LocalODE.small_add (scalar_small A) hb
  have hBm : Small (sub A.val b.val) B := SeriesLimitLaws.small_sub (scalar_small A) hb
  have heplus := translatedAffineModel_error f a d w ha hf eps H hH hp hw
  have heminus := translatedAffineModel_error f a d (scalarNeg w) ha hf eps H hH hm
    (SeriesLimitLaws.small_neg hw)
  have hemodel : (affineMidpointModel A d (scalarNeg w)).val.Equiv (sub A.val b.val) := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := (affineMidpointModel A d (scalarNeg w)).property)
      (hright := sub_valid A.property b.property)
    let av := ComplexRawQuotient.ofRaw A.val A.property
    let dv := ComplexRawQuotient.ofRaw d.val d.property
    let wv := ComplexRawQuotient.ofRaw w.val w.property
    change av+dv*(-wv)=av-(dv*wv)
    grind only
  have herrors := Small.congr
    (sub_valid (f.eval (Centered.translate a (scalarNeg w)) hm).property
      (affineMidpointModel A d (scalarNeg w)).property)
    (sub_valid (f.eval (Centered.translate a (scalarNeg w)) hm).property (sub_valid A.property b.property))
    (FunctionTheory.sub_congr (equiv_refl _ (f.eval (Centered.translate a (scalarNeg w)) hm).property) hemodel) heminus
  have hB : 0 ≤ B := by
    have h1 := scalarBound_pos A
    have h2 := Rat.mul_nonneg (Rat.mul_nonneg (show (0:Rat) ≤ 2 by decide +kernel)
      (Rat.le_of_lt (scalarBound_pos d))) (Rat.le_of_lt H.property)
    dsimp [B]; grind only
  exact scalar_perturbed_affine_maximum_bound A b (f.eval (Centered.translate a w) hp)
    (f.eval (Centered.translate a (scalarNeg w)) hm) B E hB
    (Rat.mul_nonneg (Rat.le_of_lt eps.property) (Rat.le_of_lt H.property))
    hBp hBm heplus herrors hplus hminus

end ComputableAnalysis.ModularForms
