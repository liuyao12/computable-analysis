import ComputableAnalysis.ModularForms.DiscriminantEulerZeroPropagation
import ComputableAnalysis.ModularForms.RadialNomeDomain
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- Actual divided discrepancy vanishes on the entire punctured nome domain. -/
theorem discriminantEulerDividedMap_zero (q : Scalar)
    (hq : discriminantEulerDividedMap.domain q) :
    (discriminantEulerDividedMap.eval q hq).val.Equiv zero := by
  obtain ⟨R,hR,hRs,hqr⟩ := hq.2
  let p := rationalScaledScalar (1/64) q
  let z := rationalScaledScalar 1 q
  have he : z.val.Equiv q.val := scaleRat_one_equiv q.val q.property
  let hz := (discriminantEulerDividedMap.domain_congr z q he).mpr hq
  have hpr := LocalODE.small_scale (show (0:Rat)≤1/64 by decide +kernel) hqr
  have hps : (1/64:Rat)*R≤1/65536 := by grind only
  have hp : discriminantEulerDividedMap.domain p :=
    ⟨rationalScaledScalar_nonzero (1/64) (by decide +kernel) q hq.1,
      rationalScaledScalar_nomeDomain q R (1/64) hR (by decide +kernel) hqr hps⟩
  have hpzero := discriminantEulerDividedMap_local_zero p hp (hpr.mono hps)
  have hdom (t : UnitInterval.Point) :
      discriminantEulerDividedMap.domain (RepresentedAffineSegment.point p z t) :=
    representedRadialSegment_fullNomeDomain q hq.1 R (1/64) 1 hR
      (by decide +kernel) (by decide +kernel) hqr (by simpa only [Rat.one_mul] using hRs) t
  have hh := discriminantEulerDividedMap_segment_zero p z hp hz hdom hpzero
  have hv := discriminantEulerDividedMap.eval_congr z q hz hq he
  exact equiv_trans (discriminantEulerDividedMap.eval q hq).property
    (discriminantEulerDividedMap.eval z hz).property (ofQComplex_valid _)
    (equiv_symm hv) hh

/-- Exact zero discrepancy includes every represented nome and every representation of the origin. -/
theorem discriminantEulerDifferenceMap_zero (q : Scalar) (hq : tauEulerNomeDomain q) :
    (discriminantEulerDifferenceMap.eval q hq).val.Equiv zero := by
  classical
  by_cases hz : q.val.Equiv zero
  · exact discriminantEulerDifferenceMap_at_zero q hq hz
  · have hk := ComplexRawQuotient.ofRaw_eq_ofRaw
      (hleft := (discriminantEulerDividedMap.eval q ⟨hz,hq⟩).property) (hright := ofQComplex_valid _)
      (discriminantEulerDividedMap_zero q ⟨hz,hq⟩)
    have hr := ComplexRawQuotient.ofRaw_eq_ofRaw
      (hleft := mul_valid q.property (discriminantEulerDividedMap.eval q ⟨hz,hq⟩).property)
      (hright := (discriminantEulerDifferenceMap.eval q hq).property)
      (discriminantEulerDividedMap_recovery q ⟨hz,hq⟩)
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := (discriminantEulerDifferenceMap.eval q hq).property) (hright := ofQComplex_valid _)
    change ComplexRawQuotient.ofRaw (discriminantEulerDividedMap.eval q ⟨hz,hq⟩).val
      (discriminantEulerDividedMap.eval q ⟨hz,hq⟩).property=0 at hk
    change ComplexRawQuotient.ofRaw q.val q.property *
      ComplexRawQuotient.ofRaw (discriminantEulerDividedMap.eval q ⟨hz,hq⟩).val
        (discriminantEulerDividedMap.eval q ⟨hz,hq⟩).property =
      ComplexRawQuotient.ofRaw (discriminantEulerDifferenceMap.eval q hq).val
        (discriminantEulerDifferenceMap.eval q hq).property at hr
    change ComplexRawQuotient.ofRaw (discriminantEulerDifferenceMap.eval q hq).val
      (discriminantEulerDifferenceMap.eval q hq).property=0
    rw [hk] at hr
    grind only

/-- The actual normalized Eisenstein discriminant equals the actual Euler product on the full nome domain. -/
theorem nomeNormalizedDiscriminantMap_euler_agreement (q : Scalar) (hq : tauEulerNomeDomain q) :
    (nomeNormalizedDiscriminantMap.eval q hq).val.Equiv (tauNormalizedEulerMap.eval q hq).val := by
  have hh := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := (discriminantEulerDifferenceMap.eval q hq).property) (hright := ofQComplex_valid _)
    (discriminantEulerDifferenceMap_zero q hq)
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (nomeNormalizedDiscriminantMap.eval q hq).property)
    (hright := (tauNormalizedEulerMap.eval q hq).property)
  change ComplexRawQuotient.ofRaw (nomeNormalizedDiscriminantMap.eval q hq).val
      (nomeNormalizedDiscriminantMap.eval q hq).property +
    -ComplexRawQuotient.ofRaw (tauNormalizedEulerMap.eval q hq).val
      (tauNormalizedEulerMap.eval q hq).property=0 at hh
  grind only
end ComputableAnalysis.ModularForms
