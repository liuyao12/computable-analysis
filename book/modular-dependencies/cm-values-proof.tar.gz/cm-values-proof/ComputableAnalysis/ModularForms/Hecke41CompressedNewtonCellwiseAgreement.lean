import ComputableAnalysis.ModularForms.Hecke41CompressedNewtonValidation
import ComputableAnalysis.ModularForms.Hecke41SparseNewtonCellwiseChecks
import ComputableAnalysis.ModularForms.Hecke41WeightedJPackedAgreement
import ComputableAnalysis.ModularForms.IntegerOrbitNewtonPrefixAgreement41

namespace ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem hecke41SparseNewtonCellwiseRows_checked (k : Nat) (hpos : 1≤k) (hk : k≤41) :
    hecke41SparseNewtonRow k=Array.ofFn (fun i : Fin 43 =>
      if 41*i.val+k<41 then 0 else integerOrbitNewtonSparseStep41
        hecke41ExpandedNewtonCandidate hecke41SparseTraceCoefficient k (41*i.val+k-41)) := by
  cases k with
  | zero => omega
  | succ k =>
    cases k with
    | zero => exact hecke41SparseNewtonOne_checked
    | succ k =>
      cases k with
      | zero => exact hecke41SparseNewton2_cellwise_checked
      | succ k =>
        cases k with
        | zero => exact hecke41SparseNewton3_cellwise_checked
        | succ k =>
          cases k with
          | zero => exact hecke41SparseNewton4_cellwise_checked
          | succ k =>
            cases k with
            | zero => exact hecke41SparseNewton5_cellwise_checked
            | succ k =>
              cases k with
              | zero => exact hecke41SparseNewton6_cellwise_checked
              | succ k =>
                cases k with
                | zero => exact hecke41SparseNewton7_cellwise_checked
                | succ k =>
                  cases k with
                  | zero => exact hecke41SparseNewton8_cellwise_checked
                  | succ k =>
                    cases k with
                    | zero => exact hecke41SparseNewton9_cellwise_checked
                    | succ k =>
                      cases k with
                      | zero => exact hecke41SparseNewton10_cellwise_checked
                      | succ k =>
                        cases k with
                        | zero => exact hecke41SparseNewton11_cellwise_checked
                        | succ k =>
                          cases k with
                          | zero => exact hecke41SparseNewton12_cellwise_checked
                          | succ k =>
                            cases k with
                            | zero => exact hecke41SparseNewton13_cellwise_checked
                            | succ k =>
                              cases k with
                              | zero => exact hecke41SparseNewton14_cellwise_checked
                              | succ k =>
                                cases k with
                                | zero => exact hecke41SparseNewton15_cellwise_checked
                                | succ k =>
                                  cases k with
                                  | zero => exact hecke41SparseNewton16_cellwise_checked
                                  | succ k =>
                                    cases k with
                                    | zero => exact hecke41SparseNewton17_cellwise_checked
                                    | succ k =>
                                      cases k with
                                      | zero => exact hecke41SparseNewton18_cellwise_checked
                                      | succ k =>
                                        cases k with
                                        | zero => exact hecke41SparseNewton19_cellwise_checked
                                        | succ k =>
                                          cases k with
                                          | zero => exact hecke41SparseNewton20_cellwise_checked
                                          | succ k =>
                                            cases k with
                                            | zero => exact hecke41SparseNewton21_cellwise_checked
                                            | succ k =>
                                              cases k with
                                              | zero => exact hecke41SparseNewton22_cellwise_checked
                                              | succ k =>
                                                cases k with
                                                | zero => exact hecke41SparseNewton23_cellwise_checked
                                                | succ k =>
                                                  cases k with
                                                  | zero => exact hecke41SparseNewton24_cellwise_checked
                                                  | succ k =>
                                                    cases k with
                                                    | zero => exact hecke41SparseNewton25_cellwise_checked
                                                    | succ k =>
                                                      cases k with
                                                      | zero => exact hecke41SparseNewton26_cellwise_checked
                                                      | succ k =>
                                                        cases k with
                                                        | zero => exact hecke41SparseNewton27_cellwise_checked
                                                        | succ k =>
                                                          cases k with
                                                          | zero => exact hecke41SparseNewton28_cellwise_checked
                                                          | succ k =>
                                                            cases k with
                                                            | zero => exact hecke41SparseNewton29_cellwise_checked
                                                            | succ k =>
                                                              cases k with
                                                              | zero => exact hecke41SparseNewton30_cellwise_checked
                                                              | succ k =>
                                                                cases k with
                                                                | zero => exact hecke41SparseNewton31_cellwise_checked
                                                                | succ k =>
                                                                  cases k with
                                                                  | zero => exact hecke41SparseNewton32_cellwise_checked
                                                                  | succ k =>
                                                                    cases k with
                                                                    | zero => exact hecke41SparseNewton33_cellwise_checked
                                                                    | succ k =>
                                                                      cases k with
                                                                      | zero => exact hecke41SparseNewton34_cellwise_checked
                                                                      | succ k =>
                                                                        cases k with
                                                                        | zero => exact hecke41SparseNewton35_cellwise_checked
                                                                        | succ k =>
                                                                          cases k with
                                                                          | zero => exact hecke41SparseNewton36_cellwise_checked
                                                                          | succ k =>
                                                                            cases k with
                                                                            | zero => exact hecke41SparseNewton37_cellwise_checked
                                                                            | succ k =>
                                                                              cases k with
                                                                              | zero => exact hecke41SparseNewton38_cellwise_checked
                                                                              | succ k =>
                                                                                cases k with
                                                                                | zero => exact hecke41SparseNewton39_cellwise_checked
                                                                                | succ k =>
                                                                                  cases k with
                                                                                  | zero => exact hecke41SparseNewton40_cellwise_checked
                                                                                  | succ k =>
                                                                                    cases k with
                                                                                    | zero => exact hecke41SparseNewton41_cellwise_checked
                                                                                    | succ k =>
                                                                                      omega

/-- The checked compressed table recovers actual weighted-j Newton
coefficients at every degree used by the degree-forty-one construction. -/
theorem hecke41ExpandedNewton_cellwise_actualAgreement (k n : Nat) (hk : k≤41) (hn : n<1723) :
    hecke41ExpandedNewtonCandidate k n=
      integerOrbitNewtonCoefficient41 integerJWeightedCoefficients 40 k n := by
  rw [hecke41ExpandedNewton_agreement_of_checks hecke41SparseNewtonCellwiseRows_checked k hk n hn]
  exact integerOrbitNewtonCoefficient41_prefix_equal (coefficient hecke41WeightedJCandidate)
    integerJWeightedCoefficients 40 1723 hecke41WeightedJ_coefficient_actual k n hn

end ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct
