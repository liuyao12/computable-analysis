import ComputableAnalysis.ModularForms.CMJExactClassFromNewton163

set_option maxRecDepth 4096

namespace ComputableAnalysis.ModularForms
open RiemannHilbert PackedIntegerPolynomialProduct

private theorem integerClass_constant (a : Int) :
    (a:ScalarAlgebra.Value)=ComplexRawQuotient.ofRaw (ComplexRaw.ofQComplex ⟨(a:Rat),0⟩)
      (ComplexRaw.ofQComplex_valid _) := by
  change ComplexRawQuotient.ofRaw (ComplexRaw.scaleRat (a:Rat) ComplexRaw.one)
    (ComplexRaw.scaleRat_valid (ComplexRaw.ofQComplex_valid _))=_
  apply ComplexRawQuotient.ofRaw_eq_ofRaw
  intro n
  apply (ComplexRaw.compareAt_overlap_iff _ _ n n).2
  change QBox.Overlaps (QBox.scaleRat (a:Rat) (QBox.point QComplex.one))
    (QBox.point ⟨(a:Rat),0⟩)
  unfold QBox.scaleRat
  split <;> simp [QBox.point,QComplex.one,QBox.Overlaps,QComplex.le_def,
    Rat.mul_one,Rat.mul_zero]

/-- Exact integer value of the actual modular function at the constructed
CM point. Only independently verified Newton-prefix agreement remains a premise. -/
theorem cmJValue163_exact_value_of_newton
    (hnewton : ∀ k n, k≤41 → n<1723 → hecke41ExpandedNewtonCandidate k n=
      integerOrbitNewtonCoefficient41 integerJWeightedCoefficients 40 k n) :
    cmJValue163.val.Equiv (ComplexRaw.ofQComplex ⟨-((640320:Rat)^3),0⟩) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := cmJValue163.property) (hright := ComplexRaw.ofQComplex_valid _)
  have hc := integerClass_constant (-(640320:Int)^3)
  rw [show (Int.cast (-(640320:Int)^3) : Rat)=-((640320:Rat)^3) by decide +kernel] at hc
  have hclass := cmJValue163_exact_class_of_newton hnewton
  have hcast : (Int.cast (-(640320:Int)^3) : ScalarAlgebra.Value) =
      -((Int.cast (640320:Int):ScalarAlgebra.Value)^3) := by grind only
  rw [hcast] at hc
  exact hclass.trans hc

end ComputableAnalysis.ModularForms
