import ComputableAnalysis.ModularForms.Hecke41CuspCoefficientAgreement
import ComputableAnalysis.ModularForms.Hecke41CoefficientHolomorphic

/-! Actual correspondence coefficients beyond degree forty-two vanish. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert

private theorem coefficient_beyond_length (p : RepresentedPolynomial.Coefficients) (k : Nat)
    (hk : p.length≤k) : RepresentedPolynomial.coefficient p k=RepresentedPolynomial.zero := by
  induction p generalizing k with
  | nil => rfl
  | cons a p ih =>
    cases k with
    | zero => simp only [List.length_cons] at hk; omega
    | succ k => exact ih k (by simp only [List.length_cons] at hk; omega)

theorem hecke41PolynomialCoefficient_above_degree (k : Nat) (hk : 43≤k)
    (z : Scalar) (hz : hecke41CommonDomain z) :
    ((hecke41PolynomialCoefficient k).value z hz).val.Equiv ComplexRaw.zero := by
  have he := coefficient_beyond_length (hecke41RootPolynomial z hz.2) k
    (by rw [hecke41RootPolynomial_length]; exact hk)
  have h := hecke41PolynomialCoefficient_value k z hz
  rw [he] at h
  exact h


private theorem coefficient_append_one (p : RepresentedPolynomial.Coefficients) :
    RepresentedPolynomial.coefficient (p++[RepresentedPolynomial.one]) p.length=
      RepresentedPolynomial.one := by
  induction p with
  | nil => rfl
  | cons a p ih => exact ih

theorem hecke41PolynomialCoefficient_leading (z : Scalar) (hz : hecke41CommonDomain z) :
    ((hecke41PolynomialCoefficient 42).value z hz).val.Equiv ComplexRaw.one := by
  obtain ⟨p,hp⟩ := hecke41RootPolynomial_monic z hz.2
  have hl := hecke41RootPolynomial_length z hz.2
  rw [hp,List.length_append,List.length_singleton] at hl
  have hlen : p.length=42 := by omega
  have hc := coefficient_append_one p
  rw [hlen] at hc
  have h := hecke41PolynomialCoefficient_value 42 z hz
  rw [hp,hc] at h
  exact h


theorem hecke41WeightedCoefficient_leading (m : Nat) (z : Scalar) (hz : hecke41CommonDomain z) :
    ((hecke41WeightedCoefficient 42 m).value z hz).val.Equiv
      (LocalODE.power (nome.eval z hz.1).val m) := by
  let P := LocalODE.power (nome.eval z hz.1).val m
  have hp := LocalODE.power_valid _ (nome.eval z hz.1).property m
  have h := hecke41WeightedCoefficient_value 42 m z hz
  have hc := hecke41PolynomialCoefficient_leading z hz
  have he := mul_equiv hp hp ((hecke41PolynomialCoefficient 42).value z hz).property
    (ofQComplex_valid _) (equiv_refl _ hp) hc
  exact equiv_trans ((hecke41WeightedCoefficient 42 m).value z hz).property
    (mul_valid hp ((hecke41PolynomialCoefficient 42).value z hz).property) hp h
    (equiv_trans (mul_valid hp ((hecke41PolynomialCoefficient 42).value z hz).property)
      (mul_valid hp (ofQComplex_valid _)) hp he (mul_one_equiv P hp))

end ComputableAnalysis.ModularForms
