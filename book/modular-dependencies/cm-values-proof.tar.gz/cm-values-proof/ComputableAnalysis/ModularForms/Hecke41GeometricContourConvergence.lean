import ComputableAnalysis.ModularForms.Hecke41GeometricShrinkingComparison
import ComputableAnalysis.ModularForms.Hecke41ContourDerivativeBound

/-! Actual geometric contours converge to a constructed small-contour value. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem hecke41GeometricContour_converges_small_limit (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeGeometricRadius a ha).val) (j : Nat)
    (hS : (squareShrinkingRadius R j).val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val)
    (eps : QPos) : ∃ N, ∀ n, N≤n → Small
      (sub (hecke41DyadicKernelContourLimit k a ha (squareShrinkingRadius R j) hS PDE.CauchyContour.square).val
        (hecke41GeometricDyadicContour k a ha R hR n).val) eps.val := by
  let S := squareShrinkingRadius R j
  let hG := Rat.le_trans (squareShrinkingRadius_le R j) hR
  let L := hecke41DyadicKernelContourLimit k a ha S hS PDE.CauchyContour.square
  have hsmall : ∀ eta : QPos, ∃ N, ∀ n, N≤n → Small
      (sub L.val (hecke41GeometricDyadicContour k a ha S hG n).val) eta.val := by
    intro eta
    obtain ⟨N,hN⟩ := hecke41FiniteSquareContour_converges k a ha S hS eta
    refine ⟨N, ?_⟩
    intro n hn
    have he := hecke41GeometricFiniteContour_agreement k a ha S hG
      (Rat.le_trans hS (minRadius_left _ _)) (2^n) (Nat.pow_pos (by decide +kernel)) PDE.CauchyContour.square
    exact Small.congr
      (sub_valid L.property (hecke41SquareKernelEdgeList k a ha S (2^n)
        (Nat.pow_pos (by decide +kernel)) (Rat.le_trans hS (minRadius_left _ _)) PDE.CauchyContour.square).property)
      (sub_valid L.property (hecke41GeometricDyadicContour k a ha S hG n).property)
      (FunctionTheory.sub_congr (equiv_refl _ L.property) (equiv_symm he)) (hN n hn)
  have hcompare : ∀ eta : QPos, ∃ N, ∀ n, N≤n → Small
      (sub (hecke41GeometricDyadicContour k a ha S hG n).val
        (hecke41GeometricDyadicContour k a ha R hR (n+j)).val) eta.val := by
    intro eta
    obtain ⟨N,hN⟩ := hecke41GeometricDyadicContour_shrinking_radius k a ha R hR j eta
    refine ⟨N, ?_⟩
    intro n hn
    have hb := SeriesLimitLaws.small_neg (hN n hn)
    have he : (neg (sub (hecke41GeometricDyadicContour k a ha R hR (n+j)).val
        (hecke41GeometricDyadicContour k a ha S hG n).val)).Equiv
      (sub (hecke41GeometricDyadicContour k a ha S hG n).val
        (hecke41GeometricDyadicContour k a ha R hR (n+j)).val) := by
      apply ComplexRawQuotient.equiv_of_ofRaw_eq
        (hleft := neg_valid (sub_valid (hecke41GeometricDyadicContour k a ha R hR (n+j)).property
          (hecke41GeometricDyadicContour k a ha S hG n).property))
        (hright := sub_valid (hecke41GeometricDyadicContour k a ha S hG n).property
          (hecke41GeometricDyadicContour k a ha R hR (n+j)).property)
      change -(gridScalarValue (hecke41GeometricDyadicContour k a ha R hR (n+j))-
        gridScalarValue (hecke41GeometricDyadicContour k a ha S hG n))=
        gridScalarValue (hecke41GeometricDyadicContour k a ha S hG n)-
        gridScalarValue (hecke41GeometricDyadicContour k a ha R hR (n+j))
      grind only
    exact Small.congr (neg_valid (sub_valid (hecke41GeometricDyadicContour k a ha R hR (n+j)).property
      (hecke41GeometricDyadicContour k a ha S hG n).property))
      (sub_valid (hecke41GeometricDyadicContour k a ha S hG n).property
        (hecke41GeometricDyadicContour k a ha R hR (n+j)).property) he hb
  obtain ⟨N,hN⟩ := scalarSequence_difference_trans (fun _ => L)
    (hecke41GeometricDyadicContour k a ha S hG)
    (fun n => hecke41GeometricDyadicContour k a ha R hR (n+j)) hsmall hcompare eps
  refine ⟨N+j, ?_⟩
  intro n hn
  have hnj : n-j+j=n := by omega
  have hb := hN (n-j) (by omega)
  rw [hnj] at hb
  exact hb

end ComputableAnalysis.ModularForms
