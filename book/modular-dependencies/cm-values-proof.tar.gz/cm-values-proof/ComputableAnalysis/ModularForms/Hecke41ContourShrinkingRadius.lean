import ComputableAnalysis.ModularForms.Hecke41ContourRadiusInvariance

/-! Exact contour invariance on an executable sequence of shrinking square radii. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def squareHalfRadius (R : QPos) : QPos :=
  ⟨R.val/2,by rw [Rat.div_def]; exact Rat.mul_pos R.property (by decide +kernel)⟩

theorem squareHalfRadius_le (R : QPos) : (squareHalfRadius R).val≤R.val := by
  change R.val/2≤R.val
  have h := Rat.le_of_lt R.property
  grind only [Rat.div_def]

theorem squareHalfRadius_outer (R : QPos) : squareFrameOuterRadius (squareHalfRadius R)=R := by
  apply Subtype.ext
  change 2*(R.val/2)=R.val
  grind only [Rat.div_def]

def squareShrinkingRadius (R : QPos) : Nat → QPos
  | 0 => R
  | n+1 => squareHalfRadius (squareShrinkingRadius R n)

theorem squareShrinkingRadius_le (R : QPos) (n : Nat) : (squareShrinkingRadius R n).val≤R.val := by
  induction n with
  | zero => exact Rat.le_refl
  | succ n ih => exact Rat.le_trans (squareHalfRadius_le _) ih

theorem squareShrinkingRadius_value (R : QPos) (n : Nat) :
    (squareShrinkingRadius R n).val=R.val*((1:Rat)/2)^n := by
  induction n with
  | zero => simp only [squareShrinkingRadius,Rat.pow_zero,Rat.mul_one]
  | succ n ih =>
    change (squareShrinkingRadius R n).val/2=R.val*((1:Rat)/2)^(n+1)
    rw [ih,Rat.pow_succ]
    grind only [Rat.div_def]

theorem squareShrinkingRadius_shrinks (R : QPos) :
    ShrinksToZero (fun n => (squareShrinkingRadius R n).val) := by
  intro eps
  refine ⟨RationalMajorant.natRateStage R.val eps, ?_⟩
  intro n hn
  change (squareShrinkingRadius R n).val≤eps.val
  rw [squareShrinkingRadius_value]
  have hb := Rat.mul_le_mul_of_nonneg_left (RationalMajorant.half_pow_le_one_div_succ n)
    (Rat.le_of_lt R.property)
  have he : R.val*(1/((n+1:Nat):Rat))=R.val/((n+1:Nat):Rat) := by
    rw [Rat.div_def,Rat.div_def,Rat.one_mul]
  rw [he] at hb
  exact Rat.le_trans hb (RationalMajorant.natRateStage_spec_of_le (Rat.le_of_lt R.property) eps hn)

theorem hecke41ContourLimit_half_radius (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) :
    (hecke41DyadicKernelContourLimit k a ha R hR PDE.CauchyContour.square).val.Equiv
      (hecke41DyadicKernelContourLimit k a ha (squareHalfRadius R)
        (Rat.le_trans (squareHalfRadius_le R) hR) PDE.CauchyContour.square).val := by
  have ho : (squareFrameOuterRadius (squareHalfRadius R)).val≤
      (hecke41NomeDerivativeNeighborhood k 10000 a ha).val := by
    rw [squareHalfRadius_outer]
    exact hR
  have hd := hecke41ContourLimit_doubled_radius k a ha (squareHalfRadius R) ho
  simpa only [squareHalfRadius_outer] using hd

theorem hecke41ContourLimit_shrinking_radius (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) (n : Nat) :
    (hecke41DyadicKernelContourLimit k a ha R hR PDE.CauchyContour.square).val.Equiv
      (hecke41DyadicKernelContourLimit k a ha (squareShrinkingRadius R n)
        (Rat.le_trans (squareShrinkingRadius_le R n) hR) PDE.CauchyContour.square).val := by
  induction n with
  | zero => exact equiv_refl _ (hecke41DyadicKernelContourLimit k a ha R hR PDE.CauchyContour.square).property
  | succ n ih =>
    exact equiv_trans (hecke41DyadicKernelContourLimit k a ha R hR PDE.CauchyContour.square).property
      (hecke41DyadicKernelContourLimit k a ha (squareShrinkingRadius R n)
        (Rat.le_trans (squareShrinkingRadius_le R n) hR) PDE.CauchyContour.square).property
      (hecke41DyadicKernelContourLimit k a ha (squareShrinkingRadius R (n+1))
        (Rat.le_trans (squareShrinkingRadius_le R (n+1)) hR) PDE.CauchyContour.square).property
      ih (hecke41ContourLimit_half_radius k a ha (squareShrinkingRadius R n)
        (Rat.le_trans (squareShrinkingRadius_le R n) hR))

end ComputableAnalysis.ModularForms
