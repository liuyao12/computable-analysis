import ComputableAnalysis.ModularForms.CMPoint43
import ComputableAnalysis.ModularForms.Hecke41PrincipalDiagonalAgreement
import ComputableAnalysis.ModularForms.Hecke41CompressedNewtonCellwiseAgreement

namespace ComputableAnalysis.ModularForms
set_option maxHeartbeats 0
open ComplexRaw RiemannHilbert FunctionTheory RepresentedPolynomial PackedIntegerPolynomialProduct

/-- Any actual repeated Hecke value satisfies the checked integer diagonal.
This law does not assume the numerical value of the singular modulus. -/
theorem hecke41_repeated_j_diagonal_root (z : Scalar) (hz : InUpperHalfPlane z.val)
    (i : Fin 42)
    (he : (latticeJMap.eval (hecke41Point i z)
      (latticeJMap_global_domain _ (hecke41Point_upper i z hz))).val.Equiv
      (latticeJMap.eval z (latticeJMap_global_domain z hz)).val) :
    Root (integerPolynomialEmbedding hecke41DiagonalCandidate)
      ⟨(latticeJMap.eval z (latticeJMap_global_domain z hz)).val,
        (latticeJMap.eval z (latticeJMap_global_domain z hz)).property⟩ := by
  let hd : hecke41CommonDomain z := ⟨hz,fun k =>
    latticeJMap_global_domain _ (hecke41Point_upper k z hz)⟩
  let J := latticeJMap.eval z (latticeJMap_global_domain z hz)
  have hm : hecke41JCert z hd.2 i ∈ List.ofFn (hecke41JCert z hd.2)  := List.mem_ofFn.mpr ⟨i,rfl⟩
  have hr := rootProduct_zero_of_mem (List.ofFn (hecke41JCert z hd.2)) _ hm
  have hc : Root (hecke41RootPolynomial z hd.2) ⟨J.val,J.property⟩ :=
    root_congr (equivalent_refl _) he (certTrans (eval_rootPolynomial _ _) hr)
  have hp : Root (integerHeckeRecoveredPolynomial41 J) ⟨J.val,J.property⟩ :=
    root_congr (integerHeckeRecoveredPolynomial41_equivalent z hz)
      (equiv_refl _ J.property) hc
  rw [←hecke41Diagonal_agreement_of_newton hecke41ExpandedNewton_cellwise_actualAgreement]
  exact equiv_trans
    (eval (integerPolynomialEmbedding integerHeckeDiagonalPolynomial41) ⟨J.val,J.property⟩).valid
    (eval (integerHeckeRecoveredPolynomial41 J) ⟨J.val,J.property⟩).valid zero.valid
    (integerHeckeDiagonalPolynomial41_eval J) hp

theorem cmJValue43_candidate_diagonal_root :
    Root (integerPolynomialEmbedding hecke41DiagonalCandidate) ⟨cmJValue43.val,cmJValue43.property⟩ :=
  hecke41_repeated_j_diagonal_root cmScalar43 cmPoint43_upper ⟨5,by decide⟩ hecke41Point_cm43_five_j

end ComputableAnalysis.ModularForms
