import ComputableAnalysis.ModularForms.Hecke41AffineResidueConvergence
import ComputableAnalysis.ModularForms.Hecke41FiniteContourConvergence
import ComputableAnalysis.ModularForms.Hecke41ContourShrinkingRadius

/-! Quantitative actual contour-to-derivative comparison at justified small radii. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem hecke41ContourLimit_derivative_error (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R eps : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val)
    (hDelta : R.val≤(((hecke41NomeDescended_holomorphic k 10000).atPoint a ha).delta eps).val) :
    Small (sub (hecke41DyadicKernelContourLimit k a ha R hR PDE.CauchyContour.square).val
      (scalarProduct ((hecke41NomeDescended_holomorphic k 10000).derivative a ha)
        ⟨twoPiI,twoPiI_valid⟩).val) (64*eps.val) := by
  let x := hecke41DyadicKernelContourLimit k a ha R hR PDE.CauchyContour.square
  let y := scalarProduct ((hecke41NomeDescended_holomorphic k 10000).derivative a ha) ⟨twoPiI,twoPiI_valid⟩
  let ho := Rat.le_trans hR (minRadius_left _ _)
  let p := fun n => hecke41SquareKernelEdgeList k a ha R (2^n)
    (Nat.pow_pos (by decide +kernel)) ho PDE.CauchyContour.square
  let q := fun n => hecke41FiniteAffineContour k a ha R ho (2^n)
    (Nat.pow_pos (by decide +kernel)) PDE.CauchyContour.square
  apply SeriesLimitLaws.small_closed (sub x.val y.val) (64*eps.val)
    (fun j => 2*(RepresentedCauchySum.error j).val)
    (SeriesLimitLaws.shrinks_scale _ RepresentedCauchySum.error_shrinks 2 (by decide +kernel))
  intro j
  obtain ⟨X,hX⟩ := hecke41FiniteSquareContour_converges k a ha R hR (RepresentedCauchySum.error j)
  obtain ⟨Y,hY⟩ := hecke41AffineSquareContour_converges k a ha R ho (RepresentedCauchySum.error j)
  let n := max X Y
  have hd := hecke41ActualFiniteContour_affine_bound k a ha R eps ho hDelta (2^n)
    (Nat.pow_pos (by decide +kernel)) PDE.CauchyContour.square
  change Small (sub (p n).val (q n).val) (8*(8*eps.val)) at hd
  have hb := LocalODE.small_add (LocalODE.small_add (hX n (Nat.le_max_left _ _)) hd)
    (SeriesLimitLaws.small_neg (hY n (Nat.le_max_right _ _)))
  have he : (add (add (sub x.val (p n).val) (sub (p n).val (q n).val))
      (neg (sub y.val (q n).val))).Equiv (sub x.val y.val) := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := add_valid (add_valid (sub_valid x.property (p n).property)
        (sub_valid (p n).property (q n).property)) (neg_valid (sub_valid y.property (q n).property)))
      (hright := sub_valid x.property y.property)
    change (gridScalarValue x-gridScalarValue (p n)+(gridScalarValue (p n)-gridScalarValue (q n)))+
      -(gridScalarValue y-gridScalarValue (q n))=gridScalarValue x-gridScalarValue y
    grind only
  have ht := Small.congr
    (add_valid (add_valid (sub_valid x.property (p n).property)
      (sub_valid (p n).property (q n).property)) (neg_valid (sub_valid y.property (q n).property)))
    (sub_valid x.property y.property) he hb
  have hr : (RepresentedCauchySum.error j).val+8*(8*eps.val)+(RepresentedCauchySum.error j).val=
      64*eps.val+2*(RepresentedCauchySum.error j).val := by grind only
  rw [hr] at ht
  exact ht

theorem hecke41ContourLimit_cauchy_derivative (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) :
    (hecke41DyadicKernelContourLimit k a ha R hR PDE.CauchyContour.square).val.Equiv
      (scalarProduct ((hecke41NomeDescended_holomorphic k 10000).derivative a ha)
        ⟨twoPiI,twoPiI_valid⟩).val := by
  let x := hecke41DyadicKernelContourLimit k a ha R hR PDE.CauchyContour.square
  let y := scalarProduct ((hecke41NomeDescended_holomorphic k 10000).derivative a ha) ⟨twoPiI,twoPiI_valid⟩
  apply SeriesLimitLaws.equiv_of_small_sub_zero
  apply SeriesLimitLaws.small_closed (sub x.val y.val) 0
    (fun j => 64*(RepresentedCauchySum.error j).val)
    (SeriesLimitLaws.shrinks_scale _ RepresentedCauchySum.error_shrinks 64 (by decide +kernel))
  intro j
  let eps := RepresentedCauchySum.error j
  obtain ⟨N,hN⟩ := squareShrinkingRadius_shrinks R
    (((hecke41NomeDescended_holomorphic k 10000).atPoint a ha).delta eps)
  let S := squareShrinkingRadius R N
  let hS := Rat.le_trans (squareShrinkingRadius_le R N) hR
  have hb := hecke41ContourLimit_derivative_error k a ha S eps hS (hN N (Nat.le_refl N))
  have he := FunctionTheory.sub_congr
    (equiv_symm (hecke41ContourLimit_shrinking_radius k a ha R hR N))
    (equiv_refl y.val y.property)
  have ht := Small.congr
    (sub_valid (hecke41DyadicKernelContourLimit k a ha S hS PDE.CauchyContour.square).property y.property)
    (sub_valid x.property y.property) he hb
  simpa only [Rat.zero_add] using ht

end ComputableAnalysis.ModularForms
