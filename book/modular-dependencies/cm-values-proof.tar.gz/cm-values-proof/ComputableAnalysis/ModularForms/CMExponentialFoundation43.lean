import ComputableAnalysis.ModularForms.CMExponentialAgreement43
import ComputableAnalysis.ModularForms.CMJNearIntegerError43

/-! Exact number-theoretic bounds through the current exponential API.
The actual modular value and Laurent estimates supply all arithmetic evidence. -/
namespace ComputableAnalysis.ModularForms.EC43
open ComplexRaw RiemannHilbert FunctionTheory ExponentialComputations

/-- The actual deficit computed through a selected current API evaluator. -/
def deficit (f : Implementation) (x : RealInput) : RealRaw :=
  RealRaw.add (RealRaw.ofRat 884736744) (RealRaw.neg (f.realEval x).val)

theorem deficit_valid (f : Implementation) (x : RealInput) : (deficit f x).Valid :=
  RealRaw.add_valid (RealRaw.ofRat_valid _) (RealRaw.neg_valid (f.realEval x).property)

theorem deficit_agreement (f : Implementation) (x : RealInput)
    (hx : x.val.Equiv input.val) : (deficit f x).Equiv cmIntegerGrowthDeficit43 :=
  RealRaw.add_equiv (RealRaw.ofRat_valid _) (RealRaw.ofRat_valid _)
    (RealRaw.neg_valid (f.realEval x).property)
    (RealRaw.neg_valid (realPart_valid (entireExponentialValue cmGrowthExponent43).property))
    (RealRaw.equiv_refl _ (RealRaw.ofRat_valid _))
    (RealRaw.neg_equiv (implementation_agreement f x hx))

/-- Transport the analytic error bound once the CM integer value is supplied.
The unconditional arithmetic instance is constructed in the endpoint module. -/
theorem deficit_bounds_of_cm_value (f : Implementation) (x : RealInput)
    (hx : x.val.Equiv input.val)
    (hcm : cmJValue43.val.Equiv (ofQComplex ⟨-((960:Rat)^3),0⟩)) :
    (RealRaw.ofRat (1/10000)).Le (deficit f x) ∧
      (deficit f x).Le (RealRaw.ofRat (3/10000)) := by
  have h := deficit_agreement f x hx
  have hb := cmIntegerGrowthDeficit43_bounds_of_cm_value hcm
  constructor
  · exact RealRaw.le_trans cmIntegerGrowthDeficit43_valid hb.1
      (RealRaw.le_of_equiv cmIntegerGrowthDeficit43_valid (deficit_valid f x) (RealRaw.equiv_symm h))
  · exact RealRaw.le_trans cmIntegerGrowthDeficit43_valid
      (RealRaw.le_of_equiv (deficit_valid f x) cmIntegerGrowthDeficit43_valid h)
      hb.2

/-- The full arithmetic corollary for every registered exponential and
 every equivalent represented name of the irrational argument. -/
theorem deficit_bounds (f : Implementation) (x : RealInput)
    (hx : x.val.Equiv input.val) :
    (RealRaw.ofRat (1/10000)).Le (deficit f x) ∧
      (deficit f x).Le (RealRaw.ofRat (3/10000)) :=
  deficit_bounds_of_cm_value f x hx cmJValue43_exact_value

/-- The statement directly in terms of the current real exponential. -/
theorem exp_bounds :
    let d := RealRaw.add (RealRaw.ofRat 884736744) (RealRaw.neg (exp input).val)
    (RealRaw.ofRat (1/10000)).Le d ∧ d.Le (RealRaw.ofRat (3/10000)) :=
  deficit_bounds powerSeries input (RealRaw.equiv_refl _ input.property)

theorem compoundInterest_bounds :
    (RealRaw.ofRat (1/10000)).Le (deficit compoundInterest input) ∧
      (deficit compoundInterest input).Le (RealRaw.ofRat (3/10000)) :=
  deficit_bounds compoundInterest input (RealRaw.equiv_refl _ input.property)

theorem linearODE_bounds :
    (RealRaw.ofRat (1/10000)).Le (deficit linearODE input) ∧
      (deficit linearODE input).Le (RealRaw.ofRat (3/10000)) :=
  deficit_bounds linearODE input (RealRaw.equiv_refl _ input.property)


end ComputableAnalysis.ModularForms.EC43
