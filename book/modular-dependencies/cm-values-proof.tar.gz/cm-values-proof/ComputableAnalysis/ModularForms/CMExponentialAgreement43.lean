import ComputableAnalysis.ExponentialComputations.API
import ComputableAnalysis.ModularForms.CMJExactValue43

/-! Exact agreement of the CM growth exponential with the current function API.
This analytic bridge is independent of the finite CM integer arithmetic. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory
namespace EC43
open ExponentialComputations

/-- The computable argument `pi*sqrt(43)`: twice the geometric half-pi
times the independently validated represented square root. -/
def input : RealInput := ⟨cmGrowthReal43,cmGrowthReal43_valid⟩

theorem complex_exp_agreement :
    (entireExponentialValue cmGrowthExponent43).val.Equiv
      (ExponentialComputations.Complex.exp (realAxis input)).val :=
  entireExponentialValue_congr _ _ cmGrowthExponent43_real

theorem real_exp_agreement : cmGrowthValue43.Equiv (exp input).val :=
  realPart_equiv complex_exp_agreement

/-- Agreement for any registered algorithm and any equivalent valid name
of this irrational input. No numerical precision or chart is supplied. -/
theorem implementation_agreement (f : Implementation) (x : RealInput)
    (hx : x.val.Equiv input.val) : (f.realEval x).val.Equiv cmGrowthValue43 :=
  RealRaw.equiv_trans (f.realEval x).property (exp x).property
    (realPart_valid (entireExponentialValue cmGrowthExponent43).property)
    (f.realEval_agrees x)
    (RealRaw.equiv_trans (exp x).property (exp input).property
      (realPart_valid (entireExponentialValue cmGrowthExponent43).property)
      (exp_congr x input hx) (RealRaw.equiv_symm real_exp_agreement))

end EC43
end ComputableAnalysis.ModularForms
