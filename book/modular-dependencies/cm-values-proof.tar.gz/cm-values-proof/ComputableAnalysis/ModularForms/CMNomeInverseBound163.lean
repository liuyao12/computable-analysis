import ComputableAnalysis.ModularForms.CMExponentialUpperBound163
import ComputableAnalysis.ModularForms.ExponentialInverse

/-! The actual CM nome reciprocal equals negative growth and has a justified coordinate bound. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

private theorem negative_growth_inverse (Q G : ScalarAlgebra.Value) (h : Q*G= -1) : Q*(-G)=1 := by
  grind only

/-- The actual CM nome reciprocal is exactly the negative actual CM growth exponential. -/
theorem cmNomeInverse163_growth :
    (RepresentedReciprocal.inverse (nome.eval cmScalar163 cmPoint163_upper)
      (nome_nonzero cmScalar163 cmPoint163_upper)).val.Equiv
      (neg (entireExponentialValue cmGrowthExponent163).val) := by
  let q := nome.eval cmScalar163 cmPoint163_upper
  let g := entireExponentialValue cmGrowthExponent163
  let v : Scalar := ⟨neg g.val,neg_valid g.property⟩
  apply RepresentedReciprocal.inverse_unique q (nome_nonzero cmScalar163 cmPoint163_upper) v
  have h := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := mul_valid q.property g.property) (hright := ofQComplex_valid _) nome_cm163_growth_product
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := mul_valid q.property v.property) (hright := ofQComplex_valid _)
  let Q := ComplexRawQuotient.ofRaw q.val q.property
  let G := ComplexRawQuotient.ofRaw g.val g.property
  change Q*G= -1 at h
  change Q*(-G)=1
  exact negative_growth_inverse Q G h

/-- The actual real CM growth exponential is coordinate bounded by the checked rational power. -/
theorem cmGrowthExponential163_small_upper_power :
    Small (entireExponentialValue cmGrowthExponent163).val ((8:Rat)^26) := by
  have hb : Small (ofRealRaw cmGrowthValue163) ((8:Rat)^26) := by
    refine ⟨?_,?_,?_,?_⟩
    · intro n m
      have hl := cmGrowthExponential163_lower_twentyFive 0 m
      change (25:Rat)≤(cmGrowthValue163.compute m).hi at hl
      change -((8:Rat)^26)≤(cmGrowthValue163.compute m).hi
      have hc : -((8:Rat)^26)≤25 := by decide +kernel
      exact Rat.le_trans hc hl
    · exact cmGrowthExponential163_upper_power
    · intro n m
      change -((8:Rat)^26)≤0
      decide +kernel
    · intro n m
      change (0:Rat)≤(8:Rat)^26
      decide +kernel
  exact Small.congr
    (ofRealRaw_valid _ (realPart_valid (entireExponentialValue cmGrowthExponent163).property))
    (entireExponentialValue cmGrowthExponent163).property
    (equiv_symm (equiv_real_embedding (entireExponentialValue cmGrowthExponent163)
      cmGrowthExponential163_imag_zero)) hb

/-- A concrete justified coordinate bound for the actual CM nome reciprocal. -/
theorem cmNomeInverse163_bound :
    Small (RepresentedReciprocal.inverse (nome.eval cmScalar163 cmPoint163_upper)
      (nome_nonzero cmScalar163 cmPoint163_upper)).val ((8:Rat)^26) :=
  Small.congr (neg_valid (entireExponentialValue cmGrowthExponent163).property)
    (RepresentedReciprocal.inverse (nome.eval cmScalar163 cmPoint163_upper)
      (nome_nonzero cmScalar163 cmPoint163_upper)).property
    (equiv_symm cmNomeInverse163_growth)
    (SeriesLimitLaws.small_neg cmGrowthExponential163_small_upper_power)

end ComputableAnalysis.ModularForms
