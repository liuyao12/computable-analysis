import ComputableAnalysis.ModularForms.CMJIsolationParameter163
import ComputableAnalysis.ModularForms.IntegerPolynomialRealBridge

namespace ComputableAnalysis.ModularForms
open RiemannHilbert

/-- Exact affine relation for the actual executable CM interval parameter. -/
theorem cmJIsolationParameter163_substitution :
    let T := realAxisClass cmJIsolationParameter163 cmJIsolationParameter163_valid
    let X := realAxisClass cmJValue163.val.realPart (ComplexRaw.realPart_valid cmJValue163.property)
    (1+T)*X=((-2305843009213693952:Int):ScalarAlgebra.Value)+
      ((-144115188075854872:Int):ScalarAlgebra.Value)*T := by
  dsimp only
  have hN : realAxisClass cmJIsolationNumerator163 cmJIsolationNumerator163_valid=
      realAxisClass cmJValue163.val.realPart (ComplexRaw.realPart_valid cmJValue163.property)-
        ((-2305843009213693952:Int):ScalarAlgebra.Value) := by
    unfold cmJIsolationNumerator163
    have hc := realAxisClass_int (-2305843009213693952)
    rw [show ((-2305843009213693952:Int):Rat)=(-2305843009213693952:Rat) by decide +kernel] at hc
    rw [realAxisClass_sub cmJValue163.val.realPart (RealRaw.ofRat (-2305843009213693952))
      (ComplexRaw.realPart_valid cmJValue163.property) (RealRaw.ofRat_valid _),
      hc]
  have hD : realAxisClass cmJIsolationDenominator163 cmJIsolationDenominator163_valid=
      ((-144115188075854872:Int):ScalarAlgebra.Value)-
        realAxisClass cmJValue163.val.realPart (ComplexRaw.realPart_valid cmJValue163.property) := by
    unfold cmJIsolationDenominator163
    have hc := realAxisClass_int (-144115188075854872)
    rw [show ((-144115188075854872:Int):Rat)=(-144115188075854872:Rat) by decide +kernel] at hc
    rw [realAxisClass_sub (RealRaw.ofRat (-144115188075854872)) cmJValue163.val.realPart
      (RealRaw.ofRat_valid _) (ComplexRaw.realPart_valid cmJValue163.property),
      hc]
  have hI := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := ComplexRaw.ofRealRaw_valid _
      (RealRaw.mul_valid cmJIsolationDenominator163_valid cmJIsolationInverse163_valid))
    (hright := ComplexRaw.ofRealRaw_valid RealRaw.one (RealRaw.ofRat_valid 1))
    (ComplexRaw.ofRealRaw_equiv_of_equiv (y := RealRaw.one)
      (RealRaw.mul_valid cmJIsolationDenominator163_valid cmJIsolationInverse163_valid)
      (RealRaw.ofRat_valid 1) cmJIsolationInverse163_product_identity)
  change realAxisClass (RealRaw.mul cmJIsolationDenominator163 cmJIsolationInverse163)
      (RealRaw.mul_valid cmJIsolationDenominator163_valid cmJIsolationInverse163_valid)=
      realAxisClass RealRaw.one (RealRaw.ofRat_valid 1) at hI
  rw [realAxisClass_mul _ _ cmJIsolationDenominator163_valid cmJIsolationInverse163_valid,hD] at hI
  have hOne : realAxisClass RealRaw.one (RealRaw.ofRat_valid 1)=(1:ScalarAlgebra.Value) := by
    have h := realAxisClass_int 1
    change realAxisClass RealRaw.one (RealRaw.ofRat_valid 1)=((1:Int):ScalarAlgebra.Value) at h
    rw [h]; grind only
  rw [hOne] at hI
  have hT : realAxisClass cmJIsolationParameter163 cmJIsolationParameter163_valid=
      (realAxisClass cmJValue163.val.realPart (ComplexRaw.realPart_valid cmJValue163.property)-
        ((-2305843009213693952:Int):ScalarAlgebra.Value))*
      realAxisClass cmJIsolationInverse163 cmJIsolationInverse163_valid := by
    change realAxisClass (RealRaw.mul cmJIsolationNumerator163 cmJIsolationInverse163)
      (RealRaw.mul_valid cmJIsolationNumerator163_valid cmJIsolationInverse163_valid)=_
    rw [realAxisClass_mul _ _ cmJIsolationNumerator163_valid cmJIsolationInverse163_valid,hN]
  rw [hT]
  grind only

end ComputableAnalysis.ModularForms
