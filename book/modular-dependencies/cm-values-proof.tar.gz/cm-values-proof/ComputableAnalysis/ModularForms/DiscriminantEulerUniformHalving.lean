import ComputableAnalysis.ModularForms.DiscriminantEulerDyadicAnchors
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- Rational endpoint control transfers to every represented parameter of a positive radial segment. -/
theorem discriminantEulerRadialValues_bound_of_endpoints
    (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q) (R a b B : Rat)
    (hR : 0≤R) (ha : 0<a) (hab : a≤b) (hqr : Small q.val R)
    (hs : b*R≤(1:Rat)/65536)
    (hb : ∀ c, 0<c → c≤b → ∀ hz : discriminantEulerDividedMap.domain (rationalScaledScalar c q),
      Small (discriminantEulerDividedMap.eval (rationalScaledScalar c q) hz).val B) :
    ∀ u, Small (discriminantEulerRadialValues q hq R a b hR ha hab hqr hs u).val B := by
  apply discriminantEulerRadialValues_bound_of_rational
  intro r h0 h1
  let c := a+(b-a)*r
  have hc0 : 0<c := by
    have hh := Rat.mul_nonneg (show 0≤b-a by grind only) h0
    dsimp [c]; grind only
  have hc1 : c≤b := by
    have hh := Rat.mul_le_mul_of_nonneg_left h1 (show 0≤b-a by grind only)
    dsimp [c]; grind only
  have hcs := Rat.le_trans (Rat.mul_le_mul_of_nonneg_right hc1 hR) hs
  let hc : discriminantEulerDividedMap.domain (rationalScaledScalar c q) :=
    ⟨rationalScaledScalar_nonzero c (Rat.ne_of_gt hc0) q hq,
      rationalScaledScalar_nomeDomain q R c hR (Rat.le_of_lt hc0) hqr hcs⟩
  have he := equiv_trans
    (RepresentedAffineSegment.point (rationalScaledScalar a q) (rationalScaledScalar b q)
      (UnitInterval.rational r h0 h1)).property
    (AffineSegment.point (rationalScaledScalar a q) (rationalScaledScalar b q) r).property
    (rationalScaledScalar c q).property
    (RepresentedAffineSegment.rational_agreement _ _ r h0 h1) (rationalRadialSegment_point q a b r)
  have hv := discriminantEulerDividedMap.eval_congr _ _
    (representedRadialSegment_puncturedDomain q hq R a b hR ha hab hqr hs _) hc he
  exact Small.congr (discriminantEulerDividedMap.eval (rationalScaledScalar c q) hc).property
    (discriminantEulerRadialValues q hq R a b hR ha hab hqr hs (UnitInterval.rational r h0 h1)).property
    (equiv_symm hv) (hb c hc0 hc1 hc)

/-- Actual radial contraction halves a common bound simultaneously at all positive rational scales. -/
theorem discriminantEulerRadial_uniform_halving
    (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R S b B : Rat) (hR : 0<R) (hS : 0≤S) (hb : 0<b) (hB : 0<B)
    (hqr : Small q.val R) (hi : Small (RepresentedReciprocal.inverse q hq).val S)
    (hs : b*R≤(1:Rat)/65536) (hshort : 3072*(b*R)≤(1:Rat)/2)
    (hbound : ∀ c, 0<c → c≤b → ∀ hz : discriminantEulerDividedMap.domain (rationalScaledScalar c q),
      Small (discriminantEulerDividedMap.eval (rationalScaledScalar c q) hz).val B) :
    ∀ c, 0<c → c≤b → ∀ hz : discriminantEulerDividedMap.domain (rationalScaledScalar c q),
      Small (discriminantEulerDividedMap.eval (rationalScaledScalar c q) hz).val (B/2) := by
  intro c hc hcb hz
  have hcr := Rat.mul_le_mul_of_nonneg_right hcb (Rat.le_of_lt hR)
  have hcs := Rat.le_trans hcr hs
  have hcshort := Rat.le_trans
    (Rat.mul_le_mul_of_nonneg_left hcr (show (0:Rat)≤3072 by decide +kernel)) hshort
  obtain ⟨hz',hh⟩ := discriminantEulerRadial_halving q hq R S c B hR hS hc hB
    hqr hi hcs hcshort (radialDyadicAnchor c) (radialDyadicAnchor_pos c hc)
    (radialDyadicAnchor_le c hc) (radialDyadicAnchor_shrinks c hc) (by
      intro N
      apply discriminantEulerRadialValues_bound_of_endpoints
      intro d hd hdc hdz
      exact hbound d hd (Rat.le_trans hdc hcb) hdz)
  exact hh
end ComputableAnalysis.ModularForms
