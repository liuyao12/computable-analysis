import Lean

namespace ComputableAnalysis.ModularForms.CoefficientConvolutionAlgebra
attribute [local instance] Lean.Grind.Semiring.natCast Lean.Grind.Ring.intCast
variable {R : Type} [Lean.Grind.CommRing R]

abbrev Series (R : Type) := Nat → R

def tail (a : Series R) : Series R := fun n => a (n+1)
def shift (a : Series R) : Series R
  | 0 => 0
  | n+1 => a n

def product (a b : Series R) : Nat → R
  | 0 => a 0*b 0
  | n+1 => a 0*b (n+1)+product (tail a) b n

theorem product_add_left (a b c : Series R) (n : Nat) :
    product (fun i => a i+b i) c n=product a c n+product b c n := by
  induction n generalizing a b with
  | zero => simp only [product]; grind only
  | succ n ih =>
    change (a 0+b 0)*c (n+1)+product (fun i => a (i+1)+b (i+1)) c n = _
    rw [ih]
    change (a 0+b 0)*c (n+1)+(product (tail a) c n+product (tail b) c n)=
      (a 0*c (n+1)+product (tail a) c n)+(b 0*c (n+1)+product (tail b) c n)
    grind only

theorem product_add_right (a b c : Series R) (n : Nat) :
    product a (fun i => b i+c i) n=product a b n+product a c n := by
  induction n generalizing a with
  | zero => simp only [product]; grind only
  | succ n ih =>
    change a 0*(b (n+1)+c (n+1))+product (tail a) (fun i => b i+c i) n =
      (a 0*b (n+1)+product (tail a) b n)+(a 0*c (n+1)+product (tail a) c n)
    rw [ih]
    grind only

theorem product_scale_left (r : R) (a b : Series R) (n : Nat) :
    product (fun i => r*a i) b n=r*product a b n := by
  induction n generalizing a with
  | zero => simp only [product]; grind only
  | succ n ih =>
    change (r*a 0)*b (n+1)+product (fun i => r*a (i+1)) b n = _
    rw [ih]
    change (r*a 0)*b (n+1)+r*product (tail a) b n=
      r*(a 0*b (n+1)+product (tail a) b n)
    grind only

theorem product_shift_left (a b : Series R) (n : Nat) :
    product (shift a) b n=shift (product a b) n := by
  cases n with
  | zero => change (0:R)*b 0=0; grind only
  | succ n => change (0:R)*b (n+1)+product a b n=product a b n; grind only

theorem product_tail_right (a b : Series R) (n : Nat) :
    product a b (n+1)=product a (tail b) n+a (n+1)*b 0 := by
  induction n generalizing a with
  | zero => change a 0*b 1+a 1*b 0=a 0*b 1+a 1*b 0; rfl
  | succ n ih =>
    rw [product,ih]
    change a 0*b (n+2)+(product (tail a) (tail b) n+a (n+2)*b 0)=
      (a 0*b (n+2)+product (tail a) (tail b) n)+a (n+2)*b 0
    grind only

theorem product_comm (a b : Series R) (n : Nat) : product a b n=product b a n := by
  induction n generalizing a b with
  | zero => simp only [product]; grind only
  | succ n ih =>
    rw [product,product_tail_right b a n,ih]
    change a 0*b (n+1)+product b (tail a) n=product b (tail a) n+b (n+1)*a 0
    grind only

private theorem product_decompose (a b : Series R) :
    product a b = fun i => a 0*b i+shift (product (tail a) b) i := by
  funext i
  cases i with
  | zero => change a 0*b 0=a 0*b 0+0; grind only
  | succ i => rfl

/-- Associativity follows from finite degree recursion. No infinite sums or
completion, nor any multiplication law assumed for supplied coefficients. -/
theorem product_assoc (a b c : Series R) (n : Nat) :
    product (product a b) c n=product a (product b c) n := by
  induction n generalizing a b c with
  | zero => simp only [product]; grind only
  | succ n ih =>
    rw [product_decompose a b,product_add_left,product_scale_left,product_shift_left]
    change a 0*product b c (n+1)+product (product (tail a) b) c n =
      a 0*product b c (n+1)+product (tail a) (product b c) n
    rw [ih]

theorem product_zero_left (a : Series R) (n : Nat) :
    product (fun _ => (0:R)) a n=0 := by
  induction n with
  | zero => simp only [product]; grind only
  | succ n ih =>
    change (0:R)*a (n+1)+product (fun _ => (0:R)) a n=0
    rw [ih]
    grind only

def constant (r : R) : Series R
  | 0 => r
  | _+1 => 0

theorem product_constant_left (r : R) (a : Series R) (n : Nat) :
    product (constant r) a n=r*a n := by
  cases n with
  | zero => rfl
  | succ n =>
    change r*a (n+1)+product (fun _ => (0:R)) a n=r*a (n+1)
    rw [product_zero_left]
    grind only


end ComputableAnalysis.ModularForms.CoefficientConvolutionAlgebra
