import ComputableAnalysis.ModularForms.DerivativeMaximumCrossBound

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

/-- A positive rational shrink fits two supplied positive neighborhood radii. -/
theorem rational_neighborhood_shrink (U D R : QPos) :
    ∃ t : QPos, t.val ≤ 1 ∧ t.val*U.val ≤ D.val ∧ t.val*U.val ≤ R.val := by
  let m := if D.val ≤ R.val then (if D.val ≤ 1 then D.val else 1) else (if R.val ≤ 1 then R.val else 1)
  have hm : 0 < m := by
    have hd := D.property
    have hr := R.property
    dsimp [m]
    split <;> split <;> grind only
  have hm1 : m ≤ 1 := by dsimp [m]; split <;> split <;> grind only
  have hmD : m ≤ D.val := by dsimp [m]; split <;> split <;> grind only
  have hmR : m ≤ R.val := by dsimp [m]; split <;> split <;> grind only
  have hden : 0 < U.val+1 := by have hu := U.property; grind only
  let t := m/(U.val+1)
  have ht : 0 < t := Rat.mul_pos hm (Rat.inv_pos.mpr hden)
  have hid : t*(U.val+1)=m := Rat.div_mul_cancel (Rat.ne_of_gt hden)
  have hp := Rat.mul_pos ht U.property
  have ht1 : t ≤ 1 := by grind only
  have htu : t*U.val ≤ m := by grind only
  exact ⟨⟨t,ht⟩,ht1,Rat.le_trans htu hmD,Rat.le_trans htu hmR⟩

/-- Construct an actual translated domain point with a positive shrunken direction,
small enough for the supplied derivative tolerance and the open-domain radius. -/
theorem derivative_neighborhood_shrink (f : DomainFunctions.Map) (a d u : Scalar)
    (ha : f.domain a) (hop : OpenDomain f) (hf : HasDerivativeAt f a ha d) (eps : QPos) :
    ∃ t : QPos, t.val ≤ 1 ∧
      let w : Scalar := ⟨scaleRat t.val u.val,scaleRat_valid u.property⟩
      let H : QPos := ⟨t.val*scalarBound u,Rat.mul_pos t.property (scalarBound_pos u)⟩
      H.val ≤ (hf.delta eps).val ∧ Small w.val H.val ∧ f.domain (Centered.translate a w) := by
  let U : QPos := ⟨scalarBound u,scalarBound_pos u⟩
  obtain ⟨t,ht1,htD,htR⟩ := rational_neighborhood_shrink U (hf.delta eps) (hop.radius a ha)
  let w : Scalar := ⟨scaleRat t.val u.val,scaleRat_valid u.property⟩
  have hw : Small w.val (t.val*scalarBound u) := LocalODE.small_scale (Rat.le_of_lt t.property) (scalar_small u)
  have hoff : Small (sub (Centered.translate a w).val a.val) (t.val*scalarBound u) :=
    Small.congr w.property (sub_valid (Centered.translate a w).property a.property)
      (equiv_symm (Centered.offset_translate a w)) hw
  have hp := hop.inside a ha (Centered.translate a w) (hoff.mono htR)
  exact ⟨t,ht1,htD,hw,hp⟩

end ComputableAnalysis.ModularForms
