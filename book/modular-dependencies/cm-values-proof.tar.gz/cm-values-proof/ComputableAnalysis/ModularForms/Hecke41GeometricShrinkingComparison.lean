import ComputableAnalysis.ModularForms.Hecke41GeometricHalfRadiusComparison

/-! Finite iteration of genuine geometric contour comparisons. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem scalarSequence_difference_trans (x y z : Nat → Scalar)
    (hxy : ∀ eps : QPos, ∃ N, ∀ n, N≤n → Small (sub (x n).val (y n).val) eps.val)
    (hyz : ∀ eps : QPos, ∃ N, ∀ n, N≤n → Small (sub (y n).val (z n).val) eps.val)
    (eps : QPos) : ∃ N, ∀ n, N≤n → Small (sub (x n).val (z n).val) eps.val := by
  let eta := squareHalfRadius eps
  obtain ⟨X,hX⟩ := hxy eta
  obtain ⟨Y,hY⟩ := hyz eta
  refine ⟨max X Y, ?_⟩
  intro n hn
  have hb := LocalODE.small_add (hX n (by omega)) (hY n (by omega))
  have he : (add (sub (x n).val (y n).val) (sub (y n).val (z n).val)).Equiv
      (sub (x n).val (z n).val) := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := add_valid (sub_valid (x n).property (y n).property)
        (sub_valid (y n).property (z n).property))
      (hright := sub_valid (x n).property (z n).property)
    change (gridScalarValue (x n)-gridScalarValue (y n))+
      (gridScalarValue (y n)-gridScalarValue (z n))=gridScalarValue (x n)-gridScalarValue (z n)
    grind only
  have hd := Small.congr
    (add_valid (sub_valid (x n).property (y n).property) (sub_valid (y n).property (z n).property))
    (sub_valid (x n).property (z n).property) he hb
  have hr : eta.val+eta.val=eps.val := by
    change eps.val/2+eps.val/2=eps.val
    grind only [Rat.div_def]
  rw [hr] at hd
  exact hd

theorem hecke41GeometricDyadicContour_shrinking_radius (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeGeometricRadius a ha).val) (j : Nat) (eps : QPos) :
    ∃ N, ∀ n, N≤n → Small
      (sub (hecke41GeometricDyadicContour k a ha R hR (n+j)).val
        (hecke41GeometricDyadicContour k a ha (squareShrinkingRadius R j)
          (Rat.le_trans (squareShrinkingRadius_le R j) hR) n).val) eps.val := by
  induction j generalizing eps with
  | zero =>
    refine ⟨0, ?_⟩
    intro n hn
    let x := hecke41GeometricDyadicContour k a ha R hR n
    have he : zero.Equiv (sub x.val x.val) := by
      apply ComplexRawQuotient.equiv_of_ofRaw_eq
        (hleft := ofQComplex_valid _) (hright := sub_valid x.property x.property)
      change 0=gridScalarValue x-gridScalarValue x
      grind only
    exact Small.congr (ofQComplex_valid _) (sub_valid x.property x.property)
      he (Small.zero (Rat.le_of_lt eps.property))
  | succ j ih =>
    apply scalarSequence_difference_trans
      (fun n => hecke41GeometricDyadicContour k a ha R hR (n+(j+1)))
      (fun n => hecke41GeometricDyadicContour k a ha (squareShrinkingRadius R j)
        (Rat.le_trans (squareShrinkingRadius_le R j) hR) (n+1))
      (fun n => hecke41GeometricDyadicContour k a ha (squareShrinkingRadius R (j+1))
        (Rat.le_trans (squareShrinkingRadius_le R (j+1)) hR) n)
    · intro eta
      obtain ⟨N,hN⟩ := ih eta
      refine ⟨N, ?_⟩
      intro n hn
      simpa only [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using hN (n+1) (by omega)
    · intro eta
      exact hecke41GeometricDyadicContour_half_radius k a ha (squareShrinkingRadius R j)
        (Rat.le_trans (squareShrinkingRadius_le R j) hR) eta

end ComputableAnalysis.ModularForms
