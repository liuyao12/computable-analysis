import ComputableAnalysis.ModularForms.ScalarProductNonvanishing
import ComputableAnalysis.ModularForms.PrimeHeckeQuotientLatticeDomain
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

/-- Nonvanishing of the actual normalized discriminant is invariant under every modular transformation. -/
theorem normalizedLatticeDiscriminantMap_action_nonzero_iff (g : SL2Z) (z : Scalar)
    (hz : InUpperHalfPlane z.val) :
    NonzeroBoxSearch.Nonzero (normalizedLatticeDiscriminantMap.eval
      (fractionalLinear g z hz) (fractionalLinear_mem g z hz)) ↔
      NonzeroBoxSearch.Nonzero (normalizedLatticeDiscriminantMap.eval z hz) := by
  let W : Scalar := ⟨LocalODE.power (integerAffine g.c g.d z.val) 12,
    LocalODE.power_valid _ (integerAffine_valid _ _ z.property) 12⟩
  let D := normalizedLatticeDiscriminantMap.eval z hz
  let E := normalizedLatticeDiscriminantMap.eval (fractionalLinear g z hz) (fractionalLinear_mem g z hz)
  have hW : NonzeroBoxSearch.Nonzero W :=
    scalar_power_nonzero ⟨integerAffine g.c g.d z.val,integerAffine_valid _ _ z.property⟩
      (denominator_nonzero g z hz) 12
  have he : E.val.Equiv (mul W.val D.val) := normalizedLatticeDiscriminantMap_action g z hz
  constructor
  · intro hE
    have hprod : NonzeroBoxSearch.Nonzero ⟨mul W.val D.val,mul_valid W.property D.property⟩ :=
      (NonzeroBoxSearch.nonzero_congr E _ he).mp hE
    exact ((scalar_mul_nonzero_iff W D).mp hprod).2
  · intro hD
    exact (NonzeroBoxSearch.nonzero_congr _ E (equiv_symm he)).mp (scalar_mul_nonzero W D hW hD)

/-- The actual Euler chart can be used after a supplied modular transformation. -/
theorem normalizedLatticeDiscriminantMap_nonzero_of_transformed_nome_chart (g : SL2Z)
    (z : Scalar) (hz : InUpperHalfPlane z.val)
    (hq : tauEulerNomeDomain (nome.eval (fractionalLinear g z hz) (fractionalLinear_mem g z hz))) :
    NonzeroBoxSearch.Nonzero (normalizedLatticeDiscriminantMap.eval z hz) :=
  (normalizedLatticeDiscriminantMap_action_nonzero_iff g z hz).mp
    (normalizedLatticeDiscriminantMap_nonzero_on_nome_chart _ (fractionalLinear_mem g z hz) hq)

/-- Transformed Euler evidence constructs actual lattice j domain evidence at the original point. -/
theorem latticeJMap_domain_of_transformed_nome_chart (g : SL2Z) (z : Scalar)
    (hz : InUpperHalfPlane z.val)
    (hq : tauEulerNomeDomain (nome.eval (fractionalLinear g z hz) (fractionalLinear_mem g z hz))) :
    latticeJMap.domain z := by
  exact ⟨hz,(normalizedLatticeDiscriminantMap_nonzero_iff z hz).mp
    (normalizedLatticeDiscriminantMap_nonzero_of_transformed_nome_chart g z hz hq)⟩

/-- The same transformed chart constructs the actual eigenform quotient's domain. -/
theorem discriminantPrimeHeckeDifferenceQuotient_domain_of_transformed_nome_chart
    (p : Nat) (hp : 0<(p:Rat)) (g : SL2Z) (z : Scalar) (hz : InUpperHalfPlane z.val)
    (hq : tauEulerNomeDomain (nome.eval (fractionalLinear g z hz) (fractionalLinear_mem g z hz))) :
    (discriminantPrimeHeckeDifferenceQuotient p hp).domain z :=
  ⟨hz,normalizedLatticeDiscriminantMap_nonzero_of_transformed_nome_chart g z hz hq⟩

/-- Normalization transfers the same exact invariance to the unnormalized lattice discriminant. -/
theorem latticeDiscriminantMap_action_nonzero_iff (g : SL2Z) (z : Scalar)
    (hz : InUpperHalfPlane z.val) :
    NonzeroBoxSearch.Nonzero (latticeDiscriminantMap.eval
      (fractionalLinear g z hz) (fractionalLinear_mem g z hz)) ↔
      NonzeroBoxSearch.Nonzero (latticeDiscriminantMap.eval z hz) :=
  (normalizedLatticeDiscriminantMap_nonzero_iff _ (fractionalLinear_mem g z hz)).symm.trans
    ((normalizedLatticeDiscriminantMap_action_nonzero_iff g z hz).trans
      (normalizedLatticeDiscriminantMap_nonzero_iff z hz))

/-- The actual lattice j domain is preserved and reflected by a modular transformation. -/
theorem latticeJMap_action_domain_iff (g : SL2Z) (z : Scalar) (hz : InUpperHalfPlane z.val) :
    latticeJMap.domain (fractionalLinear g z hz) ↔ latticeJMap.domain z := by
  constructor
  · intro h
    exact ⟨hz,(latticeDiscriminantMap_action_nonzero_iff g z hz).mp h.2⟩
  · intro h
    exact ⟨fractionalLinear_mem g z hz,(latticeDiscriminantMap_action_nonzero_iff g z hz).mpr h.2⟩

/-- The eigenform quotient domain is also preserved and reflected, without a prime hypothesis. -/
theorem discriminantPrimeHeckeDifferenceQuotient_action_domain_iff
    (p : Nat) (hp : 0<(p:Rat)) (g : SL2Z) (z : Scalar) (hz : InUpperHalfPlane z.val) :
    (discriminantPrimeHeckeDifferenceQuotient p hp).domain (fractionalLinear g z hz) ↔
      (discriminantPrimeHeckeDifferenceQuotient p hp).domain z :=
  (discriminantPrimeHeckeDifferenceQuotient_domain_iff_j p hp _).trans
    ((latticeJMap_action_domain_iff g z hz).trans
      (discriminantPrimeHeckeDifferenceQuotient_domain_iff_j p hp z).symm)
end ComputableAnalysis.ModularForms
