import ComputableAnalysis.ModularForms.ContinuousSimplePoleEdgeAverage

namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def continuousSimplePoleEdgeAverage (central : Bool) (f : DomainFunctions.Map)
    (hop : OpenDomain f) (a : Scalar) (ha : f.domain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val ≤ (hop.radius a ha).val) (M : Nat) (hM : 0 < M) : Scalar :=
  let terms := gridScalarSum M (fun j => if central then scalarProduct (f.eval a ha)
    (rationalRectangleScalar (simplePolePullback edge R.val (squareMidpointParameter M (j%M))))
    else continuousSimplePoleGridDensity f hop a ha edge R hR M hM j)
  ⟨scaleRat ((M:Rat)⁻¹) terms.val,scaleRat_valid terms.property⟩

def continuousSimplePoleFiniteContour (central : Bool) (f : DomainFunctions.Map)
    (hop : OpenDomain f) (a : Scalar) (ha : f.domain a) (R : QPos)
    (hR : R.val ≤ (hop.radius a ha).val) (M : Nat) (hM : 0 < M) : List HalfEdge → Scalar
  | [] => ⟨zero,ofQComplex_valid _⟩
  | e::es => scalarSum (continuousSimplePoleEdgeAverage central f hop a ha e R hR M hM)
      (continuousSimplePoleFiniteContour central f hop a ha R hR M hM es)

/-- Errors add over the actual finite contour; no contour integral is assumed. -/
theorem continuousSimplePoleFiniteContour_central_error (f : DomainFunctions.Map)
    (hop : OpenDomain f) (hf : ContinuousOn f.domain f.eval) (a : Scalar) (ha : f.domain a)
    (R eps : QPos) (hR : R.val ≤ (hop.radius a ha).val)
    (hcont : R.val ≤ (hf.delta a ha (halfError eps)).val) (M : Nat) (hM : 0 < M) (es : List HalfEdge) :
    Small (sub (continuousSimplePoleFiniteContour false f hop a ha R hR M hM es).val
      (continuousSimplePoleFiniteContour true f hop a ha R hR M hM es).val) ((es.length:Rat)*eps.val) := by
  induction es with
  | nil =>
    change Small (sub zero zero) (0*eps.val)
    rw [Rat.zero_mul]
    exact Small.congr (ofQComplex_valid _) (sub_valid (ofQComplex_valid _) (ofQComplex_valid _))
      (equiv_symm (add_neg_equiv zero (ofQComplex_valid _))) (Small.zero (by decide +kernel))
  | cons e es ih =>
    let x := continuousSimplePoleEdgeAverage false f hop a ha e R hR M hM
    let y := continuousSimplePoleEdgeAverage true f hop a ha e R hR M hM
    let p := continuousSimplePoleFiniteContour false f hop a ha R hR M hM es
    let q := continuousSimplePoleFiniteContour true f hop a ha R hR M hM es
    have he : Small (sub x.val y.val) eps.val := by
      exact continuousSimplePoleEdgeAverage_central_error f hop hf a ha e R eps hR hcont M hM
    have hb := LocalODE.small_add he ih
    have hd := Small.congr (add_valid (sub_valid x.property y.property) (sub_valid p.property q.property))
      (sub_valid (scalarSum x p).property (scalarSum y q).property) (sumPair_difference x p y q) hb
    have hr : eps.val+(es.length:Rat)*eps.val=((e::es).length:Rat)*eps.val := by
      rw [List.length_cons,Rat.natCast_add]
      change _=((es.length:Rat)+1)*_
      grind only
    rw [hr] at hd
    exact hd

/-- The eight half-edges of a square contribute at most eight times the density error. -/
theorem continuousSimplePoleSquare_central_error (f : DomainFunctions.Map)
    (hop : OpenDomain f) (hf : ContinuousOn f.domain f.eval) (a : Scalar) (ha : f.domain a)
    (R eps : QPos) (hR : R.val ≤ (hop.radius a ha).val)
    (hcont : R.val ≤ (hf.delta a ha (halfError eps)).val) (M : Nat) (hM : 0 < M) :
    Small (sub (continuousSimplePoleFiniteContour false f hop a ha R hR M hM square).val
      (continuousSimplePoleFiniteContour true f hop a ha R hR M hM square).val) (8*eps.val) := by
  exact continuousSimplePoleFiniteContour_central_error f hop hf a ha R eps hR hcont M hM square

end ComputableAnalysis.ModularForms
