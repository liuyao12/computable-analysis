import ComputableAnalysis.ModularForms.CommonSquareSignedParameter
import ComputableAnalysis.ModularForms.RationalUniformPartition
import ComputableAnalysis.ModularForms.RationalMidpointGrid

/-! Literal Cartesian boundary midpoint coordinates in signed square-side parameters. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def squareSignedInterval (S : QPos) (I : QInterval) : QInterval :=
  ⟨I.lo/S.val,I.hi/S.val⟩

theorem squareSignedInterval_midpoint_scaled (S : QPos) (I : QInterval) (M j : Nat) :
    S.val*(⟨rationalUniformPartition (squareSignedInterval S I) M j,
      rationalUniformPartition (squareSignedInterval S I) M (j+1)⟩ : QInterval).midpoint=
      I.lo+((j:Rat)+1/2)*(I.width/(M:Rat)) := by
  have hn : S.val≠0 := Rat.ne_of_gt S.property
  have hlo : S.val*(I.lo/S.val)=I.lo := by rw [Rat.mul_comm]; exact Rat.div_mul_cancel hn
  have hhi : S.val*(I.hi/S.val)=I.hi := by rw [Rat.mul_comm]; exact Rat.div_mul_cancel hn
  unfold QInterval.midpoint rationalUniformPartition squareSignedInterval QInterval.width
  rw [Rat.natCast_add]
  simp only [Rat.div_def]
  change S.val*((I.lo*S.val⁻¹+(j:Rat)*((I.hi*S.val⁻¹-I.lo*S.val⁻¹)*(M:Rat)⁻¹)+
    (I.lo*S.val⁻¹+((j:Rat)+1)*((I.hi*S.val⁻¹-I.lo*S.val⁻¹)*(M:Rat)⁻¹)))*2⁻¹)=
      I.lo+((j:Rat)+1*2⁻¹)*((I.hi-I.lo)*(M:Rat)⁻¹)
  simp only [Rat.div_def] at hlo hhi
  grind only

theorem rectangleGridHorizontalPoint_bottom_signed (S : QPos) (I : QInterval) (M j : Nat) :
    rectangleGridHorizontalPoint (I,⟨-S.val,S.val⟩) M j 0=
      QComplex.scaleRat S.val (point ⟨.south,true⟩
        (⟨rationalUniformPartition (squareSignedInterval S I) M j,
          rationalUniformPartition (squareSignedInterval S I) M (j+1)⟩ : QInterval).midpoint) := by
  have h := squareSignedInterval_midpoint_scaled S I M j
  simp only [rectangleGridHorizontalPoint,rectangleGridStepX,rectangleGridStepY,
    QComplex.scaleRat,point,rotation,orientation,QComplex.mul,↓reduceIte,QComplex.mk.injEq]
  constructor <;> change _=_ <;> grind only

theorem rectangleGridVerticalPoint_right_signed (S : QPos) (I : QInterval) (M j : Nat) :
    rectangleGridVerticalPoint (⟨S.val,S.val⟩,I) M 0 j=
      QComplex.scaleRat S.val (point ⟨.east,true⟩
        (⟨rationalUniformPartition (squareSignedInterval S I) M j,
          rationalUniformPartition (squareSignedInterval S I) M (j+1)⟩ : QInterval).midpoint) := by
  have h := squareSignedInterval_midpoint_scaled S I M j
  simp only [rectangleGridVerticalPoint,rectangleGridStepX,rectangleGridStepY,
    QComplex.scaleRat,point,rotation,orientation,QComplex.mul,↓reduceIte,QComplex.mk.injEq]
  constructor <;> change _=_ <;> grind only

theorem rectangleGridHorizontalPoint_top_signed (S : QPos) (I : QInterval) (M j : Nat) :
    rectangleGridHorizontalPoint (I,⟨S.val,S.val⟩) M j 0=
      QComplex.scaleRat S.val (point ⟨.north,true⟩
        (-(⟨rationalUniformPartition (squareSignedInterval S I) M j,
          rationalUniformPartition (squareSignedInterval S I) M (j+1)⟩ : QInterval).midpoint)) := by
  have h := squareSignedInterval_midpoint_scaled S I M j
  simp only [rectangleGridHorizontalPoint,rectangleGridStepX,rectangleGridStepY,
    QComplex.scaleRat,point,rotation,orientation,QComplex.mul,↓reduceIte,QComplex.mk.injEq]
  constructor <;> change _=_ <;> grind only

theorem rectangleGridVerticalPoint_left_signed (S : QPos) (I : QInterval) (M j : Nat) :
    rectangleGridVerticalPoint (⟨-S.val,-S.val⟩,I) M 0 j=
      QComplex.scaleRat S.val (point ⟨.west,true⟩
        (-(⟨rationalUniformPartition (squareSignedInterval S I) M j,
          rationalUniformPartition (squareSignedInterval S I) M (j+1)⟩ : QInterval).midpoint)) := by
  have h := squareSignedInterval_midpoint_scaled S I M j
  simp only [rectangleGridVerticalPoint,rectangleGridStepX,rectangleGridStepY,
    QComplex.scaleRat,point,rotation,orientation,QComplex.mul,↓reduceIte,QComplex.mk.injEq]
  constructor <;> change _=_ <;> grind only

theorem squareSignedInterval_bounds (S : QPos) (I : QInterval)
    (hI : -S.val≤I.lo ∧ I.lo≤I.hi ∧ I.hi≤S.val) :
    -1≤(squareSignedInterval S I).lo ∧
      (squareSignedInterval S I).lo≤(squareSignedInterval S I).hi ∧
      (squareSignedInterval S I).hi≤1 := by
  have hn : S.val≠0 := Rat.ne_of_gt S.property
  have hi : 0≤S.val⁻¹ := Rat.le_of_lt (Rat.inv_pos.mpr S.property)
  have h0 := Rat.mul_le_mul_of_nonneg_right hI.1 hi
  have h1 := Rat.mul_le_mul_of_nonneg_right hI.2.1 hi
  have h2 := Rat.mul_le_mul_of_nonneg_right hI.2.2 hi
  have he : S.val*S.val⁻¹=1 := Rat.mul_inv_cancel S.val hn
  change -1≤I.lo/S.val ∧ I.lo/S.val≤I.hi/S.val ∧ I.hi/S.val≤1
  simp only [Rat.div_def]
  grind only

theorem squareSignedInterval_midpoint_mem (S : QPos) (I : QInterval) (M j : Nat)
    (hI : -S.val≤I.lo ∧ I.lo≤I.hi ∧ I.hi≤S.val) (hM : 0<M) (hj : j<M) :
    -1≤(⟨rationalUniformPartition (squareSignedInterval S I) M j,
      rationalUniformPartition (squareSignedInterval S I) M (j+1)⟩ : QInterval).midpoint ∧
    (⟨rationalUniformPartition (squareSignedInterval S I) M j,
      rationalUniformPartition (squareSignedInterval S I) M (j+1)⟩ : QInterval).midpoint≤1 := by
  have hb := squareSignedInterval_bounds S I hI
  have hl := rationalUniformPartition_mem (squareSignedInterval S I) M j hb.2.1 hM (by omega)
  have hr := rationalUniformPartition_mem (squareSignedInterval S I) M (j+1) hb.2.1 hM (by omega)
  unfold QInterval.midpoint
  grind only

end ComputableAnalysis.ModularForms
