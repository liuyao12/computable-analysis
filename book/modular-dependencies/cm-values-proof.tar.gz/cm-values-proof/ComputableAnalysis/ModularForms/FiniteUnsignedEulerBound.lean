import ComputableAnalysis.Basic

namespace ComputableAnalysis.ModularForms

def unsignedEulerProduct (r : Rat) : Nat → Rat
  | 0 => 1
  | m+1 => (1+r^(m+1))*unsignedEulerProduct r m

def finiteRadiusSum (r : Rat) : Nat → Rat
  | 0 => 0
  | m+1 => finiteRadiusSum r m+r^(m+1)

theorem nonneg_radius_power (r : Rat) (hr : 0≤r) (m : Nat) : 0≤r^m := by
  induction m with
  | zero => rw [Rat.pow_zero]; decide +kernel
  | succ m ih => rw [Rat.pow_succ]; exact Rat.mul_nonneg ih hr

theorem unsignedEulerProduct_nonneg (r : Rat) (hr : 0≤r) (m : Nat) :
    0≤unsignedEulerProduct r m := by
  induction m with
  | zero => change (0:Rat)≤1; decide +kernel
  | succ m ih =>
    have hp := nonneg_radius_power r hr (m+1)
    have hf : 0≤1+r^(m+1) := by grind only
    exact Rat.mul_nonneg hf ih

theorem finiteRadiusSum_nonneg (r : Rat) (hr : 0≤r) (m : Nat) :
    0≤finiteRadiusSum r m := by
  induction m with
  | zero => change (0:Rat)≤0; exact Rat.le_refl
  | succ m ih =>
    have h := nonneg_radius_power r hr (m+1)
    change 0≤finiteRadiusSum r m+r^(m+1)
    grind only

/-- A finite positive product is controlled by its factor-increment sum. -/
theorem unsignedEulerProduct_sum_bound (r : Rat) (hr : 0≤r) (m : Nat) :
    unsignedEulerProduct r m*(1-finiteRadiusSum r m)≤1 := by
  induction m with
  | zero => change (1:Rat)*(1-0)≤1; decide +kernel
  | succ m ih =>
    have hp := unsignedEulerProduct_nonneg r hr m
    have hs := finiteRadiusSum_nonneg r hr m
    have hx := nonneg_radius_power r hr (m+1)
    have hsum : 0≤finiteRadiusSum r m+r^(m+1) := by grind only
    have h1 := Rat.mul_nonneg hx hsum
    have h2 := Rat.mul_nonneg hp h1
    change ((1+r^(m+1))*unsignedEulerProduct r m)*
      (1-(finiteRadiusSum r m+r^(m+1)))≤1
    grind only

theorem finiteRadiusSum_quarter (m : Nat) :
    3*finiteRadiusSum (1/4) m=1-(1/4:Rat)^m := by
  induction m with
  | zero => simp [finiteRadiusSum,Rat.pow_zero,Rat.mul_zero,Rat.sub_self]
  | succ m ih =>
    rw [finiteRadiusSum,Rat.pow_succ]
    have hq : (4:Rat)*(1/4)=1 := by decide +kernel
    grind only

/-- The unsigned finite Euler product at radius one quarter is bounded
uniformly in the cutoff. -/
theorem unsignedEulerProduct_quarter_bound (m : Nat) :
    unsignedEulerProduct (1/4) m≤3/2 := by
  have hr : (0:Rat)≤1/4 := by decide +kernel
  have h := unsignedEulerProduct_sum_bound (1/4) hr m
  have hp := unsignedEulerProduct_nonneg (1/4) hr m
  have hs := finiteRadiusSum_quarter m
  have hpow := nonneg_radius_power (1/4) hr m
  have hn := Rat.mul_nonneg hp hpow
  have he := congrArg (fun x => unsignedEulerProduct (1/4) m*x) hs
  have hc : (2:Rat)*(3/2)=3 := by decide +kernel
  grind only

end ComputableAnalysis.ModularForms
