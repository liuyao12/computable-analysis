import ComputableAnalysis.ModularForms.Hecke41FiniteAffineComparison
import ComputableAnalysis.ModularForms.Hecke41SquareKernelAverage

/-! Comparison sums agree with the actual finite Hecke evaluator. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def hecke41ComparisonEdgeAverage (affine : Bool) (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (M : Nat) (hM : 0<M) : Scalar :=
  let s := gridScalarSum M (hecke41SquareComparisonGridDensity affine k a ha edge R hR M hM)
  ⟨scaleRat ((M:Rat)⁻¹) s.val,scaleRat_valid s.property⟩

theorem hecke41ComparisonEdge_actual_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (M : Nat) (hM : 0<M) :
    (hecke41ComparisonEdgeAverage false k a ha edge R hR M hM).val.Equiv
      (hecke41SquareKernelAverage k a ha edge R M hM hR).val := by
  let f := fun j => scalarProduct
    ((hecke41NomeDescended k 10000).eval
      (Centered.translate a (rationalRectangleScalar
        (QComplex.scaleRat R.val (point edge (squareMidpointParameter M (j%M))))))
      (hecke41SquareEdge_domain k a ha edge R hR _
        (squareMidpointParameter_unit M (j%M) hM (Nat.mod_lt j hM)).1
        (squareMidpointParameter_unit M (j%M) hM (Nat.mod_lt j hM)).2))
    (rationalSquaredKernel (QComplex.scaleRat R.val (point edge (squareMidpointParameter M j))))
  have ht := hecke41SquareKernelAverage_sample_agreement k a ha edge R M hM hR f (by
    intro j hj
    dsimp only [f]
    simp only [Nat.mod_eq_of_lt hj]
    exact equiv_refl _ (scalarProduct
      ((hecke41NomeDescended k 10000).eval _
        (hecke41SquareEdge_domain k a ha edge R hR _
          (squareMidpointParameter_unit M j hM hj).1 (squareMidpointParameter_unit M j hM hj).2))
      (rationalSquaredKernel (QComplex.scaleRat R.val (point edge (squareMidpointParameter M j))))).property)
  have hs := gridScalarSum_congr_on_indices M
    (hecke41SquareComparisonGridDensity false k a ha edge R hR M hM)
    (fun j => scalarProduct (f j) (rationalRectangleScalar (QComplex.scaleRat R.val (velocity edge)))) (by
      intro j hj
      dsimp only [hecke41SquareComparisonGridDensity,f,suppliedSquareDensity]
      simp only [Bool.false_eq_true,↓reduceIte,Nat.mod_eq_of_lt hj]
      apply equiv_refl
      exact mul_valid
        (mul_valid ((hecke41NomeDescended k 10000).eval _
          (hecke41SquareEdge_domain k a ha edge R hR _
            (squareMidpointParameter_unit M j hM hj).1
            (squareMidpointParameter_unit M j hM hj).2)).property
          (rationalSquaredKernel (QComplex.scaleRat R.val (point edge (squareMidpointParameter M j)))).property)
        (rationalRectangleScalar (QComplex.scaleRat R.val (velocity edge))).property)
  exact equiv_trans (hecke41ComparisonEdgeAverage false k a ha edge R hR M hM).property
    (scaleRat_valid (gridScalarSum M (fun j => scalarProduct (f j)
      (rationalRectangleScalar (QComplex.scaleRat R.val (velocity edge))))).property)
    (hecke41SquareKernelAverage k a ha edge R M hM hR).property
    (scaleRat_equiv (r := ((M:Rat)⁻¹)) hs) ht

theorem hecke41ActualFiniteEdge_affine_bound (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (edge : HalfEdge) (R eps : QPos)
    (hR : R.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (hDelta : R.val≤(((hecke41NomeDescended_holomorphic k 10000).atPoint a ha).delta eps).val)
    (M : Nat) (hM : 0<M) :
    Small (sub (hecke41SquareKernelAverage k a ha edge R M hM hR).val
      (hecke41ComparisonEdgeAverage true k a ha edge R hR M hM).val) (8*eps.val) := by
  let x := hecke41ComparisonEdgeAverage false k a ha edge R hR M hM
  let y := hecke41ComparisonEdgeAverage true k a ha edge R hR M hM
  let z := hecke41SquareKernelAverage k a ha edge R M hM hR
  have he := FunctionTheory.sub_congr (hecke41ComparisonEdge_actual_agreement k a ha edge R hR M hM)
    (equiv_refl y.val y.property)
  exact Small.congr (sub_valid x.property y.property) (sub_valid z.property y.property) he
    (hecke41FiniteAffineEdge_difference_bound k a ha edge R eps hR hDelta M hM)

end ComputableAnalysis.ModularForms
