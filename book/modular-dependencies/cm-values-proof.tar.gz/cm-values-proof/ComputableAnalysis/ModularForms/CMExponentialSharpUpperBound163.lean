import ComputableAnalysis.ModularForms.RealExponentialPositiveGapOrder
import ComputableAnalysis.ModularForms.RationalExponentialPowerBounds
import ComputableAnalysis.ModularForms.CMGrowthTightBounds163
import ComputableAnalysis.ModularForms.CMNomeQuadraticDecay163

/-! A justified analytic upper bound for the actual CM growth exponential. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

def cmGrowthGapToFortyOne163 : RealRaw := RealRaw.add (RealRaw.ofRat 41) (RealRaw.neg cmGrowthReal163)

theorem cmGrowthGapToFortyOne163_valid : cmGrowthGapToFortyOne163.Valid :=
  RealRaw.add_valid (RealRaw.ofRat_valid 41) (RealRaw.neg_valid cmGrowthReal163_valid)

theorem cmGrowthGapToFortyOne163_lower_oneTwentyFifth : (RealRaw.ofRat (1/25)).Le cmGrowthGapToFortyOne163 := by
  intro n m
  have h := cmGrowthReal163_upper_tight m 0
  change (cmGrowthReal163.compute m).lo≤(1024/25:Rat) at h
  change (1/25:Rat)≤41+ -(cmGrowthReal163.compute m).lo
  grind only

theorem cmGrowthGapToFortyOne163_positive : cmGrowthGapToFortyOne163.Pos := by
  obtain ⟨N,hN⟩ := cmGrowthGapToFortyOne163_valid.2.2 (⟨1/100,by decide +kernel⟩ : QPos)
  have hw := hN N (Nat.le_refl N)
  have hl := cmGrowthGapToFortyOne163_lower_oneTwentyFifth 0 N
  change (1/25:Rat)≤(cmGrowthGapToFortyOne163.compute N).hi at hl
  unfold QInterval.width at hw
  refine ⟨N,?_⟩
  change 0<(cmGrowthGapToFortyOne163.compute N).lo
  grind only

private theorem real_gap_sum :
    (add (ofRealRaw cmGrowthReal163) (ofRealRaw cmGrowthGapToFortyOne163)).Equiv (ofQComplex ⟨41,0⟩) := by
  intro n
  apply (compareAt_overlap_iff _ _ n n).mpr
  have ho := RealRaw.interval_order_of_valid _ cmGrowthReal163_valid n
  simp only [add,ofRealRaw,cmGrowthGapToFortyOne163,RealRaw.add,RealRaw.addCompute,
    RealRaw.neg,RealRaw.negCompute,RealRaw.ofRat,QBox.add,QComplex.add,ofQComplex,QBox.point,
    QBox.Overlaps,QComplex.le_def,Rat.add_zero]
  change ((cmGrowthReal163.compute n).lo+(41+ -(cmGrowthReal163.compute n).hi)≤41 ∧ (0:Rat)≤0) ∧
    (41≤(cmGrowthReal163.compute n).hi+(41+ -(cmGrowthReal163.compute n).lo) ∧ (0:Rat)≤0)
  constructor <;> constructor <;> grind only

/-- The actual CM growth exponential is bounded above by the justified rational power. -/
theorem cmGrowthExponential163_upper_sharp_power :
    cmGrowthValue163.Le (RealRaw.ofRat ((11/4:Rat)^41)) := by
  let X : Scalar := ⟨ofRealRaw cmGrowthReal163,ofRealRaw_valid _ cmGrowthReal163_valid⟩
  let D : Scalar := ⟨ofRealRaw cmGrowthGapToFortyOne163,ofRealRaw_valid _ cmGrowthGapToFortyOne163_valid⟩
  have hx0 : (RealRaw.ofRat 0).Le cmGrowthReal163 := by
    intro n m
    have h := cmGrowthReal163_lower_twentyFour 0 m
    change (24:Rat)≤(cmGrowthReal163.compute m).hi at h
    change (0:Rat)≤(cmGrowthReal163.compute m).hi
    grind only
  have hd0 : (RealRaw.ofRat 0).Le cmGrowthGapToFortyOne163 := by
    intro n m
    have h := cmGrowthGapToFortyOne163_lower_oneTwentyFifth 0 m
    change (1/25:Rat)≤(cmGrowthGapToFortyOne163.compute m).hi at h
    change (0:Rat)≤(cmGrowthGapToFortyOne163.compute m).hi
    grind only
  have hm := entireExponential_real_positive_gap_order cmGrowthReal163 cmGrowthGapToFortyOne163
    cmGrowthReal163_valid cmGrowthGapToFortyOne163_valid cmGrowthReal163_positive
    cmGrowthGapToFortyOne163_positive hx0 hd0
  have hc := ComplexRaw.realPart_equiv (entireExponentialValue_congr cmGrowthExponent163 X cmGrowthExponent163_real)
  have hs := ComplexRaw.realPart_equiv (entireExponentialValue_congr (scalarSum X D)
    ⟨ofQComplex ⟨41,0⟩,ofQComplex_valid _⟩ real_gap_sum)
  exact RealRaw.le_trans (realPart_valid (entireExponentialValue X).property)
    (RealRaw.le_of_equiv (realPart_valid (entireExponentialValue cmGrowthExponent163).property)
      (realPart_valid (entireExponentialValue X).property) hc)
    (RealRaw.le_trans (realPart_valid (entireExponentialValue (scalarSum X D)).property) hm
      (RealRaw.le_trans (realPart_valid (entireExponentialValue ⟨ofQComplex ⟨41,0⟩,ofQComplex_valid _⟩).property)
        (RealRaw.le_of_equiv (realPart_valid (entireExponentialValue (scalarSum X D)).property)
          (realPart_valid (entireExponentialValue ⟨ofQComplex ⟨41,0⟩,ofQComplex_valid _⟩).property) hs)
        entireExponential_rational_fortyOne_upper))

end ComputableAnalysis.ModularForms
