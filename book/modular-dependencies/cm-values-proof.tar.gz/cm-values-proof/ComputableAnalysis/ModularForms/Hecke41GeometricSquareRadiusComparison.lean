import ComputableAnalysis.ModularForms.Hecke41GeometricCommonSquareEdgeAgreement
import ComputableAnalysis.ModularForms.Hecke41GeometricCommonFrameCancellation
import ComputableAnalysis.ModularForms.Hecke41SquareRadiusComparison

/-! Actual geometric finite contour comparison from square-frame cancellation. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

theorem hecke41GeometricInnerSquareContour_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (B R : QPos)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (hR : R.val≤B.val) (M : Nat) (hM : 0<M) :
    (frameScalarRectBoundary
      (squareFrameHorizontalEdge (hecke41GeometricKernelSquareSample k a ha B hB) R M)
      (squareFrameVerticalEdge (hecke41GeometricKernelSquareSample k a ha B hB) R M) 1 1 2 2).val.Equiv
      (hecke41GeometricFiniteContour k a ha R (Rat.le_trans hR hB) M hM PDE.CauchyContour.square).val :=
  equiv_trans
    (frameScalarRectBoundary
      (squareFrameHorizontalEdge (hecke41GeometricKernelSquareSample k a ha B hB) R M)
      (squareFrameVerticalEdge (hecke41GeometricKernelSquareSample k a ha B hB) R M) 1 1 2 2).property
    (commonSquareKernelEdgeList (hecke41GeometricKernelSquareSample k a ha B hB) R M PDE.CauchyContour.square).property
    (hecke41GeometricFiniteContour k a ha R (Rat.le_trans hR hB) M hM PDE.CauchyContour.square).property
    (commonInnerSquareContour_agreement _ R M hM)
    (hecke41GeometricCommonSquare_edge_list_agreement k a ha B R hB hR M hM PDE.CauchyContour.square)


theorem hecke41GeometricOuterSquareContour_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (B R : QPos)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (hR : (squareFrameOuterRadius R).val≤B.val) (M : Nat) (hM : 0<M) :
    (frameScalarRectBoundary
      (squareFrameHorizontalEdge (hecke41GeometricKernelSquareSample k a ha B hB) R M)
      (squareFrameVerticalEdge (hecke41GeometricKernelSquareSample k a ha B hB) R M) 0 0 4 4).val.Equiv
      (hecke41GeometricFiniteContour k a ha (squareFrameOuterRadius R) (Rat.le_trans hR hB) (2*M) (by omega) PDE.CauchyContour.square).val :=
  equiv_trans
    (frameScalarRectBoundary
      (squareFrameHorizontalEdge (hecke41GeometricKernelSquareSample k a ha B hB) R M)
      (squareFrameVerticalEdge (hecke41GeometricKernelSquareSample k a ha B hB) R M) 0 0 4 4).property
    (commonSquareKernelEdgeList (hecke41GeometricKernelSquareSample k a ha B hB) (squareFrameOuterRadius R) (2*M) PDE.CauchyContour.square).property
    (hecke41GeometricFiniteContour k a ha (squareFrameOuterRadius R) (Rat.le_trans hR hB) (2*M) (by omega) PDE.CauchyContour.square).property
    (commonOuterSquareContour_agreement _ R M hM)
    (hecke41GeometricCommonSquare_edge_list_agreement k a ha B (squareFrameOuterRadius R) hB hR (2*M) (by omega) PDE.CauchyContour.square)


theorem hecke41GeometricSquareContour_doubled_radius_difference_converges_zero
    (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : (squareFrameOuterRadius R).val≤
      (hecke41NomeGeometricRadius a ha).val) (eps : QPos) :
    ∃ N, ∀ n, N≤n → Small
      (sub (hecke41GeometricFiniteContour k a ha (squareFrameOuterRadius R) hR (2*(2^n))
        (by exact Nat.mul_pos (by decide +kernel) (Nat.pow_pos (by decide +kernel))) PDE.CauchyContour.square).val
        (hecke41GeometricFiniteContour k a ha R (Rat.le_trans (squareFrameRadius_le_outer R) hR) (2^n) (Nat.pow_pos (by decide +kernel)) PDE.CauchyContour.square).val) eps.val := by
  obtain ⟨N,hN⟩ := hecke41GeometricCommonFrameContourDifference_converges_zero k a ha R hR eps
  refine ⟨N, ?_⟩
  intro n hn
  have hp : 0<2^n := Nat.pow_pos (by decide +kernel)
  have ho := hecke41GeometricOuterSquareContour_agreement k a ha (squareFrameOuterRadius R) R
    hR (Rat.le_refl) (2^n) hp
  have hi := hecke41GeometricInnerSquareContour_agreement k a ha (squareFrameOuterRadius R) R
    hR (squareFrameRadius_le_outer R) (2^n) hp
  have he := FunctionTheory.sub_congr ho hi
  exact Small.congr (hecke41GeometricCommonFrameContourDifference k a ha R hR n).property
    (sub_valid (hecke41GeometricFiniteContour k a ha (squareFrameOuterRadius R) hR (2*(2^n))
      (by omega) PDE.CauchyContour.square).property
      (hecke41GeometricFiniteContour k a ha R (Rat.le_trans (squareFrameRadius_le_outer R) hR) (2^n) hp PDE.CauchyContour.square).property)
    he (hN n hn)


end ComputableAnalysis.ModularForms
