import ComputableAnalysis.ModularForms.Hecke41NomeHolomorphicDescent
import ComputableAnalysis.ModularForms.PairedRiccatiCauchyIntegrandAgreement
import ComputableAnalysis.RiemannHilbert.DomainHolomorphicIntersectionSum

/-! Actual Hecke coefficient Cauchy integrands on their genuine domains. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

def hecke41CenteredNomeMap (k : Nat) (a : Scalar) : DomainFunctions.Map :=
  DomainFunctions.compose (hecke41NomeDescended k 10000) (pairedCenterTranslationMap a)

def hecke41CenteredNomeMap_holomorphic (k : Nat) (a : Scalar) :
    Holomorphic (hecke41CenteredNomeMap k a) :=
  (hecke41NomeDescended_holomorphic k 10000).compose (pairedCenterTranslationMap_holomorphic a)

def hecke41CauchyIntegrandDomain (k : Nat) (a z : Scalar) : Prop :=
  (hecke41CenteredNomeMap k a).domain z ∧ pairedSquaredReciprocalMap.domain z

def hecke41CauchyIntegrandOpen (k : Nat) (a : Scalar) :
    ScalarTopology.OpenData (hecke41CauchyIntegrandDomain k a) :=
  intersectionOpenData (hecke41CenteredNomeMap_holomorphic k a)
    pairedSquaredReciprocalMap_holomorphic

def domainIntersectionProduct (f g : DomainFunctions.Map) : DomainFunctions.Map where
  domain z := f.domain z ∧ g.domain z
  eval z hz := scalarProduct (f.eval z hz.1) (g.eval z hz.2)
  domain_congr z w he := and_congr (f.domain_congr z w he) (g.domain_congr z w he)
  eval_congr z w hz hw he := mul_equiv (f.eval z hz.1).property (f.eval w hw.1).property
    (g.eval z hz.2).property (g.eval w hw.2).property
    (f.eval_congr z w hz.1 hw.1 he) (g.eval_congr z w hz.2 hw.2 he)

theorem domainIntersectionProduct_eval (f g : DomainFunctions.Map) (z : Scalar)
    (hz : f.domain z ∧ g.domain z) :
    ((domainIntersectionProduct f g).eval z hz).val = mul (f.eval z hz.1).val (g.eval z hz.2).val := rfl

def hecke41CauchyIntegrandMap (k : Nat) (a : Scalar) : DomainFunctions.Map :=
  domainIntersectionProduct (hecke41CenteredNomeMap k a) pairedSquaredReciprocalMap

def hecke41CauchyIntegrandMap_holomorphic (k : Nat) (a : Scalar) :
    Holomorphic (hecke41CauchyIntegrandMap k a) :=
  let ho := hecke41CauchyIntegrandOpen k a
  ((hecke41CenteredNomeMap_holomorphic k a).onDomain ho (fun _ h => h.1)).productOn
    (pairedSquaredReciprocalMap_holomorphic.onDomain ho (fun _ h => h.2)) (fun _ h => h)

theorem hecke41CauchyIntegrandMap_domain (k : Nat) (a z : Scalar) :
    (hecke41CauchyIntegrandMap k a).domain z ↔
      hecke41NomePuncturedDomain (Centered.translate a z) ∧ NonzeroBoxSearch.Nonzero z := by
  constructor
  · intro h
    have ht := (hecke41NomeDescended k 10000).domain_congr
      ((pairedCenterTranslationMap a).eval z trivial) (Centered.translate a z)
      (pairedCenterTranslationMap_eval a z)
    exact ⟨ht.1 (compose_outer_mem h.1),h.2⟩
  · intro h
    have ht := (hecke41NomeDescended k 10000).domain_congr
      ((pairedCenterTranslationMap a).eval z trivial) (Centered.translate a z)
      (pairedCenterTranslationMap_eval a z)
    exact ⟨⟨trivial,ht.2 h.1⟩,h.2⟩

end ComputableAnalysis.ModularForms
