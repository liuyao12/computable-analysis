import ComputableAnalysis.ModularForms.Hecke41ModularInvariance
import ComputableAnalysis.ModularForms.ActionHolomorphic

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

/-- Actual rational affine evaluator on the represented upper half-plane. -/
def rationalAffineMap (r b : Rat) : DomainFunctions.Map where
  domain z := InUpperHalfPlane z.val
  eval z _ := ⟨scaleRat r (translate b z.val), scaleRat_valid (translate_valid _ z.property)⟩
  domain_congr := upperOpenData.invariant
  eval_congr _ _ _ _ he := scaleRat_equiv (translate_equiv b he)

def rationalAffineMap_holomorphic (r b : Rat) : Holomorphic (rationalAffineMap r b) := by
  let offset : Scalar := ⟨scaleRat r (ofQComplex ⟨b,0⟩),scaleRat_valid (ofQComplex_valid _)⟩
  let slope : Scalar := ⟨scaleRat r (ofQComplex QComplex.one),scaleRat_valid (ofQComplex_valid _)⟩
  apply (DomainFunctions.affine_holomorphic offset slope).transfer (rationalAffineMap r b)
    (fun _ _ => trivial) ⟨upperRadius,upperRadius_inside⟩
  intro z hz
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := ((DomainFunctions.affine offset slope).eval z trivial).property)
    (hright := ((rationalAffineMap r b).eval z hz).property)
  change ComplexRawQuotient.scaleRat r (ComplexRawQuotient.ofQComplex ⟨b,0⟩) +
    ComplexRawQuotient.scaleRat r 1 * ComplexRawQuotient.ofRaw z.val z.property =
    ComplexRawQuotient.scaleRat r (ComplexRawQuotient.ofRaw z.val z.property + ComplexRawQuotient.ofQComplex ⟨b,0⟩)
  have hunit : (1 : ScalarAlgebra.Value)*ComplexRawQuotient.ofRaw z.val z.property =
      ComplexRawQuotient.ofRaw z.val z.property := by grind
  rw [← ComplexRawQuotient.scaleRat_mul, hunit, ← ComplexRawQuotient.scaleRat_add]
  congr 1
  exact ComplexRawQuotient.add_comm _ _

/-- The existing actual Hecke point evaluator as a domain-dependent map. -/
def hecke41PointMap (i : Fin 42) : DomainFunctions.Map where
  domain z := InUpperHalfPlane z.val
  eval z _ := hecke41Point i z
  domain_congr := upperOpenData.invariant
  eval_congr z w _ _ he := hecke41Point_congr i z w he

def hecke41PointMap_holomorphic (i : Fin 42) : Holomorphic (hecke41PointMap i) := by
  by_cases hi : i.val=41
  · apply (rationalAffineMap_holomorphic 41 0).transfer (hecke41PointMap i)
      (fun _ hz => hz) ⟨upperRadius,upperRadius_inside⟩
    intro z hz
    change (scaleRat 41 (translate 0 z.val)).Equiv (hecke41Point i z).val
    simp only [hecke41Point,if_pos hi]
    apply scaleRat_equiv
    exact add_zero_equiv z.val z.property
  · apply (rationalAffineMap_holomorphic (1/41) (i.val:Rat)).transfer (hecke41PointMap i)
      (fun _ hz => hz) ⟨upperRadius,upperRadius_inside⟩
    intro z hz
    simp only [hecke41PointMap,hecke41Point,if_neg hi,rationalAffineMap]
    exact equiv_refl _ (scaleRat_valid (translate_valid _ z.property))

/-- Actual j at each correspondence point, with its actual composition domain. -/
def hecke41JMap (i : Fin 42) : DomainFunctions.Map := compose latticeJMap (hecke41PointMap i)

def hecke41JMap_holomorphic (i : Fin 42) : Holomorphic (hecke41JMap i) :=
  latticeJMap_holomorphic.compose (hecke41PointMap_holomorphic i)

private def finiteDomainOpenData {n : Nat} (D : Fin n → Scalar → Prop)
    (hD : ∀ i, ScalarTopology.OpenData (D i)) :
    ScalarTopology.OpenData (fun z => ∀ i, D i z) := by
  induction n with
  | zero =>
      exact ScalarTopology.wholeData.congr (fun _ => ⟨fun _ i => Fin.elim0 i, fun _ => trivial⟩)
  | succ n ih =>
      apply ((hD 0).inter (ih (fun i => D i.succ) (fun i => hD i.succ))).congr
      intro z
      constructor
      · intro h i
        exact Fin.cases h.1 h.2 i
      · intro h
        exact ⟨h 0, fun i => h i.succ⟩

/-- Actual common domain of the entire degree-41 correspondence. -/
def hecke41CommonDomain (z : Scalar) : Prop :=
  InUpperHalfPlane z.val ∧ ∀ i, latticeJMap.domain (hecke41Point i z)

/-- A rational neighborhood radius for all actual correspondence evaluators. -/
def hecke41CommonDomain_openData : ScalarTopology.OpenData hecke41CommonDomain := by
  have hD (i : Fin 42) : ScalarTopology.OpenData (hecke41JMap i).domain :=
    ⟨(hecke41JMap i).domain_congr, (hecke41JMap_holomorphic i).openDomain.radius,
      (hecke41JMap_holomorphic i).openDomain.inside⟩
  apply (finiteDomainOpenData (fun i => (hecke41JMap i).domain) hD).congr
  intro z
  constructor
  · intro h
    exact ⟨(h 0).1,fun i => (h i).2⟩
  · intro h i
    exact ⟨h.1,h.2 i⟩

/-- Actual j evaluator restricted to the constructed common open domain. -/
def hecke41CommonJMap (i : Fin 42) : DomainFunctions.Map :=
  onDomain (hecke41JMap i) hecke41CommonDomain_openData.invariant (fun _ hz => ⟨hz.1,hz.2 i⟩)

def hecke41CommonJMap_holomorphic (i : Fin 42) : Holomorphic (hecke41CommonJMap i) :=
  (hecke41JMap_holomorphic i).onDomain hecke41CommonDomain_openData (fun _ hz => ⟨hz.1,hz.2 i⟩)

/-- Restriction keeps exactly the existing actual j value. -/
theorem hecke41CommonJMap_eval (i : Fin 42) (z : Scalar) (hz : hecke41CommonDomain z) :
    ((hecke41CommonJMap i).eval z hz).val.Equiv (hecke41JCert z hz.2 i).raw :=
  equiv_refl _ ((hecke41CommonJMap i).eval z hz).property

end ComputableAnalysis.ModularForms
