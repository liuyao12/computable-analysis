import ComputableAnalysis.ModularForms.CMJIsolationBounds163

namespace ComputableAnalysis.ModularForms

/-- Actual positive denominator for the interval substitution at the CM coordinate. -/
def cmJIsolationDenominator163 : RealRaw :=
  RealRaw.sub (RealRaw.ofRat (-144115188075854872)) cmJValue163.val.realPart

theorem cmJIsolationDenominator163_valid : cmJIsolationDenominator163.Valid :=
  RealRaw.sub_valid (RealRaw.ofRat_valid _) (ComplexRaw.realPart_valid cmJValue163.property)

/-- Quantitative denominator separation is proved from the actual CM estimate. -/
theorem cmJIsolationDenominator163_lower :
    (RealRaw.ofRat 255).Le cmJIsolationDenominator163 := by
  intro n m
  have h := cmJValue163_real_isolation_upper_margin m 0
  change (cmJValue163.val.realPart.compute m).lo≤(-144115188075855127:Rat) at h
  change (255:Rat)≤(-144115188075854872:Rat)-(cmJValue163.val.realPart.compute m).lo
  grind only

/-- A positive interval stage is obtained constructively from validity and the margin. -/
theorem cmJIsolationDenominator163_positive : cmJIsolationDenominator163.Pos := by
  obtain ⟨N,hN⟩ := cmJIsolationDenominator163_valid.2.2 (⟨1,by decide +kernel⟩ : QPos)
  have hw := hN N (Nat.le_refl N)
  have hl := cmJIsolationDenominator163_lower 0 N
  change (255:Rat)≤(cmJIsolationDenominator163.compute N).hi at hl
  unfold QInterval.width at hw
  refine ⟨N,?_⟩
  change 0<(cmJIsolationDenominator163.compute N).lo
  grind only

end ComputableAnalysis.ModularForms
