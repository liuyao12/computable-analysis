import ComputableAnalysis.ModularForms.CMJIsolation43
import ComputableAnalysis.ModularForms.CMHeckeDiagonal43
import ComputableAnalysis.ModularForms.ScalarNoZeroDivisors
import ComputableAnalysis.ModularForms.CMJModularOrbits

set_option maxRecDepth 8192

namespace ComputableAnalysis.ModularForms
open RiemannHilbert PackedIntegerPolynomialProduct

/-- The actual CM value is forced by the checked modular polynomial and
the independently constructed analytic isolation interval. -/
theorem cmJValue43_exact_class
    :
    ComplexRawQuotient.ofRaw cmJValue43.val cmJValue43.property=
      ((-(960:Int)^3):ScalarAlgebra.Value) := by
  let X := ComplexRawQuotient.ofRaw cmJValue43.val cmJValue43.property
  have hr := cmJValue43_candidate_diagonal_root
  have hc := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := (RepresentedPolynomial.eval (integerPolynomialEmbedding hecke41DiagonalCandidate)
      ⟨cmJValue43.val,cmJValue43.property⟩).valid)
    (hright := RepresentedPolynomial.zero.valid) hr
  change RepresentedPolynomial.certClass (RepresentedPolynomial.eval
    (integerPolynomialEmbedding hecke41DiagonalCandidate) ⟨cmJValue43.val,cmJValue43.property⟩)=0 at hc
  rw [integerPolynomialEmbedding_eval_class,hecke41Diagonal_factor_class43] at hc
  have hq := cmJValue43_quotient_nonzero
  have hd : X-((-(960:Int)^3):ScalarAlgebra.Value)=0 := by
    apply Classical.byContradiction
    intro hn
    have hs : (X-((-(960:Int)^3):ScalarAlgebra.Value))^2≠0 := by
      have hm := scalarClass_mul_nonzero _ _ hn hn
      have he : (X-((-(960:Int)^3):ScalarAlgebra.Value))^2=
          (X-((-(960:Int)^3):ScalarAlgebra.Value))*
            (X-((-(960:Int)^3):ScalarAlgebra.Value)) := by grind only
      rw [he]
      exact hm
    exact scalarClass_mul_nonzero _ _ hs hq hc
  change X=_
  grind only

end ComputableAnalysis.ModularForms

namespace ComputableAnalysis.ModularForms
open RiemannHilbert PackedIntegerPolynomialProduct

private theorem integerClass_constant (a : Int) :
    (a:ScalarAlgebra.Value)=ComplexRawQuotient.ofRaw (ComplexRaw.ofQComplex ⟨(a:Rat),0⟩)
      (ComplexRaw.ofQComplex_valid _) := by
  change ComplexRawQuotient.ofRaw (ComplexRaw.scaleRat (a:Rat) ComplexRaw.one)
    (ComplexRaw.scaleRat_valid (ComplexRaw.ofQComplex_valid _))=_
  apply ComplexRawQuotient.ofRaw_eq_ofRaw
  intro n
  apply (ComplexRaw.compareAt_overlap_iff _ _ n n).2
  change QBox.Overlaps (QBox.scaleRat (a:Rat) (QBox.point QComplex.one))
    (QBox.point ⟨(a:Rat),0⟩)
  unfold QBox.scaleRat
  split <;> simp [QBox.point,QComplex.one,QBox.Overlaps,QComplex.le_def,
    Rat.mul_one,Rat.mul_zero]

/-- Exact integer value of the actual modular function at the constructed
CM point, with all modular arithmetic and analytic evidence constructed internally. -/
theorem cmJValue43_exact_value
    :
    cmJValue43.val.Equiv (ComplexRaw.ofQComplex ⟨-((960:Rat)^3),0⟩) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := cmJValue43.property) (hright := ComplexRaw.ofQComplex_valid _)
  have hc := integerClass_constant (-(960:Int)^3)
  rw [show (Int.cast (-(960:Int)^3) : Rat)=-((960:Rat)^3) by decide +kernel] at hc
  have hclass := cmJValue43_exact_class
  have hcast : (Int.cast (-(960:Int)^3) : ScalarAlgebra.Value) =
      -((Int.cast (960:Int):ScalarAlgebra.Value)^3) := by grind only
  rw [hcast] at hc
  exact hclass.trans hc

end ComputableAnalysis.ModularForms

namespace ComputableAnalysis.ModularForms
open RiemannHilbert

theorem latticeJMap_cm43_equivalent_domain (z : Scalar) (hz : z.val.Equiv cmPoint43) :
    latticeJMap.domain z :=
  (latticeJMap.domain_congr z cmScalar43 hz).mpr (latticeJMap_global_domain _ cmPoint43_upper)

/-- The exact integer value applies to every equivalent valid represented name. -/
theorem latticeJMap_cm43_equivalent_value (z : Scalar) (hz : z.val.Equiv cmPoint43) :
    (latticeJMap.eval z (latticeJMap_cm43_equivalent_domain z hz)).val.Equiv
      (ComplexRaw.ofQComplex ⟨-((960:Rat)^3),0⟩) :=
  ComplexRaw.equiv_trans (latticeJMap.eval z (latticeJMap_cm43_equivalent_domain z hz)).property
    cmJValue43.property (ComplexRaw.ofQComplex_valid _)
    (latticeJMap.eval_congr z cmScalar43 _ _ hz) cmJValue43_exact_value

/-- The third exact CM integer also covers every represented modular transform. -/
theorem latticeJMap_cm43_orbit_equivalent_value (g : SL2Z) (z : Scalar)
    (hz : z.val.Equiv (fractionalLinear g cmScalar43 cmPoint43_upper).val) :
    (latticeJMap.eval z (latticeJMap_modular_orbit_equivalent_domain
      g cmScalar43 cmPoint43_upper z hz)).val.Equiv
      (ComplexRaw.ofQComplex ⟨-((960:Rat)^3),0⟩) :=
  ComplexRaw.equiv_trans
    (latticeJMap.eval z (latticeJMap_modular_orbit_equivalent_domain
      g cmScalar43 cmPoint43_upper z hz)).property cmJValue43.property (ComplexRaw.ofQComplex_valid _)
    (latticeJMap_modular_orbit_equivalent_value g cmScalar43 cmPoint43_upper z hz)
    cmJValue43_exact_value

end ComputableAnalysis.ModularForms
