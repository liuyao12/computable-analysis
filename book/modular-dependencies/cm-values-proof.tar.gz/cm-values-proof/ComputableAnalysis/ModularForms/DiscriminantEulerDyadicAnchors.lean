import ComputableAnalysis.ModularForms.DiscriminantEulerRadialHalving
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- Executable positive anchors approaching the radial origin. -/
def radialDyadicAnchor (b : Rat) (N : Nat) : Rat := b*(1/2)^N

theorem radialDyadicAnchor_pos (b : Rat) (hb : 0<b) (N : Nat) :
    0<radialDyadicAnchor b N := Rat.mul_pos hb (Rat.pow_pos (by decide +kernel))

theorem radialDyadicAnchor_le (b : Rat) (hb : 0<b) (N : Nat) :
    radialDyadicAnchor b N≤b := by
  have hp : (1/2:Rat)^N≤1 := by
    induction N with
    | zero => simp
    | succ N ih =>
      rw [Rat.pow_succ]
      have hn := Rat.pow_nonneg (n := N) (show (0:Rat)≤1/2 by decide +kernel)
      grind only
  have hm := Rat.mul_nonneg (Rat.le_of_lt hb) (show 0≤1-(1/2:Rat)^N by grind only)
  unfold radialDyadicAnchor
  grind only

theorem radialDyadicAnchor_shrinks (b : Rat) (hb : 0<b) :
    ShrinksToZero (radialDyadicAnchor b) := by
  have h := LocalODE.tail_bound_shrinks (b/4) (1/2)
    (show 0≤b/4 by grind only) (by decide +kernel) (by decide +kernel)
  intro eps
  obtain ⟨N,hN⟩ := h eps
  refine ⟨N,fun n hn => ?_⟩
  have hh := hN n hn
  unfold radialDyadicAnchor
  grind only

/-- Initial exact contraction with a constructed schedule, for arbitrary valid nome data. -/
theorem discriminantEulerRadial_dyadic_initial_halving
    (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R S b : Rat) (hR : 0<R) (hS : 0<S) (hb : 0<b)
    (hqr : Small q.val R) (hi : Small (RepresentedReciprocal.inverse q hq).val S)
    (hs : b*R≤(1:Rat)/65536) (hshort : 3072*(b*R)≤(1:Rat)/2) :
    ∃ hz : discriminantEulerDividedMap.domain (rationalScaledScalar b q),
      Small (discriminantEulerDividedMap.eval (rationalScaledScalar b q) hz).val
        ((21072*S*R*R*b)/2) :=
  discriminantEulerRadial_initial_halving q hq R S b hR hS hb hqr hi hs hshort
    (radialDyadicAnchor b) (radialDyadicAnchor_pos b hb)
    (radialDyadicAnchor_le b hb) (radialDyadicAnchor_shrinks b hb)
end ComputableAnalysis.ModularForms
