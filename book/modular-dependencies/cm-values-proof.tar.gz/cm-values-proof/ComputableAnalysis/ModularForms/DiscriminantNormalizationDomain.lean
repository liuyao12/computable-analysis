import ComputableAnalysis.ModularForms.NormalizedDiscriminantNonvanishing
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

/-- Geometric normalization reconstructs the actual lattice discriminant on the full upper plane. -/
theorem normalizedLatticeDiscriminantMap_normalization_product (z : Scalar) (hz : InUpperHalfPlane z.val) :
    (mul latticeDiscriminantNormalization.val (normalizedLatticeDiscriminantMap.eval z hz).val).Equiv
      (latticeDiscriminantMap.eval z hz).val := by
  let N := latticeDiscriminantNormalization
  let I := RepresentedReciprocal.inverse N latticeDiscriminantNormalization_nonzero
  let D := latticeDiscriminantMap.eval z hz
  have hi := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := mul_valid N.property I.property)
    (hright := ofQComplex_valid _) (RepresentedReciprocal.mul_inverse N latticeDiscriminantNormalization_nonzero)
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := mul_valid N.property (normalizedLatticeDiscriminantMap.eval z hz).property) (hright := D.property)
  let n := ComplexRawQuotient.ofRaw N.val N.property
  let i := ComplexRawQuotient.ofRaw I.val I.property
  let d := ComplexRawQuotient.ofRaw D.val D.property
  change n*i=1 at hi
  change n*(i*d)=d
  grind only

/-- Normalization preserves nonvanishing for every represented upper-half-plane input. -/
theorem normalizedLatticeDiscriminantMap_nonzero_iff (z : Scalar) (hz : InUpperHalfPlane z.val) :
    NonzeroBoxSearch.Nonzero (normalizedLatticeDiscriminantMap.eval z hz) ↔
      NonzeroBoxSearch.Nonzero (latticeDiscriminantMap.eval z hz) := by
  constructor
  · intro hn
    let D := normalizedLatticeDiscriminantMap.eval z hz
    let P : Scalar := ⟨mul latticeDiscriminantNormalization.val D.val,
      mul_valid latticeDiscriminantNormalization.property D.property⟩
    have hp : NonzeroBoxSearch.Nonzero P :=
      scalar_mul_nonzero latticeDiscriminantNormalization D latticeDiscriminantNormalization_nonzero hn
    exact (NonzeroBoxSearch.nonzero_congr P (latticeDiscriminantMap.eval z hz)
      (normalizedLatticeDiscriminantMap_normalization_product z hz)).mp hp
  · intro hn
    exact scalar_mul_nonzero
      (RepresentedReciprocal.inverse latticeDiscriminantNormalization latticeDiscriminantNormalization_nonzero)
      (latticeDiscriminantMap.eval z hz)
      (RepresentedReciprocal.inverse_nonzero latticeDiscriminantNormalization latticeDiscriminantNormalization_nonzero) hn

/-- Reciprocal normalization is exact wherever the actual lattice discriminant is nonzero. -/
theorem normalizedLatticeDiscriminantMap_inverse (z : Scalar) (hz : InUpperHalfPlane z.val)
    (hn : NonzeroBoxSearch.Nonzero (latticeDiscriminantMap.eval z hz)) :
    (RepresentedReciprocal.inverse (normalizedLatticeDiscriminantMap.eval z hz)
      ((normalizedLatticeDiscriminantMap_nonzero_iff z hz).mpr hn)).val.Equiv
      (mul latticeDiscriminantNormalization.val
        (RepresentedReciprocal.inverse (latticeDiscriminantMap.eval z hz) hn).val) := by
  let D := latticeDiscriminantMap.eval z hz
  let E := normalizedLatticeDiscriminantMap.eval z hz
  let N := latticeDiscriminantNormalization
  let I := RepresentedReciprocal.inverse D hn
  let P : Scalar := ⟨mul N.val I.val,mul_valid N.property I.property⟩
  apply RepresentedReciprocal.inverse_unique E ((normalizedLatticeDiscriminantMap_nonzero_iff z hz).mpr hn) P
  have hN := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := mul_valid N.property E.property)
    (hright := D.property) (normalizedLatticeDiscriminantMap_normalization_product z hz)
  have hi := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := mul_valid D.property I.property)
    (hright := ofQComplex_valid _) (RepresentedReciprocal.mul_inverse D hn)
  apply ComplexRawQuotient.equiv_of_ofRaw_eq (hleft := mul_valid E.property P.property) (hright := ofQComplex_valid _)
  let n := ComplexRawQuotient.ofRaw N.val N.property
  let e := ComplexRawQuotient.ofRaw E.val E.property
  let d := ComplexRawQuotient.ofRaw D.val D.property
  let i := ComplexRawQuotient.ofRaw I.val I.property
  change n*e=d at hN
  change d*i=1 at hi
  change e*(n*i)=(1:ScalarAlgebra.Value)
  grind only
end ComputableAnalysis.ModularForms
