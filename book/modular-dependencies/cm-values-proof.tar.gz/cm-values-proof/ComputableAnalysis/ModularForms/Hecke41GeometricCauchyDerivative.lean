import ComputableAnalysis.ModularForms.Hecke41GeometricContourLimit
import ComputableAnalysis.ModularForms.Hecke41NormalizedCauchyDerivative

/-! Normalized Cauchy derivative estimates at geometric nome radii. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem hecke41GeometricContourLimit_normalized_derivative (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeGeometricRadius a ha).val) :
    (scalarProduct (hecke41GeometricContourLimit k a ha R)
      cauchyNormalizationScalar).val.Equiv
      ((hecke41NomeDescended_holomorphic k 10000).derivative a ha).val := by
  let d := (hecke41NomeDescended_holomorphic k 10000).derivative a ha
  have he := mul_equiv (hecke41GeometricContourLimit k a ha R).property
    (scalarProduct d ⟨twoPiI,twoPiI_valid⟩).property
    cauchyNormalizationScalar.property cauchyNormalizationScalar.property
    (hecke41GeometricContourLimit_cauchy_derivative k a ha R)
    (equiv_refl _ cauchyNormalizationScalar.property)
  exact equiv_trans (scalarProduct (hecke41GeometricContourLimit k a ha R)
    cauchyNormalizationScalar).property
    (scalarProduct (scalarProduct d ⟨twoPiI,twoPiI_valid⟩) cauchyNormalizationScalar).property
    d.property he (suppliedDerivative_normalization d)

theorem hecke41NomeDerivative_geometric_cauchy_bound (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeGeometricRadius a ha).val) :
    Small ((hecke41NomeDescended_holomorphic k 10000).derivative a ha).val
      (2*(64*(2*(2:Rat)^10000)*(1/R.val))*scalarBound cauchyNormalizationScalar) := by
  have hB : 0≤64*(2*(2:Rat)^10000)*(1/R.val) := by
    have hi : 0≤1/R.val := by rw [Rat.div_def,Rat.one_mul]; exact Rat.le_of_lt (Rat.inv_pos.mpr R.property)
    exact Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel)
      (Rat.mul_nonneg (by decide +kernel) (Rat.pow_nonneg (by decide +kernel)))) hi
  have hb := Small.mul (hecke41GeometricContourLimit k a ha R).property
    cauchyNormalizationScalar.property hB (Rat.le_of_lt (scalarBound_pos _))
    (hecke41GeometricContourLimit_bound k a ha R hR) (scalar_small cauchyNormalizationScalar)
  exact Small.congr (scalarProduct (hecke41GeometricContourLimit k a ha R)
      cauchyNormalizationScalar).property
    ((hecke41NomeDescended_holomorphic k 10000).derivative a ha).property
    (hecke41GeometricContourLimit_normalized_derivative k a ha R hR) hb

end ComputableAnalysis.ModularForms
