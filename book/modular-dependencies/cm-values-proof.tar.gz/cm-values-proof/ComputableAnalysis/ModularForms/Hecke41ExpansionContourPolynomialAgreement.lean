import ComputableAnalysis.ModularForms.Hecke41CoefficientContourPolynomial

/-! Exact identification of the actual finite expansion contour with its coefficient polynomial. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem normalizedScalarGrid_zero (f : Nat → Scalar) (M : Nat) (r : Rat)
    (hf : ∀ j, (f j).val.Equiv zero) :
    (normalizedScalarGrid f M r).val.Equiv zero := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (normalizedScalarGrid f M r).property) (hright := ofQComplex_valid _)
  change ComplexRawQuotient.scaleRat r (gridScalarValue (gridScalarSum M f))=0
  rw [gridScalarSum_value]
  have he : (fun j => gridScalarValue (f j))=(fun _ => (0:ScalarAlgebra.Value)) := by
    funext j
    exact ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := (f j).property) (hright := ofQComplex_valid _) (hf j)
  rw [he,gridValueSum_zero]
  exact ComplexRawQuotient.scaleRat_zero r

private theorem orient_zero (upper : Bool) (x : Scalar) (hx : x.val.Equiv zero) :
    (if upper then x else scalarNeg x).val.Equiv zero := by
  have h := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := x.property) (hright := ofQComplex_valid _) hx
  change gridScalarValue x=0 at h
  cases upper
  · apply ComplexRawQuotient.equiv_of_ofRaw_eq (hleft := (scalarNeg x).property) (hright := ofQComplex_valid _)
    change -gridScalarValue x=0
    rw [h]
    grind only
  · exact hx

theorem hecke41ShiftedPoleExpansionEdgeAverage_zero (k : Nat) (a b : Scalar)
    (ha : hecke41NomePuncturedDomain a) (S : QPos)
    (hg : S.val≤(hecke41NomeGeometricRadius a ha).val)
    (edge : HalfEdge) (M : Nat) (hM : 0<M) :
    (hecke41ShiftedPoleExpansionEdgeAverage k a b ha S hg edge M hM 0).val.Equiv zero := by
  apply normalizedScalarGrid_zero
  intro j
  let x := hecke41ShiftedPoleExpansionGridSample k a b ha S hg edge M hM 0 j
  let d := rationalRectangleScalar (QComplex.scaleRat S.val (velocity edge))
  have hu := squareMidpointParameter_unit M (j%M) hM (Nat.mod_lt j hM)
  have hx : x.val.Equiv zero := hecke41ShiftedPoleExpansionSample_polynomial_agreement k a b ha S hg edge
    (squareMidpointParameter M (j%M)) hu.1 hu.2 0
  have hm := mul_equiv x.property (ofQComplex_valid _) d.property d.property hx (equiv_refl d.val d.property)
  exact equiv_trans (scalarProduct x d).property (mul_valid (ofQComplex_valid _) d.property)
    (ofQComplex_valid _) hm (zero_mul_equiv d.val d.property)

theorem hecke41ShiftedPoleExpansionFiniteContour_zero (k : Nat) (a b : Scalar)
    (ha : hecke41NomePuncturedDomain a) (S : QPos)
    (hg : S.val≤(hecke41NomeGeometricRadius a ha).val)
    (M : Nat) (hM : 0<M) (es : List HalfEdge) :
    (hecke41ShiftedPoleExpansionFiniteContour k a b ha S hg M hM 0 es).val.Equiv zero := by
  induction es with
  | nil => exact equiv_refl _ (ofQComplex_valid _)
  | cons e es ih =>
    let x := hecke41ShiftedPoleExpansionEdgeAverage k a b ha S hg e M hM 0
    have hx := orient_zero e.upper x (hecke41ShiftedPoleExpansionEdgeAverage_zero k a b ha S hg e M hM)
    have hs := add_equiv hx ih
    exact equiv_trans (hecke41ShiftedPoleExpansionFiniteContour k a b ha S hg M hM 0 (e::es)).property
      (add_valid (ofQComplex_valid _) (ofQComplex_valid _)) (ofQComplex_valid _) hs
      (zero_add_equiv zero (ofQComplex_valid _))

theorem hecke41ShiftedPoleExpansionFiniteContour_polynomial_agreement (k : Nat) (a b : Scalar)
    (ha : hecke41NomePuncturedDomain a) (S : QPos)
    (hg : S.val≤(hecke41NomeGeometricRadius a ha).val)
    (M : Nat) (hM : 0<M) (es : List HalfEdge) (n : Nat) :
    (hecke41ShiftedPoleExpansionFiniteContour k a b ha S hg M hM n es).val.Equiv
      (hecke41FiniteCoefficientContourPolynomial k a b ha S hg M hM es n).val := by
  induction n with
  | zero => exact hecke41ShiftedPoleExpansionFiniteContour_zero k a b ha S hg M hM es
  | succ n ih =>
    let x := hecke41ShiftedPoleExpansionFiniteContour k a b ha S hg M hM n es
    let y := hecke41FiniteCoefficientContourPolynomial k a b ha S hg M hM es n
    let t := scalarProduct ⟨LocalODE.power b.val n,LocalODE.power_valid _ b.property n⟩
      (hecke41ReciprocalCoefficientFiniteContour k a ha S hg M hM n es)
    exact equiv_trans (hecke41ShiftedPoleExpansionFiniteContour k a b ha S hg M hM (n+1) es).property
      (scalarSum x t).property (scalarSum y t).property
      (hecke41ShiftedPoleExpansionFiniteContour_coefficient_recurrence k a b ha S hg M hM n es)
      (add_equiv ih (equiv_refl t.val t.property))

end ComputableAnalysis.ModularForms
