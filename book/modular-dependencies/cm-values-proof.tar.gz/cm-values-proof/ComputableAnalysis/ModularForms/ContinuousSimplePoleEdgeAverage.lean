import ComputableAnalysis.ModularForms.ContinuousSimplePoleDensity
import ComputableAnalysis.ModularForms.NormalizedGridDifference

namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

/-- Actual executable midpoint density, with domain evidence constructed on the square edge. -/
def continuousSimplePoleGridDensity (f : DomainFunctions.Map) (hop : OpenDomain f)
    (a : Scalar) (ha : f.domain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val ≤ (hop.radius a ha).val) (M : Nat) (hM : 0 < M) (j : Nat) : Scalar :=
  let u := squareMidpointParameter M (j%M)
  let hu := squareMidpointParameter_unit M (j%M) hM (Nat.mod_lt j hM)
  let z := Centered.translate a (rationalRectangleScalar (QComplex.scaleRat R.val (point edge u)))
  let hz := openDomain_square_edge_mem f hop a ha edge R hR u hu.1 hu.2
  scalarProduct (f.eval z hz) (rationalRectangleScalar (simplePolePullback edge R.val u))

/-- The actual normalized finite edge quadrature has the same error bound as
its pointwise density comparison, uniformly in every positive midpoint count. -/
theorem continuousSimplePoleEdgeAverage_central_error (f : DomainFunctions.Map)
    (hop : OpenDomain f) (hf : ContinuousOn f.domain f.eval) (a : Scalar) (ha : f.domain a)
    (edge : HalfEdge) (R eps : QPos) (hR : R.val ≤ (hop.radius a ha).val)
    (hcont : R.val ≤ (hf.delta a ha (halfError eps)).val) (M : Nat) (hM : 0 < M) :
    Small (sub
      (scaleRat ((M:Rat)⁻¹) (gridScalarSum M (continuousSimplePoleGridDensity f hop a ha edge R hR M hM)).val)
      (scaleRat ((M:Rat)⁻¹) (gridScalarSum M (fun j => scalarProduct (f.eval a ha)
        (rationalRectangleScalar (simplePolePullback edge R.val (squareMidpointParameter M (j%M)))))).val)) eps.val := by
  apply normalizedGridDifference_bound _ _ M hM eps.val (Rat.le_of_lt eps.property)
  intro j _
  let u := squareMidpointParameter M (j%M)
  let hu := squareMidpointParameter_unit M (j%M) hM (Nat.mod_lt j hM)
  exact continuousSimplePoleDensity_central_error f hf a ha edge R eps hcont u hu.1 hu.2
    (openDomain_square_edge_mem f hop a ha edge R hR u hu.1 hu.2)

end ComputableAnalysis.ModularForms
