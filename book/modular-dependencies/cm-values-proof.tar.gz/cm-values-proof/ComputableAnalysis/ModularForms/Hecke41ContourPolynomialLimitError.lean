import ComputableAnalysis.ModularForms.RepresentedPolynomialLimitTail
import ComputableAnalysis.ModularForms.Hecke41ContourPolynomialGeometricTail
import ComputableAnalysis.ModularForms.Hecke41ContourPolynomialConvergence

/-! Explicit finite-prefix error for the actual shifted contour value. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem hecke41CoefficientContourPolynomial_limit_error (k : Nat) (a b : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R B S : QPos)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (hRS : R.val≤S.val) (hSB : S.val≤B.val)
    (r : Rat) (hr : 0≤r) (hR : r<R.val) (hb : Small b.val r) (hsmall : 8*r≤S.val)
    (hd : S.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val)
    (es : List HalfEdge) (m : Nat) :
    Small (sub (hecke41ShiftedPoleContourLimit k a b ha R B S hB hRS hSB r hR hb hd es).val
      (hecke41CoefficientContourPolynomial k a b ha S (Rat.le_trans hSB hB) hd es m).val)
      (2*hecke41PolynomialTermBound es*((1:Rat)/2)^m) :=
  representedSequenceLimit_tail_bound
    (fun n => hecke41CoefficientContourPolynomial k a b ha S (Rat.le_trans hSB hB) hd es n) _
    (hecke41CoefficientContourPolynomial_converges_to_shifted_contour k a b ha R B S
      hB hRS hSB r hr hR hb hsmall hd es) m _
    (hecke41CoefficientContourPolynomial_half_tail_bound k a b ha S (Rat.le_trans hSB hB)
      hd r hr hb hsmall es m)

end ComputableAnalysis.ModularForms
