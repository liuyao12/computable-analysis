import ComputableAnalysis.ModularForms.Hecke41Points
import ComputableAnalysis.ModularForms.CMOrderConjugation163

/-! Explicit modular transformations and denominator norms for the CM degree-41 points. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert

/-- Three literal transformations raise the finite CM correspondence points;
    the dilation point already has large imaginary part. -/
def cmHeckeReduction41 (i : Fin 42) : SL2Z :=
  if i.val=41 then SL2Z.identity else
    if i.val<15 then SL2Z.S else
      if i.val<26 then ⟨1,-1,2,-1,by decide +kernel⟩ else
        ⟨0,-1,1,-1,by decide +kernel⟩

/-- Clearing the denominator 41 gives an element of the actual CM order. -/
def cmHeckeDenominatorOrder41 (i : Fin 41) : QuadraticOrder163 :=
  let g := cmHeckeReduction41 ⟨i.val,by omega⟩
  ⟨g.c*(i.val:Int)+41*g.d,g.c⟩

/-- Exact finite bounds on the cleared norms, including the worst two points. -/
theorem cmHeckeDenominatorOrder41_norm_bounds : ∀ i : Fin 41,
    41≤QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i) ∧
      QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i)≤263 := by
  decide +kernel

/-- The largest cleared norm occurs at residue 15 and its reflected residue 25. -/
theorem cmHeckeDenominatorOrder41_norm_maximum : ∀ i : Fin 41,
    QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i)=263 ↔
      i.val=15 ∨ i.val=25 := by
  decide +kernel

/-- Each literal finite point has the stated actual CM-order denominator after clearing 41. -/
theorem cmHeckeDenominatorOrder41_agreement (i : Fin 41) :
    (scaleRat 41 (integerAffine (cmHeckeReduction41 ⟨i.val,by omega⟩).c
      (cmHeckeReduction41 ⟨i.val,by omega⟩).d
      (hecke41Point ⟨i.val,by omega⟩ cmScalar163).val)).Equiv
        (cmHeckeDenominatorOrder41 i).complexRaw := by
  let g := cmHeckeReduction41 ⟨i.val,by omega⟩
  have hi : i.val≠41 := by omega
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := scaleRat_valid (integerAffine_valid g.c g.d
      (hecke41Point ⟨i.val,by omega⟩ cmScalar163).property))
    (hright := (cmHeckeDenominatorOrder41 i).complexRaw_valid)
  rw [ComplexRawQuotient.ofRaw_scaleRat,integerAffine_class]
  simp only [hecke41Point,if_neg hi]
  rw [ComplexRawQuotient.ofRaw_scaleRat]
  unfold translate
  rw [ComplexRawQuotient.ofRaw_add]
  change ComplexRawQuotient.scaleRat 41
    ((g.c:ScalarAlgebra.Value)*ComplexRawQuotient.scaleRat (1/41)
      (cmPoint163Value+ComplexRawQuotient.ofQComplex ⟨(i.val:Rat),0⟩)+
      (g.d:ScalarAlgebra.Value))=(cmHeckeDenominatorOrder41 i).complexValue
  rw [QuadraticOrder163.complexValue_formula]
  have hc := integer_constant (i.val:Int)
  rw [show ((i.val:Int):Rat)=(i.val:Rat) by rfl] at hc
  rw [hc]
  change ComplexRawQuotient.scaleRat 41
    ((g.c:ScalarAlgebra.Value)*ComplexRawQuotient.scaleRat (1/41)
      (cmPoint163Value+(i.val:Int))+ (g.d:ScalarAlgebra.Value))=
    ((g.c*(i.val:Int)+41*g.d:Int):ScalarAlgebra.Value)+
      (g.c:ScalarAlgebra.Value)*cmPoint163Value
  rw [ComplexRawQuotient.scaleRat_add,←ComplexRawQuotient.mul_scaleRat,
    ComplexRawQuotient.scaleRat_scaleRat,
    show (41:Rat)*(1/41)=1 by decide +kernel,ComplexRawQuotient.scaleRat_one,
    ←show ((41:Nat):Rat)=(41:Rat) by decide +kernel,ScalarAlgebra.scale_natural 41]
  grind
  · exact translate_valid _ cmPoint163_valid
  · exact integerAffine_valid _ _ (hecke41Point ⟨i.val,by omega⟩ cmScalar163).property

/-- The norm is the actual conjugate product of each cleared represented denominator. -/
theorem cmHeckeDenominatorOrder41_norm_product (i : Fin 41) :
    let g := cmHeckeReduction41 ⟨i.val,by omega⟩
    let d := scaleRat 41 (integerAffine g.c g.d
      (hecke41Point ⟨i.val,by omega⟩ cmScalar163).val)
    (mul d (conj d)).Equiv
      (ofQComplex ⟨(QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat),0⟩) := by
  let u := cmHeckeDenominatorOrder41 i
  let g := cmHeckeReduction41 ⟨i.val,by omega⟩
  let d := scaleRat 41 (integerAffine g.c g.d
    (hecke41Point ⟨i.val,by omega⟩ cmScalar163).val)
  have hd : d.Valid := scaleRat_valid (integerAffine_valid _ _
    (hecke41Point ⟨i.val,by omega⟩ cmScalar163).property)
  have he := cmHeckeDenominatorOrder41_agreement i
  exact equiv_trans (mul_valid hd (conj_valid _ hd))
    (mul_valid u.complexRaw_valid (conj_valid _ u.complexRaw_valid)) (ofQComplex_valid _)
    (mul_equiv hd u.complexRaw_valid (conj_valid _ hd)
      (conj_valid _ u.complexRaw_valid) he (conj_equiv he))
    (QuadraticOrder163.complexRaw_norm_product u)

end ComputableAnalysis.ModularForms
