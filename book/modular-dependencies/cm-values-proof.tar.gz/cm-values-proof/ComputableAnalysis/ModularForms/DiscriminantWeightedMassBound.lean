import ComputableAnalysis.ModularForms.PackedWeightedCoefficientMass
import ComputableAnalysis.ModularForms.PackedDiscriminantAgreement
import ComputableAnalysis.ModularForms.FiniteUnsignedEulerBound

namespace ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct

private theorem rat_one_power (n : Nat) : (1:Rat)^n=1 := by
  induction n with
  | zero => rw [Rat.pow_zero]
  | succ n ih => rw [Rat.pow_succ,ih,Rat.one_mul]

private theorem rat_product_power (a b : Rat) (k : Nat) :
    (a*b)^k=a^k*b^k := by
  induction k with
  | zero => simp [Rat.pow_zero,Rat.one_mul]
  | succ k ih => simp only [Rat.pow_succ,ih]; grind only

private theorem rat_power_mono (a b : Rat) (ha : 0≤a) (hab : a≤b) (k : Nat) :
    a^k≤b^k := by
  induction k with
  | zero => rw [Rat.pow_zero,Rat.pow_zero]; exact Rat.le_refl
  | succ k ih =>
    rw [Rat.pow_succ,Rat.pow_succ]
    exact rat_mul_le_mul_of_nonneg (nonneg_radius_power a ha k) ih ha hab

theorem discriminantList_weightedMass_bound (r : Rat) (hr : 0≤r) (N m : Nat) :
    weightedMass r (discriminantList N m)≤(unsignedEulerProduct r m)^24 := by
  induction m with
  | zero =>
    change (1:Rat)+r*0≤1^24
    rw [Rat.mul_zero,Rat.add_zero]
    decide +kernel
  | succ m ih =>
    have h := factorPowerList_weightedMass r hr (m+1) N 24 (discriminantList N m)
    have hf : 0≤(1+r^(m+1))^24 :=
      nonneg_radius_power _ (by have h := nonneg_radius_power r hr (m+1); grind only) 24
    have ht := Rat.mul_le_mul_of_nonneg_left ih hf
    change weightedMass r (factorPowerList (m+1) N 24 (discriminantList N m))≤_
    rw [unsignedEulerProduct,rat_product_power]
    exact Rat.le_trans h ht

/-- The discriminant prefix has uniformly bounded weighted absolute mass. -/
theorem discriminantList_quarterMass_bound (N m : Nat) :
    weightedMass (1/4) (discriminantList N m)≤(3/2:Rat)^24 := by
  have hr : (0:Rat)≤1/4 := by decide +kernel
  exact Rat.le_trans (discriminantList_weightedMass_bound (1/4) hr N m)
    (rat_power_mono _ _ (unsignedEulerProduct_nonneg (1/4) hr m)
      (unsignedEulerProduct_quarter_bound m) 24)

/-- Each actual finite discriminant coefficient has a cutoff-independent
weighted bound, justified by the literal finite Euler product. -/
theorem discriminantProduct_quarter_bound (m n : Nat) :
    ((discriminantProduct m n).natAbs:Rat)*(1/4:Rat)^n≤(3/2:Rat)^24 := by
  have hr : (0:Rat)≤1/4 := by decide +kernel
  have h := coefficient_weightedMass_bound (1/4) hr (discriminantList (n+1) m) n
  rw [discriminantList_agreement (n+1) m n (by omega)] at h
  exact Rat.le_trans h (discriminantList_quarterMass_bound (n+1) m)

/-- An explicit coefficient bound whose exponent depends on the queried
degree rather than on the finite product cutoff. -/
theorem discriminantProduct_degree_bound (m n : Nat) :
    ((discriminantProduct m n).natAbs:Rat)≤(3/2:Rat)^24*(4:Rat)^n := by
  have h := discriminantProduct_quarter_bound m n
  have h4 : (0:Rat)≤4 := by decide +kernel
  have ht := Rat.mul_le_mul_of_nonneg_right h (nonneg_radius_power 4 h4 n)
  have hq : (1/4:Rat)*4=1 := by decide +kernel
  have he : (1/4:Rat)^n*(4:Rat)^n=1 := by
    rw [←rat_product_power,hq]
    exact rat_one_power n
  calc
    ((discriminantProduct m n).natAbs:Rat) =
        (((discriminantProduct m n).natAbs:Rat)*(1/4:Rat)^n)*(4:Rat)^n := by
      rw [Rat.mul_assoc,he,Rat.mul_one]
    _ ≤ (3/2:Rat)^24*(4:Rat)^n := ht

end ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct
