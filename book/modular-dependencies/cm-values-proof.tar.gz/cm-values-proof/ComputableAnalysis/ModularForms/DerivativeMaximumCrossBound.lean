import ComputableAnalysis.ModularForms.DerivativeSymmetricMaximumBound
import ComputableAnalysis.ModularForms.MaximumRemainderShrink

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

/-- At a genuine translated domain point, the derivative cross term is bounded
by the actual remainder error whenever the squared magnitude does not increase. -/
theorem derivative_maximum_cross_bound (f : DomainFunctions.Map) (a d w : Scalar)
    (ha : f.domain a) (hf : HasDerivativeAt f a ha d) (eps H : QPos)
    (hH : H.val ≤ (hf.delta eps).val) (hw : Small w.val H.val)
    (hp : f.domain (Centered.translate a w))
    (hmax : (mul (f.eval (Centered.translate a w) hp).val
      (conj (f.eval (Centered.translate a w) hp).val)).realPart.Le
        (mul (f.eval a ha).val (conj (f.eval a ha).val)).realPart) :
    let A := f.eval a ha
    let b := scalarProduct d w
    let B := scalarBound A+2*scalarBound d*H.val
    let E := eps.val*H.val
    (add (mul A.val (conj b.val)) (mul b.val (conj A.val))).realPart.Le
      (RealRaw.ofRat (2*E*(B+E)+2*B*E)) := by
  let A := f.eval a ha
  let b := scalarProduct d w
  let B := scalarBound A+2*scalarBound d*H.val
  let E := eps.val*H.val
  have hb : Small b.val (2*scalarBound d*H.val) := Small.mul d.property w.property
    (Rat.le_of_lt (scalarBound_pos d)) (Rat.le_of_lt H.property) (scalar_small d) hw
  have hmodel : Small (add A.val b.val) B := LocalODE.small_add (scalar_small A) hb
  have herr := translatedAffineModel_error f a d w ha hf eps H hH hp hw
  have hB : 0 ≤ B := by
    have h1 := scalarBound_pos A
    have h2 := Rat.mul_nonneg (Rat.mul_nonneg (show (0:Rat) ≤ 2 by decide +kernel)
      (Rat.le_of_lt (scalarBound_pos d))) (Rat.le_of_lt H.property)
    dsimp [B]; grind only
  exact scalar_perturbed_maximum_cross_bound A b (f.eval (Centered.translate a w) hp)
    B E hB (Rat.mul_nonneg (Rat.le_of_lt eps.property) (Rat.le_of_lt H.property))
    hmodel herr hmax

end ComputableAnalysis.ModularForms
