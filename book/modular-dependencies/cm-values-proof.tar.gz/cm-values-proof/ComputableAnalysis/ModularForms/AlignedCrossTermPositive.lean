import ComputableAnalysis.ModularForms.AffineMaximumCrossTerm
import ComputableAnalysis.ModularForms.RealComplexBridge

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- Positive represented real factors have a positive actual product, witnessed at a common rational stage. -/
theorem real_mul_positive (x y : RealRaw) (hx : x.Valid) (hy : y.Valid)
    (hxp : x.Pos) (hyp : y.Pos) : (RealRaw.mul x y).Pos := by
  obtain ⟨N,hN⟩ := hxp
  obtain ⟨M,hM⟩ := hyp
  let K := max N M
  have hxn := hx.2.1 N K (Nat.le_max_left _ _)
  have hyn := hy.2.1 M K (Nat.le_max_right _ _)
  have hxl : 0 < (x.compute K).lo := by grind only
  have hyl : 0 < (y.compute K).lo := by grind only
  have hm := QBox.mulRealInterval_of_nonneg (Rat.le_of_lt hxl)
    (RealRaw.interval_order_of_valid _ hx K) (Rat.le_of_lt hyl)
    (RealRaw.interval_order_of_valid _ hy K)
  refine ⟨K,?_⟩
  change 0 < (QBox.mulRealInterval (x.compute K).lo (x.compute K).hi
    (y.compute K).lo (y.compute K).hi).lo
  rw [hm]
  exact Rat.mul_pos hxl hyl

/-- The product of actual squared norms of two nonzero represented values is strictly positive. -/
theorem scalar_squared_norm_product_positive (a d : Scalar)
    (ha : NonzeroBoxSearch.Nonzero a) (hd : NonzeroBoxSearch.Nonzero d) :
    (mul (mul a.val (conj a.val)) (mul d.val (conj d.val))).realPart.Pos := by
  let A : Scalar := ⟨mul a.val (conj a.val),mul_valid a.property (conj_valid _ a.property)⟩
  let D : Scalar := ⟨mul d.val (conj d.val),mul_valid d.property (conj_valid _ d.property)⟩
  have hx := realPart_valid A.property
  have hy := realPart_valid D.property
  have hp := real_mul_positive A.val.realPart D.val.realPart hx hy
    (norm_product_real_positive a ha) (norm_product_real_positive d hd)
  have he := mul_equiv A.property (ofRealRaw_valid _ hx) D.property (ofRealRaw_valid _ hy)
    (equiv_real_embedding A (norm_product_imag_zero a))
    (equiv_real_embedding D (norm_product_imag_zero d))
  have hb := real_embedding_mul A.val.realPart D.val.realPart hx hy
  have htotal := equiv_trans (mul_valid A.property D.property)
    (mul_valid (ofRealRaw_valid _ hx) (ofRealRaw_valid _ hy))
    (ofRealRaw_valid _ (RealRaw.mul_valid hx hy)) he hb
  exact positive_of_equiv (RealRaw.mul_valid hx hy) (realPart_valid (mul_valid A.property D.property))
    (RealRaw.equiv_symm (realPart_equiv htotal)) hp

/-- The derivative-aligned first-order cross term is positive whenever both the value and derivative are nonzero. -/
theorem scalar_derivative_aligned_cross_positive (a d : Scalar)
    (ha : NonzeroBoxSearch.Nonzero a) (hd : NonzeroBoxSearch.Nonzero d) :
    let b := mul d.val (mul (conj d.val) a.val)
    (add (mul a.val (conj b)) (mul b (conj a.val))).realPart.Pos := by
  let P : Scalar := ⟨mul (mul a.val (conj a.val)) (mul d.val (conj d.val)),
    mul_valid (mul_valid a.property (conj_valid _ a.property)) (mul_valid d.property (conj_valid _ d.property))⟩
  obtain ⟨N,hN⟩ := scalar_squared_norm_product_positive a d ha hd
  have hsum : (add P.val P.val).realPart.Pos := by
    refine ⟨N,?_⟩
    change 0 < (P.val.compute N).lo.re + (P.val.compute N).lo.re
    change 0 < (P.val.compute N).lo.re at hN
    grind only
  let b : Scalar := ⟨mul d.val (mul (conj d.val) a.val),
    mul_valid d.property (mul_valid (conj_valid _ d.property) a.property)⟩
  exact positive_of_equiv (realPart_valid (add_valid P.property P.property))
    (realPart_valid (add_valid (mul_valid a.property (conj_valid _ b.property))
      (mul_valid b.property (conj_valid _ a.property))))
    (RealRaw.equiv_symm (realPart_equiv (scalar_derivative_aligned_cross_identity a d))) hsum

/-- Strict positivity supplies a positive rational lower margin for the actual aligned cross term. -/
theorem scalar_derivative_aligned_cross_margin (a d : Scalar)
    (ha : NonzeroBoxSearch.Nonzero a) (hd : NonzeroBoxSearch.Nonzero d) :
    let b := mul d.val (mul (conj d.val) a.val)
    ∃ L : QPos, (RealRaw.ofRat L.val).Le (add (mul a.val (conj b)) (mul b (conj a.val))).realPart := by
  let b : Scalar := ⟨mul d.val (mul (conj d.val) a.val),
    mul_valid d.property (mul_valid (conj_valid _ d.property) a.property)⟩
  let C : Scalar := ⟨add (mul a.val (conj b.val)) (mul b.val (conj a.val)),
    add_valid (mul_valid a.property (conj_valid _ b.property)) (mul_valid b.property (conj_valid _ a.property))⟩
  obtain ⟨N,hN⟩ := scalar_derivative_aligned_cross_positive a d ha hd
  refine ⟨⟨(C.val.compute N).lo.re,hN⟩,?_⟩
  intro i j
  exact RealRaw.le_refl C.val.realPart (realPart_valid C.property) N j

end ComputableAnalysis.ModularForms
