import ComputableAnalysis.ModularForms.TauLambertDividedMap
import ComputableAnalysis.ModularForms.DiscriminantEulerRegularizedEquation
import ComputableAnalysis.RiemannHilbert.ReciprocalHolomorphic
import ComputableAnalysis.RiemannHilbert.DomainHolomorphicIntersectionSum
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
private noncomputable def puncturedOpen := intersectionOpenData ReciprocalHolomorphic.holomorphic
  discriminantEulerDifferenceMap_holomorphic
private def puncturedReciprocalMap : DomainFunctions.Map :=
  onDomain ReciprocalHolomorphic.function puncturedOpen.invariant (fun _ h => h.1)
private noncomputable def puncturedReciprocalMap_holomorphic : Holomorphic puncturedReciprocalMap :=
  ReciprocalHolomorphic.holomorphic.onDomain puncturedOpen (fun _ h => h.1)
/-- Actual divided discrepancy on the justified nonzero nome domain. -/
def discriminantEulerDividedMap : DomainFunctions.Map :=
  productOn puncturedReciprocalMap discriminantEulerDifferenceMap (fun _ h => h.2)
noncomputable def discriminantEulerDividedMap_holomorphic : Holomorphic discriminantEulerDividedMap :=
  puncturedReciprocalMap_holomorphic.productOn discriminantEulerDifferenceMap_holomorphic (fun _ h => h.2)
/-- Multiplication by the nome recovers the actual discrepancy exactly. -/
theorem discriminantEulerDividedMap_recovery (q : Scalar) (hq : discriminantEulerDividedMap.domain q) :
    (mul q.val (discriminantEulerDividedMap.eval q hq).val).Equiv
      (discriminantEulerDifferenceMap.eval q hq.2).val := by
  let I := RepresentedReciprocal.inverse q hq.1
  let H := discriminantEulerDifferenceMap.eval q hq.2
  have hh := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := mul_valid q.property I.property)
    (hright := ofQComplex_valid _) (RepresentedReciprocal.mul_inverse q hq.1)
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := mul_valid q.property (discriminantEulerDividedMap.eval q hq).property) (hright := H.property)
  let z := ComplexRawQuotient.ofRaw q.val q.property
  let i := ComplexRawQuotient.ofRaw I.val I.property
  let h := ComplexRawQuotient.ofRaw H.val H.property
  change z*i=1 at hh
  change z*(i*h)=h
  grind only
/-- The actual divided discrepancy satisfies its theta equation on the punctured disk. -/
theorem discriminantEulerDividedMap_theta (q : Scalar) (hq : discriminantEulerDividedMap.domain q) :
    (mul q.val (discriminantEulerDividedMap_holomorphic.derivative q hq).val).Equiv
      (scaleRat (-24) (mul (tauLambertValue q hq.2).val (discriminantEulerDividedMap.eval q hq).val)) := by
  let I := RepresentedReciprocal.inverse q hq.1
  let H := discriminantEulerDifferenceMap.eval q hq.2
  let D := discriminantEulerDifferenceMap_holomorphic.derivative q hq.2
  let L := tauLambertValue q hq.2
  have hi := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := mul_valid q.property I.property)
    (hright := ofQComplex_valid _) (RepresentedReciprocal.mul_inverse q hq.1)
  have hh := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := sub_valid (mul_valid q.property D.property) H.property)
    (hright := scaleRat_valid (mul_valid L.property H.property))
    (discriminantEulerDifferenceMap_regularized q hq.2)
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := mul_valid q.property (discriminantEulerDividedMap_holomorphic.derivative q hq).property)
    (hright := scaleRat_valid (mul_valid L.property (discriminantEulerDividedMap.eval q hq).property))
  let z := ComplexRawQuotient.ofRaw q.val q.property
  let i := ComplexRawQuotient.ofRaw I.val I.property
  let h := ComplexRawQuotient.ofRaw H.val H.property
  let d := ComplexRawQuotient.ofRaw D.val D.property
  let l := ComplexRawQuotient.ofRaw L.val L.property
  change z*i=1 at hi
  change z*d-h=ComplexRawQuotient.scaleRat (-24) (l*h) at hh
  change z*((-(i*i))*h+i*d)=ComplexRawQuotient.scaleRat (-24) (l*(i*h))
  have lin (x : ComplexRawQuotient.Value) : ComplexRawQuotient.scaleRat (-24) x=
      ComplexRawQuotient.scaleRat (-24) 1*x := by
    rw [←ComplexRawQuotient.scaleRat_mul]; congr 1; grind only
  rw [lin] at hh
  rw [lin]
  have ht := congrArg (fun x : ComplexRawQuotient.Value => i*x) hh
  grind only
/-- Exact homogeneous differential equation with its constructed punctured coefficient. -/
theorem discriminantEulerDividedMap_differential (q : Scalar) (hq : discriminantEulerDividedMap.domain q) :
    (discriminantEulerDividedMap_holomorphic.derivative q hq).val.Equiv
      (scaleRat (-24) (mul (mul (RepresentedReciprocal.inverse q hq.1).val (tauLambertValue q hq.2).val)
        (discriminantEulerDividedMap.eval q hq).val)) := by
  let I := RepresentedReciprocal.inverse q hq.1
  let L := tauLambertValue q hq.2
  let K := discriminantEulerDividedMap.eval q hq
  let D := discriminantEulerDividedMap_holomorphic.derivative q hq
  have hi := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := mul_valid q.property I.property)
    (hright := ofQComplex_valid _) (RepresentedReciprocal.mul_inverse q hq.1)
  have ht := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := mul_valid q.property D.property)
    (hright := scaleRat_valid (mul_valid L.property K.property)) (discriminantEulerDividedMap_theta q hq)
  apply ComplexRawQuotient.equiv_of_ofRaw_eq (hleft := D.property)
    (hright := scaleRat_valid (mul_valid (mul_valid I.property L.property) K.property))
  let z := ComplexRawQuotient.ofRaw q.val q.property
  let i := ComplexRawQuotient.ofRaw I.val I.property
  let l := ComplexRawQuotient.ofRaw L.val L.property
  let k := ComplexRawQuotient.ofRaw K.val K.property
  let d := ComplexRawQuotient.ofRaw D.val D.property
  change z*i=1 at hi
  change z*d=ComplexRawQuotient.scaleRat (-24) (l*k) at ht
  change d=ComplexRawQuotient.scaleRat (-24) ((i*l)*k)
  have hs := congrArg (fun x : ComplexRawQuotient.Value => i*x) ht
  rw [ComplexRawQuotient.mul_scaleRat (-24) i (l*k)] at hs
  have hleft : i*(z*d)=d := by grind only
  rw [hleft] at hs
  have he : i*(l*k)=(i*l)*k := by grind only
  rw [he] at hs
  exact hs
/-- The homogeneous equation uses the actual holomorphic divided Lambert coefficient. -/
theorem discriminantEulerDividedMap_coefficient (q : Scalar) (hq : discriminantEulerDividedMap.domain q) :
    (discriminantEulerDividedMap_holomorphic.derivative q hq).val.Equiv
      (scaleRat (-24) (mul (tauLambertDividedMap.eval q hq).val
        (discriminantEulerDividedMap.eval q hq).val)) :=
  discriminantEulerDividedMap_differential q hq
end ComputableAnalysis.ModularForms
