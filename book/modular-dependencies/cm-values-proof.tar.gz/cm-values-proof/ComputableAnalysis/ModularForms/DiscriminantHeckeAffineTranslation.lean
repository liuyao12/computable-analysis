import ComputableAnalysis.ModularForms.DiscriminantHeckeTranslationTerms
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
set_option maxHeartbeats 2000000
private def termValue (p : Nat) (hp : 0<(p:Rat)) (N : Nat) (z : Scalar)
    (hz : InUpperHalfPlane z.val) : Scalar :=
  (discriminantAffinePullback (1/(p:Rat)) (N:Rat) (by
    rw [Rat.div_def,Rat.one_mul]; exact Rat.inv_pos.mpr hp)).eval z hz
private def termClass (p : Nat) (hp : 0<(p:Rat)) (N : Nat) (z : Scalar)
    (hz : InUpperHalfPlane z.val) : ComplexRawQuotient.Value :=
  ComplexRawQuotient.ofRaw (termValue p hp N z hz).val (termValue p hp N z hz).property
private def prefixClass (p : Nat) (hp : 0<(p:Rat)) (N : Nat) (z : Scalar)
    (hz : InUpperHalfPlane z.val) : ComplexRawQuotient.Value :=
  ComplexRawQuotient.ofRaw ((discriminantHeckeAffineSum p hp N).eval z hz).val
    ((discriminantHeckeAffineSum p hp N).eval z hz).property
private theorem prefix_zero (p : Nat) (hp : 0<(p:Rat)) (z : Scalar) (hz : InUpperHalfPlane z.val) :
    prefixClass p hp 0 z hz=0 :=
  ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := ((discriminantHeckeAffineSum p hp 0).eval z hz).property)
    (hright := ofQComplex_valid _) (discriminantHeckeAffineSum_zero p hp z hz)
private theorem prefix_succ (p : Nat) (hp : 0<(p:Rat)) (N : Nat) (z : Scalar)
    (hz : InUpperHalfPlane z.val) :
    prefixClass p hp (N+1) z hz=prefixClass p hp N z hz+termClass p hp N z hz :=
  ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := ((discriminantHeckeAffineSum p hp (N+1)).eval z hz).property)
    (hright := add_valid ((discriminantHeckeAffineSum p hp N).eval z hz).property (termValue p hp N z hz).property)
    (discriminantHeckeAffineSum_succ p hp N z hz)
private theorem term_translate (p : Nat) (hp : 0<(p:Rat)) (N : Nat) (z : Scalar)
    (hz : InUpperHalfPlane z.val) :
    termClass p hp N ⟨translate 1 z.val,translate_valid _ z.property⟩ (translate_mem _ hz)=
      termClass p hp (N+1) z hz := by
  have hh := discriminantAffinePullback_translate_one (1/(p:Rat)) (N:Rat) (by
    rw [Rat.div_def,Rat.one_mul]; exact Rat.inv_pos.mpr hp) z hz
  have hc : ((N+1:Nat):Rat)=(N:Rat)+1 := by
    simp only [Rat.natCast_add,show ((1:Nat):Rat)=1 by decide +kernel]
  apply ComplexRawQuotient.ofRaw_eq_ofRaw
  change (termValue p hp N ⟨translate 1 z.val,translate_valid _ z.property⟩ (translate_mem _ hz)).val.Equiv
    (termValue p hp (N+1) z hz).val
  unfold termValue
  rw [hc]
  exact hh
private theorem prefix_translate_telescope (p : Nat) (hp : 0<(p:Rat)) (N : Nat)
    (z : Scalar) (hz : InUpperHalfPlane z.val) :
    prefixClass p hp N ⟨translate 1 z.val,translate_valid _ z.property⟩ (translate_mem _ hz)+termClass p hp 0 z hz=
      prefixClass p hp N z hz+termClass p hp N z hz := by
  induction N with
  | zero => rw [prefix_zero,prefix_zero]
  | succ N ih =>
    rw [prefix_succ,prefix_succ,term_translate p hp N z hz]
    grind only
/-- Translation cycles the actual finite affine Hecke sum, at every represented upper-half-plane input. -/
theorem discriminantHeckeAffineSum_translate_one (p : Nat) (hp : 0<(p:Rat))
    (z : Scalar) (hz : InUpperHalfPlane z.val) :
    ((discriminantHeckeAffineSum p hp p).eval ⟨translate 1 z.val,translate_valid _ z.property⟩
      (translate_mem _ hz)).val.Equiv ((discriminantHeckeAffineSum p hp p).eval z hz).val := by
  have ht := prefix_translate_telescope p hp p z hz
  have hw := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := (termValue p hp p z hz).property)
    (hright := (termValue p hp 0 z hz).property) (discriminantHeckeAffine_wrap p hp z hz)
  change termClass p hp p z hz=termClass p hp 0 z hz at hw
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := ((discriminantHeckeAffineSum p hp p).eval ⟨translate 1 z.val,translate_valid _ z.property⟩
      (translate_mem _ hz)).property)
    (hright := ((discriminantHeckeAffineSum p hp p).eval z hz).property)
  change prefixClass p hp p ⟨translate 1 z.val,translate_valid _ z.property⟩ (translate_mem _ hz)=prefixClass p hp p z hz
  rw [hw] at ht
  grind only
end ComputableAnalysis.ModularForms
