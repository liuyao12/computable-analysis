import ComputableAnalysis.ModularForms.IntegerCauchyDiagonal
import ComputableAnalysis.RiemannHilbert.SeriesProductTails

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- Actual finite triangular product, before taking any series limit. -/
def representedProductTriangle (f g : Nat → ComplexRaw) (N : Nat) : ComplexRaw :=
  ScalarSeries.block (fun i => ScalarSeries.block (fun j => mul (f i) (g j)) 0 (N-i)) 0 N

theorem representedProductTriangle_valid (f g : Nat → ComplexRaw)
    (hf : ∀ i, (f i).Valid) (hg : ∀ j, (g j).Valid) (N : Nat) :
    (representedProductTriangle f g N).Valid :=
  ScalarSeries.block_valid _ (fun i => ScalarSeries.block_valid _
    (fun j => mul_valid (hf i) (hg j)) 0 (N-i)) 0 N

private theorem triangle_image (f g : Nat → ComplexRaw)
    (hf : ∀ i, (f i).Valid) (hg : ∀ j, (g j).Valid) (N : Nat) :
    ComplexRawQuotient.ofRaw (representedProductTriangle f g N)
      (representedProductTriangle_valid f g hf hg N) =
      FiniteProducts.triangle (fun i => ComplexRawQuotient.ofRaw (f i) (hf i))
        (fun j => ComplexRawQuotient.ofRaw (g j) (hg j)) N := by
  unfold representedProductTriangle
  rw [ScalarSeries.prefix_image _ (fun i => ScalarSeries.block_valid _
    (fun j => mul_valid (hf i) (hg j)) 0 (N-i)) N]
  apply FiniteProducts.prefix_congr
  intro i hi
  rw [ScalarSeries.prefix_image _ (fun j => mul_valid (hf i) (hg j)) (N-i)]
  have he := FiniteProducts.prefix_congr
    (fun j => ComplexRawQuotient.ofRaw (mul (f i) (g j)) (mul_valid (hf i) (hg j)))
    (fun j => ComplexRawQuotient.ofRaw (g j) (hg j)*ComplexRawQuotient.ofRaw (f i) (hf i))
    (N-i) (fun j hj => by
      change ComplexRawQuotient.ofRaw (f i) (hf i)*ComplexRawQuotient.ofRaw (g j) (hg j)=
        ComplexRawQuotient.ofRaw (g j) (hg j)*ComplexRawQuotient.ofRaw (f i) (hf i)
      grind only)
  rw [he,FiniteProducts.prefix_mul]
  grind only

/-- The difference between a rectangular prefix product and its degree
triangle is exactly the omitted product region. -/
theorem representedProductTriangle_remainder (f g : Nat → ComplexRaw)
    (hf : ∀ i, (f i).Valid) (hg : ∀ j, (g j).Valid) (N : Nat) :
    (sub (mul (ScalarSeries.block f 0 N) (ScalarSeries.block g 0 N))
      (representedProductTriangle f g N)).Equiv (ScalarSeries.missing f g N) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := sub_valid (mul_valid (ScalarSeries.block_valid f hf 0 N)
      (ScalarSeries.block_valid g hg 0 N)) (representedProductTriangle_valid f g hf hg N))
    (hright := ScalarSeries.missing_valid f g hf hg N)
  change (ComplexRawQuotient.ofRaw (ScalarSeries.block f 0 N) (ScalarSeries.block_valid f hf 0 N)*
    ComplexRawQuotient.ofRaw (ScalarSeries.block g 0 N) (ScalarSeries.block_valid g hg 0 N))-
      ComplexRawQuotient.ofRaw (representedProductTriangle f g N)
        (representedProductTriangle_valid f g hf hg N)=_
  rw [ScalarSeries.prefix_image f hf N,ScalarSeries.prefix_image g hg N,triangle_image f g hf hg N,
    ScalarSeries.missing_image f g hf hg N,FiniteProducts.rectangular_triangle]
  grind only

/-- An explicit geometric estimate for the actual omitted product region. -/
theorem representedProductTriangle_remainder_bound (f g : Nat → ComplexRaw)
    (hf : ∀ i, (f i).Valid) (hg : ∀ j, (g j).Valid) (C D s : Rat)
    (hC : 0≤C) (hD : 0≤D) (hs : 0≤s) (hlocal : s≤(1:Rat)/2)
    (hfb : ∀ n, Small (f n) (2*C*s^n)) (hgb : ∀ n, Small (g n) (2*D*s^n)) (N : Nat) :
    Small (sub (mul (ScalarSeries.block f 0 N) (ScalarSeries.block g 0 N))
      (representedProductTriangle f g N)) (32*C*D*(4*s)^N) :=
  Small.congr (ScalarSeries.missing_valid f g hf hg N)
    (sub_valid (mul_valid (ScalarSeries.block_valid f hf 0 N) (ScalarSeries.block_valid g hg 0 N))
      (representedProductTriangle_valid f g hf hg N))
    (equiv_symm (representedProductTriangle_remainder f g hf hg N))
    (ScalarSeries.missing_bound f g hf hg C D s hC hD hs hlocal hfb hgb N)

/-- A finite integer-prefix product has an explicit error against its Cauchy
coefficient prefix, proved from supplied monomial majorants. -/
theorem integerSeriesProduct_prefix_remainder_bound (a b : Coefficients) (q : Scalar)
    (C D s : Rat) (hC : 0≤C) (hD : 0≤D) (hs : 0≤s) (hlocal : s≤(1:Rat)/2)
    (hfb : ∀ n, Small (scaleRat (b n:Rat) (LocalODE.power q.val n)) (2*C*s^n))
    (hgb : ∀ n, Small (scaleRat (a n:Rat) (LocalODE.power q.val n)) (2*D*s^n)) (N : Nat) :
    Small (sub (mul (integerCoefficientPrefix b q N).val (integerCoefficientPrefix a q N).val)
      (integerCoefficientPrefix (integerSeriesProduct a b) q N).val) (32*C*D*(4*s)^N) := by
  let f := fun n => scaleRat (b n:Rat) (LocalODE.power q.val n)
  let g := fun n => scaleRat (a n:Rat) (LocalODE.power q.val n)
  have hf (n : Nat) : (f n).Valid := scaleRat_valid (LocalODE.power_valid _ q.property n)
  have hg (n : Nat) : (g n).Valid := scaleRat_valid (LocalODE.power_valid _ q.property n)
  have h := representedProductTriangle_remainder_bound f g hf hg C D s hC hD hs hlocal hfb hgb N
  have hp := mul_equiv (integerCoefficientPrefix b q N).property (ScalarSeries.block_valid f hf 0 N)
    (integerCoefficientPrefix a q N).property (ScalarSeries.block_valid g hg 0 N)
    (integerCoefficientPrefix_scalarBlock b q N) (integerCoefficientPrefix_scalarBlock a q N)
  have he := FunctionTheory.sub_congr (equiv_symm hp) (integerSeriesProduct_represented_triangle a b q N)
  exact Small.congr
    (sub_valid (mul_valid (ScalarSeries.block_valid f hf 0 N) (ScalarSeries.block_valid g hg 0 N))
      (representedProductTriangle_valid f g hf hg N))
    (sub_valid (mul_valid (integerCoefficientPrefix b q N).property (integerCoefficientPrefix a q N).property)
      (integerCoefficientPrefix _ q N).property) he h

end ComputableAnalysis.ModularForms
