import ComputableAnalysis.ModularForms.Hecke41GeometricContourConvergence

/-! Executable contour values with proved convergence on geometric radii. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def hecke41GeometricContourShrinkingCount (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos) : Nat :=
  RationalMajorant.natRateStage R.val (hecke41NomeDerivativeNeighborhood k 10000 a ha)

def hecke41GeometricContourSmallRadius (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos) : QPos :=
  squareShrinkingRadius R (hecke41GeometricContourShrinkingCount k a ha R)

theorem hecke41GeometricContourSmallRadius_le (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos) :
    (hecke41GeometricContourSmallRadius k a ha R).val≤
      (hecke41NomeDerivativeNeighborhood k 10000 a ha).val := by
  let j := hecke41GeometricContourShrinkingCount k a ha R
  change (squareShrinkingRadius R j).val≤_
  rw [squareShrinkingRadius_value]
  have hb := Rat.mul_le_mul_of_nonneg_left (RationalMajorant.half_pow_le_one_div_succ j)
    (Rat.le_of_lt R.property)
  have he : R.val*(1/((j+1:Nat):Rat))=R.val/((j+1:Nat):Rat) := by
    rw [Rat.div_def,Rat.div_def,Rat.one_mul]
  rw [he] at hb
  exact Rat.le_trans hb (RationalMajorant.natRateStage_spec_of_le
    (Rat.le_of_lt R.property) (hecke41NomeDerivativeNeighborhood k 10000 a ha) (Nat.le_refl j))

def hecke41GeometricContourLimit (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos) : Scalar :=
  hecke41DyadicKernelContourLimit k a ha (hecke41GeometricContourSmallRadius k a ha R)
    (hecke41GeometricContourSmallRadius_le k a ha R) PDE.CauchyContour.square

theorem hecke41GeometricContourLimit_converges (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeGeometricRadius a ha).val) (eps : QPos) :
    ∃ N, ∀ n, N≤n → Small (sub (hecke41GeometricContourLimit k a ha R).val
      (hecke41GeometricDyadicContour k a ha R hR n).val) eps.val :=
  hecke41GeometricContour_converges_small_limit k a ha R hR
    (hecke41GeometricContourShrinkingCount k a ha R) (hecke41GeometricContourSmallRadius_le k a ha R) eps

theorem hecke41GeometricContourLimit_cauchy_derivative (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos) :
    (hecke41GeometricContourLimit k a ha R).val.Equiv
      (scalarProduct ((hecke41NomeDescended_holomorphic k 10000).derivative a ha)
        ⟨twoPiI,twoPiI_valid⟩).val :=
  hecke41ContourLimit_cauchy_derivative k a ha (hecke41GeometricContourSmallRadius k a ha R)
    (hecke41GeometricContourSmallRadius_le k a ha R)

theorem hecke41GeometricContourLimit_bound (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeGeometricRadius a ha).val) :
    Small (hecke41GeometricContourLimit k a ha R).val
      (64*(2*(2:Rat)^10000)*(1/R.val)) := by
  apply convergentScalar_bound (hecke41GeometricContourLimit k a ha R)
    (hecke41GeometricDyadicContour k a ha R hR)
  · intro n
    have hb := hecke41GeometricFiniteContour_bound k a ha R (2^n)
      (Nat.pow_pos (by decide +kernel)) hR PDE.CauchyContour.square
    have he (C D : Rat) : 8*(8*C*D)=64*C*D := by grind only
    change Small (hecke41GeometricDyadicContour k a ha R hR n).val
      ((8:Nat)* (8*(2*(2:Rat)^10000)*(1/R.val))) at hb
    have h8 : ((8:Nat):Rat)=8 := by decide +kernel
    rw [h8,he] at hb
    exact hb
  · exact hecke41GeometricContourLimit_converges k a ha R hR

end ComputableAnalysis.ModularForms
