import ComputableAnalysis.ModularForms.RealExponentialReciprocalBound
import ComputableAnalysis.ModularForms.NomeGrowthRadius
import ComputableAnalysis.ModularForms.NomeHeightGrowthLowerBound

/-! Sharper actual heights at finite CM degree-41 correspondence points. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

private theorem sharp_height_coefficient_bounds : ∀ i : Fin 41,
    let t : Rat := 41*((QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹)/2
    0≤t ∧ (2091:Rat)/2104≤t*(51/4) := by
  decide +kernel

/-- A uniform exact lower height bound for every transformed finite CM Hecke point. -/
theorem cmHeckePoint41_height_lower_sharp (i : Fin 41) :
    let g := cmHeckeReduction41 ⟨i.val,by omega⟩
    let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
    (RealRaw.ofRat (2091/2104)).Le
      (fractionalLinear g z (hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper)).val.imagPart := by
  let g := cmHeckeReduction41 ⟨i.val,by omega⟩
  let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
  let w := fractionalLinear g z (hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper)
  let t : Rat := 41*((QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹)/2
  have ht := sharp_height_coefficient_bounds i
  have hpos : 0≤t := ht.1
  have hl : (RealRaw.ofRat (2091/2104)).Le (RealRaw.scaleRat t sqrt163) := by
    intro n m
    have hs := sqrt163_lower_fiftyOne_quarters 0 m
    change (51/4:Rat)≤(sqrt163.compute m).hi at hs
    have hb := Rat.mul_le_mul_of_nonneg_left hs ht.1
    change (2091/2104:Rat)≤((RealRaw.scaleRat t sqrt163).compute m).hi
    simp only [RealRaw.scaleRat,RealRaw.scaleRatCompute,if_pos hpos]
    exact Rat.le_trans ht.2 hb
  have he : (RealRaw.scaleRat t sqrt163).Le w.val.imagPart :=
    RealRaw.le_of_equiv (RealRaw.scaleRat_valid sqrt163_valid) (imagPart_valid w.property)
      (RealRaw.equiv_symm (cmHeckePoint41_imaginary i))
  exact RealRaw.le_trans (RealRaw.scaleRat_valid sqrt163_valid) hl he


/-- A kernel-checked factorial-series box gives an actual exponential lower bound at 6.24. -/
theorem entireExponential_rational_sixPointTwoFour_lower :
    (RealRaw.ofRat 512).Le
      (entireExponentialValue ⟨ofQComplex ⟨156/25,0⟩,ofQComplex_valid _⟩).val.realPart := by
  let f := ComplexExponentialApproximation.exponentialRawAt ⟨156/25,0⟩ (156/25)
  have hz : QComplex.normBound (⟨156/25,0⟩ : QComplex)≤(156/25:Rat) := by decide +kernel
  have hf : f.Valid := ComplexExponentialApproximation.exponentialRawAt_valid (by decide +kernel) hz
  have hbox : (512:Rat)≤(f.compute 4).lo.re := by decide +kernel
  have hl : (RealRaw.ofRat 512).Le f.realPart := by
    intro n m
    have h := RealRaw.le_refl f.realPart (realPart_valid hf) 4 m
    change (512:Rat)≤(f.compute m).hi.re
    exact Rat.le_trans hbox h
  have he := realPart_equiv (entireExponential_legacy_rational ⟨156/25,0⟩ (156/25) (by decide +kernel) hz)
  exact RealRaw.le_trans (realPart_valid hf) hl
    (RealRaw.le_of_equiv (realPart_valid hf) (realPart_valid (entireExponentialValue _).property)
      (RealRaw.equiv_symm he))

/-- Sharper growth lower bound from the exact denominator norm maximum. -/
theorem cmHeckePoint41_nomeGrowth_lower_sharp (i : Fin 41) :
    let g := cmHeckeReduction41 ⟨i.val,by omega⟩
    let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
    let w := fractionalLinear g z (hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper)
    (RealRaw.ofRat (328287/52600)).Le (nomeHeightGrowth w) := by
  have h := nomeHeightGrowth_lower _ (2091/2104) (by decide +kernel) (cmHeckePoint41_height_lower_sharp i)
  rw [show (4:Rat)*(157/100)*(2091/2104)=328287/52600 by decide +kernel] at h
  exact h

/-- The actual growth exponential is at least 512 at every transformed finite correspondence point. -/
theorem cmHeckePoint41_growthExponential_lower_sharp (i : Fin 41) :
    let g := cmHeckeReduction41 ⟨i.val,by omega⟩
    let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
    let w := fractionalLinear g z (hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper)
    (RealRaw.ofRat 512).Le
      (entireExponentialValue ⟨ofRealRaw (nomeHeightGrowth w),ofRealRaw_valid _ (nomeHeightGrowth_valid w)⟩).val.realPart := by
  have hb := cmHeckePoint41_nomeGrowth_lower_sharp i
  rw [←show (156/25:Rat)+63/52600=328287/52600 by decide +kernel] at hb
  have hm := entireExponential_real_strict_lower_comparison _ (nomeHeightGrowth_valid _)
    (156/25) (63/52600) (by decide +kernel) (by decide +kernel) hb
  exact RealRaw.le_trans (realPart_valid (entireExponentialValue _).property)
    entireExponential_rational_sixPointTwoFour_lower hm

/-- The actual nome radius improves to one over 512 at every transformed finite correspondence point. -/
theorem cmHeckePoint41_nome_small_sharp (i : Fin 41) :
    let g := cmHeckeReduction41 ⟨i.val,by omega⟩
    let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
    let w := fractionalLinear g z (hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper)
    Small (nome.eval w (fractionalLinear_mem g z
      (hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper))).val (1/512) :=
  nome_small_of_growth_exponential_lower _ _ 512 (by decide +kernel)
    (cmHeckePoint41_growthExponential_lower_sharp i)

end ComputableAnalysis.ModularForms
