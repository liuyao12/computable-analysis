import ComputableAnalysis.ModularForms.Hecke41OffCenterSideComparison

/-! Finite oriented four-side boundary assembly and error addition. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def fourSideBoundary (bottom right top left : Scalar) : Scalar :=
  scalarSum (gridScalarSub bottom top) (gridScalarSub right left)

theorem frameScalarRectBoundary_four_sides (H V : Nat → Nat → Scalar) (m n : Nat) :
    (frameScalarRectBoundary H V 0 0 m n).val.Equiv
      (fourSideBoundary (gridScalarSum m (fun j => H j 0)) (gridScalarSum n (fun j => V m j))
        (gridScalarSum m (fun j => H j n)) (gridScalarSum n (fun j => V 0 j))).val := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (frameScalarRectBoundary H V 0 0 m n).property)
    (hright := (fourSideBoundary _ _ _ _).property)
  change gridScalarValue (frameScalarRectBoundary H V 0 0 m n)=gridScalarValue (fourSideBoundary _ _ _ _)
  simp only [frameScalarRectBoundary,gridScalarBoundary,fourSideBoundary,
    gridScalarValue_add,gridScalarValue_sub,gridScalarSum_value,gridValueSum_sub,Nat.zero_add]

theorem fourSideBoundary_difference_bound (b r t l B R T L : Scalar) (eb er et el : Rat)
    (hb : Small (sub b.val B.val) eb) (hr : Small (sub r.val R.val) er)
    (ht : Small (sub t.val T.val) et) (hl : Small (sub l.val L.val) el) :
    Small (sub (fourSideBoundary b r t l).val (fourSideBoundary B R T L).val)
      ((eb+et)+(er+el)) := by
  have hs := LocalODE.small_add
    (LocalODE.small_add hb (SeriesLimitLaws.small_neg ht))
    (LocalODE.small_add hr (SeriesLimitLaws.small_neg hl))
  have he : (add (add (sub b.val B.val) (neg (sub t.val T.val)))
      (add (sub r.val R.val) (neg (sub l.val L.val)))).Equiv
      (sub (fourSideBoundary b r t l).val (fourSideBoundary B R T L).val) := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := add_valid (add_valid (sub_valid b.property B.property) (neg_valid (sub_valid t.property T.property)))
        (add_valid (sub_valid r.property R.property) (neg_valid (sub_valid l.property L.property))))
      (hright := sub_valid (fourSideBoundary b r t l).property (fourSideBoundary B R T L).property)
    let bv := gridScalarValue b
    let rv := gridScalarValue r
    let tv := gridScalarValue t
    let lv := gridScalarValue l
    let BV := gridScalarValue B
    let RV := gridScalarValue R
    let TV := gridScalarValue T
    let LV := gridScalarValue L
    change ((bv-BV)+ -(tv-TV))+((rv-RV)+ -(lv-LV))=
      ((bv-tv)+(rv-lv))-((BV-TV)+(RV-LV))
    grind only
  exact Small.congr
    (add_valid (add_valid (sub_valid b.property B.property) (neg_valid (sub_valid t.property T.property)))
      (add_valid (sub_valid r.property R.property) (neg_valid (sub_valid l.property L.property))))
    (sub_valid (fourSideBoundary b r t l).property (fourSideBoundary B R T L).property) he hs

end ComputableAnalysis.ModularForms
