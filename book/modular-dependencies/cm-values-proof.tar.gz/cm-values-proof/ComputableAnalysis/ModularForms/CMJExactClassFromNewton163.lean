import ComputableAnalysis.ModularForms.ScalarNoZeroDivisors
import ComputableAnalysis.ModularForms.CMJQuotientNonvanishing163
import ComputableAnalysis.ModularForms.Hecke41DiagonalFactorEvaluation
import ComputableAnalysis.ModularForms.Hecke41PrincipalDiagonalAgreement

namespace ComputableAnalysis.ModularForms
open RiemannHilbert PackedIntegerPolynomialProduct

/-- The exact CM value follows from the independently checked Newton-prefix
agreement; all analytic and root-isolation evidence is constructed internally. -/
theorem cmJValue163_exact_class_of_newton
    (hnewton : ∀ k n, k≤41 → n<1723 → hecke41ExpandedNewtonCandidate k n=
      integerOrbitNewtonCoefficient41 integerJWeightedCoefficients 40 k n) :
    ComplexRawQuotient.ofRaw cmJValue163.val cmJValue163.property=
      ((-(640320:Int)^3):ScalarAlgebra.Value) := by
  let X := ComplexRawQuotient.ofRaw cmJValue163.val cmJValue163.property
  have hr := cmJValue163_candidate_diagonal_root_of_newton hnewton
  have hc := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := (RepresentedPolynomial.eval (integerPolynomialEmbedding hecke41DiagonalCandidate)
      ⟨cmJValue163.val,cmJValue163.property⟩).valid)
    (hright := RepresentedPolynomial.zero.valid) hr
  change RepresentedPolynomial.certClass (RepresentedPolynomial.eval
    (integerPolynomialEmbedding hecke41DiagonalCandidate) ⟨cmJValue163.val,cmJValue163.property⟩)=0 at hc
  rw [integerPolynomialEmbedding_eval_class,hecke41DiagonalCandidate_factor_class] at hc
  have hq := cmJValue163_candidate_quotient_nonzero
  have hd : X-((-(640320:Int)^3):ScalarAlgebra.Value)=0 := by
    apply Classical.byContradiction
    intro hn
    have hs : (X-((-(640320:Int)^3):ScalarAlgebra.Value))^2≠0 := by
      have hm := scalarClass_mul_nonzero _ _ hn hn
      have he : (X-((-(640320:Int)^3):ScalarAlgebra.Value))^2=
          (X-((-(640320:Int)^3):ScalarAlgebra.Value))*
            (X-((-(640320:Int)^3):ScalarAlgebra.Value)) := by grind only
      rw [he]
      exact hm
    exact scalarClass_mul_nonzero _ _ hs hq hc
  change X=_
  grind only

end ComputableAnalysis.ModularForms
