import ComputableAnalysis.ModularForms.Hecke41SparseNewtonPackedData

namespace ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct

private theorem zero_row : ∀ i : Fin 44,
    (hecke41SparseNewtonRow 0)[i.val]?.getD 0=if i.val=1 then 1 else 0 := by
  decide +kernel

/-- The supplied zero Newton row is the actual unit series on the full prefix. -/
theorem hecke41ExpandedNewton_zero (n : Nat) (hn : n<1723) :
    hecke41ExpandedNewtonCandidate 0 n=
      integerOrbitNewtonCoefficient41 (coefficient hecke41WeightedJCandidate) 40 0 n := by
  unfold hecke41ExpandedNewtonCandidate
  rw [integerOrbitNewtonCoefficient41.eq_def]
  simp only [Nat.zero_mod,Nat.sub_zero]
  by_cases hs : n%41≠0
  · rw [if_pos hs]
    have hz : n≠0 := by omega
    rw [if_neg hz]
  · rw [if_neg hs]
    let j := (n+41)/41
    have hj : j<44 := by dsimp [j]; omega
    have he : j=1 ↔ n=0 := by dsimp [j]; omega
    have hrow := zero_row ⟨j,hj⟩
    change (hecke41SparseNewtonRow 0)[j]?.getD 0=if j=1 then 1 else 0 at hrow
    change (hecke41SparseNewtonRow 0)[j]?.getD 0=_
    rw [hrow]
    simp only [he]

/-- Every checked compressed recurrence row identifies all ordinary degrees
of its Newton row, by support and strong induction on the row number. -/
theorem hecke41ExpandedNewton_agreement_of_checks
    (hsteps : ∀ k, 1≤k → k≤41 → hecke41SparseNewtonRow k=Array.ofFn (fun i : Fin 43 =>
      if 41*i.val+k<41 then 0 else integerOrbitNewtonSparseStep41
        hecke41ExpandedNewtonCandidate hecke41SparseTraceCoefficient k (41*i.val+k-41)))
    (k : Nat) : k≤41 → ∀ n, n<1723 → hecke41ExpandedNewtonCandidate k n=
      integerOrbitNewtonCoefficient41 (coefficient hecke41WeightedJCandidate) 40 k n := by
  induction k using Nat.strongRecOn with
  | ind k ih =>
    intro hk n hn
    cases k with
    | zero => exact hecke41ExpandedNewton_zero n hn
    | succ k =>
      by_cases hs : n%41≠(k+1)%41
      · rw [hecke41ExpandedNewtonCandidate,if_pos hs]
        exact (integerOrbitNewtonCoefficient41_support _ (k+1) n hs).symm
      · let j := (n+41-(k+1))/41
        have hj : j<43 := by dsimp [j]; omega
        have hd : 41*j+(k+1)-41=n := by dsimp [j]; omega
        have hg : ¬41*j+(k+1)<41 := by dsimp [j]; omega
        have hrow := congrArg (fun A : Array Int => A[j]?.getD 0)
          (hsteps (k+1) (by omega) hk)
        rw [Array.getElem?_ofFn] at hrow
        simp only [dif_pos hj,Option.getD_some,if_neg hg] at hrow
        rw [hd] at hrow
        rw [hecke41ExpandedNewtonCandidate,if_neg hs]
        change (hecke41SparseNewtonRow (k+1))[j]?.getD 0=_
        rw [hrow]
        apply integerOrbitNewtonSparseStep41_agreement _ _ _ k n (by omega)
        · intro i hi d hd
          exact ih i hi (by omega) d (by omega)
        · intro m hm d hd
          exact hecke41SparseTraceCoefficient_agreement m d (by omega) (by omega)

end ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct
