import ComputableAnalysis.ModularForms.CMDiscriminantSharpInverseBound163
import ComputableAnalysis.ModularForms.LatticeJLinearLaurentEstimate

/-! An unconditional Laurent estimate for the actual discriminant-163 lattice j value. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- The actual CM j value differs from reciprocal-nome plus 744 by less than a fixed rational radius. -/
theorem cmJValue163_linear_laurent_bound :
    Small (sub cmJValue163.val
      (add (add (RepresentedReciprocal.inverse (nome.eval cmScalar163 cmPoint163_upper)
        (nome_nonzero cmScalar163 cmPoint163_upper)).val (ofQComplex ⟨744,0⟩))
        (scaleRat 196884 (nome.eval cmScalar163 cmPoint163_upper).val))) (1/10000000000000000000000) := by
  let q := nome.eval cmScalar163 cmPoint163_upper
  let d := nomeModularDiscriminant q (1/144115188075855872) (by decide +kernel)
    (by decide +kernel) nome_cm163_small_fiftySeven_power
  have hd := nomeModularDiscriminant_congr q q (1/144115188075855872) (1/68719476736)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    nome_cm163_small_fiftySeven_power nome_cm163_small_thirtySix_power (equiv_refl q.val q.property)
  have hi := RepresentedReciprocal.inverse_congr cmFourierDiscriminant163 d
    cmFourierDiscriminant163_nonzero
    (latticeJMap_fourier_discriminant_nonzero cmScalar163 latticeJMap_cm_domain
      (1/144115188075855872) (by decide +kernel) (by decide +kernel) nome_cm163_small_fiftySeven_power)
    (equiv_symm hd)
  have hv := Small.congr
    (RepresentedReciprocal.inverse cmFourierDiscriminant163 cmFourierDiscriminant163_nonzero).property
    (RepresentedReciprocal.inverse d
      (latticeJMap_fourier_discriminant_nonzero cmScalar163 latticeJMap_cm_domain
        (1/144115188075855872) (by decide +kernel) (by decide +kernel) nome_cm163_small_fiftySeven_power)).property
    hi cmFourierDiscriminantInverse163_sharp_bound
  have h := latticeJMap_linear_laurent_bound cmScalar163 latticeJMap_cm_domain
    (1/144115188075855872) (by decide +kernel) (by decide +kernel)
    nome_cm163_small_fiftySeven_power (by decide +kernel)
    ((11/4:Rat)^41) (8*((11/4:Rat)^41)) (by decide +kernel) (by decide +kernel)
    cmNomeInverse163_sharp_bound hv
  exact h.mono (by decide +kernel)

end ComputableAnalysis.ModularForms
