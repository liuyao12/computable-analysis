import ComputableAnalysis.ModularForms.Hecke41AffinePoleDensityAgreement
import ComputableAnalysis.ModularForms.CommonOuterRightLowerAssembly

/-! Exact finite Hecke affine contour residue. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def normalizedScalarGrid (f : Nat → Scalar) (M : Nat) (r : Rat) : Scalar :=
  ⟨scaleRat r (gridScalarSum M f).val,scaleRat_valid (gridScalarSum M f).property⟩

theorem normalizedScalarGrid_orientation (f : Nat → Scalar) (M : Nat) (r : Rat) (upper : Bool) :
    (normalizedScalarGrid (fun j => orientSquareAverage upper (f j)) M r).val.Equiv
      (orientSquareAverage upper (normalizedScalarGrid f M r)).val := by
  cases upper
  · have hs := scaleRat_equiv (r := r) (gridScalarSum_negation f M)
    exact equiv_trans
      (normalizedScalarGrid (fun j => orientSquareAverage false (f j)) M r).property
      (scaleRat_valid (neg_valid (gridScalarSum M f).property))
      (orientSquareAverage false (normalizedScalarGrid f M r)).property hs
      (scaleRat_negation (gridScalarSum M f) r)
  · exact equiv_refl _ (normalizedScalarGrid f M r).property

theorem hecke41AffineFiniteEdge_residue_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (M : Nat) (hM : 0<M) :
    (sampledSquareHalfEdge (affinePoleDensity ((hecke41NomeDescended k 10000).eval a ha)
      ((hecke41NomeDescended_holomorphic k 10000).derivative a ha) edge R.val) edge M).val.Equiv
      (orientSquareAverage edge.upper (hecke41ComparisonEdgeAverage true k a ha edge R hR M hM)).val := by
  let f := affinePoleDensity ((hecke41NomeDescended k 10000).eval a ha)
    ((hecke41NomeDescended_holomorphic k 10000).derivative a ha) edge R.val
  let g := hecke41SquareComparisonGridDensity true k a ha edge R hR M hM
  have hs := scaleRat_equiv (r := (M:Rat)⁻¹)
    (gridScalarSum_congr_on_indices M (fun j => f (squareMidpointParameter M j))
      (fun j => orientSquareAverage edge.upper (g j))
      (fun j hj => hecke41AffineGridPoleDensity_agreement k a ha edge R hR M hM j hj))
  exact equiv_trans (sampledSquareHalfEdge f edge M).property
    (weightedMidpointSum f M ((M:Rat)⁻¹)).property
    (orientSquareAverage edge.upper (hecke41ComparisonEdgeAverage true k a ha edge R hR M hM)).property
    (sampledSquareHalfEdge_midpoint f edge M hM)
    (equiv_trans (weightedMidpointSum f M ((M:Rat)⁻¹)).property
      (normalizedScalarGrid (fun j => orientSquareAverage edge.upper (g j)) M ((M:Rat)⁻¹)).property
      (orientSquareAverage edge.upper (hecke41ComparisonEdgeAverage true k a ha edge R hR M hM)).property
      hs (normalizedScalarGrid_orientation g M ((M:Rat)⁻¹) edge.upper))

theorem hecke41AffineFiniteContour_residue_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (M : Nat) (hM : 0<M) (es : List HalfEdge) :
    (suppliedAffineSquareEdgeList ((hecke41NomeDescended k 10000).eval a ha)
      ((hecke41NomeDescended_holomorphic k 10000).derivative a ha) R.val M es).val.Equiv
      (hecke41FiniteAffineContour k a ha R hR M hM es).val := by
  induction es with
  | nil => exact equiv_refl _ (ofQComplex_valid _)
  | cons e es ih => exact add_equiv (hecke41AffineFiniteEdge_residue_agreement k a ha e R hR M hM) ih

theorem hecke41AffineSquare_finite_residue (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (M : Nat) (hM : 0<M) :
    (hecke41FiniteAffineContour k a ha R hR M hM PDE.CauchyContour.square).val.Equiv
      (scalarProduct ((hecke41NomeDescended_holomorphic k 10000).derivative a ha)
        (squareResidueMidpointSum M)).val :=
  equiv_trans (hecke41FiniteAffineContour k a ha R hR M hM PDE.CauchyContour.square).property
    (suppliedAffineSquareEdgeList ((hecke41NomeDescended k 10000).eval a ha)
      ((hecke41NomeDescended_holomorphic k 10000).derivative a ha) R.val M PDE.CauchyContour.square).property
    (scalarProduct ((hecke41NomeDescended_holomorphic k 10000).derivative a ha) (squareResidueMidpointSum M)).property
    (equiv_symm (hecke41AffineFiniteContour_residue_agreement k a ha R hR M hM PDE.CauchyContour.square))
    (suppliedAffineSquareContour_finite_residue _ _ R.val R.property M hM)

end ComputableAnalysis.ModularForms
