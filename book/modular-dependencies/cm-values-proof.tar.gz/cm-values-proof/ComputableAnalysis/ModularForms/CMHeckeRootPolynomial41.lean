import ComputableAnalysis.ModularForms.CMHeckeDilation41
import ComputableAnalysis.ModularForms.Hecke41CoefficientHolomorphic
import ComputableAnalysis.FTA.GaussLucas

namespace ComputableAnalysis.ModularForms
open RiemannHilbert FunctionTheory RepresentedPolynomial

/-- All actual correspondence values, with constructed domain evidence. -/
def cmHeckeJCert41 (i : Fin 42) : ComplexCert :=
  ⟨(latticeJMap.eval (hecke41Point i cmScalar163) (hecke41Point_cm_j_domain i)).val,
    (latticeJMap.eval (hecke41Point i cmScalar163) (hecke41Point_cm_j_domain i)).property⟩

def cmHeckeRoots41 : List ComplexCert := List.ofFn cmHeckeJCert41

/-- The represented root polynomial; integrality of its coefficients is a
separate modular-polynomial theorem, not part of this construction. -/
def cmHeckeRootPolynomial41 : Coefficients := rootPolynomial cmHeckeRoots41

theorem cmHeckeRootPolynomial41_monic : Monic cmHeckeRootPolynomial41 :=
  rootPolynomial_monic _

theorem cmHeckeRootPolynomial41_length : cmHeckeRootPolynomial41.length = 43 := by
  simp [cmHeckeRootPolynomial41, rootPolynomial_length, cmHeckeRoots41]

theorem cmHeckeRootPolynomial41_cm_root :
    Root cmHeckeRootPolynomial41 ⟨cmJValue163.val, cmJValue163.property⟩ := by
  have hm : cmHeckeJCert41 ⟨40, by decide⟩ ∈ cmHeckeRoots41 := by
    simp [cmHeckeRoots41]
  have hr := rootProduct_zero_of_mem cmHeckeRoots41 _ hm
  have he := hecke41Point_cm_forty_j
  have hv : (cmHeckeJCert41 ⟨40, by decide⟩).raw.Equiv cmJValue163.val := he
  exact root_congr (equivalent_refl _) hv (certTrans (eval_rootPolynomial _ _) hr)

/-- The concrete CM polynomial is the actual correspondence construction. -/
theorem cmHeckeRootPolynomial41_agreement :
    cmHeckeRootPolynomial41 = hecke41RootPolynomial cmScalar163 hecke41Point_cm_j_domain := rfl

theorem cmHeckeRootPolynomial41_S (x : ComplexCert) :
    (eval (hecke41RootPolynomial (fractionalLinear SL2Z.S cmScalar163 cmPoint163_upper)
      (hecke41RootPolynomial_S_domain cmScalar163 cmPoint163_upper hecke41Point_cm_j_domain)) x).raw.Equiv
      (eval cmHeckeRootPolynomial41 x).raw :=
  hecke41RootPolynomial_S cmScalar163 cmPoint163_upper hecke41Point_cm_j_domain x

theorem cmHeckeRootPolynomial41_T (x : ComplexCert) :
    (eval (hecke41RootPolynomial (fractionalLinear SL2Z.T cmScalar163 cmPoint163_upper)
      (hecke41RootPolynomial_T_domain cmScalar163 cmPoint163_upper hecke41Point_cm_j_domain)) x).raw.Equiv
      (eval cmHeckeRootPolynomial41 x).raw :=
  hecke41RootPolynomial_T cmScalar163 cmPoint163_upper hecke41Point_cm_j_domain x

theorem cmHeckeRootPolynomial41_S_coefficients :
    Equivalent (hecke41RootPolynomial (fractionalLinear SL2Z.S cmScalar163 cmPoint163_upper)
      (hecke41RootPolynomial_S_domain cmScalar163 cmPoint163_upper hecke41Point_cm_j_domain))
      cmHeckeRootPolynomial41 :=
  hecke41RootPolynomial_S_coefficients cmScalar163 cmPoint163_upper hecke41Point_cm_j_domain

theorem cmHeckeRootPolynomial41_T_coefficients :
    Equivalent (hecke41RootPolynomial (fractionalLinear SL2Z.T cmScalar163 cmPoint163_upper)
      (hecke41RootPolynomial_T_domain cmScalar163 cmPoint163_upper hecke41Point_cm_j_domain))
      cmHeckeRootPolynomial41 :=
  hecke41RootPolynomial_T_coefficients cmScalar163 cmPoint163_upper hecke41Point_cm_j_domain

theorem cmHeckeRootPolynomial41_word_coefficients (g : ModularWord) :
    Equivalent (hecke41RootPolynomial (fractionalLinear g.matrix cmScalar163 cmPoint163_upper)
      (hecke41RootPolynomial_word_domain g cmScalar163 cmPoint163_upper hecke41Point_cm_j_domain))
      cmHeckeRootPolynomial41 :=
  hecke41RootPolynomial_word_coefficients g cmScalar163 cmPoint163_upper hecke41Point_cm_j_domain

/-- Concrete CM correspondence coefficients are invariant under the full modular group. -/
theorem cmHeckeRootPolynomial41_modular_coefficients (g : SL2Z) :
    Equivalent (hecke41RootPolynomial (fractionalLinear g cmScalar163 cmPoint163_upper)
      (hecke41RootPolynomial_modular_domain g cmScalar163 cmPoint163_upper hecke41Point_cm_j_domain))
      cmHeckeRootPolynomial41 :=
  hecke41RootPolynomial_modular_coefficients g cmScalar163 cmPoint163_upper hecke41Point_cm_j_domain

theorem cmScalar163_hecke41CommonDomain : hecke41CommonDomain cmScalar163 :=
  ⟨cmPoint163_upper, hecke41Point_cm_j_domain⟩

theorem cmHeckeRootPolynomial41_coefficient_value (k : Nat) :
    ((hecke41PolynomialCoefficient k).value cmScalar163 cmScalar163_hecke41CommonDomain).val.Equiv
      (coefficient cmHeckeRootPolynomial41 k).raw :=
  hecke41PolynomialCoefficient_value k cmScalar163 cmScalar163_hecke41CommonDomain

end ComputableAnalysis.ModularForms
