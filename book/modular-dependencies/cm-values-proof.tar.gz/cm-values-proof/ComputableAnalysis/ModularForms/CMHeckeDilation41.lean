import ComputableAnalysis.ModularForms.CMHeckeFiniteDiscriminant41
import ComputableAnalysis.ModularForms.NomeIntegerScaling
import ComputableAnalysis.ModularForms.CMExponentialSharpLowerBound163

/-! Constructed nonvanishing at the remaining degree-41 CM dilation point. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory
set_option maxRecDepth 8192

def cmHeckeDilationPoint41 : Scalar := integerScaleScalar cmScalar163 41

theorem cmHeckeDilationPoint41_upper : InUpperHalfPlane cmHeckeDilationPoint41.val :=
  integerScaleScalar_upper cmScalar163 cmPoint163_upper 41 (by decide +kernel)

def cmHeckeDilationRadius41 : Rat := (2*(1/144115188075855872:Rat))^41

def cmHeckeDilationInverseBound41 : Rat := (11/4:Rat)^1680

/-- The actual dilation nome has a constructed power-amplified radius. -/
theorem cmHeckeDilationNome41_small :
    Small (nome.eval cmHeckeDilationPoint41 cmHeckeDilationPoint41_upper).val cmHeckeDilationRadius41 := by
  have h := nome_integerScale_small cmScalar163 cmPoint163_upper (1/144115188075855872)
    (by decide +kernel) nome_cm163_small_fiftySeven_power 40
  exact h

/-- Rational height enclosure of the actual dilation point. -/
theorem cmHeckeDilationPoint41_height_bounds :
    (RealRaw.ofRat (2091/8)).Le cmHeckeDilationPoint41.val.imagPart ∧
      cmHeckeDilationPoint41.val.imagPart.Le (RealRaw.ofRat (1312/5)) := by
  constructor
  · intro n m
    have h := sqrt163_lower_fiftyOne_quarters 0 m
    change (51/4:Rat)≤(sqrt163.compute m).hi at h
    have hm := Rat.mul_le_mul_of_nonneg_left h (show (0:Rat)≤41/2 by decide +kernel)
    change (2091/8:Rat)≤(cmHeckeDilationPoint41.val.compute m).hi.im
    simp only [cmHeckeDilationPoint41,integerScaleScalar,integerAffine,translate,cmScalar163,cmPoint163,
      scaleRat,QBox.scaleRat,show ((41:Int):Rat)=(41:Rat) by decide +kernel,
      show ((0:Int):Rat)=(0:Rat) by decide +kernel,if_pos (show (0:Rat)≤41 by decide +kernel),
      if_pos (show (0:Rat)≤1/2 by decide +kernel),add,one,ofQComplex,QBox.add,QComplex.add,
      QComplex.one,imaginaryAxis_compute]
    grind only
  · intro n m
    have h := sqrt163_upper_sixtyFour_fifths n 0
    change (sqrt163.compute n).lo≤(64/5:Rat) at h
    have hm := Rat.mul_le_mul_of_nonneg_left h (show (0:Rat)≤41/2 by decide +kernel)
    change (cmHeckeDilationPoint41.val.compute n).lo.im≤(1312/5:Rat)
    simp only [cmHeckeDilationPoint41,integerScaleScalar,integerAffine,translate,cmScalar163,cmPoint163,
      scaleRat,QBox.scaleRat,show ((41:Int):Rat)=(41:Rat) by decide +kernel,
      show ((0:Int):Rat)=(0:Rat) by decide +kernel,if_pos (show (0:Rat)≤41 by decide +kernel),
      if_pos (show (0:Rat)≤1/2 by decide +kernel),add,one,ofQComplex,QBox.add,QComplex.add,
      QComplex.one,imaginaryAxis_compute]
    grind only

/-- Rational actual nome growth enclosure at the dilation point. -/
theorem cmHeckeDilationPoint41_growth_bounds :
    (RealRaw.ofRat (328287/200)).Le (nomeHeightGrowth cmHeckeDilationPoint41) ∧
      (nomeHeightGrowth cmHeckeDilationPoint41).Le (RealRaw.ofRat (41984/25)) := by
  have hl := nomeHeightGrowth_lower cmHeckeDilationPoint41 (2091/8) (by decide +kernel)
    cmHeckeDilationPoint41_height_bounds.1
  have hu := nomeHeightGrowth_upper cmHeckeDilationPoint41 (1312/5) (by decide +kernel)
    cmHeckeDilationPoint41_height_bounds.2
  rw [show (4:Rat)*(157/100)*(2091/8)=328287/200 by decide +kernel] at hl
  rw [show (4:Rat)*(8/5)*(1312/5)=41984/25 by decide +kernel] at hu
  exact ⟨hl,hu⟩

/-- Actual double-growth exponential upper bound for the dilation point. -/
theorem cmHeckeDilationDoubleGrowth41_exponential_upper :
    (entireExponentialValue ⟨ofRealRaw (RealRaw.scaleRat 2 (nomeHeightGrowth cmHeckeDilationPoint41)),
      ofRealRaw_valid _ (RealRaw.scaleRat_valid (nomeHeightGrowth_valid _))⟩).val.realPart.Le
        (RealRaw.ofRat (cmHeckeDilationInverseBound41*cmHeckeDilationInverseBound41)) := by
  let x := RealRaw.scaleRat 2 (nomeHeightGrowth cmHeckeDilationPoint41)
  have hx : x.Valid := RealRaw.scaleRat_valid (nomeHeightGrowth_valid _)
  have hl : (RealRaw.ofRat 12).Le x := by
    intro n m
    have h := cmHeckeDilationPoint41_growth_bounds.1 0 m
    change (328287/200:Rat)≤((nomeHeightGrowth cmHeckeDilationPoint41).compute m).hi at h
    change (12:Rat)≤(x.compute m).hi
    simp only [x,RealRaw.scaleRat,RealRaw.scaleRatCompute,if_pos (show (0:Rat)≤2 by decide +kernel)]
    grind only
  have hp : x.Pos := by
    obtain ⟨N,hN⟩ := hx.2.2 (⟨1,by decide +kernel⟩ : QPos)
    have hw := hN N (Nat.le_refl N)
    have hh := hl 0 N
    change (12:Rat)≤(x.compute N).hi at hh
    unfold QInterval.width at hw
    refine ⟨N,?_⟩
    change 0<(x.compute N).lo
    grind only
  have h0 : (RealRaw.ofRat 0).Le x := by
    intro n m
    have h := hl 0 m
    change (12:Rat)≤(x.compute m).hi at h
    change (0:Rat)≤(x.compute m).hi
    grind only
  have hb : x.Le (RealRaw.ofRat ((3360:Rat)-32/25)) := by
    intro n m
    have h := cmHeckeDilationPoint41_growth_bounds.2 n 0
    change ((nomeHeightGrowth cmHeckeDilationPoint41).compute n).lo≤(41984/25:Rat) at h
    change (x.compute n).lo≤(3360:Rat)-32/25
    simp only [x,RealRaw.scaleRat,RealRaw.scaleRatCompute,if_pos (show (0:Rat)≤2 by decide +kernel)]
    grind only
  have hm := entireExponential_real_strict_upper_comparison x hx hp h0 3360 (32/25) (by decide +kernel) hb
  have hu := entireExponential_rational_nat_power_upper 1 (11/4) 3360 (by decide +kernel) (by decide +kernel)
    entireExponential_rational_one_upper_eleven_quarters
  rw [show ((3360:Nat):Rat)*1=(3360:Rat) by decide +kernel] at hu
  rw [show (11/4:Rat)^3360=cmHeckeDilationInverseBound41*cmHeckeDilationInverseBound41 by decide +kernel] at hu
  exact RealRaw.le_trans (realPart_valid (entireExponentialValue _).property) hm hu

private theorem dilation_guards :
    0≤cmHeckeDilationRadius41 ∧ 128*cmHeckeDilationRadius41≤(1:Rat)/2 ∧
    cmHeckeDilationRadius41≤(1:Rat)/512 ∧ 0≤cmHeckeDilationInverseBound41 ∧
    440*cmHeckeDilationRadius41*cmHeckeDilationRadius41*cmHeckeDilationInverseBound41<1 := by
  decide +kernel

/-- Actual dilation nome reciprocal bound. -/
theorem cmHeckeDilationNome41_inverse_small :
    Small (RepresentedReciprocal.inverse (nome.eval cmHeckeDilationPoint41 cmHeckeDilationPoint41_upper)
      (nome_nonzero _ _)).val cmHeckeDilationInverseBound41 :=
  nome_inverse_small_of_double_growth_upper _ _ _ dilation_guards.2.2.2.1
    cmHeckeDilationDoubleGrowth41_exponential_upper

def cmHeckeDilationFourierDiscriminant41 : Scalar :=
  nomeModularDiscriminant (nome.eval cmHeckeDilationPoint41 cmHeckeDilationPoint41_upper)
    cmHeckeDilationRadius41 dilation_guards.1 dilation_guards.2.1 cmHeckeDilationNome41_small

/-- The remaining dilation Fourier discriminant is actually nonzero. -/
theorem cmHeckeDilationFourierDiscriminant41_nonzero :
    NonzeroBoxSearch.Nonzero cmHeckeDilationFourierDiscriminant41 :=
  nomeModularDiscriminant_wide_nonzero _ _ _ dilation_guards.1 dilation_guards.2.1
    cmHeckeDilationNome41_small dilation_guards.2.2.1 (nome_nonzero _ _)
    dilation_guards.2.2.2.1 cmHeckeDilationNome41_inverse_small dilation_guards.2.2.2.2

/-- The actual lattice j evaluator is justified at the remaining dilation point. -/
theorem cmHeckeDilationPoint41_j_domain : latticeJMap.domain cmHeckeDilationPoint41 :=
  latticeJMap_domain_of_fourier_nonzero _ cmHeckeDilationPoint41_upper _ dilation_guards.1
    dilation_guards.2.1 cmHeckeDilationNome41_small cmHeckeDilationFourierDiscriminant41_nonzero

/-- The dilation constructor agrees with the actual infinity-index correspondence point. -/
theorem cmHeckeDilationPoint41_agreement :
    (hecke41Point ⟨41,by decide +kernel⟩ cmScalar163).val.Equiv cmHeckeDilationPoint41.val := by
  intro n
  have ho := valid_ordered cmScalar163.property n
  apply (compareAt_overlap_iff _ _ n n).mpr
  simp only [hecke41Point,if_pos (show (41:Nat)=41 from rfl),cmHeckeDilationPoint41,
    integerScaleScalar,integerAffine,translate,add,ofQComplex,scaleRat,QBox.add,QComplex.add,QBox.scaleRat,
    show ((41:Int):Rat)=(41:Rat) by decide +kernel,
    show ((0:Int):Rat)=(0:Rat) by decide +kernel,
    if_pos (show (0:Rat)≤41 by decide +kernel),Rat.add_zero]
  obtain ⟨hr,hi⟩ := ho
  constructor <;> constructor <;> grind only

/-- The actual lattice j evaluator is justified at all 42 degree-41 CM correspondence points. -/
theorem hecke41Point_cm_j_domain (i : Fin 42) : latticeJMap.domain (hecke41Point i cmScalar163) := by
  by_cases hi : i.val=41
  · have he : i=(⟨41,by decide +kernel⟩ : Fin 42) := Fin.ext hi
    rw [he]
    exact (latticeJMap.domain_congr _ _ cmHeckeDilationPoint41_agreement).mpr cmHeckeDilationPoint41_j_domain
  · have hlt : i.val<41 := by omega
    exact cmHeckeFinitePoint41_j_domain ⟨i.val,hlt⟩

end ComputableAnalysis.ModularForms
