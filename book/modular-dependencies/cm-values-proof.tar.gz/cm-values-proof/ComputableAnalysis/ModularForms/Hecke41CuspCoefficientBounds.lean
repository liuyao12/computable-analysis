import ComputableAnalysis.ModularForms.Hecke41CuspThreshold

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

def hecke41CuspFamilyL (n : Nat) (i : Fin 42) : Rat := (hecke41CuspL i)^(n+1)
def hecke41CuspFamilyB (n : Nat) (i : Fin 42) : Rat := (hecke41CuspB i)^(n+1)

theorem hecke41CuspFamily_growth (n : Nat) (z : Scalar)
    (hl : (RealRaw.ofRat (300*((n+1:Nat):Rat))).Le z.val.imagPart)
    (hu : z.val.imagPart.Le (RealRaw.ofRat (301*((n+1:Nat):Rat)))) (i : Fin 42) :
    (RealRaw.ofRat (hecke41CuspFamilyL n i)).Le (nomeGrowthExponential (hecke41Point i z)) ∧
      (nomeDoubleGrowthExponential (hecke41Point i z)).Le
        (RealRaw.ofRat (hecke41CuspFamilyB n i*hecke41CuspFamilyB n i)) := by
  let K : Rat := ((n+1:Nat):Rat)
  have hK : 0<K := by dsimp [K]; exact_mod_cast Nat.zero_lt_succ n
  have hp := hecke41HeightFactor_positive i
  have hh := hecke41Point_height_bounds i z (300*K) (301*K) hl hu
  have hc : 0<hecke41HeightFactor i*(300*K) := Rat.mul_pos hp (Rat.mul_pos (by decide +kernel) hK)
  have hd : 0≤hecke41HeightFactor i*(301*K) :=
    Rat.mul_nonneg (Rat.le_of_lt hp) (Rat.le_of_lt (Rat.mul_pos (by decide +kernel) hK))
  have he : 0<K/2 := by grind
  have ha : 0<K*(hecke41CuspLowerExponent i:Rat) := by
    have ht : 0<(hecke41CuspLowerExponent i:Rat) := by
      unfold hecke41CuspLowerExponent; split <;> decide +kernel
    exact Rat.mul_pos hK ht
  have hg : K*(hecke41CuspLowerExponent i:Rat)+K/2≤4*(157/100)*(hecke41HeightFactor i*(300*K)) := by
    by_cases hi : i.val=41
    · simp only [hecke41CuspLowerExponent,hecke41HeightFactor,if_pos hi]
      rw [show ((77000:Nat):Rat)=77000 by decide +kernel]; grind
    · simp only [hecke41CuspLowerExponent,hecke41HeightFactor,if_neg hi]
      rw [show ((45:Nat):Rat)=45 by decide +kernel]; grind
  have hk : 2*(4*(8/5)*(hecke41HeightFactor i*(301*K)))≤K*(hecke41CuspUpperExponent i:Rat)-K/2 := by
    by_cases hi : i.val=41
    · simp only [hecke41CuspUpperExponent,hecke41HeightFactor,if_pos hi]
      rw [show ((158000:Nat):Rat)=158000 by decide +kernel]; grind
    · simp only [hecke41CuspUpperExponent,hecke41HeightFactor,if_neg hi]
      rw [show ((96:Nat):Rat)=96 by decide +kernel]; grind
  constructor
  · apply nomeGrowthExponential_height_lower _ _ _ _ _ (Rat.le_of_lt hc) ha he hh.1 hg
    exact entireExponential_rational_nat_power_lower (hecke41CuspLowerExponent i:Rat)
      (hecke41CuspL i) (n+1) (Rat.le_of_lt (hecke41Cusp_guards i).1) (hecke41Cusp_lower_exponential i)
  · apply nomeDoubleGrowthExponential_height_upper _ _ _ _ _ _ hc hd he hh.1 hh.2 hk
    have ht : 0≤(hecke41CuspUpperExponent i:Rat) := by
      unfold hecke41CuspUpperExponent; split <;> decide +kernel
    have hb := Rat.mul_nonneg (hecke41Cusp_guards i).2.1 (hecke41Cusp_guards i).2.1
    have h := entireExponential_rational_nat_power_upper (hecke41CuspUpperExponent i:Rat)
      (hecke41CuspB i*hecke41CuspB i) (n+1) ht hb (hecke41Cusp_upper_exponential i)
    have hpw (a b : Rat) : (a*b)^(n+1)=a^(n+1)*b^(n+1) := by
      have all (m : Nat) : (a*b)^m=a^m*b^m := by
        induction m with
        | zero => simp
        | succ m ih => simp only [Rat.pow_succ,ih]; grind
      exact all _
    rw [hpw] at h
    exact h

def hecke41CuspJBound (n : Nat) (i : Fin 42) : Rat :=
  let L := hecke41CuspFamilyL n i
  let B := hecke41CuspFamilyB n i
  B+744+512000000*(1/L)*(1/L)*(1/L)*B*B

def hecke41CuspCoefficientBound (n : Nat) : Rat :=
  (1+2*(List.ofFn (hecke41CuspJBound n)).sum)^42

private theorem sum_nonneg (xs : List Rat) (h : ∀ x ∈ xs, 0≤x) : 0≤xs.sum := by
  induction xs with
  | nil => simp
  | cons a xs ih => simp only [List.sum_cons]; have ha := h a (by simp); have ht := ih (fun x hx => h x (by simp [hx])); grind

private theorem mem_le_sum (xs : List Rat) (h : ∀ x ∈ xs, 0≤x) (a : Rat) (ha : a∈xs) : a≤xs.sum := by
  induction xs with
  | nil => simp at ha
  | cons b xs ih =>
      simp only [List.sum_cons]
      have ht := sum_nonneg xs (fun x hx => h x (by simp [hx]))
      rcases List.mem_cons.mp ha with he | hm
      · subst a; grind
      · have hb := h b (by simp); have hi := ih (fun x hx => h x (by simp [hx])) hm; grind

/-- A checked rational coefficient bound across every band of the unbounded cusp family. -/
theorem hecke41PolynomialCoefficient_cusp_bound (k n : Nat) (z : Scalar) (hz : InUpperHalfPlane z.val)
    (hl : (RealRaw.ofRat (300*((n+1:Nat):Rat))).Le z.val.imagPart)
    (hu : z.val.imagPart.Le (RealRaw.ofRat (301*((n+1:Nat):Rat)))) :
    Small ((hecke41PolynomialCoefficient k).value z (hecke41CommonDomain_cusp_family n z hz hl hu)).val
      (hecke41CuspCoefficientBound n) := by
  have guards (i : Fin 42) := cusp_power_guards (hecke41CuspL i) (hecke41CuspB i)
    (hecke41Cusp_guards i).1 (hecke41Cusp_guards i).2.1
    (hecke41Cusp_guards i).2.2.1 (hecke41Cusp_guards i).2.2.2 n
  have hpos (i : Fin 42) : 0≤hecke41CuspJBound n i := by
    have hL := (guards i).1
    have hB := (guards i).2.1
    change 0≤hecke41CuspFamilyB n i at hB
    have hr : 0≤1/hecke41CuspFamilyL n i := by
      rw [Rat.div_def,Rat.one_mul]; exact Rat.le_of_lt (Rat.inv_pos.mpr hL)
    have ht := Rat.mul_nonneg (Rat.mul_nonneg (Rat.mul_nonneg (Rat.mul_nonneg
      (Rat.mul_nonneg (show (0:Rat)≤512000000 by decide +kernel) hr) hr) hr) hB) hB
    unfold hecke41CuspJBound
    grind only
  have hlist : ∀ x ∈ List.ofFn (hecke41CuspJBound n), 0≤x := by
    intro x hx; obtain ⟨i,hi⟩ := List.mem_ofFn.mp hx; subst x; exact hpos i
  exact hecke41PolynomialCoefficient_growth_bound k z hz (hecke41CuspFamilyL n) (hecke41CuspFamilyB n)
    (fun i => (guards i).1) (fun i => (guards i).2.1) (fun i => (guards i).2.2.1)
    (fun i => (guards i).2.2.2) (fun i => (hecke41CuspFamily_growth n z hl hu i).1)
    (fun i => (hecke41CuspFamily_growth n z hl hu i).2) _ (sum_nonneg _ hlist)
    (fun i => mem_le_sum _ hlist (hecke41CuspJBound n i) (List.mem_ofFn.mpr ⟨i,rfl⟩))

theorem hecke41CuspJBound_nonneg (n : Nat) (i : Fin 42) : 0≤hecke41CuspJBound n i := by
  have hL : 0<hecke41CuspFamilyL n i := Rat.pow_pos (hecke41Cusp_guards i).1
  have hB : 0≤hecke41CuspFamilyB n i := Rat.pow_nonneg (hecke41Cusp_guards i).2.1
  have hr : 0≤1/hecke41CuspFamilyL n i := by
    rw [Rat.div_def,Rat.one_mul]; exact Rat.le_of_lt (Rat.inv_pos.mpr hL)
  have ht := Rat.mul_nonneg (Rat.mul_nonneg (Rat.mul_nonneg (Rat.mul_nonneg
    (Rat.mul_nonneg (show (0:Rat)≤512000000 by decide +kernel) hr) hr) hr) hB) hB
  unfold hecke41CuspJBound
  grind only

theorem hecke41CuspCoefficientBound_nonneg (n : Nat) : 0≤hecke41CuspCoefficientBound n := by
  have hs : 0≤(List.ofFn (hecke41CuspJBound n)).sum := sum_nonneg _ (by
    intro x hx; obtain ⟨i,hi⟩ := List.mem_ofFn.mp hx; subst x; exact hecke41CuspJBound_nonneg n i)
  exact Rat.pow_nonneg (by grind)

end ComputableAnalysis.ModularForms
