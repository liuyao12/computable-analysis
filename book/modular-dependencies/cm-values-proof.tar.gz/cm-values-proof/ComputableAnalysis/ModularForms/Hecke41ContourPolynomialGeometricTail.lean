import ComputableAnalysis.ModularForms.Hecke41ContourCoefficientBound
import ComputableAnalysis.ModularForms.RepresentedPolynomialGeometricTail

/-! Actual contour coefficient polynomials have geometrically shrinking local tails. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def hecke41PolynomialTermBound (es : List HalfEdge) : Rat :=
  16*(es.length:Rat)*(2*(2:Rat)^10000)

theorem hecke41PolynomialTermBound_nonneg (es : List HalfEdge) : 0≤hecke41PolynomialTermBound es :=
  Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) Rat.natCast_nonneg)
    (Rat.mul_nonneg (by decide +kernel) (Rat.pow_nonneg (by decide +kernel)))

theorem hecke41ContourPolynomial_term_half_bound (k : Nat) (a b : Scalar)
    (ha : hecke41NomePuncturedDomain a) (S : QPos)
    (hg : S.val≤(hecke41NomeGeometricRadius a ha).val)
    (hd : S.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val)
    (r : Rat) (hr : 0≤r) (hb : Small b.val r) (hsmall : 8*r≤S.val)
    (es : List HalfEdge) (j : Nat) :
    Small (scalarProduct ⟨LocalODE.power b.val j,LocalODE.power_valid _ b.property j⟩
      (hecke41ReciprocalCoefficientContourLimit k a ha S hg hd j es)).val
      (hecke41PolynomialTermBound es*((1:Rat)/2)^j) := by
  have hi : 0≤1/S.val := by rw [Rat.div_def,Rat.one_mul]; exact Rat.le_of_lt (Rat.inv_pos.mpr S.property)
  have hc : (1/S.val)*S.val=1 := Rat.div_mul_cancel (Rat.ne_of_gt S.property)
  have hbase : 4*r*(1/S.val)≤(1:Rat)/2 := by
    have hh := Rat.mul_le_mul_of_nonneg_right hsmall hi
    have hs : S.val*(1/S.val)=1 := by grind only
    rw [hs] at hh
    grind only
  have hp := rational_power_mono (4*r*(1/S.val)) ((1:Rat)/2)
    (Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hr) hi) hbase j
  have hm := Small.mul (LocalODE.power_valid _ b.property j)
    (hecke41ReciprocalCoefficientContourLimit k a ha S hg hd j es).property
    (Rat.pow_nonneg (Rat.mul_nonneg (by decide +kernel) hr))
    (Rat.mul_nonneg Rat.natCast_nonneg (hecke41CoefficientDensityBound_nonneg S j))
    (LocalODE.power_small b.val b.property r hr hb j)
    (hecke41ReciprocalCoefficientContourLimit_bound k a ha S hg hd j es)
  have he : 2*(2*r)^j*((es.length:Rat)*hecke41CoefficientDensityBound S j)=
      hecke41PolynomialTermBound es*(4*r*(1/S.val))^j := by
    unfold hecke41CoefficientDensityBound hecke41PolynomialTermBound
    rw [Rat.pow_succ]
    have hpow : (4*r*(1/S.val))^j=(2*r)^j*(2*(1/S.val))^j := by
      have hh : 4*r*(1/S.val)=(2*r)*(2*(1/S.val)) := by grind only
      rw [hh,rational_power_product]
    rw [hpow]
    grind only
  rw [he] at hm
  exact hm.mono (Rat.mul_le_mul_of_nonneg_left hp (hecke41PolynomialTermBound_nonneg es))

theorem hecke41CoefficientContourPolynomial_half_tail_bound (k : Nat) (a b : Scalar)
    (ha : hecke41NomePuncturedDomain a) (S : QPos)
    (hg : S.val≤(hecke41NomeGeometricRadius a ha).val)
    (hd : S.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val)
    (r : Rat) (hr : 0≤r) (hb : Small b.val r) (hsmall : 8*r≤S.val)
    (es : List HalfEdge) (m n : Nat) :
    Small (sub (hecke41CoefficientContourPolynomial k a b ha S hg hd es (m+n)).val
      (hecke41CoefficientContourPolynomial k a b ha S hg hd es m).val)
      (2*hecke41PolynomialTermBound es*((1:Rat)/2)^m) :=
  representedCoefficientPolynomial_half_tail_bound _ b _ (hecke41PolynomialTermBound_nonneg es)
    (hecke41ContourPolynomial_term_half_bound k a b ha S hg hd r hr hb hsmall es) m n

theorem hecke41CoefficientContourPolynomial_tail_shrinks (es : List HalfEdge) :
    ShrinksToZero (fun m => 2*hecke41PolynomialTermBound es*((1:Rat)/2)^m) :=
  representedPolynomialHalfTail_shrinks _ (hecke41PolynomialTermBound_nonneg es)

end ComputableAnalysis.ModularForms
