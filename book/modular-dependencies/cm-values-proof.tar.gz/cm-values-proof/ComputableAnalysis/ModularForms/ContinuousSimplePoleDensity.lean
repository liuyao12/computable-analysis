import ComputableAnalysis.ModularForms.SimplePoleDensityBound
import ComputableAnalysis.RiemannHilbert.DomainHolomorphicComposition

namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

/-- Every point of a sufficiently small rational square lies in the supplied open domain. -/
theorem openDomain_square_edge_mem (f : DomainFunctions.Map) (hop : OpenDomain f)
    (a : Scalar) (ha : f.domain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val ≤ (hop.radius a ha).val) (u : Rat) (hu : 0 ≤ u) (hu1 : u ≤ 1) :
    f.domain (Centered.translate a (rationalRectangleScalar (QComplex.scaleRat R.val (point edge u)))) := by
  let w := rationalRectangleScalar (QComplex.scaleRat R.val (point edge u))
  have hw := scaledSquarePoint_small edge R.val u (Rat.le_of_lt R.property) hu hu1
  have hz := Small.congr w.property (sub_valid (Centered.translate a w).property a.property)
    (equiv_symm (Centered.offset_translate a w)) hw
  exact hop.inside a ha (Centered.translate a w) (hz.mono hR)

/-- Actual continuity controls the simple-pole density error on a shrinking square.
The kernel factor has a radius-independent bound; no Cauchy formula is assumed. -/
theorem continuousSimplePoleDensity_central_error (f : DomainFunctions.Map)
    (hf : ContinuousOn f.domain f.eval) (a : Scalar) (ha : f.domain a)
    (edge : HalfEdge) (R eps : QPos)
    (hR : R.val ≤ (hf.delta a ha (halfError eps)).val)
    (u : Rat) (hu : 0 ≤ u) (hu1 : u ≤ 1)
    (hz : f.domain (Centered.translate a (rationalRectangleScalar (QComplex.scaleRat R.val (point edge u))))) :
    let z := Centered.translate a (rationalRectangleScalar (QComplex.scaleRat R.val (point edge u)))
    let b := rationalRectangleScalar (simplePolePullback edge R.val u)
    Small (sub (scalarProduct (f.eval z hz) b).val (scalarProduct (f.eval a ha) b).val) eps.val := by
  intro z b
  have hzSmall : Small (sub z.val a.val) R.val :=
    Small.congr (rationalRectangleScalar (QComplex.scaleRat R.val (point edge u))).property
      (sub_valid z.property a.property) (equiv_symm (Centered.offset_translate a _))
      (scaledSquarePoint_small edge R.val u (Rat.le_of_lt R.property) hu hu1)
  have hc := hf.estimate a ha (halfError eps) z hz (hzSmall.mono hR)
  have hb : Small b.val 1 := by
    dsimp only [b]
    rw [simplePolePullback_scale_invariant edge R.val u R.property]
    exact squareSimplePole_pullback_small edge u hu hu1
  have hm := Small.mul (sub_valid (f.eval z hz).property (f.eval a ha).property) b.property
    (Rat.le_of_lt (halfError eps).property) (by decide +kernel : (0:Rat) ≤ 1) hc hb
  have he : 2*(halfError eps).val*1=eps.val := by
    rw [Rat.mul_one]; exact halfError_identity eps
  rw [he] at hm
  have hprod : (mul (sub (f.eval z hz).val (f.eval a ha).val) b.val).Equiv
      (sub (scalarProduct (f.eval z hz) b).val (scalarProduct (f.eval a ha) b).val) := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := mul_valid (sub_valid (f.eval z hz).property (f.eval a ha).property) b.property)
      (hright := sub_valid (scalarProduct (f.eval z hz) b).property (scalarProduct (f.eval a ha) b).property)
    change (gridScalarValue (f.eval z hz)-gridScalarValue (f.eval a ha))*gridScalarValue b =
      gridScalarValue (f.eval z hz)*gridScalarValue b-gridScalarValue (f.eval a ha)*gridScalarValue b
    grind only
  exact Small.congr (mul_valid (sub_valid (f.eval z hz).property (f.eval a ha).property) b.property)
    (sub_valid (scalarProduct (f.eval z hz) b).property (scalarProduct (f.eval a ha) b).property) hprod hm

end ComputableAnalysis.ModularForms
