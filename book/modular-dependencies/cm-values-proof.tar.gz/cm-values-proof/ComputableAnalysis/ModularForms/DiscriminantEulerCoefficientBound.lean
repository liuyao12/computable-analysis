import ComputableAnalysis.ModularForms.TauLambertRegularCoefficientAgreement
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- Executable bounded coefficient of the regularized discrepancy equation. -/
def discriminantEulerRegularCoefficient (q : Scalar) (hq : tauEulerNomeDomain q) : Scalar :=
  ⟨scaleRat (-24) (tauLambertRegularCoefficientValue q hq).val,
    scaleRat_valid (tauLambertRegularCoefficientValue q hq).property⟩
/-- The regular coefficient has a uniform rational coordinate bound throughout the nome disk. -/
theorem discriminantEulerRegularCoefficient_bound (q : Scalar) (hq : tauEulerNomeDomain q) :
    Small (discriminantEulerRegularCoefficient q hq).val 384 := by
  have hh := LocalODE.small_scale (c := (24:Rat)) (by decide +kernel)
    (tauLambertRegularCoefficientValue_bound q hq)
  have hn := SeriesLimitLaws.small_neg hh
  have he : (neg (scaleRat 24 (tauLambertRegularCoefficientValue q hq).val)).Equiv
      (discriminantEulerRegularCoefficient q hq).val := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := neg_valid (scaleRat_valid (tauLambertRegularCoefficientValue q hq).property))
      (hright := (discriminantEulerRegularCoefficient q hq).property)
    let c := ComplexRawQuotient.ofRaw (tauLambertRegularCoefficientValue q hq).val (tauLambertRegularCoefficientValue q hq).property
    change -ComplexRawQuotient.scaleRat 24 c=ComplexRawQuotient.scaleRat (-24) c
    exact ComplexRawQuotient.neg_scaleRat _ _
  rw [show (24:Rat)*16=384 by decide +kernel] at hn
  exact Small.congr (neg_valid (scaleRat_valid (tauLambertRegularCoefficientValue q hq).property))
    (discriminantEulerRegularCoefficient q hq).property he hn
/-- The actual divided discrepancy solves the equation with the constructed bounded coefficient. -/
theorem discriminantEulerDividedMap_boundedEquation (q : Scalar) (hq : discriminantEulerDividedMap.domain q) :
    (discriminantEulerDividedMap_holomorphic.derivative q hq).val.Equiv
      (mul (discriminantEulerRegularCoefficient q hq.2).val (discriminantEulerDividedMap.eval q hq).val) := by
  have hh := discriminantEulerDividedMap_regularCoefficient q hq
  have he : (scaleRat (-24) (mul (tauLambertRegularCoefficientValue q hq.2).val
      (discriminantEulerDividedMap.eval q hq).val)).Equiv
      (mul (discriminantEulerRegularCoefficient q hq.2).val (discriminantEulerDividedMap.eval q hq).val) := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := scaleRat_valid (mul_valid (tauLambertRegularCoefficientValue q hq.2).property
        (discriminantEulerDividedMap.eval q hq).property))
      (hright := mul_valid (discriminantEulerRegularCoefficient q hq.2).property
        (discriminantEulerDividedMap.eval q hq).property)
    let c := ComplexRawQuotient.ofRaw (tauLambertRegularCoefficientValue q hq.2).val (tauLambertRegularCoefficientValue q hq.2).property
    let k := ComplexRawQuotient.ofRaw (discriminantEulerDividedMap.eval q hq).val (discriminantEulerDividedMap.eval q hq).property
    change ComplexRawQuotient.scaleRat (-24) (c*k)=ComplexRawQuotient.scaleRat (-24) c*k
    exact ComplexRawQuotient.scaleRat_mul _ _ _
  exact equiv_trans (discriminantEulerDividedMap_holomorphic.derivative q hq).property
    (scaleRat_valid (mul_valid (tauLambertRegularCoefficientValue q hq.2).property (discriminantEulerDividedMap.eval q hq).property))
    (mul_valid (discriminantEulerRegularCoefficient q hq.2).property (discriminantEulerDividedMap.eval q hq).property) hh he
end ComputableAnalysis.ModularForms
