import ComputableAnalysis.ModularForms.Hecke41CommonSamplerBoundary
import ComputableAnalysis.ModularForms.SquareFrameSharedEdges

/-! Actual common-sampler square-frame cancellation and vanishing difference. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

theorem hecke41CommonFrame_uniform_depth (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : (squareFrameOuterRadius R).val≤
      ((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val) (eps : QPos) :
    ∃ N, ∀ n, N≤n → ∀ j l, squareFrameTileIndex j l →
      Small (rectangleGridBoundary (hecke41KernelSquareSample k a ha (squareFrameOuterRadius R) hR)
        (squareFrameTile R j l) (2^n)).val eps.val := by
  have h : ∀ j, j<4 → ∃ N, ∀ n, N≤n → ∀ l, l<4 → squareFrameTileIndex j l →
      Small (rectangleGridBoundary (hecke41KernelSquareSample k a ha (squareFrameOuterRadius R) hR)
        (squareFrameTile R j l) (2^n)).val eps.val := by
    intro j hj
    apply finite_eventual_depth
    intro l hl
    by_cases hf : squareFrameTileIndex j l
    · obtain ⟨N,hN⟩ := hecke41KernelSquareSample_boundary_converges_zero k a ha
        (squareFrameTile R j l) R (squareFrameOuterRadius R) (squareFrameTile_separated R j l hf)
        (squareFrameInterval_outer_bounds R j hj).1 (squareFrameInterval_outer_bounds R j hj).2
        (squareFrameInterval_outer_bounds R l hl).1 (squareFrameInterval_outer_bounds R l hl).2 hR
        (squareFrameTile_ordered R j l).1 (squareFrameTile_ordered R j l).2 eps
      exact ⟨N,fun n hn _ => hN n hn⟩
    · exact ⟨0,by intro n hn hh; exact False.elim (hf hh)⟩
  obtain ⟨N,hN⟩ := finite_eventual_depth _ 4 h
  exact ⟨N,fun n hn j l hf => hN n hn j hf.1 l hf.2.1 hf⟩

def hecke41CommonFrameBoundarySum (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : (squareFrameOuterRadius R).val≤
      ((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val) (n : Nat) : Scalar :=
  frameScalarSum (fun j l => rectangleGridBoundary
    (hecke41KernelSquareSample k a ha (squareFrameOuterRadius R) hR) (squareFrameTile R j l) (2^n))
    1 2 1 1 2 1

theorem hecke41CommonFrameBoundarySum_converges_zero (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : (squareFrameOuterRadius R).val≤
      ((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val) (eps : QPos) :
    ∃ N, ∀ n, N≤n → Small (hecke41CommonFrameBoundarySum k a ha R hR n).val eps.val := by
  let eta : QPos := ⟨eps.val/12,by
    rw [Rat.div_def]
    exact Rat.mul_pos eps.property (Rat.inv_pos.mpr (by decide +kernel))⟩
  obtain ⟨N,hN⟩ := hecke41CommonFrame_uniform_depth k a ha R hR eta
  refine ⟨N, ?_⟩
  intro n hn
  have hb := frameScalarSum_bound (fun j l => rectangleGridBoundary
    (hecke41KernelSquareSample k a ha (squareFrameOuterRadius R) hR) (squareFrameTile R j l) (2^n))
    1 2 1 1 2 1 eta.val (Rat.le_of_lt eta.property) (by
      intro j l hf
      have hi : squareFrameTileIndex j l := by
        unfold representedFrameCell at hf
        unfold squareFrameTileIndex
        omega
      exact hN n hn j l hi)
  have he : ((representedFrameCellCount 1 2 1 1 2 1:Nat):Rat)*eta.val=eps.val := by
    change 12*(eps.val/12)=eps.val
    grind only
  rw [he] at hb
  exact hb

def hecke41CommonFrameContourDifference (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : (squareFrameOuterRadius R).val≤
      ((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val) (n : Nat) : Scalar :=
  let f := hecke41KernelSquareSample k a ha (squareFrameOuterRadius R) hR
  gridScalarSub
    (frameScalarRectBoundary (squareFrameHorizontalEdge f R (2^n)) (squareFrameVerticalEdge f R (2^n)) 0 0 4 4)
    (frameScalarRectBoundary (squareFrameHorizontalEdge f R (2^n)) (squareFrameVerticalEdge f R (2^n)) 1 1 2 2)

theorem hecke41CommonFrameContourDifference_converges_zero (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : (squareFrameOuterRadius R).val≤
      ((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val) (eps : QPos) :
    ∃ N, ∀ n, N≤n → Small (hecke41CommonFrameContourDifference k a ha R hR n).val eps.val := by
  obtain ⟨N,hN⟩ := hecke41CommonFrameBoundarySum_converges_zero k a ha R hR eps
  refine ⟨N, ?_⟩
  intro n hn
  exact Small.congr (hecke41CommonFrameBoundarySum k a ha R hR n).property
    (hecke41CommonFrameContourDifference k a ha R hR n).property
    (squareFrame_tiled_boundary_agreement
      (hecke41KernelSquareSample k a ha (squareFrameOuterRadius R) hR) R (2^n)
      (Nat.pow_pos (by decide +kernel))) (hN n hn)

end ComputableAnalysis.ModularForms
