import ComputableAnalysis.ModularForms.ContinuousSimplePoleSquareAverage
import ComputableAnalysis.ModularForms.SimplePoleCentralQuadrature

namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem continuousSimplePoleCentralEdge_midpoint (F : DomainFunctions.Map) (hop : OpenDomain F) (a : Scalar)
    (ha : F.domain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val ≤ (hop.radius a ha).val) (M : Nat) (hM : 0<M) :
    (continuousSimplePoleEdgeAverage true F hop a ha edge R hR M hM).val.Equiv
      (weightedMidpointSum (fun u => scalarProduct (F.eval a ha)
        (rationalRectangleScalar (simplePolePullback edge R.val u))) M ((M:Rat)⁻¹)).val := by
  apply representedScale_congr
  apply gridScalarSum_congr_on_indices
  intro j hj
  dsimp only [continuousSimplePoleEdgeAverage]
  simp only [↓reduceIte,Nat.mod_eq_of_lt hj]
  exact equiv_refl _ (scalarProduct (F.eval a ha)
    (rationalRectangleScalar (simplePolePullback edge R.val (squareMidpointParameter M j)))).property

theorem continuousSimplePoleCentralContour_midpoint (F : DomainFunctions.Map) (hop : OpenDomain F) (a : Scalar)
    (ha : F.domain a) (R : QPos)
    (hR : R.val ≤ (hop.radius a ha).val) (M : Nat) (hM : 0<M)
    (es : List HalfEdge) :
    (continuousSimplePoleFiniteContour true F hop a ha R hR M hM es).val.Equiv
      (weightedMidpointSum (fun u => poleCoefficientEdgeList
        (F.eval a ha)
        (fun e => simplePolePullback e R.val u) es) M ((M:Rat)⁻¹)).val := by
  induction es with
  | nil =>
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := (continuousSimplePoleFiniteContour true F hop a ha R hR M hM []).property)
      (hright := (weightedMidpointSum (fun u => poleCoefficientEdgeList
        (F.eval a ha) (fun e => simplePolePullback e R.val u) [])
        M ((M:Rat)⁻¹)).property)
    change (0:ScalarAlgebra.Value)=ComplexRawQuotient.scaleRat ((M:Rat)⁻¹)
      (gridScalarValue (gridScalarSum M (fun _ => ⟨zero,ofQComplex_valid _⟩)))
    rw [gridScalarSum_value]
    change (0:ScalarAlgebra.Value)=ComplexRawQuotient.scaleRat ((M:Rat)⁻¹) (gridValueSum M (fun _ => 0))
    rw [gridValueSum_zero]
    exact (ComplexRawQuotient.scaleRat_zero _).symm
  | cons e es ih =>
    let f := fun u => scalarProduct (F.eval a ha)
      (rationalRectangleScalar (simplePolePullback e R.val u))
    let g := fun u => poleCoefficientEdgeList (F.eval a ha)
      (fun e => simplePolePullback e R.val u) es
    have hh := continuousSimplePoleCentralEdge_midpoint F hop a ha e R hR M hM
    have h := add_equiv hh ih
    exact equiv_trans (continuousSimplePoleFiniteContour true F hop a ha R hR M hM (e::es)).property
      (scalarSum (weightedMidpointSum f M ((M:Rat)⁻¹)) (weightedMidpointSum g M ((M:Rat)⁻¹))).property
      (weightedMidpointSum (fun u => scalarSum (f u) (g u)) M ((M:Rat)⁻¹)).property h
      (weightedMidpointSum_add f g M ((M:Rat)⁻¹))

/-- The actual center-value finite square contour has its exact represented residue. -/
theorem continuousSimplePoleCentralSquare_residue (F : DomainFunctions.Map)
    (hop : OpenDomain F) (a : Scalar) (ha : F.domain a) (R : QPos)
    (hR : R.val ≤ (hop.radius a ha).val) (M : Nat) (hM : 0 < M) :
    (continuousSimplePoleFiniteContour true F hop a ha R hR M hM square).val.Equiv
      (scalarProduct (F.eval a ha) (squareResidueMidpointSum M)).val := by
  exact equiv_trans (continuousSimplePoleFiniteContour true F hop a ha R hR M hM square).property
    (weightedMidpointSum (fun u => poleCoefficientEdgeList (F.eval a ha)
      (fun e => simplePolePullback e R.val u) square) M ((M:Rat)⁻¹)).property
    (scalarProduct (F.eval a ha) (squareResidueMidpointSum M)).property
    (continuousSimplePoleCentralContour_midpoint F hop a ha R hR M hM square)
    (simplePoleCentralSquare_midpoint_residue (F.eval a ha) R M)

/-- A single refinement depth controls every admissible radius of the actual central square. -/
theorem continuousSimplePoleCentralSquare_uniform_convergence (F : DomainFunctions.Map)
    (hop : OpenDomain F) (a : Scalar) (ha : F.domain a) (eps : QPos) :
    ∃ N, ∀ n, N ≤ n → ∀ (R : QPos) (hR : R.val ≤ (hop.radius a ha).val),
      Small (sub (scalarProduct (F.eval a ha) ⟨twoPiI,twoPiI_valid⟩).val
        (continuousSimplePoleFiniteContour true F hop a ha R hR (2^n)
          (Nat.pow_pos (by decide +kernel)) square).val) eps.val := by
  obtain ⟨N,hN⟩ := suppliedDerivativeResidue_converges (F.eval a ha) eps
  refine ⟨N,?_⟩
  intro n hn R hR
  let V := scalarProduct (F.eval a ha) ⟨twoPiI,twoPiI_valid⟩
  let S := scalarProduct (F.eval a ha) (squareResidueMidpointSum (2^n))
  let Q := continuousSimplePoleFiniteContour true F hop a ha R hR (2^n)
    (Nat.pow_pos (by decide +kernel)) square
  have he := FunctionTheory.sub_congr (equiv_refl _ V.property)
    (equiv_symm (continuousSimplePoleCentralSquare_residue F hop a ha R hR (2^n)
      (Nat.pow_pos (by decide +kernel))))
  exact Small.congr (sub_valid V.property S.property) (sub_valid V.property Q.property) he (hN n hn)

end ComputableAnalysis.ModularForms
