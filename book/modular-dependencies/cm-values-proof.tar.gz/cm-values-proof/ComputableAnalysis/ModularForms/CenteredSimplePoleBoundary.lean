import ComputableAnalysis.ModularForms.SimplePoleRepresentedRectangleDomain
import ComputableAnalysis.ModularForms.HolomorphicRectangleBoundaryVanishing

namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

/-- Entire affine translation agrees exactly with represented addition. -/
theorem simplePoleAffine_translation (a w : Scalar) :
    ((DomainFunctions.affine a oneScalar).eval w trivial).val.Equiv (Centered.translate a w).val := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := ((DomainFunctions.affine a oneScalar).eval w trivial).property) (hright := (Centered.translate a w).property)
  change gridScalarValue a+1*gridScalarValue w=gridScalarValue a+gridScalarValue w
  grind only

def centeredSimplePoleIntegrand (F : DomainFunctions.Map) (hf : Holomorphic F) (a : Scalar) :
    DomainFunctions.Map := compose (holomorphicSimplePoleIntegrand F hf a) (DomainFunctions.affine a oneScalar)

def centeredSimplePoleIntegrand_holomorphic (F : DomainFunctions.Map) (hf : Holomorphic F) (a : Scalar) :
    Holomorphic (centeredSimplePoleIntegrand F hf a) :=
  (holomorphicSimplePoleIntegrand_holomorphic F hf a).compose (affine_holomorphic a oneScalar)

/-- The centered analytic evaluator covers every represented point of a separated rectangle. -/
theorem centeredSimplePole_rectangle_domain (F : DomainFunctions.Map) (hf : Holomorphic F)
    (a : Scalar) (ha : F.domain a) (J : QInterval × QInterval) (R B : QPos)
    (hs : rectangleSeparated J R)
    (hxl : -B.val ≤ J.1.lo) (hxu : J.1.hi ≤ B.val)
    (hyl : -B.val ≤ J.2.lo) (hyu : J.2.hi ≤ B.val)
    (hB : B.val ≤ (hf.openDomain.radius a ha).val)
    (w : Scalar) (hw : representedRectangleContains J w) :
    (centeredSimplePoleIntegrand F hf a).domain w := by
  have hd := simplePoleIntegrand_rectangle_domain F hf a ha J R B hs hxl hxu hyl hyu hB w hw
  refine ⟨trivial,?_⟩
  exact ((holomorphicSimplePoleIntegrand F hf a).domain_congr _ _
    (equiv_symm (simplePoleAffine_translation a w))).mp hd

/-- Actual centered simple-pole rectangle boundary sums converge to zero,
with the full represented rectangle domain proved rather than supplied. -/
theorem centeredSimplePole_rectangle_boundary_zero (F : DomainFunctions.Map) (hf : Holomorphic F)
    (a : Scalar) (ha : F.domain a) (J : QInterval × QInterval) (R B : QPos)
    (hs : rectangleSeparated J R)
    (hxl : -B.val ≤ J.1.lo) (hxu : J.1.hi ≤ B.val)
    (hyl : -B.val ≤ J.2.lo) (hyu : J.2.hi ≤ B.val)
    (hB : B.val ≤ (hf.openDomain.radius a ha).val)
    (hX : J.1.lo ≤ J.1.hi) (hY : J.2.lo ≤ J.2.hi) (eps : QPos) :
    ∃ N, ∀ n, N ≤ n → Small
      (holomorphicRectangleGridBoundary (centeredSimplePoleIntegrand F hf a)
        (centeredSimplePoleIntegrand_holomorphic F hf a) J
        (centeredSimplePole_rectangle_domain F hf a ha J R B hs hxl hxu hyl hyu hB) n).val eps.val :=
  holomorphicRectangleGridBoundary_converges_zero _ _ J
    (centeredSimplePole_rectangle_domain F hf a ha J R B hs hxl hxu hyl hyu hB) hX hY eps

end ComputableAnalysis.ModularForms
