import ComputableAnalysis.ModularForms.Hecke41KernelSquareSampler
import ComputableAnalysis.ModularForms.RectangleDyadicBoundaryAgreement

/-! Actual common-square boundary vanishing on justified separated rectangles. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

theorem hecke41KernelSquareSample_boundary_converges_zero (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (J : QInterval × QInterval) (R B : QPos) (hs : rectangleSeparated J R)
    (hxl : -B.val≤J.1.lo) (hxu : J.1.hi≤B.val)
    (hyl : -B.val≤J.2.lo) (hyu : J.2.hi≤B.val)
    (hB : B.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (hX : J.1.lo≤J.1.hi) (hY : J.2.lo≤J.2.hi) (eps : QPos) :
    ∃ N, ∀ n, N≤n → Small
      (rectangleGridBoundary (hecke41KernelSquareSample k a ha B hB) J (2^n)).val eps.val := by
  obtain ⟨N,hN⟩ := hecke41KernelGridBoundary_converges_zero k a ha J R B hs hxl hxu hyl hyu hB hX hY eps
  refine ⟨N, ?_⟩
  intro n hn
  have he := rectangleDyadicBoundary_congr
    (hecke41KernelSquareSample k a ha B hB)
    (hecke41KernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB) J hX hY
    (hecke41KernelSquareSample_rectangle_agreement k a ha J R B hs hxl hxu hyl hyu hB) n
  exact Small.congr (hecke41KernelGridBoundary k a ha J R B hs hxl hxu hyl hyu hB n).property
    (rectangleGridBoundary (hecke41KernelSquareSample k a ha B hB) J (2^n)).property
    (equiv_symm he) (hN n hn)

end ComputableAnalysis.ModularForms
