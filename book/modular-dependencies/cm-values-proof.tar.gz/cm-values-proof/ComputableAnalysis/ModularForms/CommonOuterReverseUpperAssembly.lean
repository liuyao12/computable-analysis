import ComputableAnalysis.ModularForms.CommonOuterSquareTopSamples
import ComputableAnalysis.ModularForms.CommonOuterSquareLeftSamples
import ComputableAnalysis.ModularForms.CommonOuterRightLowerAssembly

/-! Reflected midpoint assembly of the outer top and left upper halves. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem commonNegativeReflectedAverage_agreement (f : QComplex → Scalar)
    (edge : HalfEdge) (S : QPos) (M : Nat) (hM : 0<M) :
    (weightedMidpointSum (fun u => commonSquareEdgeDensity f edge S (1-u))
      M (-(1/(M:Rat)))).val.Equiv
      (neg (commonSquareKernelAverage f edge S M).val) := by
  let d := fun v => commonSquareEdgeDensity f edge S (1-squareMidpointParameter M v)
  exact equiv_trans
    (weightedMidpointSum (fun u => commonSquareEdgeDensity f edge S (1-u)) M (-(1/(M:Rat)))).property
    (neg_valid (commonReflectedSquareAverage f edge S M).property)
    (neg_valid (commonSquareKernelAverage f edge S M).property)
    (negativeScale_equiv_negScale (gridScalarSum M d) (1/(M:Rat)))
    (neg_equiv (commonReflectedSquareAverage_agreement f edge S M hM))

theorem common_outer_top_upper_average (f : QComplex → Scalar) (R : QPos)
    (M : Nat) (hM : 0<M) :
    (scalarSum (squareFrameHorizontalEdge f R M 0 4) (squareFrameHorizontalEdge f R M 1 4)).val.Equiv
      (neg (commonSquareKernelAverage f ⟨.north,true⟩ (squareFrameOuterRadius R) (2*M)).val) := by
  have h0 := common_outer_top_tile_average f R M 0 hM
  have h1 := common_outer_top_tile_average f R M 1 hM
  have p0 (u : Rat) : (2-((0:Nat):Rat)-u)/2=1-u/2 := by
    change (2-0-u)/2=1-u/2
    grind only
  have p1 (u : Rat) : (2-((1:Nat):Rat)-u)/2=1-(1+u)/2 := by
    change (2-1-u)/2=1-(1+u)/2
    grind only
  have hr : -1/(2*(M:Rat))= -(1/((2*M:Nat):Rat)) := by
    rw [Rat.natCast_mul]
    change -1/(2*(M:Rat))= -(1/(2*(M:Rat)))
    grind only [Rat.div_def]
  simp only [p0,hr] at h0
  simp only [p1,hr] at h1
  let A := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.north,true⟩
    (squareFrameOuterRadius R) (1-u/2)) M (-(1/((2*M:Nat):Rat)))
  let B := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.north,true⟩
    (squareFrameOuterRadius R) (1-(1+u)/2)) M (-(1/((2*M:Nat):Rat)))
  let C := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.north,true⟩
    (squareFrameOuterRadius R) (1-u)) (2*M) (-(1/((2*M:Nat):Rat)))
  have hc := weightedSquareMidpointSum_concat (fun u => commonSquareEdgeDensity f ⟨.north,true⟩
    (squareFrameOuterRadius R) (1-u)) M hM (-(1/((2*M:Nat):Rat)))
  exact equiv_trans (scalarSum (squareFrameHorizontalEdge f R M 0 4) (squareFrameHorizontalEdge f R M 1 4)).property
    (scalarSum A B).property
    (neg_valid (commonSquareKernelAverage f ⟨.north,true⟩ (squareFrameOuterRadius R) (2*M)).property)
    (add_equiv h0 h1)
    (equiv_trans (scalarSum A B).property C.property
      (neg_valid (commonSquareKernelAverage f ⟨.north,true⟩ (squareFrameOuterRadius R) (2*M)).property)
      hc (commonNegativeReflectedAverage_agreement f ⟨.north,true⟩ (squareFrameOuterRadius R) (2*M) (by omega)))

theorem common_outer_left_upper_average (f : QComplex → Scalar) (R : QPos)
    (M : Nat) (hM : 0<M) :
    (scalarSum (squareFrameVerticalEdge f R M 0 0) (squareFrameVerticalEdge f R M 0 1)).val.Equiv
      (neg (commonSquareKernelAverage f ⟨.west,true⟩ (squareFrameOuterRadius R) (2*M)).val) := by
  have h0 := common_outer_left_tile_average f R M 0 hM
  have h1 := common_outer_left_tile_average f R M 1 hM
  have p0 (u : Rat) : (2-((0:Nat):Rat)-u)/2=1-u/2 := by
    change (2-0-u)/2=1-u/2
    grind only
  have p1 (u : Rat) : (2-((1:Nat):Rat)-u)/2=1-(1+u)/2 := by
    change (2-1-u)/2=1-(1+u)/2
    grind only
  have hr : -1/(2*(M:Rat))= -(1/((2*M:Nat):Rat)) := by
    rw [Rat.natCast_mul]
    change -1/(2*(M:Rat))= -(1/(2*(M:Rat)))
    grind only [Rat.div_def]
  simp only [p0,hr] at h0
  simp only [p1,hr] at h1
  let A := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.west,true⟩
    (squareFrameOuterRadius R) (1-u/2)) M (-(1/((2*M:Nat):Rat)))
  let B := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.west,true⟩
    (squareFrameOuterRadius R) (1-(1+u)/2)) M (-(1/((2*M:Nat):Rat)))
  let C := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.west,true⟩
    (squareFrameOuterRadius R) (1-u)) (2*M) (-(1/((2*M:Nat):Rat)))
  have hc := weightedSquareMidpointSum_concat (fun u => commonSquareEdgeDensity f ⟨.west,true⟩
    (squareFrameOuterRadius R) (1-u)) M hM (-(1/((2*M:Nat):Rat)))
  exact equiv_trans (scalarSum (squareFrameVerticalEdge f R M 0 0) (squareFrameVerticalEdge f R M 0 1)).property
    (scalarSum A B).property
    (neg_valid (commonSquareKernelAverage f ⟨.west,true⟩ (squareFrameOuterRadius R) (2*M)).property)
    (add_equiv h0 h1)
    (equiv_trans (scalarSum A B).property C.property
      (neg_valid (commonSquareKernelAverage f ⟨.west,true⟩ (squareFrameOuterRadius R) (2*M)).property)
      hc (commonNegativeReflectedAverage_agreement f ⟨.west,true⟩ (squareFrameOuterRadius R) (2*M) (by omega)))

end ComputableAnalysis.ModularForms
