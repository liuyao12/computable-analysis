import ComputableAnalysis.ModularForms.CommonOuterReverseUpperAssembly

/-! Doubled-grid concatenation of the remaining outer lower halves. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem commonSquareLower_signed_sample (f : QComplex → Scalar) (quarter : Quarter)
    (S : QPos) (u r : Rat) :
    (scaleRat (-r) (commonSquareEdgeDensity f ⟨quarter,true⟩ S (-u)).val).Equiv
      (scaleRat r (commonSquareEdgeDensity f ⟨quarter,false⟩ S u).val) := by
  have hp : point ⟨quarter,true⟩ (-u)=point ⟨quarter,false⟩ u := by
    cases quarter <;> simp only [point,rotation,orientation,Bool.false_eq_true,↓reduceIte,
      QComplex.mul,QComplex.mk.injEq] <;> constructor <;> grind only
  have hv : QComplex.scaleRat S.val (velocity ⟨quarter,false⟩)=
      QComplex.scaleRat (-1) (QComplex.scaleRat S.val (velocity ⟨quarter,true⟩)) := by
    cases quarter <;> simp only [velocity,rotation,orientation,Bool.false_eq_true,↓reduceIte,
      QComplex.mul,QComplex.scaleRat,QComplex.mk.injEq] <;> constructor <;> grind only
  unfold commonSquareEdgeDensity
  rw [hp,hv]
  have h := weightedSample_signed_scale
    (f (QComplex.scaleRat S.val (point ⟨quarter,false⟩ u)))
    (QComplex.scaleRat S.val (velocity ⟨quarter,true⟩)) (-r)
  simpa only [Rat.neg_neg] using h

theorem commonSquareLower_signed_average (f : QComplex → Scalar) (quarter : Quarter)
    (S : QPos) (M : Nat) :
    (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨quarter,true⟩ S (-u))
      M (-(1/(M:Rat)))).val.Equiv
      (commonSquareKernelAverage f ⟨quarter,false⟩ S M).val := by
  let r := 1/(M:Rat)
  let d := fun v => commonSquareEdgeDensity f ⟨quarter,true⟩ S (-squareMidpointParameter M v)
  let e := fun v => commonSquareEdgeDensity f ⟨quarter,false⟩ S (squareMidpointParameter M v)
  let A := fun v => (⟨scaleRat (-r) (d v).val,scaleRat_valid (d v).property⟩ : Scalar)
  let B := fun v => (⟨scaleRat r (e v).val,scaleRat_valid (e v).property⟩ : Scalar)
  have hs := gridScalarSum_congr M A B
    (fun v => commonSquareLower_signed_sample f quarter S (squareMidpointParameter M v) r)
  exact equiv_trans (scaleRat_valid (gridScalarSum M d).property)
    (gridScalarSum M A).property (commonSquareKernelAverage f ⟨quarter,false⟩ S M).property
    (equiv_symm (gridScalarSum_scale (-r) d M))
    (equiv_trans (gridScalarSum M A).property (gridScalarSum M B).property
      (commonSquareKernelAverage f ⟨quarter,false⟩ S M).property hs (gridScalarSum_scale r e M))

theorem common_outer_top_lower_concatenation (f : QComplex → Scalar) (R : QPos)
    (M : Nat) (hM : 0<M) :
    (scalarSum (squareFrameHorizontalEdge f R M 2 4) (squareFrameHorizontalEdge f R M 3 4)).val.Equiv
      (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.north,true⟩
        (squareFrameOuterRadius R) (-u)) (2*M) (-(1/((2*M:Nat):Rat)))).val := by
  have h0 := common_outer_top_tile_average f R M 2 hM
  have h1 := common_outer_top_tile_average f R M 3 hM
  have p0 (u : Rat) : (2-((2:Nat):Rat)-u)/2= -(u/2) := by
    change (2-2-u)/2= -(u/2)
    grind only [Rat.div_def]
  have p1 (u : Rat) : (2-((3:Nat):Rat)-u)/2= -((1+u)/2) := by
    change (2-3-u)/2= -((1+u)/2)
    grind only [Rat.div_def]
  have hr : -1/(2*(M:Rat))= -(1/((2*M:Nat):Rat)) := by
    rw [Rat.natCast_mul]
    change -1/(2*(M:Rat))= -(1/(2*(M:Rat)))
    grind only [Rat.div_def]
  simp only [p0,hr] at h0
  simp only [p1,hr] at h1
  let A := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.north,true⟩
    (squareFrameOuterRadius R) (-(u/2))) M (-(1/((2*M:Nat):Rat)))
  let B := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.north,true⟩
    (squareFrameOuterRadius R) (-((1+u)/2))) M (-(1/((2*M:Nat):Rat)))
  let C := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.north,true⟩
    (squareFrameOuterRadius R) (-u)) (2*M) (-(1/((2*M:Nat):Rat)))
  exact equiv_trans (scalarSum (squareFrameHorizontalEdge f R M 2 4) (squareFrameHorizontalEdge f R M 3 4)).property
    (scalarSum A B).property C.property (add_equiv h0 h1)
    (weightedSquareMidpointSum_concat (fun u => commonSquareEdgeDensity f ⟨.north,true⟩
      (squareFrameOuterRadius R) (-u)) M hM _)

theorem common_outer_left_lower_concatenation (f : QComplex → Scalar) (R : QPos)
    (M : Nat) (hM : 0<M) :
    (scalarSum (squareFrameVerticalEdge f R M 0 2) (squareFrameVerticalEdge f R M 0 3)).val.Equiv
      (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.west,true⟩
        (squareFrameOuterRadius R) (-u)) (2*M) (-(1/((2*M:Nat):Rat)))).val := by
  have h0 := common_outer_left_tile_average f R M 2 hM
  have h1 := common_outer_left_tile_average f R M 3 hM
  have p0 (u : Rat) : (2-((2:Nat):Rat)-u)/2= -(u/2) := by
    change (2-2-u)/2= -(u/2)
    grind only [Rat.div_def]
  have p1 (u : Rat) : (2-((3:Nat):Rat)-u)/2= -((1+u)/2) := by
    change (2-3-u)/2= -((1+u)/2)
    grind only [Rat.div_def]
  have hr : -1/(2*(M:Rat))= -(1/((2*M:Nat):Rat)) := by
    rw [Rat.natCast_mul]
    change -1/(2*(M:Rat))= -(1/(2*(M:Rat)))
    grind only [Rat.div_def]
  simp only [p0,hr] at h0
  simp only [p1,hr] at h1
  let A := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.west,true⟩
    (squareFrameOuterRadius R) (-(u/2))) M (-(1/((2*M:Nat):Rat)))
  let B := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.west,true⟩
    (squareFrameOuterRadius R) (-((1+u)/2))) M (-(1/((2*M:Nat):Rat)))
  let C := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.west,true⟩
    (squareFrameOuterRadius R) (-u)) (2*M) (-(1/((2*M:Nat):Rat)))
  exact equiv_trans (scalarSum (squareFrameVerticalEdge f R M 0 2) (squareFrameVerticalEdge f R M 0 3)).property
    (scalarSum A B).property C.property (add_equiv h0 h1)
    (weightedSquareMidpointSum_concat (fun u => commonSquareEdgeDensity f ⟨.west,true⟩
      (squareFrameOuterRadius R) (-u)) M hM _)

theorem common_outer_top_lower_average (f : QComplex → Scalar) (R : QPos)
    (M : Nat) (hM : 0<M) :
    (scalarSum (squareFrameHorizontalEdge f R M 2 4) (squareFrameHorizontalEdge f R M 3 4)).val.Equiv
      (commonSquareKernelAverage f ⟨.north,false⟩ (squareFrameOuterRadius R) (2*M)).val := by
  let C := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.north,true⟩
    (squareFrameOuterRadius R) (-u)) (2*M) (-(1/((2*M:Nat):Rat)))
  exact equiv_trans (scalarSum (squareFrameHorizontalEdge f R M 2 4) (squareFrameHorizontalEdge f R M 3 4)).property C.property
    (commonSquareKernelAverage f ⟨.north,false⟩ (squareFrameOuterRadius R) (2*M)).property
    (common_outer_top_lower_concatenation f R M hM)
    (commonSquareLower_signed_average f .north (squareFrameOuterRadius R) (2*M))

theorem common_outer_left_lower_average (f : QComplex → Scalar) (R : QPos)
    (M : Nat) (hM : 0<M) :
    (scalarSum (squareFrameVerticalEdge f R M 0 2) (squareFrameVerticalEdge f R M 0 3)).val.Equiv
      (commonSquareKernelAverage f ⟨.west,false⟩ (squareFrameOuterRadius R) (2*M)).val := by
  let C := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.west,true⟩
    (squareFrameOuterRadius R) (-u)) (2*M) (-(1/((2*M:Nat):Rat)))
  exact equiv_trans (scalarSum (squareFrameVerticalEdge f R M 0 2) (squareFrameVerticalEdge f R M 0 3)).property C.property
    (commonSquareKernelAverage f ⟨.west,false⟩ (squareFrameOuterRadius R) (2*M)).property
    (common_outer_left_lower_concatenation f R M hM)
    (commonSquareLower_signed_average f .west (squareFrameOuterRadius R) (2*M))

end ComputableAnalysis.ModularForms
