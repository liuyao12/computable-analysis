import ComputableAnalysis.ModularForms.Hecke41DiagonalCandidateData

namespace ComputableAnalysis.ModularForms
open RiemannHilbert

private theorem shift_class (p : List Int) (X : ScalarAlgebra.Value) :
    integerPolynomialClass (0::p) X=X*integerPolynomialClass p X := by
  change ComplexRawQuotient.scaleRat ((0:Int):Rat) 1+X*integerPolynomialClass p X=_
  rw [show ((0:Int):Rat)=0 by decide +kernel,ComplexRawQuotient.scaleRat_zeroScalar]
  grind only

private theorem scale_class (p : List Int) (a : Int) (X : ScalarAlgebra.Value) :
    integerPolynomialClass (p.map (fun b => a*b)) X=
      (a:ScalarAlgebra.Value)*integerPolynomialClass p X := by
  induction p with
  | nil => change (0:ScalarAlgebra.Value)=(a:ScalarAlgebra.Value)*0; grind only
  | cons b p ih =>
    change ((a*b:Int):ScalarAlgebra.Value)+X*integerPolynomialClass (p.map (fun b => a*b)) X=
      (a:ScalarAlgebra.Value)*((b:ScalarAlgebra.Value)+X*integerPolynomialClass p X)
    rw [ih]; grind

/-- The checked finite squared-factor identity evaluates exactly at every
represented complex value. -/
theorem hecke41DiagonalCandidate_factor_class (X : ScalarAlgebra.Value) :
    integerPolynomialClass hecke41DiagonalCandidate X=
      (X-((-(640320:Int)^3):ScalarAlgebra.Value))^2*
        integerPolynomialClass hecke41DiagonalCandidateQuotient X := by
  rw [hecke41DiagonalCandidate_factorization]
  unfold hecke41DiagonalCandidateFactorPolynomial
  dsimp only
  rw [integerPolynomialAdd_class,integerPolynomialAdd_class,
    shift_class,shift_class,shift_class,scale_class,scale_class]
  grind only

end ComputableAnalysis.ModularForms
