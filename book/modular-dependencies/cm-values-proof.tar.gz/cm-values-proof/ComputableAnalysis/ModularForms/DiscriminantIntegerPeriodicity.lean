import ComputableAnalysis.ModularForms.DiscriminantHeckeOperator
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- Integer translates of the actual normalized discriminant agree on the full upper half-plane. -/
theorem normalizedLatticeDiscriminantMap_integer_periodic (z : Scalar)
    (hz : InUpperHalfPlane z.val) (k : Int) :
    (normalizedLatticeDiscriminantMap.eval ⟨translate (k:Rat) z.val,translate_valid _ z.property⟩
      (translate_mem _ hz)).val.Equiv (normalizedLatticeDiscriminantMap.eval z hz).val := by
  let g : SL2Z := ⟨1,k,0,1,by grind only⟩
  let w : Scalar := ⟨translate (k:Rat) z.val,translate_valid _ z.property⟩
  have hw : InUpperHalfPlane w.val := translate_mem _ hz
  have hg : (fractionalLinear g z hz).val.Equiv w.val := by
    apply fractionalLinear_unique g z hz w
    have hd := integerAffine_zero 1 z
    have hn := integerAffine_one k z
    have hm := mul_equiv (integerAffine_valid 0 1 z.property) (ofQComplex_valid _)
      w.property w.property hd (equiv_refl _ w.property)
    exact equiv_trans (mul_valid (integerAffine_valid _ _ z.property) w.property)
      (mul_valid (ofQComplex_valid _) w.property) (integerAffine_valid _ _ z.property)
      hm (equiv_trans (mul_valid (ofQComplex_valid _) w.property) w.property
        (integerAffine_valid _ _ z.property) (one_mul_equiv _ w.property) (equiv_symm hn))
  have ht := normalizedLatticeDiscriminantMap_action g z hz
  have he := normalizedLatticeDiscriminantMap.eval_congr _ _ (fractionalLinear_mem g z hz) hw hg
  have hfactor := LocalODE.power_congr (integerAffine 0 1 z.val) one (integerAffine_valid 0 1 z.property) (ofQComplex_valid _)
    (integerAffine_zero 1 z) 12
  have hprod := mul_equiv (LocalODE.power_valid _ (integerAffine_valid 0 1 z.property) 12)
    (LocalODE.power_valid _ (ofQComplex_valid _) 12) (normalizedLatticeDiscriminantMap.eval z hz).property
    (normalizedLatticeDiscriminantMap.eval z hz).property hfactor
    (equiv_refl _ (normalizedLatticeDiscriminantMap.eval z hz).property)
  have hu : (mul (LocalODE.power one 12) (normalizedLatticeDiscriminantMap.eval z hz).val).Equiv
      (normalizedLatticeDiscriminantMap.eval z hz).val := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := mul_valid (LocalODE.power_valid _ (ofQComplex_valid _) 12)
        (normalizedLatticeDiscriminantMap.eval z hz).property)
      (hright := (normalizedLatticeDiscriminantMap.eval z hz).property)
    rw [ComplexRawQuotient.ofRaw_mul,ScalarAlgebra.ofRaw_power]
    change (1:ComplexRawQuotient.Value)^12 * _ = _
    grind only
    exact LocalODE.power_valid _ (ofQComplex_valid _) 12
    exact (normalizedLatticeDiscriminantMap.eval z hz).property
  exact equiv_trans (normalizedLatticeDiscriminantMap.eval w hw).property
    (normalizedLatticeDiscriminantMap.eval (fractionalLinear g z hz) (fractionalLinear_mem g z hz)).property
    (normalizedLatticeDiscriminantMap.eval z hz).property (equiv_symm he)
    (equiv_trans
      (normalizedLatticeDiscriminantMap.eval (fractionalLinear g z hz) (fractionalLinear_mem g z hz)).property
      (mul_valid (LocalODE.power_valid _ (integerAffine_valid 0 1 z.property) 12)
        (normalizedLatticeDiscriminantMap.eval z hz).property)
      (normalizedLatticeDiscriminantMap.eval z hz).property ht
      (equiv_trans
        (mul_valid (LocalODE.power_valid _ (integerAffine_valid 0 1 z.property) 12)
          (normalizedLatticeDiscriminantMap.eval z hz).property)
        (mul_valid (LocalODE.power_valid _ (ofQComplex_valid _) 12)
          (normalizedLatticeDiscriminantMap.eval z hz).property)
        (normalizedLatticeDiscriminantMap.eval z hz).property hprod hu))
end ComputableAnalysis.ModularForms
