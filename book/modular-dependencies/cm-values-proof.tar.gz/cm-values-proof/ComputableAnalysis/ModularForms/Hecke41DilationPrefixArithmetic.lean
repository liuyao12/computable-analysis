import ComputableAnalysis.ModularForms.Hecke41WeightedJPackedAgreement
import ComputableAnalysis.ModularForms.IntegerSeriesImpulseProduct

namespace ComputableAnalysis.ModularForms
open PackedIntegerPolynomialProduct

/-- The first two actual weighted-j coefficients, recovered from the checked
finite quotient witness. -/
theorem integerJWeightedCoefficients_first_two :
    integerJWeightedCoefficients 0=1 ∧ integerJWeightedCoefficients 1=744 := by
  constructor
  · rw [← hecke41WeightedJ_coefficient_actual 0 (by decide)]
    decide +kernel
  · rw [← hecke41WeightedJ_coefficient_actual 1 (by decide)]
    decide +kernel

/-- Only two coefficients of the Hecke dilation occur in the required prefix. -/
theorem integerHeckeDilation_prefix_arithmetic (n : Nat) (hn : n<1723) :
    (if n%1681=0 then integerJWeightedCoefficients (n/1681) else 0)=
      (if n=0 then (1:Int) else 0)+(if n=1681 then (744:Int) else 0) := by
  obtain ⟨h0,h1⟩ := integerJWeightedCoefficients_first_two
  by_cases hz : n=0
  · subst n; simp [h0]
  by_cases hm : n=1681
  · subst n; simp [h1]
  have hr : n%1681≠0 := by omega
  simp only [if_neg hz,if_neg hm,if_neg hr,Int.zero_add]

/-- Every required dilation convolution is a sum of two actual Newton
coefficient queries; no later dilation coefficients enter the result. -/
theorem integerHeckeDilation_product_prefix_arithmetic (b : Coefficients)
    (n : Nat) (hn : n<1723) :
    integerSeriesProduct
      (fun i => if i%1681=0 then integerJWeightedCoefficients (i/1681) else 0) b n=
      b n+(if 1681≤n then (744:Int)*b (n-1681) else 0) := by
  rw [integerSeriesProduct_two_impulses_prefix _ b 1 744 0 1681 1723
    integerHeckeDilation_prefix_arithmetic n hn]
  simp

end ComputableAnalysis.ModularForms
