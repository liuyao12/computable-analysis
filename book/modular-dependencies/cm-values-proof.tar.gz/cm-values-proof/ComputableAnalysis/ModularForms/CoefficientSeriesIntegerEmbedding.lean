import ComputableAnalysis.ModularForms.CoefficientSeriesRing

namespace ComputableAnalysis.ModularForms.CoefficientConvolutionAlgebra
attribute [local instance] Lean.Grind.Semiring.natCast Lean.Grind.Ring.intCast
variable {R : Type} [Lean.Grind.CommRing R]

/-- Canonical integer embedding at every literal coefficient degree. -/
def integerEmbedding (a : Value Int) : Value R := ⟨fun n => Int.cast (a.coefficient n)⟩

private theorem product_integer_cast (a b : Series Int) (n : Nat) :
    product (fun i => (Int.cast (a i):R)) (fun i => (Int.cast (b i):R)) n=
      Int.cast (product a b n) := by
  induction n generalizing a with
  | zero => change (Int.cast (a 0):R)*Int.cast (b 0)=Int.cast (a 0*b 0); rw [Lean.Grind.Ring.intCast_mul]
  | succ n ih =>
    change (Int.cast (a 0):R)*Int.cast (b (n+1))+
      product (fun i => (Int.cast (a (i+1)):R)) (fun i => (Int.cast (b i):R)) n=
      Int.cast (a 0*b (n+1)+product (tail a) b n)
    rw [Lean.Grind.Ring.intCast_add,Lean.Grind.Ring.intCast_mul]
    have h := ih (tail a)
    dsimp only [tail] at h
    rw [h]

theorem integerEmbedding_add (a b : Value Int) :
    (integerEmbedding (a+b):Value R)=integerEmbedding a+integerEmbedding b := by
  apply Value.ext; funext n
  change Int.cast (a.coefficient n+b.coefficient n)=
    (Int.cast (a.coefficient n):R)+Int.cast (b.coefficient n)
  rw [Lean.Grind.Ring.intCast_add]

theorem integerEmbedding_mul (a b : Value Int) :
    (integerEmbedding (a*b):Value R)=integerEmbedding a*integerEmbedding b := by
  apply Value.ext; funext n
  exact (product_integer_cast a.coefficient b.coefficient n).symm

theorem integerEmbedding_neg (a : Value Int) :
    (integerEmbedding (-a):Value R)= -integerEmbedding a := by
  apply Value.ext; funext n
  change Int.cast (-a.coefficient n)= -(Int.cast (a.coefficient n):R)
  rw [Lean.Grind.Ring.intCast_neg]

theorem integerEmbedding_one : (integerEmbedding (1:Value Int):Value R)=1 := by
  apply Value.ext; funext n
  change Int.cast (constant (1:Int) n)=constant (1:R) n
  cases n <;> simp only [constant]
  · exact Lean.Grind.Ring.intCast_one
  · exact Lean.Grind.Ring.intCast_zero

theorem integerEmbedding_zero : (integerEmbedding (0:Value Int):Value R)=0 := by
  apply Value.ext; funext n
  change Int.cast (constant (0:Int) n)=constant (0:R) n
  cases n <;> simp only [constant] <;> exact Lean.Grind.Ring.intCast_zero (α:=R)

theorem integerEmbedding_power (a : Value Int) (m : Nat) :
    (integerEmbedding (a^m):Value R)=(integerEmbedding a:Value R)^m := by
  induction m with
  | zero => exact integerEmbedding_one
  | succ m ih =>
    rw [Lean.Grind.Semiring.pow_succ,Lean.Grind.Semiring.pow_succ,integerEmbedding_mul,ih]

end ComputableAnalysis.ModularForms.CoefficientConvolutionAlgebra
