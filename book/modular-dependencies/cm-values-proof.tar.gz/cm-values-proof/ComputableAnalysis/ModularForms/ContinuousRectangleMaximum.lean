import ComputableAnalysis.ModularForms.RectangleMaximumPath

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

/-- A supplied actual continuous evaluator attains a maximum of its real coordinate
on a represented rational rectangle. The point is constructed by a proof-facing rational bisection path. -/
theorem continuous_rectangle_real_maximum {D : Scalar → Prop}
    (f : ∀ z, D z → Scalar) (hf : ContinuousOn D f)
    (J : QInterval × QInterval) (hX : J.1.lo ≤ J.1.hi) (hY : J.2.lo ≤ J.2.hi)
    (hdom : ∀ z : Scalar, representedRectangleContains J z → D z) :
    ∃ a : Scalar, ∃ ha : D a, representedRectangleContains J a ∧
      ∀ (z : Scalar), representedRectangleContains J z → ∀ hz : D z,
        (f z hz).val.realPart.Le (f a ha).val.realPart := by
  let v := fun z : {z : Scalar // D z} => (f z.val z.property).val.realPart
  let choice := rectangleMaximumChoice v J
  let a := rectangleBisectionPoint J hX hY choice
  have hamem : representedRectangleContains J a := rectangleBisectionPoint_mem J hX hY choice 0
  let ha := hdom a hamem
  refine ⟨a,ha,hamem,?_⟩
  intro z hz hzf n m
  apply Classical.byContradiction
  intro hbad
  have hgap : 0 < ((f z hzf).val.compute n).lo.re - ((f a ha).val.compute m).hi.re := by
    change ¬((f z hzf).val.compute n).lo.re ≤ ((f a ha).val.compute m).hi.re at hbad
    grind only
  let eps : QPos := ⟨(((f z hzf).val.compute n).lo.re - ((f a ha).val.compute m).hi.re)/4,by
    rw [Rat.div_def]; exact Rat.mul_pos hgap (by decide +kernel)⟩
  let b : Rat := (((f z hzf).val.compute n).lo.re + ((f a ha).val.compute m).hi.re)/2
  obtain ⟨N,hN⟩ := rectangleBisectionPoint_continuous_values f hf J hX hY choice ha eps
  have hub : rationalValueUpperBound v
      (fun w => representedRectangleContains (rectangleMaximumCell v J N) w.val) b := by
    intro w hw i j
    rw [rectangleMaximumCell_path] at hw
    have hs := hN N (Nat.le_refl N) w.val w.property hw
    let k := max i m
    have he := hs.2.1 k 0
    have hn := (f w.val w.property).property.2.1 i k (Nat.le_max_left _ _)
    have hm := (f a ha).property.2.1 m k (Nat.le_max_right _ _)
    change ((f w.val w.property).val.compute k).lo.re + -((f a ha).val.compute k).hi.re ≤ eps.val at he
    change ((v w).compute i).lo ≤ b
    change ((f w.val w.property).val.compute i).lo.re ≤ b
    dsimp [b,eps] at he ⊢
    grind only
  have hg := rectangleMaximumCell_retains v J N b hub
  have hu := hg ⟨z,hzf⟩ hz n 0
  change ((f z hzf).val.compute n).lo.re ≤ b at hu
  dsimp [b] at hu
  change ¬((f z hzf).val.compute n).lo.re ≤ ((f a ha).val.compute m).hi.re at hbad
  grind only

/-- The actual quotient squared magnitude attains a maximum on every closed upper-plane rectangle. -/
theorem discriminantPrimeHeckeQuotientSquaredMagnitude_rectangle_maximum
    (p : Nat) (hpR : 0 < (p : Rat)) (J : QInterval × QInterval)
    (hX : J.1.lo ≤ J.1.hi) (hY : J.2.lo ≤ J.2.hi) (hJ : 0 < J.2.lo) :
    ∃ a : UpperPoint, representedRectangleContains J a.val ∧
      ∀ z : UpperPoint, representedRectangleContains J z.val →
        (discriminantPrimeHeckeQuotientSquaredMagnitude p hpR z).Le
          (discriminantPrimeHeckeQuotientSquaredMagnitude p hpR a) := by
  let F := discriminantPrimeHeckeDifferenceQuotient p hpR
  let f := fun (z : Scalar) (hz : InUpperHalfPlane z.val) =>
    let w := F.eval z (discriminantPrimeHeckeDifferenceQuotient_global_domain p hpR z hz)
    scalarProduct w ⟨conj w.val,conj_valid _ w.property⟩
  obtain ⟨a,ha,hamem,hmax⟩ := continuous_rectangle_real_maximum f
    (discriminantPrimeHeckeSquaredMagnitudeProductContinuous p hpR) J hX hY
    (representedRectangle_upper J hJ)
  exact ⟨⟨a,ha⟩,hamem,fun z hz => hmax z.val hz z.property⟩

end ComputableAnalysis.ModularForms
