import ComputableAnalysis.ModularForms.CoefficientSeriesRing

namespace ComputableAnalysis.ModularForms.CoefficientConvolutionAlgebra
variable {R : Type} [Lean.Grind.CommRing R]

def monomial (d : Nat) (r : R) : Series R := fun n => if n=d then r else 0

private theorem monomial_zero (r : R) : monomial 0 r=constant r := by
  funext n; cases n <;> simp [monomial,constant]

private theorem monomial_succ (d : Nat) (r : R) : monomial (d+1) r=shift (monomial d r) := by
  funext n; cases n <;> simp [monomial,shift]

/-- A monomial contributes at exactly the complementary degree, with an
explicit guard before natural subtraction. -/
theorem product_monomial_left (d : Nat) (r : R) (b : Series R) (n : Nat) :
    product (monomial d r) b n=if d≤n then r*b (n-d) else 0 := by
  induction d generalizing n with
  | zero => rw [monomial_zero,product_constant_left]; simp
  | succ d ih =>
    rw [monomial_succ,product_shift_left]
    cases n with
    | zero => simp [shift]
    | succ n =>
      change product (monomial d r) b n=if d+1≤n+1 then r*b (n+1-(d+1)) else 0
      rw [ih]
      simp

/-- Multiplication of literal coefficient monomials adds their degrees. -/
theorem product_monomials (d e : Nat) (r s : R) :
    product (monomial d r) (monomial e s)=monomial (d+e) (r*s) := by
  funext n
  rw [product_monomial_left]
  by_cases hd : d≤n
  · have he : n-d=e ↔ n=d+e := by omega
    simp only [hd,if_true,monomial,he]
    split <;> grind only
  · have he : n≠d+e := by omega
    simp only [hd,if_false,monomial,he]

end ComputableAnalysis.ModularForms.CoefficientConvolutionAlgebra
