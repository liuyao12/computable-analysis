import ComputableAnalysis.ModularForms.FiniteSignedNewton

namespace ComputableAnalysis.ModularForms.FiniteRingNewton

attribute [local instance] Lean.Grind.Semiring.natCast

variable {R : Type} [Lean.Grind.CommRing R]

def finiteValueSum (f : Nat → R) : Nat → R
  | 0 => 0
  | n+1 => finiteValueSum f n+f n

private theorem sum_congr (f g : Nat → R) (n : Nat)
    (h : ∀ i, i<n → f i=g i) : finiteValueSum f n=finiteValueSum g n := by
  induction n with
  | zero => rfl
  | succ n ih => rw [finiteValueSum,finiteValueSum,ih (fun i hi => h i (by omega)),h n (by omega)]

private theorem sum_add (f g : Nat → R) (n : Nat) :
    finiteValueSum (fun i => f i+g i) n=finiteValueSum f n+finiteValueSum g n := by
  induction n with
  | zero => change (0:R)=0+0; grind only
  | succ n ih => simp only [finiteValueSum,ih]; grind only

private theorem sum_sub (f g : Nat → R) (n : Nat) :
    finiteValueSum (fun i => f i-g i) n=finiteValueSum f n-finiteValueSum g n := by
  induction n with
  | zero => change (0:R)=0-0; grind only
  | succ n ih => simp only [finiteValueSum,ih]; grind only

private theorem sum_scale (x : R) (f : Nat → R) (n : Nat) :
    finiteValueSum (fun i => x*f i) n=x*finiteValueSum f n := by
  induction n with
  | zero => change (0:R)=x*0; grind only
  | succ n ih => simp only [finiteValueSum,ih]; grind only

private theorem sum_head (f : Nat → R) (n : Nat) :
    finiteValueSum f (n+1)=f 0+finiteValueSum (fun i => f (i+1)) n := by
  induction n with
  | zero => change (0:R)+f 0=f 0+0; grind only
  | succ n ih =>
    change finiteValueSum f (n+1)+f (n+1)=f 0+
      (finiteValueSum (fun i => f (i+1)) n+f (n+1))
    rw [ih]
    grind only

private def convolution (a p : Nat → R) (n : Nat) : R :=
  finiteValueSum (fun i => a i*p (n-i)) n

private def consCoefficients (x : R) (a : Nat → R) :
    Nat → R
  | 0 => a 0
  | n+1 => a (n+1)-x*a n

private theorem convolution_add (a p q : Nat → R) (n : Nat) :
    convolution a (fun i => p i+q i) n=convolution a p n+convolution a q n := by
  unfold convolution
  have h := sum_congr (fun i => a i*(p (n-i)+q (n-i)))
    (fun i => a i*p (n-i)+a i*q (n-i)) n (fun _ _ => by grind only)
  rw [h,sum_add]

private theorem convolution_cons (x : R) (a p : Nat → R) (n : Nat) :
    convolution (consCoefficients x a) p (n+1)=convolution a p (n+1)-x*convolution a p n := by
  unfold convolution
  rw [sum_head,sum_head]
  simp only [consCoefficients,Nat.sub_zero]
  have h := sum_congr
    (fun i => (a (i+1)-x*a i)*p (n+1-(i+1)))
    (fun i => a (i+1)*p (n+1-(i+1))-x*(a i*p (n-i))) n (fun i hi => by
      rw [show n+1-(i+1)=n-i by omega]
      grind only)
  rw [h,sum_sub,sum_scale]
  grind only

private theorem convolution_power_step (a : Nat → R)
    (x : R) (n : Nat) :
    convolution a (fun i => x^i) (n+1)=x*convolution a (fun i => x^i) n+x*a n := by
  unfold convolution
  rw [finiteValueSum]
  have h := sum_congr (fun i => a i*x^(n+1-i)) (fun i => x*(a i*x^(n-i))) n
    (fun i hi => by
      rw [show n+1-i=(n-i)+1 by omega,Lean.Grind.Semiring.pow_succ]
      grind only)
  rw [h,sum_scale]
  rw [show n+1-n=1 by omega]
  have hp : x^(1:Nat)=x := by grind only
  dsimp only
  rw [hp]
  grind only

private theorem convolution_cons_power (a : Nat → R)
    (x : R) (n : Nat) :
    convolution (consCoefficients x a) (fun i => x^i) (n+1)=x*a n := by
  rw [convolution_cons,convolution_power_step]
  grind only

/-- Signed elementary symmetric coefficients of the literal finite product
of factors with constant term one and linear term minus the supplied value. -/
def finiteSignedSymmetric : List R → Nat → R
  | _, 0 => 1
  | [], _+1 => 0
  | x::xs, n+1 => finiteSignedSymmetric xs (n+1)-x*finiteSignedSymmetric xs n

/-- Actual finite power sum of the supplied ring values. -/
def finitePowerSum (xs : List R) (n : Nat) : R :=
  xs.foldr (fun x s => x^n+s) 0

private theorem symmetric_cons (x : R) (xs : List R) :
    finiteSignedSymmetric (x::xs)=consCoefficients x (finiteSignedSymmetric xs) := by
  funext n
  cases n with
  | zero => cases xs <;> rfl
  | succ n => rfl

/-- Newton's identity, proved for arbitrary finite values of a supplied commutative ring.
The coefficients are constructed by the signed symmetric-product recursion. -/
theorem finiteSignedSymmetric_newton (xs : List R) (n : Nat) :
    (NatCast.natCast n:R)*finiteSignedSymmetric xs n+
      finiteValueSum (fun i => finiteSignedSymmetric xs i*finitePowerSum xs (n-i)) n=0 := by
  induction xs generalizing n with
  | nil =>
    cases n with
    | zero => change (NatCast.natCast 0:R)*1+0=0; grind only
    | succ n =>
      have h := sum_congr (fun i => finiteSignedSymmetric [] i*finitePowerSum [] (n+1-i))
        (fun _ => (0:R)) (n+1) (fun _ _ => by
          change _*0=0; grind only)
      have hz (m : Nat) : finiteValueSum (fun _ => (0:R)) m=0 := by
        induction m with
        | zero => rfl
        | succ m ih => rw [finiteValueSum,ih]; grind only
      change (_:R)*0+_=0
      rw [h,hz]
      grind only
  | cons x xs ih =>
    cases n with
    | zero => change (NatCast.natCast 0:R)*1+0=0; grind only
    | succ n =>
      have h₁ := ih (n+1)
      have h₂ := ih n
      change (_:R)*(finiteSignedSymmetric xs (n+1)-x*finiteSignedSymmetric xs n)+
        convolution (finiteSignedSymmetric (x::xs))
          (fun i => x^i+finitePowerSum xs i) (n+1)=0
      rw [symmetric_cons,convolution_add,convolution_cons_power,convolution_cons]
      change (NatCast.natCast (n+1):R)*finiteSignedSymmetric xs (n+1)+
        convolution (finiteSignedSymmetric xs) (finitePowerSum xs) (n+1)=0 at h₁
      change (NatCast.natCast n:R)*finiteSignedSymmetric xs n+
        convolution (finiteSignedSymmetric xs) (finitePowerSum xs) n=0 at h₂
      have hnat : (NatCast.natCast (n+1):R)=(NatCast.natCast n:R)+1 :=
        by grind only
      rw [hnat] at h₁ ⊢
      grind only

/-- Unsigned elementary symmetric coefficients of the supplied finite roots. -/
def finiteUnsignedSymmetric : List R → Nat → R
  | _, 0 => 1
  | [], _+1 => 0
  | x::xs, n+1 => finiteUnsignedSymmetric xs (n+1)+x*finiteUnsignedSymmetric xs n

theorem finiteSignedSymmetric_negated (xs : List R) (n : Nat) :
    finiteSignedSymmetric (xs.map (fun x => -x)) n=finiteUnsignedSymmetric xs n := by
  induction xs generalizing n with
  | nil => cases n <;> rfl
  | cons x xs ih =>
    cases n with
    | zero => rfl
    | succ n =>
      simp only [List.map_cons,finiteSignedSymmetric,finiteUnsignedSymmetric,ih]
      grind only

private theorem negative_power (x : R) (n : Nat) : (-x)^n=(-1:R)^n*x^n := by
  induction n with
  | zero => grind only
  | succ n ih =>
    rw [Lean.Grind.Semiring.pow_succ,Lean.Grind.Semiring.pow_succ,
      Lean.Grind.Semiring.pow_succ,ih]
    grind only

theorem finitePowerSum_negated (xs : List R) (n : Nat) :
    finitePowerSum (xs.map (fun x => -x)) n=(-1:R)^n*finitePowerSum xs n := by
  induction xs with
  | nil => change (0:R)=(-1:R)^n*0; grind only
  | cons x xs ih =>
    change (-x)^n+finitePowerSum (xs.map (fun x => -x)) n=
      (-1:R)^n*(x^n+finitePowerSum xs n)
    rw [negative_power,ih]
    grind only

/-- Newton's unsigned identity over a supplied commutative ring. The signs
are constructed by powers of minus one, matching integer coefficient
reconstruction without assuming an evaluated identity. -/
theorem finiteUnsignedSymmetric_newton (xs : List R) (n : Nat) :
    (NatCast.natCast n:R)*finiteUnsignedSymmetric xs n +
      finiteValueSum (fun i => finiteUnsignedSymmetric xs i*
        ((-1:R)^(n-i)*finitePowerSum xs (n-i))) n=0 := by
  have h := finiteSignedSymmetric_newton (xs.map (fun x => -x)) n
  simp only [finiteSignedSymmetric_negated,finitePowerSum_negated] at h
  exact h

/-- Specialization recovers the existing signed represented-scalar
construction, rather than changing its mathematical coefficients. -/
theorem finiteSignedSymmetric_scalar_agreement
    (xs : List RiemannHilbert.ScalarAlgebra.Value) (n : Nat) :
    finiteSignedSymmetric xs n =
      ComputableAnalysis.ModularForms.finiteSignedSymmetric xs n := by
  induction xs generalizing n with
  | nil => cases n <;> rfl
  | cons x xs ih =>
    cases n with
    | zero => rfl
    | succ n =>
      simp only [finiteSignedSymmetric,
        ComputableAnalysis.ModularForms.finiteSignedSymmetric,ih]

theorem finitePowerSum_scalar_agreement
    (xs : List RiemannHilbert.ScalarAlgebra.Value) (n : Nat) :
    finitePowerSum xs n = ComputableAnalysis.ModularForms.finitePowerSum xs n := rfl

theorem finiteValueSum_scalar_agreement
    (f : Nat → RiemannHilbert.ScalarAlgebra.Value) (n : Nat) :
    finiteValueSum f n = ComputableAnalysis.ModularForms.finiteValueSum f n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [finiteValueSum,ComputableAnalysis.ModularForms.finiteValueSum,ih]

end ComputableAnalysis.ModularForms.FiniteRingNewton
