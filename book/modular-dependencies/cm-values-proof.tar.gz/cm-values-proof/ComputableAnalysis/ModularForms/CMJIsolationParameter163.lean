import ComputableAnalysis.ModularForms.PositiveReciprocalAgreement
import ComputableAnalysis.ModularForms.CMJIsolationDenominator163
import ComputableAnalysis.PositiveReciprocal

namespace ComputableAnalysis.ModularForms

def cmJIsolationNumerator163 : RealRaw :=
  RealRaw.sub cmJValue163.val.realPart (RealRaw.ofRat (-2305843009213693952))

theorem cmJIsolationNumerator163_valid : cmJIsolationNumerator163.Valid :=
  RealRaw.sub_valid (ComplexRaw.realPart_valid cmJValue163.property) (RealRaw.ofRat_valid _)

theorem cmJIsolationNumerator163_nonnegative :
    (RealRaw.ofRat 0).Le cmJIsolationNumerator163 := by
  intro n m
  have h := cmJValue163_real_isolation_bounds.1 0 m
  change (-2305843009213693952:Rat)≤(cmJValue163.val.realPart.compute m).hi at h
  change (0:Rat)≤(cmJValue163.val.realPart.compute m).hi-(-2305843009213693952:Rat)
  grind only

def cmJIsolationInverse163 : RealRaw := RealRaw.positiveReciprocal cmJIsolationDenominator163 255

theorem cmJIsolationInverse163_valid : cmJIsolationInverse163.Valid :=
  RealRaw.positiveReciprocal_valid _ _ cmJIsolationDenominator163_valid (by decide +kernel)
    (fun n => cmJIsolationDenominator163_lower 0 n)

theorem cmJIsolationInverse163_nonnegative :
    (RealRaw.ofRat 0).Le cmJIsolationInverse163 := by
  intro n m
  rw [show cmJIsolationInverse163=RealRaw.positiveReciprocal cmJIsolationDenominator163 255 by rfl,
    RealRaw.positiveReciprocal_compute _ _ (by decide +kernel) m]
  change (0:Rat)≤1/maxRat2 (cmJIsolationDenominator163.compute m).lo 255
  have h : (0:Rat)<maxRat2 (cmJIsolationDenominator163.compute m).lo 255 := by
    unfold maxRat2; split <;> grind only
  rw [Rat.div_def]
  exact Rat.mul_nonneg (by decide +kernel) (Rat.le_of_lt (Rat.inv_pos.mpr h))

/-- Actual executable parameter for the CM interval substitution. -/
def cmJIsolationParameter163 : RealRaw := RealRaw.mul cmJIsolationNumerator163 cmJIsolationInverse163

theorem cmJIsolationParameter163_valid : cmJIsolationParameter163.Valid :=
  RealRaw.mul_valid cmJIsolationNumerator163_valid cmJIsolationInverse163_valid

/-- The actual constructed parameter is nonnegative on the full represented domain. -/
theorem cmJIsolationParameter163_nonnegative :
    (RealRaw.ofRat 0).Le cmJIsolationParameter163 := by
  intro n m
  have hn := cmJIsolationNumerator163_nonnegative 0 m
  have hi := cmJIsolationInverse163_nonnegative 0 m
  change (0:Rat)≤(cmJIsolationNumerator163.compute m).hi at hn
  change (0:Rat)≤(cmJIsolationInverse163.compute m).hi at hi
  have ho := QBox.mulRealInterval_contains
    (RealRaw.interval_order_of_valid _ cmJIsolationNumerator163_valid m)
    (Rat.le_refl : (cmJIsolationNumerator163.compute m).hi≤(cmJIsolationNumerator163.compute m).hi)
    (RealRaw.interval_order_of_valid _ cmJIsolationInverse163_valid m)
    (Rat.le_refl : (cmJIsolationInverse163.compute m).hi≤(cmJIsolationInverse163.compute m).hi)
  change (0:Rat)≤(QBox.mulRealInterval (cmJIsolationNumerator163.compute m).lo
    (cmJIsolationNumerator163.compute m).hi (cmJIsolationInverse163.compute m).lo
    (cmJIsolationInverse163.compute m).hi).hi
  exact Rat.le_trans (Rat.mul_nonneg hn hi) ho.2

/-- The clipped reciprocal agrees exactly with the inverse role required by
this concrete denominator, using its proved margin. -/
theorem cmJIsolationInverse163_product_identity :
    (RealRaw.mul cmJIsolationDenominator163 cmJIsolationInverse163).Equiv RealRaw.one :=
  positiveReciprocal_mul_identity _ cmJIsolationDenominator163_valid 255
    (by decide +kernel) cmJIsolationDenominator163_lower

end ComputableAnalysis.ModularForms
