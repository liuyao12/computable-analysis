import ComputableAnalysis.ModularForms.SquareFrameSharedEdges

namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

/-- Finitely many justified tile boundary limits admit a common refinement depth. -/
theorem squareFrame_uniform_boundary_depth (f : QComplex → Scalar) (R eps : QPos)
    (htile : ∀ j l, squareFrameTileIndex j l → ∀ eta : QPos,
      ∃ N, ∀ n, N ≤ n → Small (rectangleGridBoundary f (squareFrameTile R j l) (2^n)).val eta.val) :
    ∃ N, ∀ n, N ≤ n → ∀ j l, squareFrameTileIndex j l →
      Small (rectangleGridBoundary f (squareFrameTile R j l) (2^n)).val eps.val := by
  have h : ∀ j, j < 4 → ∃ N, ∀ n, N ≤ n → ∀ l, l < 4 → squareFrameTileIndex j l →
      Small (rectangleGridBoundary f (squareFrameTile R j l) (2^n)).val eps.val := by
    intro j _
    apply finite_eventual_depth
    intro l _
    by_cases h : squareFrameTileIndex j l
    · obtain ⟨N,hN⟩ := htile j l h eps
      exact ⟨N,fun n hn _ => hN n hn⟩
    · exact ⟨0,by intro n hn hh; exact False.elim (h hh)⟩
  obtain ⟨N,hN⟩ := finite_eventual_depth _ 4 h
  exact ⟨N,fun n hn j l h => hN n hn j h.1 l h.2.1 h⟩

/-- Shared finite edges cancel exactly, so justified vanishing tile boundaries
force the actual outer-minus-inner frame contour to converge to zero. -/
theorem squareFrame_contour_difference_converges_zero (f : QComplex → Scalar) (R eps : QPos)
    (htile : ∀ j l, squareFrameTileIndex j l → ∀ eta : QPos,
      ∃ N, ∀ n, N ≤ n → Small (rectangleGridBoundary f (squareFrameTile R j l) (2^n)).val eta.val) :
    ∃ N, ∀ n, N ≤ n →
      Small (gridScalarSub
        (frameScalarRectBoundary (squareFrameHorizontalEdge f R (2^n)) (squareFrameVerticalEdge f R (2^n)) 0 0 4 4)
        (frameScalarRectBoundary (squareFrameHorizontalEdge f R (2^n)) (squareFrameVerticalEdge f R (2^n)) 1 1 2 2)).val eps.val := by
  let eta : QPos := ⟨eps.val/12,by
    rw [Rat.div_def]; exact Rat.mul_pos eps.property (Rat.inv_pos.mpr (by decide +kernel))⟩
  obtain ⟨N,hN⟩ := squareFrame_uniform_boundary_depth f R eta htile
  refine ⟨N,?_⟩
  intro n hn
  let B := frameScalarSum (fun j l => rectangleGridBoundary f (squareFrameTile R j l) (2^n)) 1 2 1 1 2 1
  have hb := frameScalarSum_bound (fun j l => rectangleGridBoundary f (squareFrameTile R j l) (2^n))
    1 2 1 1 2 1 eta.val (Rat.le_of_lt eta.property) (by
      intro j l h
      have hi : squareFrameTileIndex j l := by
        unfold representedFrameCell at h
        unfold squareFrameTileIndex
        omega
      exact hN n hn j l hi)
  have he : ((representedFrameCellCount 1 2 1 1 2 1:Nat):Rat)*eta.val=eps.val := by
    change 12*(eps.val/12)=eps.val
    grind only
  rw [he] at hb
  exact Small.congr B.property (sub_valid
    (frameScalarRectBoundary (squareFrameHorizontalEdge f R (2^n)) (squareFrameVerticalEdge f R (2^n)) 0 0 4 4).property
    (frameScalarRectBoundary (squareFrameHorizontalEdge f R (2^n)) (squareFrameVerticalEdge f R (2^n)) 1 1 2 2).property)
    (squareFrame_tiled_boundary_agreement f R (2^n) (Nat.pow_pos (by decide +kernel))) hb

end ComputableAnalysis.ModularForms
