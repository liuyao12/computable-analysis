import ComputableAnalysis.ModularForms.Hecke41CuspBand

namespace ComputableAnalysis.ModularForms

private theorem pow_product (a b : Rat) (n : Nat) : (a*b)^n=a^n*b^n := by
  induction n with
  | zero => simp
  | succ n ih => simp only [Rat.pow_succ,ih]; grind

theorem rational_reciprocal_power (a : Rat) (ha : 0<a) (n : Nat) : 1/(a^n)=(1/a)^n := by
  have hp : 0<a^n := Rat.pow_pos ha
  have hunit : a*(1/a)=1 := by rw [Rat.div_def,Rat.one_mul]; exact Rat.mul_inv_cancel a (Rat.ne_of_gt ha)
  have h := congrArg (fun t : Rat => t^n) hunit
  rw [pow_product] at h
  have hnunit : (a^n)*(1/(a^n))=1 := by
    rw [Rat.div_def,Rat.one_mul]
    exact Rat.mul_inv_cancel (a^n) (Rat.ne_of_gt hp)
  have hone : (1:Rat)^n=1 := by
    clear hp h hnunit hunit ha a
    induction n with
    | zero => simp
    | succ n ih => rw [Rat.pow_succ,ih,Rat.one_mul]
  rw [hone] at h
  grind only

private theorem decreasing_power (a : Rat) (ha : 0≤a) (hu : a≤1) (n : Nat) : a^(n+1)≤a := by
  induction n with
  | zero => simp
  | succ n ih =>
      rw [Rat.pow_succ]
      have h := Rat.mul_le_mul_of_nonneg_right ih ha
      have h₂ := Rat.mul_le_mul_of_nonneg_left hu ha
      grind

/-- Small-nome reciprocal guards persist under positive integer amplification. -/
theorem cusp_power_guards (L B : Rat) (hL : 0<L) (hB : 0≤B)
    (hs : 1/L≤(1:Rat)/65536) (hg : 440*(1/L)*(1/L)*B≤(1:Rat)/8) (n : Nat) :
    0<L^(n+1) ∧ 0≤B^(n+1) ∧ 1/(L^(n+1))≤(1:Rat)/65536 ∧
      440*(1/(L^(n+1)))*(1/(L^(n+1)))*B^(n+1)≤(1:Rat)/8 := by
  have hr : 0≤1/L := by rw [Rat.div_def,Rat.one_mul]; exact Rat.le_of_lt (Rat.inv_pos.mpr hL)
  have hq : 0≤(1/L)*(1/L)*B := Rat.mul_nonneg (Rat.mul_nonneg hr hr) hB
  have hq₁ : (1/L)*(1/L)*B≤1 := by grind
  refine ⟨Rat.pow_pos hL,Rat.pow_nonneg hB,?_,?_⟩
  · rw [rational_reciprocal_power L hL]
    exact Rat.le_trans (decreasing_power _ hr (by grind) n) hs
  · rw [rational_reciprocal_power L hL]
    have hi : (1/L)^(n+1)*(1/L)^(n+1)*B^(n+1)=((1/L)*(1/L)*B)^(n+1) := by
      rw [pow_product,pow_product]
    have hb := Rat.mul_le_mul_of_nonneg_left (decreasing_power _ hq hq₁ n) (show (0:Rat)≤440 by decide +kernel)
    have he : 440*(1/L)^(n+1)*(1/L)^(n+1)*B^(n+1)=440*((1/L)^(n+1)*(1/L)^(n+1)*B^(n+1)) := by grind
    rw [he,hi]
    exact Rat.le_trans hb (by simpa only [Rat.mul_assoc] using hg)

end ComputableAnalysis.ModularForms
