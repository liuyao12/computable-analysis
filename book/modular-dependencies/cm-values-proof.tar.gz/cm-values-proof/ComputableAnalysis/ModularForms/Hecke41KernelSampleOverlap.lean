import ComputableAnalysis.ModularForms.Hecke41KernelRectangleSamples

/-! Exact overlap agreement of actual rectangle samplers. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

theorem hecke41KernelRectangleSample_overlap (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (J K : QInterval × QInterval) (R B S C : QPos)
    (hsJ : rectangleSeparated J R) (hsK : rectangleSeparated K S)
    (hJxl : -B.val≤J.1.lo) (hJxu : J.1.hi≤B.val)
    (hJyl : -B.val≤J.2.lo) (hJyu : J.2.hi≤B.val)
    (hKxl : -C.val≤K.1.lo) (hKxu : K.1.hi≤C.val)
    (hKyl : -C.val≤K.2.lo) (hKyu : K.2.hi≤C.val)
    (hB : B.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (hC : C.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (q : QComplex) (hqJ : rationalRectangleContains J q) (hqK : rationalRectangleContains K q) :
    (hecke41KernelRectangleSample k a ha J R B hsJ hJxl hJxu hJyl hJyu hB q).val.Equiv
      (hecke41KernelRectangleSample k a ha K S C hsK hKxl hKxu hKyl hKyu hC q).val := by
  simp only [hecke41KernelRectangleSample,dif_pos hqJ,dif_pos hqK]
  exact equiv_refl _ ((hecke41CauchyIntegrandMap k a).eval (rationalRectangleScalar q)
    (hecke41KernelRectangle_domain k a ha J R B hsJ hJxl hJxu hJyl hJyu hB _
      (rationalRectangle_represented_mem J q hqJ))).property

end ComputableAnalysis.ModularForms
