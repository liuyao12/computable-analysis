import ComputableAnalysis.ModularForms.IntegerAffineHeckeUniformBounds41

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- Executable common value bound for all symmetric degrees. -/
def scalarSymmetricBound41 (H : Rat) : Nat → Rat
  | 0 => 1
  | n+1 => (1+2*H)*scalarSymmetricBound41 H n

theorem scalarSymmetricBound41_ge_one (H : Rat) (hH : 0≤H) (n : Nat) :
    1≤scalarSymmetricBound41 H n := by
  induction n with
  | zero => exact Rat.le_refl
  | succ n ih =>
    have hb : 0≤scalarSymmetricBound41 H n := Rat.le_trans (by decide) ih
    have hp := Rat.mul_nonneg (Rat.mul_nonneg (by decide : (0:Rat)≤2) hH) hb
    change 1≤(1+2*H)*scalarSymmetricBound41 H n
    rw [Rat.add_mul,Rat.one_mul]
    exact Rat.le_trans ih (by grind only)

theorem scalarSymmetricBound41_nonneg (H : Rat) (hH : 0≤H) (n : Nat) :
    0≤scalarSymmetricBound41 H n := Rat.le_trans (by decide) (scalarSymmetricBound41_ge_one H hH n)

/-- Supplied actual factor bounds control every represented symmetric sum. -/
theorem representedElementarySymmetric41_bound (xs : List Scalar) (k : Nat)
    (H : Rat) (hH : 0≤H) (h : ∀ x∈xs, Small x.val H) :
    Small (representedElementarySymmetric41 xs k) (scalarSymmetricBound41 H xs.length) := by
  induction xs generalizing k with
  | nil =>
    cases k with
    | zero => exact scalarUnit41_small
    | succ k => exact Small.zero (show (0:Rat)≤1 by decide)
  | cons x xs ih =>
    cases k with
    | zero => exact scalarUnit41_small.mono (scalarSymmetricBound41_ge_one H hH _)
    | succ k =>
      have ht : ∀ y∈xs, Small y.val H := fun y hy => h y (by simp [hy])
      have hb := scalarSymmetricBound41_nonneg H hH xs.length
      have hp := Small.mul x.property (representedElementarySymmetric41_valid xs k) hH hb
        (h x (by simp)) (ih k ht)
      have hs := LocalODE.small_add (ih (k+1) ht) hp
      have he : scalarSymmetricBound41 H xs.length+2*H*scalarSymmetricBound41 H xs.length=
          scalarSymmetricBound41 H (xs.length+1) := by
        simp only [scalarSymmetricBound41,Rat.add_mul,Rat.one_mul]
      simpa only [representedElementarySymmetric41,List.length_cons,he] using hs

end ComputableAnalysis.ModularForms
