import ComputableAnalysis.ModularForms.CMGrowthTightBounds163
import ComputableAnalysis.ModularForms.CMImaginaryCoordinates163
import ComputableAnalysis.ModularForms.CMHeckeReduction41
import ComputableAnalysis.ModularForms.CMLatticeInverseFormula163

/-! Exact affine clearing and reciprocal formulas at the CM correspondence points. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert

/-- Clearing 41 in any affine expression at a finite CM Hecke point gives its order embedding. -/
theorem hecke41_cm_affine_clearing (a b : Int) (i : Fin 41) :
    (scaleRat 41 (integerAffine a b (hecke41Point ⟨i.val,by omega⟩ cmScalar163).val)).Equiv
      (⟨a*(i.val:Int)+41*b,a⟩ : QuadraticOrder163).complexRaw := by
  have hi : i.val≠41 := by omega
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := scaleRat_valid (integerAffine_valid a b
      (hecke41Point ⟨i.val,by omega⟩ cmScalar163).property))
    (hright := (⟨a*(i.val:Int)+41*b,a⟩ : QuadraticOrder163).complexRaw_valid)
  rw [ComplexRawQuotient.ofRaw_scaleRat,integerAffine_class]
  simp only [hecke41Point,if_neg hi]
  rw [ComplexRawQuotient.ofRaw_scaleRat]
  unfold translate
  rw [ComplexRawQuotient.ofRaw_add]
  change ComplexRawQuotient.scaleRat 41
    ((a:ScalarAlgebra.Value)*ComplexRawQuotient.scaleRat (1/41)
      (cmPoint163Value+ComplexRawQuotient.ofQComplex ⟨(i.val:Rat),0⟩)+
      (b:ScalarAlgebra.Value))=(⟨a*(i.val:Int)+41*b,a⟩ : QuadraticOrder163).complexValue
  rw [QuadraticOrder163.complexValue_formula]
  have hc := integer_constant (i.val:Int)
  rw [show ((i.val:Int):Rat)=(i.val:Rat) by rfl] at hc
  rw [hc]
  change ComplexRawQuotient.scaleRat 41
    ((a:ScalarAlgebra.Value)*ComplexRawQuotient.scaleRat (1/41)
      (cmPoint163Value+(i.val:Int))+ (b:ScalarAlgebra.Value))=
    ((a*(i.val:Int)+41*b:Int):ScalarAlgebra.Value)+
      (a:ScalarAlgebra.Value)*cmPoint163Value
  rw [ComplexRawQuotient.scaleRat_add,←ComplexRawQuotient.mul_scaleRat,
    ComplexRawQuotient.scaleRat_scaleRat,
    show (41:Rat)*(1/41)=1 by decide +kernel,ComplexRawQuotient.scaleRat_one,
    ←show ((41:Nat):Rat)=(41:Rat) by decide +kernel,ScalarAlgebra.scale_natural 41]
  grind
  · exact translate_valid _ cmPoint163_valid
  · exact integerAffine_valid _ _ (hecke41Point ⟨i.val,by omega⟩ cmScalar163).property


/-- The chosen denominator order element is nonzero at every finite residue. -/
theorem cmHeckeDenominatorOrder41_nonzero (i : Fin 41) :
    cmHeckeDenominatorOrder41 i≠QuadraticOrder163.zero := by
  intro h
  have hb := (cmHeckeDenominatorOrder41_norm_bounds i).1
  rw [h] at hb
  change (41:Int)≤0 at hb
  omega

/-- Actual reciprocal of the modular denominator, derived from the CM order norm formula. -/
theorem cmHeckeDenominator41_inverse (i : Fin 41) :
    let g := cmHeckeReduction41 ⟨i.val,by omega⟩
    let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
    let hz := hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper
    let d : Scalar := ⟨integerAffine g.c g.d z.val,integerAffine_valid _ _ z.property⟩
    (RepresentedReciprocal.inverse d (denominator_nonzero g z hz)).val.Equiv
      (scaleRat 41 (cmHeckeDenominatorOrder41 i).normInverseRaw) := by
  let g := cmHeckeReduction41 ⟨i.val,by omega⟩
  let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
  let hz := hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper
  let d : Scalar := ⟨integerAffine g.c g.d z.val,integerAffine_valid _ _ z.property⟩
  let u := cmHeckeDenominatorOrder41 i
  let r : Scalar := ⟨scaleRat 41 u.normInverseRaw,scaleRat_valid u.normInverseRaw_valid⟩
  apply RepresentedReciprocal.inverse_unique d (denominator_nonzero g z hz) r
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := mul_valid d.property r.property) (hright := ofQComplex_valid _)
  have he := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := scaleRat_valid d.property) (hright := u.complexRaw_valid)
    (cmHeckeDenominatorOrder41_agreement i)
  have hu := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := mul_valid u.complexRaw_valid u.normInverseRaw_valid) (hright := ofQComplex_valid _)
    (QuadraticOrder163.normInverseRaw_product u (cmHeckeDenominatorOrder41_nonzero i))
  let D := ComplexRawQuotient.ofRaw d.val d.property
  let U := u.complexValue
  let R := ComplexRawQuotient.ofRaw u.normInverseRaw u.normInverseRaw_valid
  change ComplexRawQuotient.scaleRat 41 D=U at he
  change U*R=1 at hu
  change D*ComplexRawQuotient.scaleRat 41 R=1
  rw [ComplexRawQuotient.mul_scaleRat,ComplexRawQuotient.scaleRat_mul,he]
  exact hu

/-- The cleared numerator of the chosen transformation. -/
def cmHeckeNumeratorOrder41 (i : Fin 41) : QuadraticOrder163 :=
  let g := cmHeckeReduction41 ⟨i.val,by omega⟩
  ⟨g.a*(i.val:Int)+41*g.b,g.a⟩

/-- Multiplication by the conjugate denominator reduces the quotient to a rational affine CM point. -/
def cmHeckeQuotientOrder41 (i : Fin 41) : QuadraticOrder163 :=
  QuadraticOrder163.mul (cmHeckeNumeratorOrder41 i)
    (QuadraticOrder163.conjugate (cmHeckeDenominatorOrder41 i))

/-- The imaginary coefficient of each reduced order numerator is exactly 41. -/
theorem cmHeckeQuotientOrder41_imaginary_coefficient : ∀ i : Fin 41,
    (cmHeckeQuotientOrder41 i).y=41 := by
  decide +kernel

/-- Each transformed finite CM point agrees with the explicit rationally scaled order element. -/
theorem cmHeckePoint41_quotient (i : Fin 41) :
    let g := cmHeckeReduction41 ⟨i.val,by omega⟩
    let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
    (fractionalLinear g z (hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper)).val.Equiv
      (scaleRat ((QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹)
        (cmHeckeQuotientOrder41 i).complexRaw) := by
  let g := cmHeckeReduction41 ⟨i.val,by omega⟩
  let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
  let hz := hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper
  let d : Scalar := ⟨integerAffine g.c g.d z.val,integerAffine_valid _ _ z.property⟩
  let n : Scalar := ⟨integerAffine g.a g.b z.val,integerAffine_valid _ _ z.property⟩
  let u := cmHeckeDenominatorOrder41 i
  let v := cmHeckeNumeratorOrder41 i
  have hi := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := (RepresentedReciprocal.inverse d (denominator_nonzero g z hz)).property)
    (hright := scaleRat_valid u.normInverseRaw_valid) (cmHeckeDenominator41_inverse i)
  have hn := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := scaleRat_valid n.property) (hright := v.complexRaw_valid)
    (hecke41_cm_affine_clearing g.a g.b i)
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (fractionalLinear g z hz).property)
    (hright := scaleRat_valid (cmHeckeQuotientOrder41 i).complexRaw_valid)
  change ComplexRawQuotient.ofRaw n.val n.property *
    ComplexRawQuotient.ofRaw (RepresentedReciprocal.inverse d (denominator_nonzero g z hz)).val
      (RepresentedReciprocal.inverse d (denominator_nonzero g z hz)).property=
    ComplexRawQuotient.scaleRat ((QuadraticOrder163.norm u:Rat)⁻¹)
      (cmHeckeQuotientOrder41 i).complexValue
  change ComplexRawQuotient.scaleRat 41 (ComplexRawQuotient.ofRaw n.val n.property)=v.complexValue at hn
  rw [hi]
  change ComplexRawQuotient.ofRaw n.val n.property *
    ComplexRawQuotient.scaleRat 41 (ComplexRawQuotient.ofRaw u.normInverseRaw u.normInverseRaw_valid)=_
  rw [ComplexRawQuotient.mul_scaleRat,ComplexRawQuotient.scaleRat_mul,hn]
  change v.complexValue*ComplexRawQuotient.scaleRat ((QuadraticOrder163.norm u:Rat)⁻¹)
    (QuadraticOrder163.conjugate u).complexValue=
    ComplexRawQuotient.scaleRat ((QuadraticOrder163.norm u:Rat)⁻¹)
      (QuadraticOrder163.mul v (QuadraticOrder163.conjugate u)).complexValue
  rw [ComplexRawQuotient.mul_scaleRat,QuadraticOrder163.complexValue_mul]

/-- Exact imaginary part of every transformed finite CM correspondence point. -/
theorem cmHeckePoint41_imaginary (i : Fin 41) :
    let g := cmHeckeReduction41 ⟨i.val,by omega⟩
    let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
    (fractionalLinear g z (hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper)).val.imagPart.Equiv
      (RealRaw.scaleRat (41*((QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹)/2) sqrt163) := by
  let u := cmHeckeQuotientOrder41 i
  let t : Rat := (QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹
  have hn : (0:Rat)<(QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat) := by
    exact_mod_cast QuadraticOrder163.norm_positive _ (cmHeckeDenominatorOrder41_nonzero i)
  have ht : 0≤t := Rat.le_of_lt (Rat.inv_pos.mpr hn)
  have hy : u.y=41 := cmHeckeQuotientOrder41_imaginary_coefficient i
  have hc : (0:Rat)≤41*t/2 := by grind
  have he : (scaleRat t u.complexRaw).imagPart.Equiv (RealRaw.scaleRat (41*t/2) sqrt163) := by
    intro n
    have him := QuadraticOrder163.complexRaw_imag_compute u n
    have hlo := congrArg QInterval.lo him
    have hhi := congrArg QInterval.hi him
    simp only [hy,show ((41:Int):Rat)=(41:Rat) by decide +kernel,
      RealRaw.scaleRat,RealRaw.scaleRatCompute,
      if_pos (show (0:Rat)≤41/2 by decide +kernel),imagPart] at hlo hhi
    apply (RealRaw.compareAt_overlap_iff _ _ n n).mpr
    simp only [imagPart,scaleRat,QBox.scaleRat,if_pos ht,
      RealRaw.scaleRat,RealRaw.scaleRatCompute,if_pos hc]
    rw [hlo,hhi]
    have ho := RealRaw.interval_order_of_valid sqrt163 sqrt163_valid n
    have hb := Rat.mul_le_mul_of_nonneg_left ho hc
    constructor <;> grind
  exact RealRaw.equiv_trans
    (imagPart_valid (fractionalLinear _ _
      (hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper)).property)
    (imagPart_valid (scaleRat_valid u.complexRaw_valid))
    (RealRaw.scaleRat_valid sqrt163_valid)
    (imagPart_equiv (cmHeckePoint41_quotient i)) he

private theorem height_coefficient_bounds : ∀ i : Fin 41,
    let t : Rat := 41*((QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹)/2
    0≤t ∧ (99:Rat)/100≤t*(51/4) := by
  decide +kernel

/-- A uniform exact lower height bound for every transformed finite CM Hecke point. -/
theorem cmHeckePoint41_height_lower (i : Fin 41) :
    let g := cmHeckeReduction41 ⟨i.val,by omega⟩
    let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
    (RealRaw.ofRat (99/100)).Le
      (fractionalLinear g z (hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper)).val.imagPart := by
  let g := cmHeckeReduction41 ⟨i.val,by omega⟩
  let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
  let w := fractionalLinear g z (hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper)
  let t : Rat := 41*((QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹)/2
  have ht := height_coefficient_bounds i
  have hpos : 0≤t := ht.1
  have hl : (RealRaw.ofRat (99/100)).Le (RealRaw.scaleRat t sqrt163) := by
    intro n m
    have hs := sqrt163_lower_fiftyOne_quarters 0 m
    change (51/4:Rat)≤(sqrt163.compute m).hi at hs
    have hb := Rat.mul_le_mul_of_nonneg_left hs ht.1
    change (99/100:Rat)≤((RealRaw.scaleRat t sqrt163).compute m).hi
    simp only [RealRaw.scaleRat,RealRaw.scaleRatCompute,if_pos hpos]
    exact Rat.le_trans ht.2 hb
  have he : (RealRaw.scaleRat t sqrt163).Le w.val.imagPart :=
    RealRaw.le_of_equiv (RealRaw.scaleRat_valid sqrt163_valid) (imagPart_valid w.property)
      (RealRaw.equiv_symm (cmHeckePoint41_imaginary i))
  exact RealRaw.le_trans (RealRaw.scaleRat_valid sqrt163_valid) hl he

end ComputableAnalysis.ModularForms
