import ComputableAnalysis.ModularForms.CMGrowthIsolationBounds163
import ComputableAnalysis.ModularForms.CMJNearIntegerError163

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

private def mainTerm : RealRaw := RealRaw.add (RealRaw.neg cmGrowthValue163) (RealRaw.ofRat 744)
private theorem main_valid : mainTerm.Valid :=
  RealRaw.add_valid (RealRaw.neg_valid (realPart_valid (entireExponentialValue cmGrowthExponent163).property))
    (RealRaw.ofRat_valid _)

private theorem error_agreement :
    cmJGrowthError163.val.realPart.Equiv (RealRaw.sub cmJValue163.val.realPart mainTerm) := by
  intro n
  apply (RealRaw.compareAt_overlap_iff _ _ n n).2
  have ho := RealRaw.interval_order_of_valid (RealRaw.sub cmJValue163.val.realPart mainTerm)
    (RealRaw.sub_valid (realPart_valid cmJValue163.property) main_valid) n
  change (cmJGrowthError163.val.realPart.compute n).lo≤
      ((RealRaw.sub cmJValue163.val.realPart mainTerm).compute n).hi ∧
    ((RealRaw.sub cmJValue163.val.realPart mainTerm).compute n).lo≤
      (cmJGrowthError163.val.realPart.compute n).hi
  simpa [cmJGrowthError163,mainTerm,cmGrowthValue163,ComplexRaw.realPart,
    ComplexRaw.sub,ComplexRaw.add,ComplexRaw.neg,ComplexRaw.ofQComplex,
    QBox.add,QBox.neg,QComplex.add,RealRaw.sub,RealRaw.subCompute,
    RealRaw.add,RealRaw.addCompute,RealRaw.neg,RealRaw.negCompute,RealRaw.ofRat,
    Rat.sub_eq_add_neg] using And.intro ho ho

/-- Exact reconstruction from the proved Laurent main term and actual error. -/
theorem cmJValue163_real_reconstruction :
    (RealRaw.add cmJGrowthError163.val.realPart mainTerm).Equiv cmJValue163.val.realPart :=
  RealRaw.equiv_trans (RealRaw.add_valid (realPart_valid cmJGrowthError163.property) main_valid)
    (RealRaw.add_valid (RealRaw.sub_valid (realPart_valid cmJValue163.property) main_valid) main_valid)
    (realPart_valid cmJValue163.property)
    (RealRaw.add_equiv (realPart_valid cmJGrowthError163.property)
      (RealRaw.sub_valid (realPart_valid cmJValue163.property) main_valid)
      main_valid main_valid error_agreement (RealRaw.equiv_refl mainTerm main_valid))
    (RealRaw.sub_add_cancel_equiv (realPart_valid cmJValue163.property) main_valid)

/-- The actual CM real coordinate lies in the checked quotient-isolation interval. -/
theorem cmJValue163_real_isolation_bounds :
    (RealRaw.ofRat (-2305843009213693952)).Le cmJValue163.val.realPart ∧
      cmJValue163.val.realPart.Le (RealRaw.ofRat (-144115188075854872)) := by
  have hv := RealRaw.add_valid (realPart_valid cmJGrowthError163.property) main_valid
  constructor
  · apply RealRaw.le_trans hv _
      (RealRaw.le_of_equiv hv (realPart_valid cmJValue163.property) cmJValue163_real_reconstruction)
    intro n m
    have he := cmJGrowthError163_small.1 0 m
    have hg := cmGrowthValue163_isolation_upper m 0
    change -(9/10000000000000:Rat)≤(cmJGrowthError163.val.realPart.compute m).hi at he
    change (cmGrowthValue163.compute m).lo≤2305843009213693000 at hg
    change (-2305843009213693952:Rat)≤
      (cmJGrowthError163.val.realPart.compute m).hi+(-(cmGrowthValue163.compute m).lo+744)
    grind only
  · apply RealRaw.le_trans hv
      (RealRaw.le_of_equiv (realPart_valid cmJValue163.property) hv
        (RealRaw.equiv_symm cmJValue163_real_reconstruction))
    intro n m
    have he := cmJGrowthError163_small.2.1 n 0
    have hg := cmGrowthValue163_isolation_lower 0 n
    change (cmJGrowthError163.val.realPart.compute n).lo≤(9/10000000000000:Rat) at he
    change (144115188075855872:Rat)≤(cmGrowthValue163.compute n).hi at hg
    change (cmJGrowthError163.val.realPart.compute n).lo+(-(cmGrowthValue163.compute n).hi+744)≤
      (-144115188075854872:Rat)
    grind only


/-- The actual CM coordinate stays at least 255 below the interval's upper endpoint. -/
theorem cmJValue163_real_isolation_upper_margin :
    cmJValue163.val.realPart.Le (RealRaw.ofRat (-144115188075855127)) := by
  have hv := RealRaw.add_valid (realPart_valid cmJGrowthError163.property) main_valid
  apply RealRaw.le_trans hv
    (RealRaw.le_of_equiv (realPart_valid cmJValue163.property) hv
      (RealRaw.equiv_symm cmJValue163_real_reconstruction))
  intro n m
  have he := cmJGrowthError163_small.2.1 n 0
  have hg := cmGrowthValue163_isolation_lower 0 n
  change (cmJGrowthError163.val.realPart.compute n).lo≤(9/10000000000000:Rat) at he
  change (144115188075855872:Rat)≤(cmGrowthValue163.compute n).hi at hg
  change (cmJGrowthError163.val.realPart.compute n).lo+(-(cmGrowthValue163.compute n).hi+744)≤
    (-144115188075855127:Rat)
  grind only

end ComputableAnalysis.ModularForms
