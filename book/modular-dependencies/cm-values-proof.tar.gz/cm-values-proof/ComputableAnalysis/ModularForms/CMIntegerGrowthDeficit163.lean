import ComputableAnalysis.ModularForms.CMJExactValue163
import ComputableAnalysis.ModularForms.CMJNearIntegerError163

namespace ComputableAnalysis.ModularForms

/-- The exponential near-integer statement follows from the exact CM value
and the independently proved Laurent error bounds. -/
theorem cmIntegerGrowthDeficit163_bounds :
    (RealRaw.ofRat (1/100000000000000)).Le cmIntegerGrowthDeficit163 ∧
      cmIntegerGrowthDeficit163.Le (RealRaw.ofRat (9/10000000000000)) :=
  cmIntegerGrowthDeficit163_bounds_of_cm_value cmJValue163_exact_value

end ComputableAnalysis.ModularForms
