import ComputableAnalysis.ModularForms.Hecke41NomeGeometricSquareDomain
import ComputableAnalysis.ModularForms.Hecke41NormalizedCauchyDerivative

/-! Actual finite edge evaluation with only geometric domain evidence. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def hecke41GeometricKernelGridSample (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val≤(hecke41NomeGeometricRadius a ha).val) (M : Nat) (hM : 0<M) (j : Nat) : Scalar :=
  let u := squareMidpointParameter M (j%M)
  let hu := squareMidpointParameter_unit M (j%M) hM (Nat.mod_lt j hM)
  let z := Centered.translate a (rationalRectangleScalar (QComplex.scaleRat R.val (point edge u)))
  let hz := hecke41NomeGeometric_square_edge_domain a ha edge R hR u hu.1 hu.2
  scalarProduct ((hecke41NomeDescended k 10000).eval z hz)
    (rationalSquaredKernel (QComplex.scaleRat R.val (point edge (squareMidpointParameter M j))))

def hecke41GeometricFiniteEdgeAverage (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val≤(hecke41NomeGeometricRadius a ha).val) (M : Nat) (hM : 0<M) : Scalar :=
  let s := gridScalarSum M (fun j => scalarProduct
    (hecke41GeometricKernelGridSample k a ha edge R hR M hM j)
    (rationalRectangleScalar (QComplex.scaleRat R.val (velocity edge))))
  ⟨scaleRat ((M:Rat)⁻¹) s.val,scaleRat_valid s.property⟩

theorem hecke41GeometricFiniteEdgeAverage_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val≤(hecke41NomeGeometricRadius a ha).val)
    (hOpen : R.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (M : Nat) (hM : 0<M) :
    (hecke41GeometricFiniteEdgeAverage k a ha edge R hR M hM).val.Equiv
      (hecke41SquareKernelAverage k a ha edge R M hM hOpen).val := by
  apply hecke41SquareKernelAverage_sample_agreement k a ha edge R M hM hOpen
    (hecke41GeometricKernelGridSample k a ha edge R hR M hM)
  intro j hj
  dsimp only [hecke41GeometricKernelGridSample]
  simp only [Nat.mod_eq_of_lt hj]
  apply equiv_refl
  exact mul_valid ((hecke41NomeDescended k 10000).eval _
    (hecke41SquareEdge_domain k a ha edge R hOpen _
      (squareMidpointParameter_unit M j hM hj).1
      (squareMidpointParameter_unit M j hM hj).2)).property
    (rationalSquaredKernel (QComplex.scaleRat R.val (point edge (squareMidpointParameter M j)))).property

theorem hecke41GeometricFiniteEdgeAverage_bound (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val≤(hecke41NomeGeometricRadius a ha).val) (M : Nat) (hM : 0<M) :
    Small (hecke41GeometricFiniteEdgeAverage k a ha edge R hR M hM).val
      (8*(2*(2:Rat)^10000)*(1/R.val)) := by
  let v := fun j => (hecke41NomeDescended k 10000).eval
    (Centered.translate a (rationalRectangleScalar (QComplex.scaleRat R.val
      (point edge (squareMidpointParameter M (j%M))))))
    (hecke41NomeGeometric_square_edge_domain a ha edge R hR _
      (squareMidpointParameter_unit M (j%M) hM (Nat.mod_lt j hM)).1
      (squareMidpointParameter_unit M (j%M) hM (Nat.mod_lt j hM)).2)
  exact squareSquaredKernel_finite_average_bound edge R M hM v (2*(2:Rat)^10000)
    (Rat.mul_nonneg (by decide +kernel) (Rat.pow_nonneg (by decide +kernel)))
    (fun j _ => hecke41NomeDescended_pole_bound k _
      (hecke41NomeGeometric_square_edge_domain a ha edge R hR _
        (squareMidpointParameter_unit M (j%M) hM (Nat.mod_lt j hM)).1
        (squareMidpointParameter_unit M (j%M) hM (Nat.mod_lt j hM)).2))

end ComputableAnalysis.ModularForms
