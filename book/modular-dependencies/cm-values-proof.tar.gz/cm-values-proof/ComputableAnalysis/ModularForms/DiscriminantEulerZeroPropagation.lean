import ComputableAnalysis.ModularForms.DiscriminantEulerLocalZero
import ComputableAnalysis.ModularForms.HomogeneousSegmentZeroPropagation
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
private noncomputable def coefficientOpen : ScalarTopology.OpenData tauLambertDividedMap.domain :=
  { invariant := tauLambertDividedMap.domain_congr
    radius := tauLambertDividedMap_holomorphic.openDomain.radius
    inside := tauLambertDividedMap_holomorphic.openDomain.inside }
private noncomputable def coefficientConstant : DomainFunctions.Map :=
  constantOn tauLambertDividedMap.domain coefficientOpen.invariant
    ⟨scaleRat (-24) one,scaleRat_valid (ofQComplex_valid _)⟩
/-- Actual holomorphic coefficient of the homogeneous divided-discrepancy equation. -/
noncomputable def discriminantEulerHolomorphicCoefficient : DomainFunctions.Map :=
  productOn coefficientConstant tauLambertDividedMap (fun _ h => h)
noncomputable def discriminantEulerHolomorphicCoefficient_holomorphic :
    Holomorphic discriminantEulerHolomorphicCoefficient :=
  (constantOn_holomorphic coefficientOpen
    ⟨scaleRat (-24) one,scaleRat_valid (ofQComplex_valid _)⟩).productOn
    tauLambertDividedMap_holomorphic (fun _ h => h)

theorem discriminantEulerDividedMap_homogeneous (q : Scalar)
    (hq : discriminantEulerDividedMap.domain q) :
    (discriminantEulerDividedMap_holomorphic.derivative q hq).val.Equiv
      (mul (discriminantEulerHolomorphicCoefficient.eval q hq).val
        (discriminantEulerDividedMap.eval q hq).val) := by
  have hh := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := (discriminantEulerDividedMap_holomorphic.derivative q hq).property)
    (hright := scaleRat_valid (mul_valid (tauLambertDividedMap.eval q hq).property
      (discriminantEulerDividedMap.eval q hq).property))
    (discriminantEulerDividedMap_coefficient q hq)
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (discriminantEulerDividedMap_holomorphic.derivative q hq).property)
    (hright := mul_valid (discriminantEulerHolomorphicCoefficient.eval q hq).property
      (discriminantEulerDividedMap.eval q hq).property)
  let d := ComplexRawQuotient.ofRaw (discriminantEulerDividedMap_holomorphic.derivative q hq).val
    (discriminantEulerDividedMap_holomorphic.derivative q hq).property
  let l := ComplexRawQuotient.ofRaw (tauLambertDividedMap.eval q hq).val (tauLambertDividedMap.eval q hq).property
  let k := ComplexRawQuotient.ofRaw (discriminantEulerDividedMap.eval q hq).val (discriminantEulerDividedMap.eval q hq).property
  change d=ComplexRawQuotient.scaleRat (-24) (l*k) at hh
  change d=(ComplexRawQuotient.scaleRat (-24) 1*l)*k
  rw [hh,ComplexRawQuotient.scaleRat_mul (-24) l k]
  rw [←ComplexRawQuotient.scaleRat_mul (-24) 1 l]
  congr 2
  grind only

/-- Zero of the actual discrepancy propagates along any justified represented punctured-nome segment. -/
theorem discriminantEulerDividedMap_segment_zero (p q : Scalar)
    (hp : discriminantEulerDividedMap.domain p) (hq : discriminantEulerDividedMap.domain q)
    (hdom : ∀ t : UnitInterval.Point,
      discriminantEulerDividedMap.domain (RepresentedAffineSegment.point p q t))
    (hz : (discriminantEulerDividedMap.eval p hp).val.Equiv zero) :
    (discriminantEulerDividedMap.eval q hq).val.Equiv zero :=
  homogeneous_segment_zero discriminantEulerDividedMap discriminantEulerHolomorphicCoefficient
    discriminantEulerDividedMap_holomorphic discriminantEulerHolomorphicCoefficient_holomorphic
    (fun _ h => h) discriminantEulerDividedMap_homogeneous p q hp hq hdom hz
end ComputableAnalysis.ModularForms
