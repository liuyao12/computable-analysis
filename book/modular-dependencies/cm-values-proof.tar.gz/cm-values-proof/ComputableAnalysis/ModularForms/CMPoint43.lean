import ComputableAnalysis.AlgebraicFunctions
import ComputableAnalysis.ModularForms.ImaginaryUnitAlgebra
import ComputableAnalysis.ModularForms.Hecke41Points
import ComputableAnalysis.ModularForms.GlobalDiscriminantNonvanishing

/-! An executable represented CM point for discriminant -43. -/
namespace ComputableAnalysis.ModularForms

private theorem sqrt43_domain : sqrtDomain 43 := by
  unfold sqrtDomain
  decide +kernel

def sqrt43 : RealRaw := sqrtRaw 43 sqrt43_domain

theorem sqrt43_valid : sqrt43.Valid := sqrtRaw_valid _ _

theorem sqrt43_square : (RealRaw.mul sqrt43 sqrt43).Equiv (RealRaw.ofRat 43) :=
  sqrtRaw_mul_self_equiv_of_domain _ _

theorem sqrt43_positive : sqrt43.Pos := by
  obtain ⟨N,hN⟩ := sqrt43_valid.2.2 (⟨1/2,by decide +kernel⟩ : QPos)
  have hw := hN N (Nat.le_refl N)
  have hs := sqrtRaw_stage_spec 43 sqrt43_domain N
  have hl := hs.sub_width_le_lo_of_sq_le (r := 1) (by decide +kernel)
  refine ⟨N, ?_⟩
  change 0<(sqrtApproxOnDomain 43 sqrt43_domain N).lo
  change (sqrtApproxOnDomain 43 sqrt43_domain N).width≤1/2 at hw
  change 1-(sqrtApproxOnDomain 43 sqrt43_domain N).width≤
    (sqrtApproxOnDomain 43 sqrt43_domain N).lo at hl
  grind

def cmPoint43 : ComplexRaw :=
  ComplexRaw.scaleRat (1/2)
    (ComplexRaw.add ComplexRaw.one (ComplexRaw.imaginaryAxis sqrt43))

theorem cmPoint43_valid : cmPoint43.Valid :=
  ComplexRaw.scaleRat_valid_of_nonneg (by decide +kernel)
    (ComplexRaw.add_valid (ComplexRaw.ofQComplex_valid _) (ComplexRaw.imaginaryAxis_valid sqrt43_valid))

theorem cmPoint43_upper : InUpperHalfPlane cmPoint43 := by
  obtain ⟨N,hN⟩ := sqrt43_positive
  refine ⟨N, ?_⟩
  change 0<(cmPoint43.compute N).lo.im
  unfold cmPoint43
  simp only [ComplexRaw.scaleRat,ComplexRaw.add,ComplexRaw.one,
    ComplexRaw.ofQComplex,ComplexRaw.imaginaryAxis_compute,QBox.scaleRat,
    QBox.add,if_pos (show (0:Rat)≤1/2 by decide +kernel)]
  change 0<(1/2)*(0+(sqrt43.compute N).lo)
  change 0<(sqrt43.compute N).lo at hN
  grind


open RiemannHilbert
set_option maxRecDepth 8192

def sqrt43Complex : ComplexRaw := ComplexRaw.ofRealRaw sqrt43

theorem sqrt43Complex_valid : sqrt43Complex.Valid :=
  ComplexRaw.ofRealRaw_valid _ sqrt43_valid

theorem sqrt43Complex_square :
    (ComplexRaw.mul sqrt43Complex sqrt43Complex).Equiv
      (ComplexRaw.ofQComplex ⟨43,0⟩) := by
  have hmul := real_embedding_mul sqrt43 sqrt43 sqrt43_valid sqrt43_valid
  have he := ComplexRaw.ofRealRaw_equiv_of_equiv
    (x := RealRaw.mul sqrt43 sqrt43) (y := RealRaw.ofRat 43)
    (RealRaw.mul_valid sqrt43_valid sqrt43_valid) (RealRaw.ofRat_valid 43) sqrt43_square
  exact ComplexRaw.equiv_trans
    (ComplexRaw.mul_valid sqrt43Complex_valid sqrt43Complex_valid)
    (ComplexRaw.ofRealRaw_valid _ (RealRaw.mul_valid sqrt43_valid sqrt43_valid))
    (ComplexRaw.ofQComplex_valid _) hmul he

def sqrt43Value : ScalarAlgebra.Value :=
  ComplexRawQuotient.ofRaw sqrt43Complex sqrt43Complex_valid

theorem sqrt43Value_square : sqrt43Value*sqrt43Value=((43 : Int) : ScalarAlgebra.Value) := by
  have h := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := ComplexRaw.mul_valid sqrt43Complex_valid sqrt43Complex_valid)
    (hright := ComplexRaw.ofQComplex_valid ⟨43,0⟩) sqrt43Complex_square
  rw [ComplexRawQuotient.ofRaw_mul] at h
  exact h.trans (integer_constant 43)



open RiemannHilbert
set_option maxRecDepth 8192

def cmPoint43Value : ScalarAlgebra.Value :=
  ComplexRawQuotient.ofRaw cmPoint43 cmPoint43_valid

private def halfValue : ScalarAlgebra.Value := ComplexRawQuotient.scaleRat (1/2) 1

private theorem half_twice : halfValue+halfValue=1 := by
  unfold halfValue
  rw [ComplexRawQuotient.add_scaleRat]
  have h : (1/2:Rat)+1/2=1 := by decide +kernel
  rw [h,ComplexRawQuotient.scaleRat_one]

theorem cmPoint43Value_formula :
    cmPoint43Value=ComplexRawQuotient.scaleRat (1/2)
      (1+imaginaryUnitValue*sqrt43Value) := by
  have hi := mulI_class (⟨sqrt43Complex,sqrt43Complex_valid⟩ : Scalar)
  change ComplexRawQuotient.ofRaw (ComplexRaw.imaginaryAxis sqrt43)
    (ComplexRaw.imaginaryAxis_valid sqrt43_valid)=imaginaryUnitValue*sqrt43Value at hi
  change ComplexRawQuotient.scaleRat (1/2)
    (1+ComplexRawQuotient.ofRaw (ComplexRaw.imaginaryAxis sqrt43)
      (ComplexRaw.imaginaryAxis_valid sqrt43_valid)) = _
  rw [hi]

theorem cmPoint43Value_quadratic :
    cmPoint43Value*cmPoint43Value=cmPoint43Value-11 := by
  have hform := cmPoint43Value_formula
  have hscale : ComplexRawQuotient.scaleRat (1/2)
      (1+imaginaryUnitValue*sqrt43Value)=halfValue*(1+imaginaryUnitValue*sqrt43Value) := by
    unfold halfValue
    rw [← ComplexRawQuotient.scaleRat_mul]
    congr 1
    grind
  rw [hscale] at hform
  have hs := sqrt43Value_square
  have hi := imaginaryUnitValue_square
  have hh := half_twice
  have ht : 2*(cmPoint43Value*cmPoint43Value-cmPoint43Value+11)=0 := by grind
  have hm := congrArg (fun x : ScalarAlgebra.Value => halfValue*x) ht
  grind

theorem cmPoint43_quadratic :
    (ComplexRaw.mul cmPoint43 cmPoint43).Equiv
      (integerAffine 1 (-11) cmPoint43) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := ComplexRaw.mul_valid cmPoint43_valid cmPoint43_valid)
    (hright := integerAffine_valid _ _ cmPoint43_valid)
  rw [ComplexRawQuotient.ofRaw_mul,
    integerAffine_class 1 (-11) (⟨cmPoint43,cmPoint43_valid⟩ : Scalar)]
  have h := cmPoint43Value_quadratic
  change cmPoint43Value*cmPoint43Value =
    ((1:Int):ScalarAlgebra.Value)*cmPoint43Value+((-11:Int):ScalarAlgebra.Value)
  grind


end ComputableAnalysis.ModularForms

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

def cmScalar43 : Scalar := ⟨cmPoint43,cmPoint43_valid⟩
def cmJValue43 : Scalar := latticeJMap.eval cmScalar43 (latticeJMap_global_domain _ cmPoint43_upper)

/-- The inverse of T^6 S sends the CM point to its fifth degree-41 representative. -/
def cmHeckeOrbitMatrix43 : SL2Z := ⟨0,1,-1,6,by decide +kernel⟩

theorem cmHeckePointFive43_action_agreement :
    (fractionalLinear cmHeckeOrbitMatrix43 cmScalar43 cmPoint43_upper).val.Equiv
      (hecke41Point ⟨5,by decide⟩ cmScalar43).val := by
  apply fractionalLinear_unique cmHeckeOrbitMatrix43 cmScalar43 cmPoint43_upper
    (hecke41Point ⟨5,by decide⟩ cmScalar43)
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := mul_valid (integerAffine_valid (-1) 6 cmScalar43.property)
      (hecke41Point ⟨5,by decide⟩ cmScalar43).property)
    (hright := integerAffine_valid 0 1 cmScalar43.property)
  rw [ComplexRawQuotient.ofRaw_mul _ _ (integerAffine_valid (-1) 6 cmScalar43.property)
    (hecke41Point ⟨5,by decide⟩ cmScalar43).property,
    integerAffine_class (-1) 6 cmScalar43,integerAffine_class 0 1 cmScalar43]
  have hc : ComplexRawQuotient.ofQComplex ⟨5,0⟩=(5:ScalarAlgebra.Value) := by
    have h := integer_constant 5
    rw [show ((5:Int):Rat)=(5:Rat) by decide +kernel] at h
    grind
  have hp := cmPoint43Value_quadratic
  change (((-1:Int):ScalarAlgebra.Value)*cmPoint43Value+((6:Int):ScalarAlgebra.Value))*
      ComplexRawQuotient.scaleRat (1/41) (cmPoint43Value+ComplexRawQuotient.ofQComplex ⟨5,0⟩)=
      ((0:Int):ScalarAlgebra.Value)*cmPoint43Value+((1:Int):ScalarAlgebra.Value)
  rw [hc,ComplexRawQuotient.mul_scaleRat]
  have hm : (((-1:Int):ScalarAlgebra.Value)*cmPoint43Value+((6:Int):ScalarAlgebra.Value))*
      (cmPoint43Value+5)=(41:ScalarAlgebra.Value) := by grind only
  have h41 : (41:ScalarAlgebra.Value)=ComplexRawQuotient.scaleRat 41 1 := by
    have h := ScalarAlgebra.scale_natural 41 (1:ScalarAlgebra.Value)
    rw [show ((41:Nat):Rat)=(41:Rat) by decide +kernel] at h
    grind only
  rw [hm,h41,
    ComplexRawQuotient.scaleRat_scaleRat,show (1/41:Rat)*41=1 by decide +kernel,
    ComplexRawQuotient.scaleRat_one]
  grind only

theorem hecke41Point_cm43_five_j :
    (latticeJMap.eval (hecke41Point ⟨5,by decide⟩ cmScalar43)
      (latticeJMap_global_domain _ (hecke41Point_upper _ _ cmPoint43_upper))).val.Equiv cmJValue43.val := by
  have he := latticeJMap.eval_congr
    (fractionalLinear cmHeckeOrbitMatrix43 cmScalar43 cmPoint43_upper)
    (hecke41Point ⟨5,by decide⟩ cmScalar43)
    (latticeJMap_action_mem _ _ (latticeJMap_global_domain _ cmPoint43_upper))
    (latticeJMap_global_domain _ (hecke41Point_upper _ _ cmPoint43_upper))
    cmHeckePointFive43_action_agreement
  exact equiv_trans
    (latticeJMap.eval (hecke41Point ⟨5,by decide⟩ cmScalar43)
      (latticeJMap_global_domain _ (hecke41Point_upper _ _ cmPoint43_upper))).property
    (latticeJMap.eval (fractionalLinear cmHeckeOrbitMatrix43 cmScalar43 cmPoint43_upper)
      (latticeJMap_action_mem _ _ (latticeJMap_global_domain _ cmPoint43_upper))).property
    cmJValue43.property (equiv_symm he)
    (latticeJMap_invariant _ _ (latticeJMap_global_domain _ cmPoint43_upper))

end ComputableAnalysis.ModularForms
