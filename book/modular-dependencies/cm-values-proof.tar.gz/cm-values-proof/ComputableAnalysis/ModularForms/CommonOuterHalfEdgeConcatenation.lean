import ComputableAnalysis.ModularForms.OuterHalfEdgeConcatenation
import ComputableAnalysis.ModularForms.Hecke41CommonSquareEdgeAgreement

/-! Exact midpoint subdivision of a supplied square-edge density. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def commonSquareEdgeDensity (f : QComplex → Scalar) (edge : HalfEdge)
    (S : QPos) (u : Rat) : Scalar :=
  scalarProduct (f (QComplex.scaleRat S.val (point edge u)))
    (rationalRectangleScalar (QComplex.scaleRat S.val (velocity edge)))

theorem commonSquareKernelAverage_midpoint_split (f : QComplex → Scalar)
    (edge : HalfEdge) (S : QPos) (M : Nat) (hM : 0<M) :
    (scalarSum
      (weightedMidpointSum (fun u => commonSquareEdgeDensity f edge S (u/2))
        M (1/((2*M:Nat):Rat)))
      (weightedMidpointSum (fun u => commonSquareEdgeDensity f edge S ((1+u)/2))
        M (1/((2*M:Nat):Rat)))).val.Equiv
      (commonSquareKernelAverage f edge S (2*M)).val :=
  weightedSquareMidpointSum_concat (commonSquareEdgeDensity f edge S) M hM _

theorem hecke41SquareKernelAverage_midpoint_split (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (B S : QPos)
    (hB : B.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (hS : S.val≤B.val) (edge : HalfEdge) (M : Nat) (hM : 0<M) :
    (scalarSum
      (weightedMidpointSum (fun u => commonSquareEdgeDensity
        (hecke41KernelSquareSample k a ha B hB) edge S (u/2)) M (1/((2*M:Nat):Rat)))
      (weightedMidpointSum (fun u => commonSquareEdgeDensity
        (hecke41KernelSquareSample k a ha B hB) edge S ((1+u)/2)) M (1/((2*M:Nat):Rat)))).val.Equiv
      (hecke41SquareKernelAverage k a ha edge S (2*M) (by omega)
        (Rat.le_trans hS hB)).val := by
  let f := hecke41KernelSquareSample k a ha B hB
  let left := scalarSum
    (weightedMidpointSum (fun u => commonSquareEdgeDensity f edge S (u/2)) M (1/((2*M:Nat):Rat)))
    (weightedMidpointSum (fun u => commonSquareEdgeDensity f edge S ((1+u)/2)) M (1/((2*M:Nat):Rat)))
  exact equiv_trans left.property (commonSquareKernelAverage f edge S (2*M)).property
    (hecke41SquareKernelAverage k a ha edge S (2*M) (by omega) (Rat.le_trans hS hB)).property
    (commonSquareKernelAverage_midpoint_split _ edge S M hM)
    (hecke41CommonSquare_edge_average_agreement k a ha B S hB hS edge (2*M) (by omega))

end ComputableAnalysis.ModularForms
