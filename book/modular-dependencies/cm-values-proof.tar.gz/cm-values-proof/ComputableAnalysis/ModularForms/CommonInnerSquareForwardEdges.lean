import ComputableAnalysis.ModularForms.Hecke41CommonSquareEdgeAgreement
import ComputableAnalysis.ModularForms.SquareFrameWeightedSides

/-! Generic inner-frame edge geometry for actual supplied samplers. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem common_inner_right_upper_sample (f : QComplex → Scalar) (R : QPos)
    (M v : Nat) (hM : 0<M) :
    (rectangleGridVertical f (squareFrameTile R 3 2) M 0 v).val.Equiv
      (scaleRat (1/(M:Rat)) (scalarProduct
        (f (QComplex.scaleRat R.val (point ⟨.east,true⟩ (squareMidpointParameter M v))))
        (rationalRectangleScalar (QComplex.scaleRat R.val (velocity ⟨.east,true⟩)))).val) := by
  rw [←squareFrameTile_shared_vertical_samples f R M 2 2 v hM]
  unfold rectangleGridVertical
  rw [squareFrame_inner_right_point R M 2 v hM,(squareFrameTile_grid_steps R M 2 2).2]
  have hp : ((2:Nat):Rat)-2+((v:Rat)+1/2)/(M:Rat)=squareMidpointParameter M v := by
    rw [show ((2:Nat):Rat)=(2:Rat) by decide +kernel]
    simp only [squareMidpointParameter,Rat.sub_self,Rat.zero_add]
  rw [hp,cartesianSquarePoint_agreement]
  have hw : (⟨0,R.val/(M:Rat)⟩ : QComplex)=QComplex.scaleRat (1/(M:Rat)) ⟨0,R.val⟩ := by
    simp only [QComplex.scaleRat,QComplex.mk.injEq,Rat.div_def]
    constructor <;> grind only
  rw [hw]
  have hv : QComplex.scaleRat R.val (velocity ⟨.east,true⟩)=⟨0,R.val⟩ := by
    simp only [velocity,rotation,orientation,↓reduceIte,QComplex.mul,QComplex.scaleRat,
      Rat.mul_zero,Rat.mul_one,Rat.sub_self,Rat.add_zero]
  rw [hv]
  exact rationalWeightedSample_scale _ _ _

theorem common_inner_right_upper_average (f : QComplex → Scalar) (R : QPos)
    (M : Nat) (hM : 0<M) :
    (squareFrameVerticalEdge f R M 3 2).val.Equiv
      (commonSquareKernelAverage f ⟨.east,true⟩ R M).val := by
  let density := fun v => scalarProduct
    (f (QComplex.scaleRat R.val (point ⟨.east,true⟩ (squareMidpointParameter M v))))
    (rationalRectangleScalar (QComplex.scaleRat R.val (velocity ⟨.east,true⟩)))
  have hs := gridScalarSum_congr M _
    (fun v => (⟨scaleRat (1/(M:Rat)) (density v).val,scaleRat_valid (density v).property⟩ : Scalar))
    (fun v => common_inner_right_upper_sample f R M v hM)
  exact equiv_trans (squareFrameVerticalEdge f R M 3 2).property
    (gridScalarSum M (fun v => (⟨scaleRat (1/(M:Rat)) (density v).val,
      scaleRat_valid (density v).property⟩ : Scalar))).property
    (commonSquareKernelAverage f ⟨.east,true⟩ R M).property hs
    (gridScalarSum_scale (1/(M:Rat)) density M)

theorem common_inner_bottom_upper_sample (f : QComplex → Scalar) (R : QPos)
    (M v : Nat) (hM : 0<M) :
    (rectangleGridHorizontal f (squareFrameTile R 2 1) M v 0).val.Equiv
      (scaleRat (1/(M:Rat)) (scalarProduct
        (f (QComplex.scaleRat R.val (point ⟨.south,true⟩ (squareMidpointParameter M v))))
        (rationalRectangleScalar (QComplex.scaleRat R.val (velocity ⟨.south,true⟩)))).val) := by
  unfold rectangleGridHorizontal
  rw [squareFrame_inner_bottom_point R M 2 v hM,(squareFrameTile_grid_steps R M 2 1).1]
  have hp : ((2:Nat):Rat)-2+((v:Rat)+1/2)/(M:Rat)=squareMidpointParameter M v := by
    rw [show ((2:Nat):Rat)=(2:Rat) by decide +kernel]
    simp only [squareMidpointParameter,Rat.sub_self,Rat.zero_add]
  rw [hp,cartesianSquarePoint_agreement]
  have hw : (⟨R.val/(M:Rat),0⟩ : QComplex)=QComplex.scaleRat (1/(M:Rat)) ⟨R.val,0⟩ := by
    simp only [QComplex.scaleRat,QComplex.mk.injEq,Rat.div_def]
    constructor <;> grind only
  rw [hw]
  have hv : QComplex.scaleRat R.val (velocity ⟨.south,true⟩)=⟨R.val,0⟩ := by
    simp only [velocity,rotation,orientation,↓reduceIte,QComplex.mul,QComplex.scaleRat,
      Rat.mul_zero,Rat.mul_one,Rat.sub_self,Rat.add_zero,Rat.sub_eq_add_neg,Rat.neg_neg,Rat.zero_add]
  rw [hv]
  exact rationalWeightedSample_scale _ _ _

theorem common_inner_bottom_upper_average (f : QComplex → Scalar) (R : QPos)
    (M : Nat) (hM : 0<M) :
    (squareFrameHorizontalEdge f R M 2 1).val.Equiv
      (commonSquareKernelAverage f ⟨.south,true⟩ R M).val := by
  let density := fun v => scalarProduct
    (f (QComplex.scaleRat R.val (point ⟨.south,true⟩ (squareMidpointParameter M v))))
    (rationalRectangleScalar (QComplex.scaleRat R.val (velocity ⟨.south,true⟩)))
  have hs := gridScalarSum_congr M _
    (fun v => (⟨scaleRat (1/(M:Rat)) (density v).val,scaleRat_valid (density v).property⟩ : Scalar))
    (fun v => common_inner_bottom_upper_sample f R M v hM)
  exact equiv_trans (squareFrameHorizontalEdge f R M 2 1).property
    (gridScalarSum M (fun v => (⟨scaleRat (1/(M:Rat)) (density v).val,
      scaleRat_valid (density v).property⟩ : Scalar))).property
    (commonSquareKernelAverage f ⟨.south,true⟩ R M).property hs
    (gridScalarSum_scale (1/(M:Rat)) density M)

theorem hecke41_inner_right_upper_average_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (B R : QPos)
    (hB : B.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (hR : R.val≤B.val) (M : Nat) (hM : 0<M) :
    (squareFrameVerticalEdge (hecke41KernelSquareSample k a ha B hB) R M 3 2).val.Equiv
      (hecke41SquareKernelAverage k a ha ⟨.east,true⟩ R M hM (Rat.le_trans hR hB)).val :=
  equiv_trans (squareFrameVerticalEdge (hecke41KernelSquareSample k a ha B hB) R M 3 2).property
    (commonSquareKernelAverage (hecke41KernelSquareSample k a ha B hB) ⟨.east,true⟩ R M).property
    (hecke41SquareKernelAverage k a ha ⟨.east,true⟩ R M hM (Rat.le_trans hR hB)).property
    (common_inner_right_upper_average _ R M hM)
    (hecke41CommonSquare_edge_average_agreement k a ha B R hB hR ⟨.east,true⟩ M hM)

theorem hecke41_inner_bottom_upper_average_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (B R : QPos)
    (hB : B.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (hR : R.val≤B.val) (M : Nat) (hM : 0<M) :
    (squareFrameHorizontalEdge (hecke41KernelSquareSample k a ha B hB) R M 2 1).val.Equiv
      (hecke41SquareKernelAverage k a ha ⟨.south,true⟩ R M hM (Rat.le_trans hR hB)).val :=
  equiv_trans (squareFrameHorizontalEdge (hecke41KernelSquareSample k a ha B hB) R M 2 1).property
    (commonSquareKernelAverage (hecke41KernelSquareSample k a ha B hB) ⟨.south,true⟩ R M).property
    (hecke41SquareKernelAverage k a ha ⟨.south,true⟩ R M hM (Rat.le_trans hR hB)).property
    (common_inner_bottom_upper_average _ R M hM)
    (hecke41CommonSquare_edge_average_agreement k a ha B R hB hR ⟨.south,true⟩ M hM)

end ComputableAnalysis.ModularForms
