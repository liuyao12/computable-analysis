import ComputableAnalysis.ModularForms.CommonOuterSquareBottomSamples
import ComputableAnalysis.ModularForms.CommonOuterRightLowerAssembly

/-! Signed assembly of the outer bottom half edges. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem commonSquareSouthDensity_lower_reflection (f : QComplex → Scalar)
    (S : QPos) (u : Rat) :
    (commonSquareEdgeDensity f ⟨.south,true⟩ S (u-1)).val.Equiv
      (neg (commonSquareEdgeDensity f ⟨.south,false⟩ S (1-u)).val) := by
  have hp : point ⟨.south,true⟩ (u-1)=point ⟨.south,false⟩ (1-u) := by
    simp only [point,rotation,orientation,Bool.false_eq_true,↓reduceIte,QComplex.mul,
      QComplex.mk.injEq]
    constructor <;> grind only
  have hv : QComplex.scaleRat S.val (velocity ⟨.south,false⟩)=
      QComplex.scaleRat (-1) (QComplex.scaleRat S.val (velocity ⟨.south,true⟩)) := by
    simp only [velocity,rotation,orientation,Bool.false_eq_true,↓reduceIte,
      QComplex.mul,QComplex.scaleRat,QComplex.mk.injEq]
    constructor <;> grind only
  let z := f (QComplex.scaleRat S.val (point ⟨.south,false⟩ (1-u)))
  let q := QComplex.scaleRat S.val (velocity ⟨.south,true⟩)
  have hs := rationalWeightedSample_scale z q (-1)
  have hn := negativeScale_equiv_negScale (scalarProduct z (rationalRectangleScalar q)) 1
  have ho := scaleRat_one_equiv (scalarProduct z (rationalRectangleScalar q)).val
    (scalarProduct z (rationalRectangleScalar q)).property
  have he := equiv_trans
    (scalarProduct z (rationalRectangleScalar (QComplex.scaleRat (-1) q))).property
    (scaleRat_valid (scalarProduct z (rationalRectangleScalar q)).property)
    (neg_valid (scaleRat_valid (scalarProduct z (rationalRectangleScalar q)).property)) hs hn
  have ht := equiv_trans
    (scalarProduct z (rationalRectangleScalar (QComplex.scaleRat (-1) q))).property
    (neg_valid (scaleRat_valid (scalarProduct z (rationalRectangleScalar q)).property))
    (neg_valid (scalarProduct z (rationalRectangleScalar q)).property) he (neg_equiv ho)
  have hr := neg_equiv ht
  have hd : (neg (neg (scalarProduct z (rationalRectangleScalar q)).val)).Equiv
      (scalarProduct z (rationalRectangleScalar q)).val := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := neg_valid (neg_valid (scalarProduct z (rationalRectangleScalar q)).property))
      (hright := (scalarProduct z (rationalRectangleScalar q)).property)
    rw [ComplexRawQuotient.ofRaw_neg,ComplexRawQuotient.ofRaw_neg,ComplexRawQuotient.neg_neg]
    all_goals first
      | exact (scalarProduct z (rationalRectangleScalar q)).property
      | exact neg_valid (scalarProduct z (rationalRectangleScalar q)).property
  unfold commonSquareEdgeDensity
  rw [hp,hv]
  exact equiv_symm (equiv_trans
    (neg_valid (scalarProduct z (rationalRectangleScalar (QComplex.scaleRat (-1) q))).property)
    (neg_valid (neg_valid (scalarProduct z (rationalRectangleScalar q)).property))
    (scalarProduct z (rationalRectangleScalar q)).property hr hd)

theorem common_outer_bottom_lower_concatenation (f : QComplex → Scalar) (R : QPos)
    (M : Nat) (hM : 0<M) :
    (scalarSum (squareFrameHorizontalEdge f R M 0 0)
      (squareFrameHorizontalEdge f R M 1 0)).val.Equiv
      (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.south,true⟩
        (squareFrameOuterRadius R) (u-1)) (2*M) (1/((2*M:Nat):Rat))).val := by
  have h0 := common_outer_bottom_tile_average f R M 0 hM
  have h1 := common_outer_bottom_tile_average f R M 1 hM
  have p0 (u : Rat) : (((0:Nat):Rat)-2+u)/2=u/2-1 := by
    change (0-2+u)/2=u/2-1
    grind only
  have p1 (u : Rat) : (((1:Nat):Rat)-2+u)/2=(1+u)/2-1 := by
    change (1-2+u)/2=(1+u)/2-1
    grind only
  have hr : 1/(2*(M:Rat))=1/((2*M:Nat):Rat) := by
    rw [Rat.natCast_mul]
    rfl
  simp only [p0,hr] at h0
  simp only [p1,hr] at h1
  let A := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.south,true⟩
    (squareFrameOuterRadius R) (u/2-1)) M (1/((2*M:Nat):Rat))
  let B := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.south,true⟩
    (squareFrameOuterRadius R) ((1+u)/2-1)) M (1/((2*M:Nat):Rat))
  let C := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.south,true⟩
    (squareFrameOuterRadius R) (u-1)) (2*M) (1/((2*M:Nat):Rat))
  exact equiv_trans (scalarSum (squareFrameHorizontalEdge f R M 0 0)
    (squareFrameHorizontalEdge f R M 1 0)).property (scalarSum A B).property C.property
    (add_equiv h0 h1)
    (weightedSquareMidpointSum_concat (fun u => commonSquareEdgeDensity f ⟨.south,true⟩
      (squareFrameOuterRadius R) (u-1)) M hM _)


theorem commonSouthShiftedAverage_agreement (f : QComplex → Scalar)
    (S : QPos) (M : Nat) (hM : 0<M) :
    (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.south,true⟩ S (u-1))
      M (1/(M:Rat))).val.Equiv
      (neg (commonSquareKernelAverage f ⟨.south,false⟩ S M).val) := by
  let d := fun v => commonSquareEdgeDensity f ⟨.south,false⟩ S
    (1-squareMidpointParameter M v)
  have hs := gridScalarSum_congr M _ (fun v => scalarNeg (d v))
    (fun v => commonSquareSouthDensity_lower_reflection f S (squareMidpointParameter M v))
  have ht := gridScalarSum_negation d M
  have hn := scaleRat_negation (gridScalarSum M d) (1/(M:Rat))
  have ha := scaleRat_equiv (r := 1/(M:Rat))
    (equiv_trans (gridScalarSum M (fun v => commonSquareEdgeDensity f ⟨.south,true⟩ S (squareMidpointParameter M v-1))).property
      (gridScalarSum M (fun v => scalarNeg (d v))).property
      (neg_valid (gridScalarSum M d).property) hs ht)
  have hb := neg_equiv (commonReflectedSquareAverage_agreement f ⟨.south,false⟩ S M hM)
  exact equiv_trans
    (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.south,true⟩ S (u-1)) M (1/(M:Rat))).property
    (scaleRat_valid (neg_valid (gridScalarSum M d).property))
    (neg_valid (commonSquareKernelAverage f ⟨.south,false⟩ S M).property) ha
    (equiv_trans (scaleRat_valid (neg_valid (gridScalarSum M d).property))
      (neg_valid (commonReflectedSquareAverage f ⟨.south,false⟩ S M).property)
      (neg_valid (commonSquareKernelAverage f ⟨.south,false⟩ S M).property) hn hb)

theorem common_outer_bottom_lower_average (f : QComplex → Scalar) (R : QPos)
    (M : Nat) (hM : 0<M) :
    (scalarSum (squareFrameHorizontalEdge f R M 0 0)
      (squareFrameHorizontalEdge f R M 1 0)).val.Equiv
      (neg (commonSquareKernelAverage f ⟨.south,false⟩ (squareFrameOuterRadius R) (2*M)).val) := by
  let C := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.south,true⟩
    (squareFrameOuterRadius R) (u-1)) (2*M) (1/((2*M:Nat):Rat))
  exact equiv_trans (scalarSum (squareFrameHorizontalEdge f R M 0 0)
    (squareFrameHorizontalEdge f R M 1 0)).property C.property
    (neg_valid (commonSquareKernelAverage f ⟨.south,false⟩ (squareFrameOuterRadius R) (2*M)).property)
    (common_outer_bottom_lower_concatenation f R M hM)
    (commonSouthShiftedAverage_agreement f (squareFrameOuterRadius R) (2*M) (by omega))

end ComputableAnalysis.ModularForms
