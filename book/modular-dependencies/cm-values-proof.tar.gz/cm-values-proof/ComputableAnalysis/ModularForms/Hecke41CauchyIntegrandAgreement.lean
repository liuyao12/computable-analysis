import ComputableAnalysis.ModularForms.Hecke41CauchyIntegrand

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

theorem hecke41CauchyIntegrandMap_eval (k : Nat) (a z : Scalar)
    (hz : hecke41CauchyIntegrandDomain k a z) :
    ((hecke41CauchyIntegrandMap k a).eval z hz).val =
      (mul ((hecke41CenteredNomeMap k a).eval z hz.1).val
        (pairedSquaredReciprocalMap.eval z hz.2).val) :=
  domainIntersectionProduct_eval _ _ z hz

theorem hecke41CenteredNomeMap_eval (k : Nat) (a z : Scalar)
    (hz : (hecke41CenteredNomeMap k a).domain z)
    (ht : hecke41NomePuncturedDomain (Centered.translate a z)) :
    ((hecke41CenteredNomeMap k a).eval z hz).val.Equiv
      ((hecke41NomeDescended k 10000).eval (Centered.translate a z) ht).val :=
  (hecke41NomeDescended k 10000).eval_congr
    ((pairedCenterTranslationMap a).eval z trivial) (Centered.translate a z)
    (compose_outer_mem hz) ht (pairedCenterTranslationMap_eval a z)

theorem pairedSquaredReciprocalMap_rational_agreement (q : QComplex)
    (hq : QComplex.normSq q≠0)
    (hz : pairedSquaredReciprocalMap.domain (rationalRectangleScalar q)) :
    (pairedSquaredReciprocalMap.eval (rationalRectangleScalar q) hz).val.Equiv
      (mul (ofQComplex (RationalReciprocal.inverse q))
        (ofQComplex (RationalReciprocal.inverse q))) :=
  mul_equiv (RepresentedReciprocal.inverse (rationalRectangleScalar q) hz).property
    (ofQComplex_valid _) (RepresentedReciprocal.inverse (rationalRectangleScalar q) hz).property
    (ofQComplex_valid _) (representedInverse_rational_agreement q hq hz)
    (representedInverse_rational_agreement q hq hz)

theorem hecke41CauchyIntegrandMap_rational_agreement (k : Nat) (a : Scalar) (q : QComplex)
    (hq : QComplex.normSq q≠0)
    (hz : (hecke41CauchyIntegrandMap k a).domain (rationalRectangleScalar q))
    (ht : hecke41NomePuncturedDomain (Centered.translate a (rationalRectangleScalar q))) :
    ((hecke41CauchyIntegrandMap k a).eval (rationalRectangleScalar q) hz).val.Equiv
      (mul ((hecke41NomeDescended k 10000).eval
        (Centered.translate a (rationalRectangleScalar q)) ht).val
        (mul (ofQComplex (RationalReciprocal.inverse q))
          (ofQComplex (RationalReciprocal.inverse q)))) := by
  have hv := hecke41CenteredNomeMap_eval k a (rationalRectangleScalar q) hz.1 ht
  have hi := pairedSquaredReciprocalMap_rational_agreement q hq hz.2
  rw [hecke41CauchyIntegrandMap_eval k a (rationalRectangleScalar q) hz]
  exact mul_equiv ((hecke41CenteredNomeMap k a).eval (rationalRectangleScalar q) hz.1).property
      ((hecke41NomeDescended k 10000).eval (Centered.translate a (rationalRectangleScalar q)) ht).property
      (pairedSquaredReciprocalMap.eval (rationalRectangleScalar q) hz.2).property
      (mul_valid (ofQComplex_valid _) (ofQComplex_valid _)) hv hi

end ComputableAnalysis.ModularForms
