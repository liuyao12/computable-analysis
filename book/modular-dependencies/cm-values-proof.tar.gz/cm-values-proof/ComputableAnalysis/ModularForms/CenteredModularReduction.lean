import ComputableAnalysis.ModularForms.GlobalDiscriminantNonvanishing
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory
set_option maxRecDepth 4000

/-- Total modular representative with both a fixed central strip and a proved lower height. -/
def centeredModularReducedPoint (z : UpperPoint) : UpperPoint :=
  ⟨modularCenteredPoint (modularReducedPoint z).val,
    modularCenteredPoint_mem _ (modularReducedPoint z).property⟩
def centeredModularReductionMatrix (z : UpperPoint) : SL2Z :=
  SL2Z.multiply (modularCenteringMatrix (modularReducedPoint z).val) (modularReductionMatrix z)

theorem centeredModularReducedPoint_action (z : UpperPoint) :
    (centeredModularReducedPoint z).val.val.Equiv
      (fractionalLinear (centeredModularReductionMatrix z) z.val z.property).val := by
  let w := modularReducedPoint z
  let g := modularCenteringMatrix w.val
  let h := modularReductionMatrix z
  have hc := equiv_symm (modularCenteredPoint_action w.val w.property)
  have ht := fractionalLinear_congr g w.val (fractionalLinear h z.val z.property)
    w.property (fractionalLinear_mem _ _ _) (modularReducedPoint_action z)
  exact equiv_trans (modularCenteredPoint w.val).property (fractionalLinear g w.val w.property).property
    (fractionalLinear (SL2Z.multiply g h) z.val z.property).property hc
    (equiv_trans (fractionalLinear g w.val w.property).property
      (fractionalLinear g (fractionalLinear h z.val z.property) (fractionalLinear_mem _ _ _)).property
      (fractionalLinear (SL2Z.multiply g h) z.val z.property).property ht
      (fractionalLinear_compose g h z.val z.property))

theorem centeredModularReducedPoint_real_bounds (z : UpperPoint) :
    (RealRaw.ofRat (-(33:Rat)/64)).Le (centeredModularReducedPoint z).val.val.realPart ∧
      (centeredModularReducedPoint z).val.val.realPart.Le (RealRaw.ofRat ((33:Rat)/64)) :=
  modularCenteredPoint_real_bounds (modularReducedPoint z).val

theorem centeredModularReducedPoint_height (z : UpperPoint) :
    (RealRaw.ofRat (3/4)).Le (centeredModularReducedPoint z).val.val.imagPart := by
  intro i j
  change (3/4:Rat)≤((modularCenteredPoint (modularReducedPoint z).val).val.imagPart.compute j).hi
  rw [congrFun (modularCenteredPoint_imag_compute (modularReducedPoint z).val) j]
  exact modularReducedPoint_height z i j

/-- The actual Hecke discrepancy quotient takes the same value at the constructed central representative. -/
theorem discriminantPrimeHeckeDifferenceQuotient_centered_reduction (p : Nat) (hp : BasicPrime p)
    (hpR : 0<(p:Rat)) (z : UpperPoint) :
    ((discriminantPrimeHeckeDifferenceQuotient p hpR).eval (centeredModularReducedPoint z).val
      (discriminantPrimeHeckeDifferenceQuotient_global_domain p hpR _ (centeredModularReducedPoint z).property)).val.Equiv
      ((discriminantPrimeHeckeDifferenceQuotient p hpR).eval z.val
        (discriminantPrimeHeckeDifferenceQuotient_global_domain p hpR z.val z.property)).val := by
  let F := discriminantPrimeHeckeDifferenceQuotient p hpR
  let hz := discriminantPrimeHeckeDifferenceQuotient_global_domain p hpR z.val z.property
  let w := centeredModularReducedPoint z
  let hw := discriminantPrimeHeckeDifferenceQuotient_global_domain p hpR w.val w.property
  let g := centeredModularReductionMatrix z
  let v := fractionalLinear g z.val z.property
  let hv := discriminantPrimeHeckeDifferenceQuotient_action_mem p hpR g z.val hz
  have he := F.eval_congr w.val v hw hv (centeredModularReducedPoint_action z)
  exact equiv_trans (F.eval w.val hw).property (F.eval v hv).property (F.eval z.val hz).property he
    (discriminantPrimeHeckeDifferenceQuotient_action p hp hpR g z.val hz)

end ComputableAnalysis.ModularForms
