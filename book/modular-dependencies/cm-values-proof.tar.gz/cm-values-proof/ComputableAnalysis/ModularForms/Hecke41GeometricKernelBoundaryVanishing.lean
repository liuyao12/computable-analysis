import ComputableAnalysis.ModularForms.Hecke41GeometricKernelUniformCells

/-! Actual Hecke rectangle boundaries vanish under dyadic refinement,
by analytic cell bounds and exact shared-edge cancellation. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

def hecke41GeometricKernelGridBoundary (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (J : QInterval × QInterval) (R B : QPos) (hs : rectangleSeparated J R)
    (hxl : -B.val≤J.1.lo) (hxu : J.1.hi≤B.val)
    (hyl : -B.val≤J.2.lo) (hyu : J.2.hi≤B.val)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val) (n : Nat) : Scalar :=
  rectangleGridBoundary (hecke41GeometricKernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB) J (2^n)

theorem hecke41GeometricKernelGridBoundary_eventual_bound (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (J : QInterval × QInterval) (R B : QPos) (hs : rectangleSeparated J R)
    (hxl : -B.val≤J.1.lo) (hxu : J.1.hi≤B.val)
    (hyl : -B.val≤J.2.lo) (hyu : J.2.hi≤B.val)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (eps W : QPos) (hX : J.1.lo≤J.1.hi) (hY : J.2.lo≤J.2.hi)
    (hx : J.1.width≤2*W.val) (hy : J.2.width≤2*W.val) :
    ∃ N, ∀ n, N≤n → Small (hecke41GeometricKernelGridBoundary k a ha J R B hs hxl hxu hyl hyu hB n).val (64*eps.val*W.val*W.val) := by
  obtain ⟨N,hN⟩ := hecke41GeometricKernel_indexed_dyadic_cell_bound k a ha J R B hs hxl hxu hyl hyu hB eps W hX hY hx hy
  refine ⟨N, ?_⟩
  intro n hn
  let E := 64*eps.val*(W.val*((1:Rat)/2)^n)*(W.val*((1:Rat)/2)^n)
  have hw : 0≤W.val*((1:Rat)/2)^n :=
    Rat.mul_nonneg (Rat.le_of_lt W.property) (Rat.pow_nonneg (by decide +kernel))
  have hE : 0≤E := Rat.mul_nonneg
    (Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) (Rat.le_of_lt eps.property)) hw) hw
  have hb := gridScalarDoubleSum_bound (2^n) (2^n)
    (fun j l => fullRectangleMidpointCycle (hecke41GeometricKernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB) (rectangleGridCell J (2^n) j l)) E hE
    (fun j l hj hl => hN n hn j l hj hl)
  have hp := two_pow_half_pow n
  have he : ((2^n:Nat):Rat)*(((2^n:Nat):Rat)*E)=64*eps.val*W.val*W.val := by
    dsimp [E]
    grind only
  rw [he] at hb
  exact Small.congr (rectangleGridCycleSum (hecke41GeometricKernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB) J (2^n)).property (hecke41GeometricKernelGridBoundary k a ha J R B hs hxl hxu hyl hyu hB n).property
    (rectangleGridCycleSum_boundary_agreement
      (hecke41GeometricKernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB) J (2^n)) hb

theorem hecke41GeometricKernelGridBoundary_converges_zero (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (J : QInterval × QInterval) (R B : QPos) (hs : rectangleSeparated J R)
    (hxl : -B.val≤J.1.lo) (hxu : J.1.hi≤B.val)
    (hyl : -B.val≤J.2.lo) (hyu : J.2.hi≤B.val)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (hX : J.1.lo≤J.1.hi) (hY : J.2.lo≤J.2.hi) (eps : QPos) :
    ∃ N, ∀ n, N≤n → Small (hecke41GeometricKernelGridBoundary k a ha J R B hs hxl hxu hyl hyu hB n).val eps.val := by
  let W : QPos := ⟨1+qabs J.1.width+qabs J.2.width,by
    have hx := qabs_nonneg J.1.width
    have hy := qabs_nonneg J.2.width
    grind only⟩
  have hx : J.1.width≤2*W.val := by
    have ha := self_le_qabs J.1.width
    have hb := qabs_nonneg J.1.width
    have hc := qabs_nonneg J.2.width
    change J.1.width≤2*(1+qabs J.1.width+qabs J.2.width)
    grind only
  have hy : J.2.width≤2*W.val := by
    have ha := self_le_qabs J.2.width
    have hb := qabs_nonneg J.1.width
    have hc := qabs_nonneg J.2.width
    change J.2.width≤2*(1+qabs J.1.width+qabs J.2.width)
    grind only
  have hD : 0<64*W.val*W.val :=
    Rat.mul_pos (Rat.mul_pos (by decide +kernel) W.property) W.property
  let eta : QPos := ⟨eps.val/(64*W.val*W.val),by
    rw [Rat.div_def]
    exact Rat.mul_pos eps.property (Rat.inv_pos.mpr hD)⟩
  obtain ⟨N,hN⟩ := hecke41GeometricKernelGridBoundary_eventual_bound k a ha J R B hs hxl hxu hyl hyu hB eta W hX hY hx hy
  refine ⟨N, ?_⟩
  intro n hn
  have hb := hN n hn
  have he : eta.val*(64*W.val*W.val)=eps.val := Rat.div_mul_cancel (Rat.ne_of_gt hD)
  have he' : 64*eta.val*W.val*W.val=eps.val := by grind only
  rw [he'] at hb
  exact hb

end ComputableAnalysis.ModularForms
