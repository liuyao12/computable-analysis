import ComputableAnalysis.ModularForms.Hecke41ShiftedPoleVariation

/-! Uniform variation of the actual executable common sampler on whole square half-edges. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem hecke41ShiftedPoleCommonSample_square_variation (k : Nat) (a b : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R B S : QPos)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (hRS : R.val≤S.val) (hSB : S.val≤B.val)
    (hd : S.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val)
    (r : Rat) (hr : r<R.val) (hb : Small b.val r)
    (edge : HalfEdge) (u v : Rat) (hu : 0≤u) (hu1 : u≤1) (hv : 0≤v) (hv1 : v≤1) :
    Small (sub
      (hecke41ShiftedPoleCommonSample k a b ha R B hB r hr hb
        (QComplex.scaleRat S.val (point edge u))).val
      (hecke41ShiftedPoleCommonSample k a b ha R B hB r hr hb
        (QComplex.scaleRat S.val (point edge v))).val)
      (hecke41ShiftedPoleVariationRate k a ha R S r*qabs (u-v)) := by
  let F := hecke41ShiftedPoleIntegrandMap k a b
  let x := F.eval (rationalRectangleScalar (QComplex.scaleRat S.val (point edge u)))
    (hecke41ShiftedPole_square_edge_domain k a b ha R B S hB hRS hSB r hr hb edge u hu hu1)
  let y := F.eval (rationalRectangleScalar (QComplex.scaleRat S.val (point edge v)))
    (hecke41ShiftedPole_square_edge_domain k a b ha R B S hB hRS hSB r hr hb edge v hv hv1)
  let p := hecke41ShiftedPoleCommonSample k a b ha R B hB r hr hb (QComplex.scaleRat S.val (point edge u))
  let q := hecke41ShiftedPoleCommonSample k a b ha R B hB r hr hb (QComplex.scaleRat S.val (point edge v))
  exact Small.congr (sub_valid x.property y.property) (sub_valid p.property q.property)
    (FunctionTheory.sub_congr
      (equiv_symm (hecke41ShiftedPoleCommonSample_square_edge_agreement k a b ha R B S hB hRS hSB r hr hb edge u hu hu1))
      (equiv_symm (hecke41ShiftedPoleCommonSample_square_edge_agreement k a b ha R B S hB hRS hSB r hr hb edge v hv hv1)))
    (hecke41ShiftedPole_uniform_variation k a b ha R B S hB hRS hSB hd r hr hb edge u v hu hu1 hv hv1)

end ComputableAnalysis.ModularForms
