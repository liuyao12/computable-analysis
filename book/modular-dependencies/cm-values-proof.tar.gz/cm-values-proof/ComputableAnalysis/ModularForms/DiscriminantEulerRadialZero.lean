import ComputableAnalysis.ModularForms.DiscriminantEulerUniformHalving
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- Iterated actual contraction gives a geometric bound at every positive rational radial scale. -/
theorem discriminantEulerRadial_iterated_bound
    (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R S b : Rat) (hR : 0<R) (hS : 0<S) (hb : 0<b)
    (hqr : Small q.val R) (hi : Small (RepresentedReciprocal.inverse q hq).val S)
    (hs : b*R≤(1:Rat)/65536) (hshort : 3072*(b*R)≤(1:Rat)/2) (N : Nat) :
    ∀ c, 0<c → c≤b → ∀ hz : discriminantEulerDividedMap.domain (rationalScaledScalar c q),
      Small (discriminantEulerDividedMap.eval (rationalScaledScalar c q) hz).val
        (radialDyadicAnchor (21072*S*R*R*b) N) := by
  have hB : 0<21072*S*R*R*b :=
    Rat.mul_pos (Rat.mul_pos (Rat.mul_pos (Rat.mul_pos (by decide +kernel) hS) hR) hR) hb
  induction N with
  | zero =>
    intro c hc hcb hz
    have hcs := Rat.le_trans (Rat.mul_le_mul_of_nonneg_right hcb (Rat.le_of_lt hR)) hs
    have hh := discriminantEulerDividedMap_radial_decay q hq R S c
      (Rat.le_of_lt hR) (Rat.le_of_lt hS) hc hqr hi hcs
    apply hh.mono
    simp only [radialDyadicAnchor, Rat.pow_zero, Rat.mul_one]
    change 21072*S*R*R*c≤21072*S*R*R*b
    exact Rat.mul_le_mul_of_nonneg_left hcb
      (Rat.mul_nonneg (Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) (Rat.le_of_lt hS))
        (Rat.le_of_lt hR)) (Rat.le_of_lt hR))
  | succ N ih =>
    have hh := discriminantEulerRadial_uniform_halving q hq R S b _ hR (Rat.le_of_lt hS) hb
      (radialDyadicAnchor_pos _ hB N) hqr hi hs hshort ih
    intro c hc hcb hz
    have ht := hh c hc hcb hz
    have he : radialDyadicAnchor (21072*S*R*R*b) (N+1) =
        radialDyadicAnchor (21072*S*R*R*b) N/2 := by
      unfold radialDyadicAnchor
      rw [Rat.pow_succ]
      grind only
    rw [he]
    exact ht

/-- The actual divided discrepancy vanishes exactly on a sufficiently short positive radial segment. -/
theorem discriminantEulerRadial_zero
    (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R S b : Rat) (hR : 0<R) (hS : 0<S) (hb : 0<b)
    (hqr : Small q.val R) (hi : Small (RepresentedReciprocal.inverse q hq).val S)
    (hs : b*R≤(1:Rat)/65536) (hshort : 3072*(b*R)≤(1:Rat)/2)
    (c : Rat) (hc : 0<c) (hcb : c≤b)
    (hz : discriminantEulerDividedMap.domain (rationalScaledScalar c q)) :
    (discriminantEulerDividedMap.eval (rationalScaledScalar c q) hz).val.Equiv zero := by
  have hB : 0<21072*S*R*R*b :=
    Rat.mul_pos (Rat.mul_pos (Rat.mul_pos (Rat.mul_pos (by decide +kernel) hS) hR) hR) hb
  have hzsmall : Small (discriminantEulerDividedMap.eval (rationalScaledScalar c q) hz).val 0 := by
    apply SeriesLimitLaws.small_closed _ 0 (radialDyadicAnchor (21072*S*R*R*b))
      (radialDyadicAnchor_shrinks _ hB)
    intro N
    simpa only [Rat.zero_add] using
      discriminantEulerRadial_iterated_bound q hq R S b hR hS hb hqr hi hs hshort N c hc hcb hz
  apply SeriesLimitLaws.equiv_of_small_sub_zero
  simpa only [Rat.add_zero] using SeriesLimitLaws.small_sub hzsmall (Small.zero (show (0:Rat)≤0 by decide +kernel))
end ComputableAnalysis.ModularForms
