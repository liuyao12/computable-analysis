import ComputableAnalysis.ModularForms.CMHeckePointwiseGrowth41
import ComputableAnalysis.ModularForms.RealExponentialStrictUpperComparison

/-! Literal rational candidates for point-specific CM correspondence exponential bounds. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory
set_option maxRecDepth 8192
set_option maxHeartbeats 4000000

/-- Literal bounds to be justified by finite factorial-series boxes. -/
def cmHeckeExponentialBounds41 (i : Fin 41) : Rat × Rat :=
  match QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i) with
  | 41 => (241000000000000000,622000000000000000)
  | 43 => (37400000000000000,92500000000000000)
  | 47 => (1450000000000000,3340000000000000)
  | 53 => (27800000000000,58400000000000)
  | 61 => (480000000000,915000000000)
  | 71 => (10800000000,19000000000)
  | 83 => (383000000,620000000)
  | 97 => (22000000,33400000)
  | 113 => (2010000,2880000)
  | 131 => (273000,374000)
  | 151 => (52000,68400)
  | 163 => (23300,30200)
  | 167 => (18300,23600)
  | 173 => (13000,16700)
  | 179 => (9490,12100)
  | 197 => (4100,5100)
  | 199 => (3770,4680)
  | 223 => (1550,1890)
  | 227 => (1360,1660)
  | 251 => (684,814)
  | 263 => (512,595)
  | _ => (512,595)

/-- All literal candidates satisfy the radius and discriminant comparison guards. -/
theorem cmHeckeExponentialBounds41_guards : ∀ i : Fin 41,
    let (L,B) := cmHeckeExponentialBounds41 i
    512≤L ∧ 0<B ∧ 440*(1/L)*(1/L)*B<1 := by
  decide +kernel

def cmHeckeLowerExponentialInput41 (i : Fin 41) : Rat :=
  (328287/200)*((QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹)-1/1000

def cmHeckeUpperDoubleExponentialInput41 (i : Fin 41) : Rat :=
  2*((41984/25)*((QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹)+1/1000)

def cmHeckeLowerExponentialBudget41 (i : Fin 41) : Rat :=
  match QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i) with
  | 41 => 41
  | 43 => 39
  | 47 => 35
  | 53 => 31
  | 61 => 27
  | 71 => 24
  | 83 => 20
  | 97 => 17
  | 113 => 15
  | 131 => 13
  | 151 => 11
  | 163 => 11
  | 167 => 10
  | 173 => 10
  | 179 => 10
  | 197 => 9
  | 199 => 9
  | 223 => 8
  | 227 => 8
  | 251 => 7
  | 263 => 7
  | _ => 83

def cmHeckeUpperDoubleExponentialBudget41 (i : Fin 41) : Rat :=
  match QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i) with
  | 41 => 82
  | 43 => 79
  | 47 => 72
  | 53 => 64
  | 61 => 56
  | 71 => 48
  | 83 => 41
  | 97 => 35
  | 113 => 30
  | 131 => 26
  | 151 => 23
  | 163 => 21
  | 167 => 21
  | 173 => 20
  | 179 => 19
  | 197 => 18
  | 199 => 17
  | 223 => 16
  | 227 => 15
  | 251 => 14
  | 263 => 13
  | _ => 83

/-- Integer radius budgets cover all rational exponential inputs. -/
theorem cmHeckeExponentialBudget41_valid : ∀ i : Fin 41,
    0<cmHeckeLowerExponentialInput41 i ∧
    cmHeckeLowerExponentialInput41 i≤cmHeckeLowerExponentialBudget41 i ∧
    0<cmHeckeUpperDoubleExponentialInput41 i ∧
    cmHeckeUpperDoubleExponentialInput41 i≤cmHeckeUpperDoubleExponentialBudget41 i := by
  decide +kernel

/-- All rational lower exponential candidates are certified by finite factorial-series boxes. -/
theorem cmHeckeLowerExponentialInput41_boxes : ∀ i : Fin 41,
    (cmHeckeExponentialBounds41 i).1≤
      ((ComplexExponentialApproximation.exponentialRawAt ⟨cmHeckeLowerExponentialInput41 i,0⟩
        (cmHeckeLowerExponentialBudget41 i)).compute 4).lo.re := by
  decide +kernel

/-- All rational double-growth upper candidates are certified by finite factorial-series boxes. -/
theorem cmHeckeUpperDoubleExponentialInput41_boxes : ∀ i : Fin 41,
    ((ComplexExponentialApproximation.exponentialRawAt ⟨cmHeckeUpperDoubleExponentialInput41 i,0⟩
      (cmHeckeUpperDoubleExponentialBudget41 i)).compute 4).hi.re≤
        (cmHeckeExponentialBounds41 i).2*(cmHeckeExponentialBounds41 i).2 := by
  decide +kernel

/-- The finite lower boxes bound the actual rational-input exponential. -/
theorem cmHeckeLowerExponentialInput41_lower (i : Fin 41) :
    (RealRaw.ofRat (cmHeckeExponentialBounds41 i).1).Le
      (entireExponentialValue ⟨ofQComplex ⟨cmHeckeLowerExponentialInput41 i,0⟩,ofQComplex_valid _⟩).val.realPart := by
  let t := cmHeckeLowerExponentialInput41 i
  let C := cmHeckeLowerExponentialBudget41 i
  have h := cmHeckeExponentialBudget41_valid i
  have ht : 0≤t := Rat.le_of_lt h.1
  have hC : 0≤C := Rat.le_trans ht h.2.1
  have hz : QComplex.normBound (⟨t,0⟩ : QComplex)≤C := by
    simpa [QComplex.normBound,qabs,if_neg (show ¬t<0 by grind only),Rat.add_zero] using h.2.1
  let f := ComplexExponentialApproximation.exponentialRawAt ⟨t,0⟩ C
  have hf : f.Valid := ComplexExponentialApproximation.exponentialRawAt_valid hC hz
  have hl : (RealRaw.ofRat (cmHeckeExponentialBounds41 i).1).Le f.realPart := by
    intro n m
    have ho := RealRaw.le_refl f.realPart (realPart_valid hf) 4 m
    change (cmHeckeExponentialBounds41 i).1≤(f.compute m).hi.re
    exact Rat.le_trans (cmHeckeLowerExponentialInput41_boxes i) ho
  have he := realPart_equiv (entireExponential_legacy_rational ⟨t,0⟩ C hC hz)
  exact RealRaw.le_trans (realPart_valid hf) hl
    (RealRaw.le_of_equiv (realPart_valid hf) (realPart_valid (entireExponentialValue _).property)
      (RealRaw.equiv_symm he))

/-- The finite upper boxes bound the actual rational-input double-growth exponential. -/
theorem cmHeckeUpperDoubleExponentialInput41_upper (i : Fin 41) :
    (entireExponentialValue ⟨ofQComplex ⟨cmHeckeUpperDoubleExponentialInput41 i,0⟩,ofQComplex_valid _⟩).val.realPart.Le
      (RealRaw.ofRat ((cmHeckeExponentialBounds41 i).2*(cmHeckeExponentialBounds41 i).2)) := by
  let t := cmHeckeUpperDoubleExponentialInput41 i
  let C := cmHeckeUpperDoubleExponentialBudget41 i
  have h := cmHeckeExponentialBudget41_valid i
  have ht : 0≤t := Rat.le_of_lt h.2.2.1
  have hC : 0≤C := Rat.le_trans ht h.2.2.2
  have hz : QComplex.normBound (⟨t,0⟩ : QComplex)≤C := by
    simpa [QComplex.normBound,qabs,if_neg (show ¬t<0 by grind only),Rat.add_zero] using h.2.2.2
  let f := ComplexExponentialApproximation.exponentialRawAt ⟨t,0⟩ C
  have hf : f.Valid := ComplexExponentialApproximation.exponentialRawAt_valid hC hz
  have hl : f.realPart.Le (RealRaw.ofRat ((cmHeckeExponentialBounds41 i).2*(cmHeckeExponentialBounds41 i).2)) := by
    intro n m
    have ho := RealRaw.le_refl f.realPart (realPart_valid hf) n 4
    change (f.compute n).lo.re≤(cmHeckeExponentialBounds41 i).2*(cmHeckeExponentialBounds41 i).2
    exact Rat.le_trans ho (cmHeckeUpperDoubleExponentialInput41_boxes i)
  have he := realPart_equiv (entireExponential_legacy_rational ⟨t,0⟩ C hC hz)
  exact RealRaw.le_trans (realPart_valid hf)
    (RealRaw.le_of_equiv (realPart_valid (entireExponentialValue _).property) (realPart_valid hf) he) hl

end ComputableAnalysis.ModularForms
