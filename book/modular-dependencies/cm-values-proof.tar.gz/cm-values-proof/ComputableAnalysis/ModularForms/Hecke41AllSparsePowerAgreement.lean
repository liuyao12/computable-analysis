import ComputableAnalysis.ModularForms.Hecke41SparsePowerRows
import ComputableAnalysis.ModularForms.Hecke41SparsePowerPackedChecks

namespace ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem hecke41SparsePowerRows_checked (k : Nat) (hk : k≤41) :
    hecke41SparsePowerRow k=sparsePowerQueryRow k := by
  cases k with
  | zero => exact hecke41SparsePower0_checked
  | succ k =>
    cases k with
    | zero => exact hecke41SparsePowerOne_checked
    | succ k =>
      cases k with
      | zero => exact hecke41SparsePower2_checked
      | succ k =>
        cases k with
        | zero => exact hecke41SparsePower3_checked
        | succ k =>
          cases k with
          | zero => exact hecke41SparsePower4_checked
          | succ k =>
            cases k with
            | zero => exact hecke41SparsePower5_checked
            | succ k =>
              cases k with
              | zero => exact hecke41SparsePower6_checked
              | succ k =>
                cases k with
                | zero => exact hecke41SparsePower7_checked
                | succ k =>
                  cases k with
                  | zero => exact hecke41SparsePower8_checked
                  | succ k =>
                    cases k with
                    | zero => exact hecke41SparsePower9_checked
                    | succ k =>
                      cases k with
                      | zero => exact hecke41SparsePower10_checked
                      | succ k =>
                        cases k with
                        | zero => exact hecke41SparsePower11_checked
                        | succ k =>
                          cases k with
                          | zero => exact hecke41SparsePower12_checked
                          | succ k =>
                            cases k with
                            | zero => exact hecke41SparsePower13_checked
                            | succ k =>
                              cases k with
                              | zero => exact hecke41SparsePower14_checked
                              | succ k =>
                                cases k with
                                | zero => exact hecke41SparsePower15_checked
                                | succ k =>
                                  cases k with
                                  | zero => exact hecke41SparsePower16_checked
                                  | succ k =>
                                    cases k with
                                    | zero => exact hecke41SparsePower17_checked
                                    | succ k =>
                                      cases k with
                                      | zero => exact hecke41SparsePower18_checked
                                      | succ k =>
                                        cases k with
                                        | zero => exact hecke41SparsePower19_checked
                                        | succ k =>
                                          cases k with
                                          | zero => exact hecke41SparsePower20_checked
                                          | succ k =>
                                            cases k with
                                            | zero => exact hecke41SparsePower21_checked
                                            | succ k =>
                                              cases k with
                                              | zero => exact hecke41SparsePower22_checked
                                              | succ k =>
                                                cases k with
                                                | zero => exact hecke41SparsePower23_checked
                                                | succ k =>
                                                  cases k with
                                                  | zero => exact hecke41SparsePower24_checked
                                                  | succ k =>
                                                    cases k with
                                                    | zero => exact hecke41SparsePower25_checked
                                                    | succ k =>
                                                      cases k with
                                                      | zero => exact hecke41SparsePower26_checked
                                                      | succ k =>
                                                        cases k with
                                                        | zero => exact hecke41SparsePower27_checked
                                                        | succ k =>
                                                          cases k with
                                                          | zero => exact hecke41SparsePower28_checked
                                                          | succ k =>
                                                            cases k with
                                                            | zero => exact hecke41SparsePower29_checked
                                                            | succ k =>
                                                              cases k with
                                                              | zero => exact hecke41SparsePower30_checked
                                                              | succ k =>
                                                                cases k with
                                                                | zero => exact hecke41SparsePower31_checked
                                                                | succ k =>
                                                                  cases k with
                                                                  | zero => exact hecke41SparsePower32_checked
                                                                  | succ k =>
                                                                    cases k with
                                                                    | zero => exact hecke41SparsePower33_checked
                                                                    | succ k =>
                                                                      cases k with
                                                                      | zero => exact hecke41SparsePower34_checked
                                                                      | succ k =>
                                                                        cases k with
                                                                        | zero => exact hecke41SparsePower35_checked
                                                                        | succ k =>
                                                                          cases k with
                                                                          | zero => exact hecke41SparsePower36_checked
                                                                          | succ k =>
                                                                            cases k with
                                                                            | zero => exact hecke41SparsePower37_checked
                                                                            | succ k =>
                                                                              cases k with
                                                                              | zero => exact hecke41SparsePower38_checked
                                                                              | succ k =>
                                                                                cases k with
                                                                                | zero => exact hecke41SparsePower39_checked
                                                                                | succ k =>
                                                                                  cases k with
                                                                                  | zero => exact hecke41SparsePower40_checked
                                                                                  | succ k =>
                                                                                    cases k with
                                                                                    | zero => exact hecke41SparsePower41_checked
                                                                                    | succ k =>
                                                                                      omega

/-- Every checked sparse power row gives the finite integer-series power
coefficients of the candidate input at all selected degrees. -/
theorem hecke41SparsePowerRows_integerAgreement (k : Nat) (hk : k≤41) (i : Fin 43) :
    (hecke41SparsePowerRow k)[i.val]?.getD 0=
      if 41*i.val+k<41 then 0 else
        integerSeriesPower (coefficient hecke41WeightedJCandidate) k (41*i.val+k-41) := by
  rw [hecke41SparsePowerRows_checked k hk]
  exact sparsePowerQueryRow_integerAgreement k hk i

end ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct
