import ComputableAnalysis.ModularForms.Hecke41FiniteAffineContourBound
import ComputableAnalysis.ModularForms.SuppliedAffineFiniteResidue

/-! Exact identification of the Hecke affine density with the general residue density. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem suppliedAffinePoleDensity_agreement (A d : Scalar) (edge : HalfEdge)
    (R : QPos) (u : Rat) :
    (affinePoleDensity A d edge R.val u).val.Equiv
      (orientSquareAverage edge.upper (suppliedSquareDensity
        (suppliedAffineValue A d (rationalRectangleScalar (QComplex.scaleRat R.val (point edge u))))
        edge R u)).val :=
  orientedPoleProduct_weight_agreement
    (suppliedAffineValue A d (rationalRectangleScalar (QComplex.scaleRat R.val (point edge u))))
    edge R.val u

theorem hecke41AffineGridPoleDensity_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (M : Nat) (hM : 0<M) (j : Nat) (hj : j<M) :
    (affinePoleDensity ((hecke41NomeDescended k 10000).eval a ha)
      ((hecke41NomeDescended_holomorphic k 10000).derivative a ha)
      edge R.val (squareMidpointParameter M j)).val.Equiv
      (orientSquareAverage edge.upper
        (hecke41SquareComparisonGridDensity true k a ha edge R hR M hM j)).val := by
  dsimp only [hecke41SquareComparisonGridDensity]
  simp only [↓reduceIte,Nat.mod_eq_of_lt hj]
  exact suppliedAffinePoleDensity_agreement _ _ edge R _

end ComputableAnalysis.ModularForms
