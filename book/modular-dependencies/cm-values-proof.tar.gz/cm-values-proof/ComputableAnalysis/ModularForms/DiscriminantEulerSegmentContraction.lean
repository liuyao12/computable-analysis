import ComputableAnalysis.ModularForms.DiscriminantEulerRadialDecay
import ComputableAnalysis.ModularForms.DomainSegmentBisection
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- A segment estimate for the actual divided discrepancy with bounded values on that segment. -/
theorem discriminantEulerDividedMap_segment_variation (p q : Scalar)
    (hp : discriminantEulerDividedMap.domain p) (hq : discriminantEulerDividedMap.domain q)
    (W : QPos) (B : Rat) (hB : 0<B)
    (hdom : ∀ t : UnitInterval.Point, discriminantEulerDividedMap.domain (RepresentedAffineSegment.point p q t))
    (hd : Small (AffineSegment.displacement p q).val W.val)
    (hb : ∀ t, Small (discriminantEulerDividedMap.eval (RepresentedAffineSegment.point p q t) (hdom t)).val B) :
    Small (sub (discriminantEulerDividedMap.eval q hq).val (discriminantEulerDividedMap.eval p hp).val)
      (3072*B*W.val) := by
  let Z : Scalar := ⟨zero,ofQComplex_valid _⟩
  let eps : QPos := ⟨768*B,Rat.mul_pos (by decide +kernel) hB⟩
  have hder (t : UnitInterval.Point) :
      Small (sub (discriminantEulerDividedMap_holomorphic.derivative
        (RepresentedAffineSegment.point p q t) (hdom t)).val Z.val) eps.val := by
    have hh := discriminantEulerDividedMap_derivative_bound _ (hdom t) B (Rat.le_of_lt hB) (hb t)
    have hs := SeriesLimitLaws.small_sub hh (Small.zero (by decide +kernel : (0:Rat)≤0))
    simpa only [Rat.add_zero] using hs
  have hr := domainSegment_remainder_bound discriminantEulerDividedMap
    discriminantEulerDividedMap_holomorphic p q Z hp hq W eps hdom hd hder
  have he : (DomainFunctions.remainder discriminantEulerDividedMap p hp Z q hq).Equiv
      (sub (discriminantEulerDividedMap.eval q hq).val (discriminantEulerDividedMap.eval p hp).val) := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq (hleft := DomainFunctions.remainder_valid _ _ _ _ _ _)
      (hright := sub_valid (discriminantEulerDividedMap.eval q hq).property (discriminantEulerDividedMap.eval p hp).property)
    let a := ComplexRawQuotient.ofRaw (discriminantEulerDividedMap.eval q hq).val (discriminantEulerDividedMap.eval q hq).property
    let b := ComplexRawQuotient.ofRaw (discriminantEulerDividedMap.eval p hp).val (discriminantEulerDividedMap.eval p hp).property
    let z := ComplexRawQuotient.ofRaw q.val q.property
    let w := ComplexRawQuotient.ofRaw p.val p.property
    change (a-b)-0*(z-w)=a-b
    grind only
  have hh := Small.congr (DomainFunctions.remainder_valid _ _ _ _ _ _)
    (sub_valid (discriminantEulerDividedMap.eval q hq).property (discriminantEulerDividedMap.eval p hp).property) he hr
  apply hh.mono
  change 4*(768*B)*W.val≤3072*B*W.val
  grind only
/-- A small anchor value and a short justified segment improve the actual discrepancy bound. -/
theorem discriminantEulerDividedMap_segment_contraction (p q : Scalar)
    (hp : discriminantEulerDividedMap.domain p) (hq : discriminantEulerDividedMap.domain q)
    (W : QPos) (B E : Rat) (hB : 0<B)
    (hdom : ∀ t : UnitInterval.Point, discriminantEulerDividedMap.domain (RepresentedAffineSegment.point p q t))
    (hd : Small (AffineSegment.displacement p q).val W.val)
    (hb : ∀ t, Small (discriminantEulerDividedMap.eval (RepresentedAffineSegment.point p q t) (hdom t)).val B)
    (he : Small (discriminantEulerDividedMap.eval p hp).val E) (hshort : 3072*W.val≤(1:Rat)/2) :
    Small (discriminantEulerDividedMap.eval q hq).val (B/2+E) := by
  have hv := discriminantEulerDividedMap_segment_variation p q hp hq W B hB hdom hd hb
  have hh := LocalODE.small_add hv he
  have heq : (add (sub (discriminantEulerDividedMap.eval q hq).val (discriminantEulerDividedMap.eval p hp).val)
      (discriminantEulerDividedMap.eval p hp).val).Equiv (discriminantEulerDividedMap.eval q hq).val := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := add_valid (sub_valid (discriminantEulerDividedMap.eval q hq).property
        (discriminantEulerDividedMap.eval p hp).property) (discriminantEulerDividedMap.eval p hp).property)
      (hright := (discriminantEulerDividedMap.eval q hq).property)
    let a := ComplexRawQuotient.ofRaw (discriminantEulerDividedMap.eval q hq).val (discriminantEulerDividedMap.eval q hq).property
    let b := ComplexRawQuotient.ofRaw (discriminantEulerDividedMap.eval p hp).val (discriminantEulerDividedMap.eval p hp).property
    change (a-b)+b=a
    grind only
  have hs := Small.congr (add_valid (sub_valid (discriminantEulerDividedMap.eval q hq).property
    (discriminantEulerDividedMap.eval p hp).property) (discriminantEulerDividedMap.eval p hp).property)
    (discriminantEulerDividedMap.eval q hq).property heq hh
  apply hs.mono
  have hm := Rat.mul_le_mul_of_nonneg_right hshort (Rat.le_of_lt hB)
  grind only
/-- Shrinking actual anchor values remove the additive error in the segment contraction.
The supplied segments must stay in the justified punctured domain. -/
theorem discriminantEulerDividedMap_limit_contraction (q : Scalar)
    (hq : discriminantEulerDividedMap.domain q) (p : Nat → Scalar)
    (hp : ∀ N, discriminantEulerDividedMap.domain (p N)) (W : QPos) (B : Rat) (hB : 0<B)
    (hdom : ∀ N, ∀ t : UnitInterval.Point,
      discriminantEulerDividedMap.domain (RepresentedAffineSegment.point (p N) q t))
    (hd : ∀ N, Small (AffineSegment.displacement (p N) q).val W.val)
    (hb : ∀ N t, Small (discriminantEulerDividedMap.eval
      (RepresentedAffineSegment.point (p N) q t) (hdom N t)).val B)
    (E : Nat → Rat) (he : ∀ N, Small (discriminantEulerDividedMap.eval (p N) (hp N)).val (E N))
    (hlim : ShrinksToZero E) (hshort : 3072*W.val≤(1:Rat)/2) :
    Small (discriminantEulerDividedMap.eval q hq).val (B/2) := by
  apply SeriesLimitLaws.small_closed _ (B/2) E hlim
  intro N
  exact discriminantEulerDividedMap_segment_contraction (p N) q (hp N) hq W B (E N) hB
    (hdom N) (hd N) (hb N) (he N) hshort
end ComputableAnalysis.ModularForms
