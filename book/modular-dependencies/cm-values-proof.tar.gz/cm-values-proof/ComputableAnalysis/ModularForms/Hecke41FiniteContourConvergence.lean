import ComputableAnalysis.ModularForms.Hecke41DyadicFiniteContourAgreement

/-! Actual finite square contours converge to the constructed contour value. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem hecke41FiniteSquareContour_converges (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) (eps : QPos) :
    ∃ N, ∀ n, N≤n → Small
      (sub (hecke41DyadicKernelContourLimit k a ha R hR PDE.CauchyContour.square).val
        (hecke41SquareKernelEdgeList k a ha R (2^n) (Nat.pow_pos (by decide +kernel))
          (Rat.le_trans hR (minRadius_left _ _)) PDE.CauchyContour.square).val) eps.val := by
  let eta : QPos := ⟨eps.val/(16*R.val), by
    rw [Rat.div_def]
    exact Rat.mul_pos eps.property (Rat.inv_pos.mpr
      (Rat.mul_pos (by decide +kernel) R.property))⟩
  obtain ⟨N,hN⟩ := hecke41SquareKernelTail_shrinks k a ha R eta
  refine ⟨N, ?_⟩
  intro n hn
  have hb := hecke41ContourLimit_finite_error k a ha R hR n PDE.CauchyContour.square
  have ht := hN n hn
  have he (E : Rat) (hE : E≤eta.val) : 8*(2*E*R.val)≤eps.val := by
    have hp : 0<16*R.val := Rat.mul_pos (by decide +kernel) R.property
    have hm := Rat.mul_le_mul_of_nonneg_right hE (Rat.le_of_lt hp)
    have hc : (eps.val/(16*R.val))*(16*R.val)=eps.val := Rat.div_mul_cancel (Rat.ne_of_gt hp)
    change E*(16*R.val)≤(eps.val/(16*R.val))*(16*R.val) at hm
    rw [hc] at hm
    have ha : 8*(2*E*R.val)=E*(16*R.val) := by grind only
    rw [ha]
    exact hm
  apply hb.mono
  change 8*(2*hecke41SquareKernelTail k a ha R n*R.val)≤eps.val
  exact he _ ht

end ComputableAnalysis.ModularForms
