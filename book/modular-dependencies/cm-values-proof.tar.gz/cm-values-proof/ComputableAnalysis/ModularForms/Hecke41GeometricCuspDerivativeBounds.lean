import ComputableAnalysis.ModularForms.Hecke41GeometricCauchyDerivative
import ComputableAnalysis.ModularForms.Hecke41CuspCauchyDerivativeBounds

/-! Higher cusp weight derivative bounds from actual geometric Cauchy estimates. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

theorem hecke41NomeLinearDerivative_geometric_cauchy_bound (k : Nat) (q : Scalar)
    (hq : hecke41NomePuncturedDomain q) (S : QPos)
    (hS : S.val≤(hecke41NomeGeometricRadius q hq).val)
    (R : Rat) (hR : 0≤R) (hqR : Small q.val R) :
    Small ((hecke41NomeDescended_holomorphic k 10001).derivative q hq).val
      (2*hecke41CauchyDerivativeRate S*R+2*(2:Rat)^10000) :=
  hecke41NomeDescended_linear_derivative_bound k q hq R (hecke41CauchyDerivativeRate S)
    hR (hecke41CauchyDerivativeRate_nonneg S) hqR (hecke41NomeDerivative_geometric_cauchy_bound k q hq S hS)

theorem hecke41NomeQuadraticDerivative_geometric_cauchy_bound (k : Nat) (q : Scalar)
    (hq : hecke41NomePuncturedDomain q) (S : QPos)
    (hS : S.val≤(hecke41NomeGeometricRadius q hq).val)
    (R : Rat) (hR : 0≤R) (hqR : Small q.val R) :
    Small ((hecke41NomeDescended_holomorphic k 10002).derivative q hq).val
      (4*hecke41CauchyDerivativeRate S*R*R+4*(2*(2:Rat)^10000)*R) :=
  hecke41NomeDescended_quadratic_derivative_bound k q hq R (hecke41CauchyDerivativeRate S)
    hR (hecke41CauchyDerivativeRate_nonneg S) hqR (hecke41NomeDerivative_geometric_cauchy_bound k q hq S hS)

end ComputableAnalysis.ModularForms
