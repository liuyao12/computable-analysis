import ComputableAnalysis.ModularForms.PrimeHeckeWeightedInversionTerm
namespace ComputableAnalysis.ModularForms
open RiemannHilbert
/-- Literal finite sum of certified scalar values, in the proof quotient. -/
def scalarClassListSum : List ScalarAlgebra.Value → ScalarAlgebra.Value
  | [] => 0
  | x::xs => x+scalarClassListSum xs
/-- A justified finite permutation preserves the literal scalar sum. -/
theorem scalarClassListSum_perm {xs ys : List ScalarAlgebra.Value} (h : xs.Perm ys) :
    scalarClassListSum xs=scalarClassListSum ys := by
  induction h with
  | nil => rfl
  | cons a h ih => simp only [scalarClassListSum,ih]
  | swap a b l => simp only [scalarClassListSum]; grind only
  | trans h1 h2 ih1 ih2 => exact ih1.trans ih2
private theorem ofFn_nodup {n : Nat} {α : Type} (f : Fin n → α) (hf : Function.Injective f) :
    (List.ofFn f).Nodup := by
  induction n with
  | zero => simp [List.ofFn_zero]
  | succ n ih =>
    rw [List.ofFn_succ]
    apply List.nodup_cons.mpr
    constructor
    · intro h
      obtain ⟨j,hj⟩ := List.mem_ofFn.mp h
      have hh := congrArg Fin.val (hf hj)
      change j.val+1=0 at hh
      omega
    · apply ih (fun j => f j.succ)
      intro j k h
      have hh := congrArg Fin.val (hf h)
      apply Fin.ext
      change j.val+1=k.val+1 at hh
      omega
/-- The proved inversion bijection permutes the literal finite index list. -/
theorem primeHeckeSIndex_list_perm (p : Nat) (hp : BasicPrime p) :
    (List.ofFn (primeHeckeSIndex p hp)).Perm (List.ofFn (fun i : Fin (p+1) => i)) := by
  apply (List.perm_ext_iff_of_nodup
    (ofFn_nodup _ (primeHeckeSIndex_injective p hp)) (ofFn_nodup _ (fun _ _ h => h))).mpr
  intro i
  simp only [List.mem_ofFn]
  constructor
  · intro _; exact ⟨i,rfl⟩
  · intro _; exact primeHeckeSIndex_surjective p hp i
/-- Reindexing by the executable prime inversion preserves every supplied scalar finite sum. -/
theorem primeHeckeSIndex_scalar_sum (p : Nat) (hp : BasicPrime p)
    (f : Fin (p+1) → ScalarAlgebra.Value) :
    scalarClassListSum (List.ofFn (fun i => f (primeHeckeSIndex p hp i)))=
      scalarClassListSum (List.ofFn f) := by
  have hh := (primeHeckeSIndex_list_perm p hp).map f
  rw [List.map_ofFn,List.map_ofFn] at hh
  exact scalarClassListSum_perm hh
/-- A supplied scalar factor distributes over a literal finite sum. -/
theorem scalarClassListSum_mul_left (v : ScalarAlgebra.Value) (xs : List ScalarAlgebra.Value) :
    scalarClassListSum (xs.map (fun x => v*x))=v*scalarClassListSum xs := by
  induction xs with
  | nil => simp only [List.map,scalarClassListSum]; grind only
  | cons x xs ih => simp only [List.map,scalarClassListSum,ih]; grind only
end ComputableAnalysis.ModularForms
