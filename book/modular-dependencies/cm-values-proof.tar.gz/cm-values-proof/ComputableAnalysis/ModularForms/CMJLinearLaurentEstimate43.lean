import ComputableAnalysis.ModularForms.CMJAnalyticBounds43
import ComputableAnalysis.ModularForms.LatticeJLinearLaurentEstimate

/-! A quantitative linear Laurent estimate for the actual discriminant-43 value. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- After the linear nome term, the actual Fourier error is at most a millionth. -/
theorem cmJValue43_linear_laurent_bound :
    Small (sub cmJValue43.val
      (add (add (RepresentedReciprocal.inverse (nome.eval cmScalar43 cmPoint43_upper)
        (nome_nonzero cmScalar43 cmPoint43_upper)).val (ofQComplex ⟨744,0⟩))
        (scaleRat 196884 (nome.eval cmScalar43 cmPoint43_upper).val))) (1/1000000) := by
  let q := nome.eval cmScalar43 cmPoint43_upper
  let d := nomeModularDiscriminant q (1/750000000) (by decide +kernel) (by decide +kernel) nome_cm43_small
  have hd := nomeModularDiscriminant_sharp_linear_bound q (1/750000000)
    (by decide +kernel) (by decide +kernel) nome_cm43_small (by decide +kernel)
  have hv := scalar_perturbation_inverse_bound q d (nome_nonzero _ _)
    (latticeJMap_fourier_discriminant_nonzero cmScalar43 (latticeJMap_global_domain _ cmPoint43_upper)
      (1/750000000) (by decide +kernel) (by decide +kernel) nome_cm43_small)
    1400000000 (103*(1/750000000)*(1/750000000))
    (by decide +kernel) (by decide +kernel) cmNomeInverse43_bound hd (by decide +kernel)
  exact (latticeJMap_linear_laurent_bound cmScalar43 (latticeJMap_global_domain _ cmPoint43_upper)
    (1/750000000) (by decide +kernel) (by decide +kernel) nome_cm43_small (by decide +kernel)
    1400000000 (8*1400000000) (by decide +kernel) (by decide +kernel)
    cmNomeInverse43_bound hv).mono (by decide +kernel)

end ComputableAnalysis.ModularForms
