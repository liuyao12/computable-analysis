import ComputableAnalysis.ModularForms.Hecke41GeometricSquareRadiusComparison
import ComputableAnalysis.ModularForms.Hecke41ContourShrinkingRadius

/-! Geometric finite contour comparison in the shrinking-radius coordinates. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def hecke41GeometricDyadicContour (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeGeometricRadius a ha).val) (n : Nat) : Scalar :=
  hecke41GeometricFiniteContour k a ha R hR (2^n)
    (Nat.pow_pos (by decide +kernel)) PDE.CauchyContour.square

theorem hecke41GeometricDyadicContour_half_radius (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeGeometricRadius a ha).val) (eps : QPos) :
    ∃ N, ∀ n, N≤n → Small
      (sub (hecke41GeometricDyadicContour k a ha R hR (n+1)).val
        (hecke41GeometricDyadicContour k a ha (squareHalfRadius R)
          (Rat.le_trans (squareHalfRadius_le R) hR) n).val) eps.val := by
  have ho : (squareFrameOuterRadius (squareHalfRadius R)).val≤
      (hecke41NomeGeometricRadius a ha).val := by
    rw [squareHalfRadius_outer]
    exact hR
  obtain ⟨N,hN⟩ := hecke41GeometricSquareContour_doubled_radius_difference_converges_zero
    k a ha (squareHalfRadius R) ho eps
  refine ⟨N, ?_⟩
  intro n hn
  have he : 2*(2^n)=2^(n+1) := by rw [Nat.pow_succ]; omega
  simpa only [squareHalfRadius_outer,he,hecke41GeometricDyadicContour] using hN n hn

end ComputableAnalysis.ModularForms
