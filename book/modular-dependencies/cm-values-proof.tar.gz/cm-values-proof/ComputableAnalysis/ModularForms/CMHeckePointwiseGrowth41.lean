import ComputableAnalysis.ModularForms.CMHeckeSharpHeight41

/-! Point-specific rational enclosures for actual CM correspondence growth. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- A justified nonnegative upper height bound bounds the actual nome growth above. -/
theorem nomeHeightGrowth_upper (z : Scalar) (c : Rat) (hc : 0≤c)
    (hz : z.val.imagPart.Le (RealRaw.ofRat c)) :
    (nomeHeightGrowth z).Le (RealRaw.ofRat (4*(8/5)*c)) := by
  intro n m
  have ho := RealRaw.interval_order_of_valid _ GeometricPiRotation.halfPi_valid n
  have hi := RealRaw.interval_order_of_valid _ (imagPart_valid z.property) n
  have hh := halfPi_upper_eight_fifths n 0
  have hy := hz n 0
  change (GeometricPiRotation.halfPi.compute n).lo≤(8/5:Rat) at hh
  change (z.val.compute n).lo.im≤c at hy
  have hn : 0≤(GeometricPiRotation.halfPi.compute n).lo := by
    have h := (GeometricPiRotation.halfPi_bounds n).1
    grind only
  have ha := Rat.mul_le_mul_of_nonneg_left hy hn
  have hb := Rat.mul_le_mul_of_nonneg_right hh hc
  have hp := QBox.mulRealInterval_contains (Rat.le_refl) ho (Rat.le_refl) hi
  have ht : (QBox.mulRealInterval (GeometricPiRotation.halfPi.compute n).lo
      (GeometricPiRotation.halfPi.compute n).hi (z.val.compute n).lo.im (z.val.compute n).hi.im).lo≤(8/5)*c := by
    have hu := hp.1
    change _≤(GeometricPiRotation.halfPi.compute n).lo*(z.val.compute n).lo.im at hu
    exact Rat.le_trans hu (Rat.le_trans ha hb)
  have hs := Rat.mul_le_mul_of_nonneg_left ht (show (0:Rat)≤4 by decide +kernel)
  change 4*(QBox.mulRealInterval (GeometricPiRotation.halfPi.compute n).lo
    (GeometricPiRotation.halfPi.compute n).hi (z.val.compute n).lo.im (z.val.compute n).hi.im).lo≤4*(8/5)*c
  grind only

private theorem coefficient_nonnegative : ∀ i : Fin 41,
    0≤(41:Rat)*((QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹)/2 := by
  decide +kernel

/-- Rational height enclosure specialized to each actual transformed finite CM point. -/
theorem cmHeckePoint41_height_bounds (i : Fin 41) :
    let g := cmHeckeReduction41 ⟨i.val,by omega⟩
    let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
    let w := fractionalLinear g z (hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper)
    let t : Rat := 41*((QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹)/2
    (RealRaw.ofRat (t*(51/4))).Le w.val.imagPart ∧
      w.val.imagPart.Le (RealRaw.ofRat (t*(64/5))) := by
  let g := cmHeckeReduction41 ⟨i.val,by omega⟩
  let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
  let w := fractionalLinear g z (hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper)
  let t : Rat := 41*((QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹)/2
  have ht : 0≤t := coefficient_nonnegative i
  have he : w.val.imagPart.Equiv (RealRaw.scaleRat t sqrt163) := cmHeckePoint41_imaginary i
  have hl : (RealRaw.ofRat (t*(51/4))).Le (RealRaw.scaleRat t sqrt163) := by
    intro n m
    have h := Rat.mul_le_mul_of_nonneg_left (sqrt163_lower_fiftyOne_quarters 0 m) ht
    change t*(51/4)≤((RealRaw.scaleRat t sqrt163).compute m).hi
    simp only [RealRaw.scaleRat,RealRaw.scaleRatCompute,if_pos ht]
    exact h
  have hu : (RealRaw.scaleRat t sqrt163).Le (RealRaw.ofRat (t*(64/5))) := by
    intro n m
    have h := Rat.mul_le_mul_of_nonneg_left (sqrt163_upper_sixtyFour_fifths n 0) ht
    change ((RealRaw.scaleRat t sqrt163).compute n).lo≤t*(64/5)
    simp only [RealRaw.scaleRat,RealRaw.scaleRatCompute,if_pos ht]
    exact h
  exact ⟨RealRaw.le_trans (RealRaw.scaleRat_valid sqrt163_valid) hl
      (RealRaw.le_of_equiv (RealRaw.scaleRat_valid sqrt163_valid) (imagPart_valid w.property) (RealRaw.equiv_symm he)),
    RealRaw.le_trans (RealRaw.scaleRat_valid sqrt163_valid)
      (RealRaw.le_of_equiv (imagPart_valid w.property) (RealRaw.scaleRat_valid sqrt163_valid) he) hu⟩

/-- Point-specific lower and upper growth bounds from the actual denominator norm. -/
theorem cmHeckePoint41_growth_bounds (i : Fin 41) :
    let g := cmHeckeReduction41 ⟨i.val,by omega⟩
    let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
    let w := fractionalLinear g z (hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper)
    let n : Rat := (QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹
    (RealRaw.ofRat ((328287/200)*n)).Le (nomeHeightGrowth w) ∧
      (nomeHeightGrowth w).Le (RealRaw.ofRat ((41984/25)*n)) := by
  have ht := coefficient_nonnegative i
  have hcL : 0≤(41*((QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹)/2)*(51/4) :=
    Rat.mul_nonneg ht (by decide +kernel)
  have hcU : 0≤(41*((QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹)/2)*(64/5) :=
    Rat.mul_nonneg ht (by decide +kernel)
  have hl := nomeHeightGrowth_lower _ _ hcL (cmHeckePoint41_height_bounds i).1
  have hu := nomeHeightGrowth_upper _ _ hcU (cmHeckePoint41_height_bounds i).2
  have hL (x : Rat) : 4*(157/100)*(41*x/2*(51/4))=(328287/200)*x := by grind only
  have hU (x : Rat) : 4*(8/5)*(41*x/2*(64/5))=(41984/25)*x := by grind only
  rw [hL] at hl
  rw [hU] at hu
  exact ⟨hl,hu⟩

end ComputableAnalysis.ModularForms
