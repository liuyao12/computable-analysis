import ComputableAnalysis.ModularForms.Hecke41SquareKernelLimitInvariance

/-! Actual oriented dyadic contour candidates and finite comparison errors.
Their integral role is not inferred from numerical validity. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def squareOrientedVelocity (edge : HalfEdge) (R : QPos) : Scalar :=
  let v := rationalRectangleScalar (QComplex.scaleRat R.val (velocity edge))
  if edge.upper then v else scalarNeg v

theorem squareOrientedVelocity_bound (edge : HalfEdge) (R : QPos) :
    Small (squareOrientedVelocity edge R).val R.val := by
  have hv := (BoxApproximation.rational_small _).mono
    (scaledSquareVelocity_coordinate_bound edge R.val (Rat.le_of_lt R.property))
  unfold squareOrientedVelocity
  split
  · exact hv
  · exact SeriesLimitLaws.small_neg hv

def hecke41DyadicKernelEdgeLimit (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (edge : HalfEdge) (R : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) : Scalar :=
  scalarProduct ⟨hecke41SquareKernelLimit k a ha edge R hR,
    hecke41SquareKernelLimit_valid k a ha edge R hR⟩ (squareOrientedVelocity edge R)

def hecke41DyadicKernelEdgeSample (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (edge : HalfEdge) (R : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) (n : Nat) : Scalar :=
  scalarProduct (hecke41SquareKernelDyadicAverage k a ha edge R hR n)
    (squareOrientedVelocity edge R)

theorem hecke41DyadicKernelEdgeLimit_sample_error (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) (n : Nat) :
    Small (sub (hecke41DyadicKernelEdgeLimit k a ha edge R hR).val
      (hecke41DyadicKernelEdgeSample k a ha edge R hR n).val)
      (2*hecke41SquareKernelTail k a ha R n*R.val) := by
  let L : Scalar := ⟨hecke41SquareKernelLimit k a ha edge R hR,
    hecke41SquareKernelLimit_valid k a ha edge R hR⟩
  let S := hecke41SquareKernelDyadicAverage k a ha edge R hR n
  let V := squareOrientedVelocity edge R
  have hb := Small.mul (sub_valid L.property S.property) V.property
    (hecke41SquareKernelTail_nonneg k a ha R n) (Rat.le_of_lt R.property)
    (hecke41SquareKernelLimit_sample_error k a ha edge R hR n)
    (squareOrientedVelocity_bound edge R)
  exact Small.congr (mul_valid (sub_valid L.property S.property) V.property)
    (sub_valid (mul_valid L.property V.property) (mul_valid S.property V.property))
    (constantProduct_difference L S V) hb

def hecke41DyadicKernelContourLimit (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (R : QPos) (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) :
    List HalfEdge → Scalar
  | [] => ⟨zero,ofQComplex_valid _⟩
  | e::es => scalarSum (hecke41DyadicKernelEdgeLimit k a ha e R hR)
      (hecke41DyadicKernelContourLimit k a ha R hR es)

def hecke41DyadicKernelContourSample (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (R : QPos) (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) (n : Nat) :
    List HalfEdge → Scalar
  | [] => ⟨zero,ofQComplex_valid _⟩
  | e::es => scalarSum (hecke41DyadicKernelEdgeSample k a ha e R hR n)
      (hecke41DyadicKernelContourSample k a ha R hR n es)

theorem hecke41DyadicKernelContourLimit_sample_error (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val)
    (n : Nat) (es : List HalfEdge) :
    Small (sub (hecke41DyadicKernelContourLimit k a ha R hR es).val
      (hecke41DyadicKernelContourSample k a ha R hR n es).val)
      ((es.length:Rat)*(2*hecke41SquareKernelTail k a ha R n*R.val)) := by
  induction es with
  | nil =>
    change Small (sub zero zero) (0*_)
    rw [Rat.zero_mul]
    exact Small.congr (ofQComplex_valid _) (sub_valid (ofQComplex_valid _) (ofQComplex_valid _))
      (equiv_symm (add_neg_equiv zero (ofQComplex_valid _))) (Small.zero (by decide +kernel))
  | cons e es ih =>
    have hb := LocalODE.small_add (hecke41DyadicKernelEdgeLimit_sample_error k a ha e R hR n) ih
    have hd := Small.congr
      (add_valid
        (sub_valid (hecke41DyadicKernelEdgeLimit k a ha e R hR).property
          (hecke41DyadicKernelEdgeSample k a ha e R hR n).property)
        (sub_valid (hecke41DyadicKernelContourLimit k a ha R hR es).property
          (hecke41DyadicKernelContourSample k a ha R hR n es).property))
      (sub_valid (hecke41DyadicKernelContourLimit k a ha R hR (e::es)).property
        (hecke41DyadicKernelContourSample k a ha R hR n (e::es)).property)
      (sumPair_difference (hecke41DyadicKernelEdgeLimit k a ha e R hR)
        (hecke41DyadicKernelContourLimit k a ha R hR es)
        (hecke41DyadicKernelEdgeSample k a ha e R hR n)
        (hecke41DyadicKernelContourSample k a ha R hR n es)) hb
    have he (E : Rat) : E+(es.length:Rat)*E=((e::es).length:Rat)*E := by
      rw [List.length_cons,Rat.natCast_add]
      change _=((es.length:Rat)+1)*_
      grind only
    rw [he] at hd
    exact hd

theorem hecke41DyadicKernelContourLimit_congr (k : Nat) (a b : Scalar)
    (ha : hecke41NomePuncturedDomain a) (hb : hecke41NomePuncturedDomain b)
    (he : a.val.Equiv b.val) (R : QPos)
    (hRa : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val)
    (hRb : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 b hb).val)
    (es : List HalfEdge) :
    (hecke41DyadicKernelContourLimit k a ha R hRa es).val.Equiv
      (hecke41DyadicKernelContourLimit k b hb R hRb es).val := by
  induction es with
  | nil => exact equiv_refl _ (ofQComplex_valid _)
  | cons e es ih =>
    have hv := mul_equiv
      (hecke41SquareKernelLimit_valid k a ha e R hRa)
      (hecke41SquareKernelLimit_valid k b hb e R hRb)
      (squareOrientedVelocity e R).property (squareOrientedVelocity e R).property
      (hecke41SquareKernelLimit_congr k a b ha hb he e R hRa hRb)
      (equiv_refl _ (squareOrientedVelocity e R).property)
    exact add_equiv hv ih

end ComputableAnalysis.ModularForms
