import ComputableAnalysis.ModularForms.Hecke41FiniteAffineEvaluatorAgreement
import ComputableAnalysis.ModularForms.Hecke41DyadicKernelContour
import ComputableAnalysis.ModularForms.Hecke41SquareKernelContour

/-! Full oriented actual-to-affine finite contour error. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def orientSquareAverage (upper : Bool) (x : Scalar) : Scalar := if upper then x else scalarNeg x

theorem orientSquareAverage_difference_bound (upper : Bool) (x y : Scalar) (E : Rat)
    (h : Small (sub x.val y.val) E) :
    Small (sub (orientSquareAverage upper x).val (orientSquareAverage upper y).val) E := by
  cases upper
  · have he : (neg (sub x.val y.val)).Equiv (sub (neg x.val) (neg y.val)) := by
      apply ComplexRawQuotient.equiv_of_ofRaw_eq
        (hleft := neg_valid (sub_valid x.property y.property))
        (hright := sub_valid (neg_valid x.property) (neg_valid y.property))
      change -(gridScalarValue x-gridScalarValue y)= -gridScalarValue x-(-gridScalarValue y)
      grind only
    exact Small.congr (neg_valid (sub_valid x.property y.property))
      (sub_valid (neg_valid x.property) (neg_valid y.property)) he (SeriesLimitLaws.small_neg h)
  · exact h

def hecke41FiniteAffineContour (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (R : QPos) (hR : R.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (M : Nat) (hM : 0<M) : List HalfEdge → Scalar
  | [] => ⟨zero,ofQComplex_valid _⟩
  | e::es => scalarSum
      (orientSquareAverage e.upper (hecke41ComparisonEdgeAverage true k a ha e R hR M hM))
      (hecke41FiniteAffineContour k a ha R hR M hM es)

theorem hecke41ActualFiniteContour_affine_bound (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R eps : QPos)
    (hR : R.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (hDelta : R.val≤(((hecke41NomeDescended_holomorphic k 10000).atPoint a ha).delta eps).val)
    (M : Nat) (hM : 0<M) (es : List HalfEdge) :
    Small (sub (hecke41SquareKernelEdgeList k a ha R M hM hR es).val
      (hecke41FiniteAffineContour k a ha R hR M hM es).val) ((es.length:Rat)*(8*eps.val)) := by
  induction es with
  | nil =>
    change Small (sub zero zero) (0*_)
    rw [Rat.zero_mul]
    exact Small.congr (ofQComplex_valid _) (sub_valid (ofQComplex_valid _) (ofQComplex_valid _))
      (equiv_symm (add_neg_equiv zero (ofQComplex_valid _))) (Small.zero (by decide +kernel))
  | cons e es ih =>
    let x := orientSquareAverage e.upper (hecke41SquareKernelAverage k a ha e R M hM hR)
    let y := orientSquareAverage e.upper (hecke41ComparisonEdgeAverage true k a ha e R hR M hM)
    let p := hecke41SquareKernelEdgeList k a ha R M hM hR es
    let q := hecke41FiniteAffineContour k a ha R hR M hM es
    have hb := LocalODE.small_add
      (orientSquareAverage_difference_bound e.upper _ _ _
        (hecke41ActualFiniteEdge_affine_bound k a ha e R eps hR hDelta M hM)) ih
    have hd := Small.congr (add_valid (sub_valid x.property y.property) (sub_valid p.property q.property))
      (sub_valid (scalarSum x p).property (scalarSum y q).property)
      (sumPair_difference x p y q) hb
    have he (E : Rat) : E+(es.length:Rat)*E=((e::es).length:Rat)*E := by
      rw [List.length_cons,Rat.natCast_add]
      change _=((es.length:Rat)+1)*_
      grind only
    rw [he] at hd
    exact hd

end ComputableAnalysis.ModularForms
