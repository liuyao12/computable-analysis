import ComputableAnalysis.ModularForms.CMJEquivalentPoint163
import ComputableAnalysis.ModularForms.Hecke41CompressedNewtonCellwiseAgreement

namespace ComputableAnalysis.ModularForms
open RiemannHilbert PackedIntegerPolynomialProduct

/-- Exact integer value of the actual modular function at the constructed
CM point, with the finite Newton evidence supplied internally. -/
theorem cmJValue163_exact_value :
    cmJValue163.val.Equiv (ComplexRaw.ofQComplex ⟨-((640320:Rat)^3),0⟩) :=
  cmJValue163_exact_value_of_newton hecke41ExpandedNewton_cellwise_actualAgreement

/-- The exact integer value is independent of the valid name of the CM point. -/
theorem latticeJMap_cm_equivalent_value (z : Scalar) (hz : z.val.Equiv cmPoint163) :
    (latticeJMap.eval z (latticeJMap_domain_at_cm_equivalent z hz)).val.Equiv
      (ComplexRaw.ofQComplex ⟨-((640320:Rat)^3),0⟩) :=
  latticeJMap_cm_equivalent_value_of_newton
    hecke41ExpandedNewton_cellwise_actualAgreement z hz

end ComputableAnalysis.ModularForms
