import ComputableAnalysis.ModularForms.FiniteScalarSymmetricBounds41

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- Computed amplification for symmetric sums of any degree. -/
def scalarSymmetricSensitivity41 (H : Rat) : Nat → Rat
  | 0 => 0
  | n+1 => (1+2*H)*scalarSymmetricSensitivity41 H n+2*scalarSymmetricBound41 H n

theorem scalarSymmetricSensitivity41_nonneg (H : Rat) (hH : 0≤H) (n : Nat) :
    0≤scalarSymmetricSensitivity41 H n := by
  induction n with
  | zero => exact Rat.le_refl
  | succ n ih =>
    exact Rat.add_nonneg
      (Rat.mul_nonneg (Rat.add_nonneg (by decide) (Rat.mul_nonneg (by decide) hH)) ih)
      (Rat.mul_nonneg (by decide) (scalarSymmetricBound41_nonneg H hH n))

private theorem self_difference_small (z : ComplexRaw) (hz : z.Valid) (B : Rat) (hB : 0≤B) :
    Small (sub z z) B := by
  have he : zero.Equiv (sub z z) := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq (hleft := ofQComplex_valid _) (hright := sub_valid hz hz)
    change (0 : ComplexRawQuotient.Value)=ComplexRawQuotient.ofRaw z hz-ComplexRawQuotient.ofRaw z hz
    grind only
  exact Small.congr (ofQComplex_valid _) (sub_valid hz hz) he (Small.zero hB)

/-- Uniform supplied factor errors propagate through every actual represented
symmetric degree with an executable amplification. -/
theorem representedElementarySymmetric41_difference_bound {α : Type} (f g : α → Scalar)
    (is : List α) (k : Nat) (H E : Rat) (hH : 0≤H) (hE : 0≤E)
    (hf : ∀ i∈is, Small (f i).val H) (hg : ∀ i∈is, Small (g i).val H)
    (he : ∀ i∈is, Small (sub (f i).val (g i).val) E) :
    Small (sub (representedElementarySymmetric41 (is.map f) k)
      (representedElementarySymmetric41 (is.map g) k)) (E*scalarSymmetricSensitivity41 H is.length) := by
  induction is generalizing k with
  | nil =>
    cases k <;> exact self_difference_small _ (ofQComplex_valid _) _
      (Rat.mul_nonneg hE (scalarSymmetricSensitivity41_nonneg H hH 0))
  | cons i is ih =>
    cases k with
    | zero =>
      exact self_difference_small _ (ofQComplex_valid _) _
        (Rat.mul_nonneg hE (scalarSymmetricSensitivity41_nonneg H hH _))
    | succ k =>
      have hft : ∀ j∈is, Small (f j).val H := fun j hj => hf j (by simp [hj])
      have hgt : ∀ j∈is, Small (g j).val H := fun j hj => hg j (by simp [hj])
      have het : ∀ j∈is, Small (sub (f j).val (g j).val) E := fun j hj => he j (by simp [hj])
      have hb := representedElementarySymmetric41_bound (is.map f) k H hH (by
        intro x hx; obtain ⟨j,hj,rfl⟩ := List.mem_map.mp hx; exact hft j hj)
      simp only [List.length_map] at hb
      have hd := ih k hft hgt het
      have hp := SeriesLimitLaws.product_close (f i).val (representedElementarySymmetric41 (is.map f) k)
        (g i).val (representedElementarySymmetric41 (is.map g) k)
        (f i).property (representedElementarySymmetric41_valid _ _) (g i).property
        (representedElementarySymmetric41_valid _ _) E (E*scalarSymmetricSensitivity41 H is.length)
        H (scalarSymmetricBound41 H is.length) hE
        (Rat.mul_nonneg hE (scalarSymmetricSensitivity41_nonneg H hH _)) hH
        (scalarSymmetricBound41_nonneg H hH _) (he i (by simp)) hd (hg i (by simp)) hb
      have ht := ih (k+1) hft hgt het
      have hh := LocalODE.small_add ht hp
      have eqv := SeriesLimitLaws.addition_difference
        (representedElementarySymmetric41 (is.map f) (k+1))
        (representedElementarySymmetric41 (is.map g) (k+1))
        (mul (f i).val (representedElementarySymmetric41 (is.map f) k))
        (mul (g i).val (representedElementarySymmetric41 (is.map g) k))
        (representedElementarySymmetric41_valid _ _) (representedElementarySymmetric41_valid _ _)
        (mul_valid (f i).property (representedElementarySymmetric41_valid _ _))
        (mul_valid (g i).property (representedElementarySymmetric41_valid _ _))
      have hout := Small.congr
        (add_valid (sub_valid (representedElementarySymmetric41_valid _ _) (representedElementarySymmetric41_valid _ _))
          (sub_valid (mul_valid (f i).property (representedElementarySymmetric41_valid _ _))
            (mul_valid (g i).property (representedElementarySymmetric41_valid _ _))))
        (sub_valid (representedElementarySymmetric41_valid ((i::is).map f) (k+1))
          (representedElementarySymmetric41_valid ((i::is).map g) (k+1))) (equiv_symm eqv) hh
      have hr : E*scalarSymmetricSensitivity41 H is.length+
          (2*E*scalarSymmetricBound41 H is.length+2*H*(E*scalarSymmetricSensitivity41 H is.length))=
          E*scalarSymmetricSensitivity41 H (i::is).length := by
        simp only [List.length_cons,scalarSymmetricSensitivity41]
        grind only
      rw [hr] at hout
      exact hout

end ComputableAnalysis.ModularForms
