import ComputableAnalysis.ModularForms.DiscriminantEulerDifferenceBound
import ComputableAnalysis.RiemannHilbert.DomainDerivativeUniqueness
namespace ComputableAnalysis.ModularForms
set_option maxHeartbeats 2000000
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
private def originRadius (eps : QPos) : QPos :=
  let d := divideRadius eps ⟨10536,by decide +kernel⟩
  if h : d.val≤(1:Rat)/65536 then d else ⟨1/65536,by decide +kernel⟩
/-- The quadratic discrepancy bound constructs an actual zero derivative at the origin. -/
def discriminantEulerDifferenceMap_originDerivative (q : Scalar) (hq : tauEulerNomeDomain q)
    (hz : q.val.Equiv zero) : HasDerivativeAt discriminantEulerDifferenceMap q hq ⟨zero,ofQComplex_valid _⟩ where
  delta := originRadius
  estimate eps H z hzd hH hs := by
    have hd1 : (originRadius eps).val≤(1:Rat)/65536 := by
      unfold originRadius
      dsimp only
      split <;> grind only
    have hd2 : (originRadius eps).val≤(divideRadius eps ⟨10536,by decide +kernel⟩).val := by
      unfold originRadius
      dsimp only
      split <;> grind only
    have hsmall : H.val≤(1:Rat)/65536 := Rat.le_trans hH hd1
    have hqz : (sub z.val q.val).Equiv z.val := by
      have hh := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := q.property) (hright := ofQComplex_valid _) hz
      apply ComplexRawQuotient.equiv_of_ofRaw_eq (hleft := sub_valid z.property q.property) (hright := z.property)
      change ComplexRawQuotient.ofRaw z.val z.property-ComplexRawQuotient.ofRaw q.val q.property=ComplexRawQuotient.ofRaw z.val z.property
      change ComplexRawQuotient.ofRaw q.val q.property=0 at hh
      rw [hh]
      grind only
    have hzs := Small.congr (sub_valid z.property q.property) z.property hqz hs
    have hg : 128*H.val≤(1:Rat)/2 := by grind only
    have hb := discriminantEulerDifferenceMap_quadratic_bound z hzd H.val (Rat.le_of_lt H.property) hg hzs hsmall
    have he : (discriminantEulerDifferenceMap.eval z hzd).val.Equiv
        (DomainFunctions.remainder discriminantEulerDifferenceMap q hq ⟨zero,ofQComplex_valid _⟩ z hzd) := by
      have h0 := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := (discriminantEulerDifferenceMap.eval q hq).property)
        (hright := ofQComplex_valid _) (discriminantEulerDifferenceMap_at_zero q hq hz)
      apply ComplexRawQuotient.equiv_of_ofRaw_eq (hleft := (discriminantEulerDifferenceMap.eval z hzd).property)
        (hright := DomainFunctions.remainder_valid _ _ _ _ _ _)
      change ComplexRawQuotient.ofRaw (discriminantEulerDifferenceMap.eval q hq).val (discriminantEulerDifferenceMap.eval q hq).property=0 at h0
      change ComplexRawQuotient.ofRaw (discriminantEulerDifferenceMap.eval z hzd).val (discriminantEulerDifferenceMap.eval z hzd).property=
        (ComplexRawQuotient.ofRaw (discriminantEulerDifferenceMap.eval z hzd).val (discriminantEulerDifferenceMap.eval z hzd).property+
          -ComplexRawQuotient.ofRaw (discriminantEulerDifferenceMap.eval q hq).val (discriminantEulerDifferenceMap.eval q hq).property)+
          -(0*(ComplexRawQuotient.ofRaw z.val z.property+ -ComplexRawQuotient.ofRaw q.val q.property))
      rw [h0]
      grind only
    have hb' := Small.congr (discriminantEulerDifferenceMap.eval z hzd).property (DomainFunctions.remainder_valid _ _ _ _ _ _) he hb
    apply hb'.mono
    have hlim := Rat.le_trans hH hd2
    change H.val≤eps.val/10536 at hlim
    have hm := Rat.mul_le_mul_of_nonneg_right hlim (show (0:Rat)≤10536 by decide +kernel)
    rw [Rat.div_mul_cancel (by decide +kernel : (10536:Rat)≠0)] at hm
    have ht := Rat.mul_le_mul_of_nonneg_right hm (Rat.le_of_lt H.property)
    grind only
theorem discriminantEulerDifferenceMap_derivative_at_zero (q : Scalar) (hq : tauEulerNomeDomain q)
    (hz : q.val.Equiv zero) :
    (discriminantEulerDifferenceMap_holomorphic.derivative q hq).val.Equiv zero :=
  (discriminantEulerDifferenceMap_holomorphic.atPoint q hq).unique
    (discriminantEulerDifferenceMap_originDerivative q hq hz)
    discriminantEulerDifferenceMap_holomorphic.openDomain
end ComputableAnalysis.ModularForms
