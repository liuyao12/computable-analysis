import ComputableAnalysis.ModularForms.IntegerPolynomialRealSign
import ComputableAnalysis.ModularForms.Hecke41IntervalTransformPackedData

namespace ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct

private theorem candidate_nonempty : hecke41IntervalTransformCandidate≠[] := by decide +kernel

/-- The checked interval transform never vanishes at any valid nonnegative
represented real, without restricting its input to rational numbers. -/
theorem hecke41IntervalTransform_real_nonzero (x : RealRaw) (hx : x.Valid)
    (hp : (RealRaw.ofRat 0).Le x) :
    ¬(integerPolynomialRealEval hecke41IntervalTransformCandidate x).Equiv
      (RealRaw.ofRat 0) := by
  generalize he : hecke41IntervalTransformCandidate=p
  have hne : p≠[] := by rw [←he]; exact candidate_nonempty
  have hc : ∀ a∈p, a<0 := by rw [←he]; exact hecke41IntervalTransform_negative
  cases p with
  | nil => exact False.elim (hne rfl)
  | cons a p =>
    exact integerPolynomialRealEval_nonzero a p x hx hp
      (hc a (by simp)) (fun b hb => Int.le_of_lt (hc b (by simp [hb])))

end ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct
