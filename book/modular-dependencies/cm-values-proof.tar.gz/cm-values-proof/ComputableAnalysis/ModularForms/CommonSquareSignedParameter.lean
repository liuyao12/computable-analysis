import ComputableAnalysis.ModularForms.Hecke41CommonSquareVariation

/-! Exact signed-side parameter reflection for actual common square samples. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem squarePoint_signed_lower_reflection (quarter : Quarter) (u : Rat) :
    point ⟨quarter,true⟩ u=point ⟨quarter,false⟩ (-u) := by
  cases quarter <;>
    simp only [point,rotation,orientation,QComplex.mul,Bool.false_eq_true,↓reduceIte,QComplex.mk.injEq] <;>
    constructor <;> grind only

theorem commonSquareSignedSample_lower_reflection (f : QComplex → Scalar)
    (quarter : Quarter) (S u : Rat) :
    f (QComplex.scaleRat S (point ⟨quarter,true⟩ u))=
      f (QComplex.scaleRat S (point ⟨quarter,false⟩ (-u))) := by
  rw [squarePoint_signed_lower_reflection]

theorem hecke41ShiftedPoleCommonSample_signed_negative_variation (k : Nat) (a b : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R B S : QPos)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (hRS : R.val≤S.val) (hSB : S.val≤B.val)
    (hd : S.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val)
    (r : Rat) (hr : r<R.val) (hb : Small b.val r)
    (quarter : Quarter) (u v : Rat) (hu : -1≤u ∧ u≤0) (hv : -1≤v ∧ v≤0) :
    Small (sub
      (hecke41ShiftedPoleCommonSample k a b ha R B hB r hr hb
        (QComplex.scaleRat S.val (point ⟨quarter,true⟩ u))).val
      (hecke41ShiftedPoleCommonSample k a b ha R B hB r hr hb
        (QComplex.scaleRat S.val (point ⟨quarter,true⟩ v))).val)
      (hecke41ShiftedPoleVariationRate k a ha R S r*qabs (u-v)) := by
  rw [squarePoint_signed_lower_reflection quarter u,squarePoint_signed_lower_reflection quarter v]
  have h := hecke41ShiftedPoleCommonSample_square_variation k a b ha R B S hB hRS hSB hd r hr hb
    ⟨quarter,false⟩ (-u) (-v) (by grind only) (by grind only) (by grind only) (by grind only)
  have he : qabs (-u- -v)=qabs (u-v) := by
    unfold qabs
    split <;> split <;> grind only
  rw [he] at h
  exact h

private theorem signedSample_difference_chain (x y z : Scalar) :
    (add (sub x.val y.val) (sub y.val z.val)).Equiv (sub x.val z.val) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := add_valid (sub_valid x.property y.property) (sub_valid y.property z.property))
    (hright := sub_valid x.property z.property)
  let X := gridScalarValue x
  let Y := gridScalarValue y
  let Z := gridScalarValue z
  change (X-Y)+(Y-Z)=X-Z
  grind only

theorem hecke41ShiftedPoleCommonSample_signed_variation (k : Nat) (a b : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R B S : QPos)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (hRS : R.val≤S.val) (hSB : S.val≤B.val)
    (hd : S.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val)
    (r : Rat) (hr : r<R.val) (hb : Small b.val r)
    (quarter : Quarter) (u v : Rat) (hu : -1≤u ∧ u≤1) (hv : -1≤v ∧ v≤1) :
    Small (sub
      (hecke41ShiftedPoleCommonSample k a b ha R B hB r hr hb
        (QComplex.scaleRat S.val (point ⟨quarter,true⟩ u))).val
      (hecke41ShiftedPoleCommonSample k a b ha R B hB r hr hb
        (QComplex.scaleRat S.val (point ⟨quarter,true⟩ v))).val)
      (hecke41ShiftedPoleVariationRate k a ha R S r*qabs (u-v)) := by
  let f := fun t => hecke41ShiftedPoleCommonSample k a b ha R B hB r hr hb
    (QComplex.scaleRat S.val (point ⟨quarter,true⟩ t))
  let L := hecke41ShiftedPoleVariationRate k a ha R S r
  have hpos := fun x y hx hx1 hy hy1 =>
    hecke41ShiftedPoleCommonSample_square_variation k a b ha R B S hB hRS hSB hd r hr hb
      ⟨quarter,true⟩ x y hx hx1 hy hy1
  have hneg := fun x y hx hy =>
    hecke41ShiftedPoleCommonSample_signed_negative_variation k a b ha R B S hB hRS hSB hd r hr hb
      quarter x y hx hy
  by_cases hu0 : 0≤u
  · by_cases hv0 : 0≤v
    · exact hpos u v hu0 hu.2 hv0 hv.2
    · have hx := hpos u 0 hu0 hu.2 (by decide +kernel) (by decide +kernel)
      have hy := hneg 0 v (by constructor <;> decide +kernel) (by grind only)
      have hs := LocalODE.small_add hx hy
      have ht := Small.congr
        (add_valid (sub_valid (f u).property (f 0).property) (sub_valid (f 0).property (f v).property))
        (sub_valid (f u).property (f v).property) (signedSample_difference_chain (f u) (f 0) (f v)) hs
      have he : L*qabs (u-0)+L*qabs (0-v)=L*qabs (u-v) := by
        unfold qabs
        split <;> split <;> split <;> grind only
      change Small (sub (f u).val (f v).val) (L*qabs (u-0)+L*qabs (0-v)) at ht
      rw [he] at ht
      exact ht
  · by_cases hv0 : 0≤v
    · have hx := hneg u 0 (by grind only) (by constructor <;> decide +kernel)
      have hy := hpos 0 v (by decide +kernel) (by decide +kernel) hv0 hv.2
      have hs := LocalODE.small_add hx hy
      have ht := Small.congr
        (add_valid (sub_valid (f u).property (f 0).property) (sub_valid (f 0).property (f v).property))
        (sub_valid (f u).property (f v).property) (signedSample_difference_chain (f u) (f 0) (f v)) hs
      have he : L*qabs (u-0)+L*qabs (0-v)=L*qabs (u-v) := by
        unfold qabs
        split <;> split <;> split <;> grind only
      change Small (sub (f u).val (f v).val) (L*qabs (u-0)+L*qabs (0-v)) at ht
      rw [he] at ht
      exact ht
    · exact hneg u v (by grind only) (by grind only)

end ComputableAnalysis.ModularForms
