import ComputableAnalysis.ModularForms.HolomorphicMaximumFiberNeighborhood
import ComputableAnalysis.RiemannHilbert.DomainHolomorphicComposition

namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

/-- A nonzero represented value has an explicit positive coordinate
separation tolerance, taken from its searched separated box. -/
theorem scalar_nonzero_excludes_small (z : Scalar) (hz : NonzeroBoxSearch.Nonzero z) :
    ∃ eps : QPos, ¬ Small z.val eps.val := by
  let k := NonzeroBoxSearch.stage z hz
  let B := z.val.compute k
  have hB : NonzeroBoxSearch.separated B := NonzeroBoxSearch.stage_spec z hz
  let M := NonzeroBoxSearch.margin B
  have hM : 0<M := NonzeroBoxSearch.margin_pos B hB
  let eps : QPos := ⟨M/2,Rat.mul_pos hM (by decide +kernel)⟩
  refine ⟨eps,?_⟩
  intro hs
  have hrlo := hs.2.1 k 0
  have hrhi := hs.1 0 k
  have hilo := hs.2.2.2 k 0
  have hihi := hs.2.2.1 0 k
  change B.lo.re≤M/2 at hrlo
  change -(M/2)≤B.hi.re at hrhi
  change B.lo.im≤M/2 at hilo
  change -(M/2)≤B.hi.im at hihi
  dsimp only [M,NonzeroBoxSearch.margin] at *
  split at * <;> split at * <;> split at * <;>
    unfold NonzeroBoxSearch.separated at hB <;> grind only

/-- The complement of an exact value fiber has justified local
neighborhoods, derived from actual value continuity and separation. -/
theorem continuous_value_fiber_complement_neighborhood
    (F : DomainFunctions.Map) (hF : ContinuousOn F.domain F.eval) (a x : Scalar)
    (ha : F.domain a) (hx : F.domain x)
    (hne : ¬ (F.eval x hx).val.Equiv (F.eval a ha).val) :
    ∃ rho : QPos, ∀ z hz, Small (sub z.val x.val) rho.val →
      ¬ (F.eval z hz).val.Equiv (F.eval a ha).val := by
  let d : Scalar := ⟨sub (F.eval x hx).val (F.eval a ha).val,
    sub_valid (F.eval x hx).property (F.eval a ha).property⟩
  have hd : NonzeroBoxSearch.Nonzero d := by
    intro he
    apply hne
    apply SeriesLimitLaws.equiv_of_small_sub_zero
    exact Small.congr (ofQComplex_valid _) d.property (equiv_symm he) (Small.zero (by decide +kernel))
  obtain ⟨eps,heps⟩ := scalar_nonzero_excludes_small d hd
  refine ⟨hF.delta x hx eps,?_⟩
  intro z hz hnear he
  have hs := hF.estimate x hx eps z hz hnear
  have ht := Small.congr (sub_valid (F.eval z hz).property (F.eval x hx).property)
    (sub_valid (F.eval a ha).property (F.eval x hx).property)
    (FunctionTheory.sub_congr he (equiv_refl _ (F.eval x hx).property)) hs
  exact heps (RepresentedCauchySum.small_sub_symm (F.eval a ha).val (F.eval x hx).val eps.val ht)

end ComputableAnalysis.ModularForms
