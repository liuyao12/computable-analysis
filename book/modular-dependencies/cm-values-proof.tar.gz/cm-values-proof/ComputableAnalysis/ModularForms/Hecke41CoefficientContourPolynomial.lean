import ComputableAnalysis.ModularForms.RepresentedCoefficientPolynomial

/-! Actual finite contour-coefficient polynomials converge to their constructed represented polynomials. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def hecke41CoefficientContourPolynomial (k : Nat) (a b : Scalar)
    (ha : hecke41NomePuncturedDomain a) (S : QPos)
    (hg : S.val≤(hecke41NomeGeometricRadius a ha).val)
    (hd : S.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val)
    (es : List HalfEdge) (n : Nat) : Scalar :=
  representedCoefficientPolynomial (fun d => hecke41ReciprocalCoefficientContourLimit k a ha S hg hd d es) b n

def hecke41FiniteCoefficientContourPolynomial (k : Nat) (a b : Scalar)
    (ha : hecke41NomePuncturedDomain a) (S : QPos)
    (hg : S.val≤(hecke41NomeGeometricRadius a ha).val)
    (M : Nat) (hM : 0<M) (es : List HalfEdge) (n : Nat) : Scalar :=
  representedCoefficientPolynomial (fun d => hecke41ReciprocalCoefficientFiniteContour k a ha S hg M hM d es) b n

theorem hecke41FiniteCoefficientContourPolynomial_converges (k : Nat) (a b : Scalar)
    (ha : hecke41NomePuncturedDomain a) (S : QPos)
    (hg : S.val≤(hecke41NomeGeometricRadius a ha).val)
    (hd : S.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val)
    (es : List HalfEdge) (n : Nat) (eps : QPos) :
    ∃ J, ∀ j, J≤j → Small
      (sub (hecke41CoefficientContourPolynomial k a b ha S hg hd es n).val
        (hecke41FiniteCoefficientContourPolynomial k a b ha S hg (2^j)
          (Nat.pow_pos (by decide +kernel)) es n).val) eps.val :=
  representedCoefficientPolynomial_converges
    (fun d => hecke41ReciprocalCoefficientContourLimit k a ha S hg hd d es)
    (fun j d => hecke41ReciprocalCoefficientFiniteContour k a ha S hg (2^j)
      (Nat.pow_pos (by decide +kernel)) d es) b
    (fun d => hecke41ReciprocalCoefficientFiniteContour_converges k a ha S hg hd d es) n eps

end ComputableAnalysis.ModularForms
