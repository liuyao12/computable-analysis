import ComputableAnalysis.ModularForms.PerturbedAffineMaximum

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

/-- The exact squared-norm expansion exposes its first-order cross term. -/
theorem scalar_norm_product_add_expansion (a b : Scalar) :
    (mul (add a.val b.val) (conj (add a.val b.val))).Equiv
      (add (mul a.val (conj a.val))
        (add (add (mul a.val (conj b.val)) (mul b.val (conj a.val))) (mul b.val (conj b.val)))) := by
  let A : ComplexCert := ⟨a.val,a.property⟩
  let B : ComplexCert := ⟨b.val,b.property⟩
  let x : RepresentedPolynomial.Arithmetic.Expression := .parameter A
  let y : RepresentedPolynomial.Arithmetic.Expression := .parameter B
  apply RepresentedPolynomial.Arithmetic.Expression.equiv_of_samples
    (.mul (.add x y) (.conj (.add x y)))
    (.add (.mul x (.conj x)) (.add (.add (.mul x (.conj y)) (.mul y (.conj x))) (.mul y (.conj y))))
  intro s
  simp only [x,y,RepresentedPolynomial.Arithmetic.Expression.sample,QComplex.add,QComplex.mul,QComplex.conj]
  congr 1 <;> grind only

/-- Cancellation with a rational slack follows from the proved duplicated-sum comparison. -/
theorem real_add_rational_upper_cancel (x y : RealRaw) (hx : x.Valid) (hy : y.Valid) (E : Rat)
    (h : (RealRaw.add x y).Le (RealRaw.add x (RealRaw.ofRat E))) : y.Le (RealRaw.ofRat E) :=
  real_duplicated_add_rational_upper x y hx hy E (RealRaw.le_add_le_add h h)

/-- An affine squared-magnitude upper bound controls the actual first-order cross term. -/
theorem scalar_affine_maximum_cross_bound (a b : Scalar) (E : Rat)
    (h : (mul (add a.val b.val) (conj (add a.val b.val))).realPart.Le
      (RealRaw.add (mul a.val (conj a.val)).realPart (RealRaw.ofRat E))) :
    (add (mul a.val (conj b.val)) (mul b.val (conj a.val))).realPart.Le (RealRaw.ofRat E) := by
  let x := (mul a.val (conj a.val)).realPart
  let y := (add (mul a.val (conj b.val)) (mul b.val (conj a.val))).realPart
  let n := (mul b.val (conj b.val)).realPart
  have hx : x.Valid := realPart_valid (mul_valid a.property (conj_valid _ a.property))
  have hy : y.Valid := realPart_valid (add_valid (mul_valid a.property (conj_valid _ b.property))
    (mul_valid b.property (conj_valid _ a.property)))
  have hn : n.Valid := realPart_valid (mul_valid b.property (conj_valid _ b.property))
  have he : (mul (add a.val b.val) (conj (add a.val b.val))).realPart.Equiv
      (RealRaw.add x (RealRaw.add y n)) := realPart_equiv (scalar_norm_product_add_expansion a b)
  have hl := RealRaw.le_of_equiv (RealRaw.add_valid hx (RealRaw.add_valid hy hn))
    (realPart_valid (mul_valid (add_valid a.property b.property) (conj_valid _ (add_valid a.property b.property))))
    (RealRaw.equiv_symm he)
  have ht := RealRaw.le_trans
    (realPart_valid (mul_valid (add_valid a.property b.property) (conj_valid _ (add_valid a.property b.property)))) hl h
  have hc := real_add_rational_upper_cancel x (RealRaw.add y n) hx (RealRaw.add_valid hy hn) E ht
  have hnon := scalar_squared_magnitude_nonnegative b
  have hyle : y.Le (RealRaw.add y n) := by
    intro i j
    have hh := RealRaw.le_refl y hy i j
    have hh0 := hnon 0 j
    change 0 ≤ (n.compute j).hi at hh0
    change (y.compute i).lo ≤ (y.compute j).hi + (n.compute j).hi
    grind only
  exact RealRaw.le_trans (RealRaw.add_valid hy hn) hyle hc

/-- The cross term of a justified affine approximation is controlled by the actual norm error at a maximum. -/
theorem scalar_perturbed_maximum_cross_bound (a b u : Scalar) (B E : Rat)
    (hB : 0 ≤ B) (hE : 0 ≤ E) (hmodel : Small (add a.val b.val) B)
    (herr : Small (sub u.val (add a.val b.val)) E)
    (hmax : (mul u.val (conj u.val)).realPart.Le (mul a.val (conj a.val)).realPart) :
    (add (mul a.val (conj b.val)) (mul b.val (conj a.val))).realPart.Le
      (RealRaw.ofRat (2*E*(B+E)+2*B*E)) := by
  let M : Scalar := ⟨add a.val b.val,add_valid a.property b.property⟩
  have hs := LocalODE.small_add hmodel herr
  have hu : Small u.val (B+E) := Small.congr
    (add_valid M.property (sub_valid u.property M.property)) u.property
    (SeriesLimitLaws.add_difference u.val M.val u.property M.property) hs
  have he := scalar_squared_magnitude_perturbation u M (B+E) B E
    (Rat.add_nonneg hB hE) hB hE hu hmodel herr
  let U : Scalar := ⟨mul u.val (conj u.val),mul_valid u.property (conj_valid _ u.property)⟩
  let N : Scalar := ⟨mul M.val (conj M.val),mul_valid M.property (conj_valid _ M.property)⟩
  let D := 2*E*(B+E)+2*B*E
  have hl := realPart_le_add_of_small_difference U N D he
  have hh := RealRaw.le_add_le_add hmax (RealRaw.le_refl (RealRaw.ofRat D) (RealRaw.ofRat_valid D))
  have ht := RealRaw.le_trans (y := RealRaw.add U.val.realPart (RealRaw.ofRat D))
    (RealRaw.add_valid (realPart_valid U.property) (RealRaw.ofRat_valid D)) hl hh
  exact scalar_affine_maximum_cross_bound a b D ht

/-- Aligning a displacement with the value and conjugate derivative exposes twice the product of squared norms. -/
theorem scalar_derivative_aligned_cross_identity (a d : Scalar) :
    let b := mul d.val (mul (conj d.val) a.val)
    (add (mul a.val (conj b)) (mul b (conj a.val))).Equiv
      (add (mul (mul a.val (conj a.val)) (mul d.val (conj d.val)))
        (mul (mul a.val (conj a.val)) (mul d.val (conj d.val)))) := by
  let A : ComplexCert := ⟨a.val,a.property⟩
  let D : ComplexCert := ⟨d.val,d.property⟩
  let x : RepresentedPolynomial.Arithmetic.Expression := .parameter A
  let y : RepresentedPolynomial.Arithmetic.Expression := .parameter D
  let b : RepresentedPolynomial.Arithmetic.Expression := .mul y (.mul (.conj y) x)
  let n : RepresentedPolynomial.Arithmetic.Expression := .mul (.mul x (.conj x)) (.mul y (.conj y))
  apply RepresentedPolynomial.Arithmetic.Expression.equiv_of_samples
    (.add (.mul x (.conj b)) (.mul b (.conj x))) (.add n n)
  intro s
  simp only [x,y,b,n,RepresentedPolynomial.Arithmetic.Expression.sample,QComplex.add,QComplex.mul,QComplex.conj]
  congr 1 <;> grind only

end ComputableAnalysis.ModularForms
