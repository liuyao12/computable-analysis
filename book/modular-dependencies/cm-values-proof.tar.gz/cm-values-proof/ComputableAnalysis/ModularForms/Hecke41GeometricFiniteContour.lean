import ComputableAnalysis.ModularForms.Hecke41GeometricFiniteEdge

/-! Actual oriented finite contours on geometrically justified squares. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def hecke41GeometricFiniteContour (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (R : QPos) (hR : R.val≤(hecke41NomeGeometricRadius a ha).val)
    (M : Nat) (hM : 0<M) : List HalfEdge → Scalar
  | [] => ⟨zero,ofQComplex_valid _⟩
  | e::es =>
    let v := hecke41GeometricFiniteEdgeAverage k a ha e R hR M hM
    scalarSum (if e.upper then v else scalarNeg v) (hecke41GeometricFiniteContour k a ha R hR M hM es)

theorem hecke41GeometricFiniteContour_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeGeometricRadius a ha).val)
    (hOpen : R.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (M : Nat) (hM : 0<M) (es : List HalfEdge) :
    (hecke41GeometricFiniteContour k a ha R hR M hM es).val.Equiv
      (hecke41SquareKernelEdgeList k a ha R M hM hOpen es).val := by
  induction es with
  | nil => exact equiv_refl _ (ofQComplex_valid _)
  | cons e es ih =>
    have he := hecke41GeometricFiniteEdgeAverage_agreement k a ha e R hR hOpen M hM
    cases h : e.upper
    · simp only [hecke41GeometricFiniteContour,hecke41SquareKernelEdgeList,h,Bool.false_eq_true,↓reduceIte]
      exact add_equiv (neg_equiv he) ih
    · simp only [hecke41GeometricFiniteContour,hecke41SquareKernelEdgeList,h,↓reduceIte]
      exact add_equiv he ih

theorem hecke41GeometricFiniteContour_bound (k : Nat) (q : Scalar) (hq : hecke41NomePuncturedDomain q)
    (R : QPos) (M : Nat) (hM : 0<M)
    (hR : R.val≤(hecke41NomeGeometricRadius q hq).val)
    (es : List HalfEdge) :
    Small (hecke41GeometricFiniteContour k q hq R hR M hM es).val
      ((es.length:Rat)*(8*(2*(2:Rat)^10000)*(1/R.val))) := by
  induction es with
  | nil =>
    change Small zero (0*(8*(2*(2:Rat)^10000)*(1/R.val)))
    rw [Rat.zero_mul]
    exact Small.zero (by decide +kernel)
  | cons e es ih =>
    have he := hecke41GeometricFiniteEdgeAverage_bound k q hq e R hR M hM
    have ho : Small (if e.upper then (hecke41GeometricFiniteEdgeAverage k q hq e R hR M hM).val
        else (scalarNeg (hecke41GeometricFiniteEdgeAverage k q hq e R hR M hM)).val)
        (8*(2*(2:Rat)^10000)*(1/R.val)) := by
      split
      · exact he
      · exact SeriesLimitLaws.small_neg he
    have hb := LocalODE.small_add ho ih
    have hr : 8*(2*(2:Rat)^10000)*(1/R.val)+
        (es.length:Rat)*(8*(2*(2:Rat)^10000)*(1/R.val))=
        ((es.length+1:Nat):Rat)*(8*(2*(2:Rat)^10000)*(1/R.val)) := by
      rw [Rat.natCast_add]
      grind only
    rw [hr] at hb
    cases h : e.upper <;> simpa only [hecke41GeometricFiniteContour,h,Bool.false_eq_true,↓reduceIte,List.length_cons,scalarSum] using hb

end ComputableAnalysis.ModularForms
