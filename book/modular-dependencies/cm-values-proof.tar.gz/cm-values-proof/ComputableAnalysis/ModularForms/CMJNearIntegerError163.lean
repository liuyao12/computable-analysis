import ComputableAnalysis.ModularForms.CMJLinearLaurentEstimate163

/-! Magnitude and sign of the actual CM j error, without assuming the CM integer identity. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- The actual difference between j at the CM point and negative exponential growth plus 744. -/
def cmJGrowthError163 : Scalar :=
  ⟨sub cmJValue163.val
    (add (neg (entireExponentialValue cmGrowthExponent163).val) (ofQComplex ⟨744,0⟩)),
    sub_valid cmJValue163.property (add_valid
      (neg_valid (entireExponentialValue cmGrowthExponent163).property) (ofQComplex_valid _))⟩

private def linearError : Scalar :=
  let q := nome.eval cmScalar163 cmPoint163_upper
  let u := RepresentedReciprocal.inverse q (nome_nonzero cmScalar163 cmPoint163_upper)
  ⟨sub cmJValue163.val (add (add u.val (ofQComplex ⟨744,0⟩)) (scaleRat 196884 q.val)),
    sub_valid cmJValue163.property (add_valid (add_valid u.property (ofQComplex_valid _))
      (scaleRat_valid q.property))⟩

private theorem cancellation (J U K L : ScalarAlgebra.Value) :
    (J-((U+K)+L))+L=J-(U+K) := by grind only

private theorem error_decomposition :
    (add linearError.val (scaleRat 196884 (nome.eval cmScalar163 cmPoint163_upper).val)).Equiv
      cmJGrowthError163.val := by
  let q := nome.eval cmScalar163 cmPoint163_upper
  let u := RepresentedReciprocal.inverse q (nome_nonzero cmScalar163 cmPoint163_upper)
  have hc : (add linearError.val (scaleRat 196884 q.val)).Equiv
      (sub cmJValue163.val (add u.val (ofQComplex ⟨744,0⟩))) := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := add_valid linearError.property (scaleRat_valid q.property))
      (hright := sub_valid cmJValue163.property (add_valid u.property (ofQComplex_valid _)))
    let J := ComplexRawQuotient.ofRaw cmJValue163.val cmJValue163.property
    let U := ComplexRawQuotient.ofRaw u.val u.property
    let K := ComplexRawQuotient.ofQComplex ⟨744,0⟩
    let L := ComplexRawQuotient.scaleRat 196884 (ComplexRawQuotient.ofRaw q.val q.property)
    change (J-((U+K)+L))+L=J-(U+K)
    exact cancellation J U K L
  have hn := FunctionTheory.sub_congr (equiv_refl cmJValue163.val cmJValue163.property)
    (ComplexRaw.add_equiv cmNomeInverse163_growth (equiv_refl _ (ofQComplex_valid ⟨744,0⟩)))
  exact equiv_trans (add_valid linearError.property (scaleRat_valid q.property))
    (sub_valid cmJValue163.property (add_valid u.property (ofQComplex_valid _)))
    cmJGrowthError163.property hc hn

/-- The actual CM j versus growth error is below the desired trillionth scale. -/
theorem cmJGrowthError163_small : Small cmJGrowthError163.val (9/10000000000000) := by
  have h := LocalODE.small_add cmJValue163_linear_laurent_bound
    (LocalODE.small_scale (show (0:Rat)≤196884 by decide +kernel) nome_cm163_small_sharp_power)
  have hb := Small.congr
    (add_valid linearError.property (scaleRat_valid (nome.eval cmScalar163 cmPoint163_upper).property))
    cmJGrowthError163.property error_decomposition h
  exact hb.mono (by decide +kernel)

/-- The actual CM nome magnitude is separated from zero using the checked growth upper bound. -/
theorem cmNomeMagnitude163_lower_sharp :
    (RealRaw.ofRat (1/((11/4:Rat)^41))).Le cmNomeMagnitude163 := by
  intro n m
  have hx := cmGrowthExponential163_upper_sharp_power m 0
  change (cmGrowthValue163.compute m).lo≤((11/4:Rat)^41) at hx
  have hm : maxRat2 (cmGrowthValue163.compute m).lo 25≤((11/4:Rat)^41) := by
    unfold maxRat2
    split
    · exact (show (25:Rat)≤((11/4:Rat)^41) by decide +kernel)
    · exact hx
  have hp : 0<maxRat2 (cmGrowthValue163.compute m).lo 25 := by
    unfold maxRat2
    split <;> grind only
  have h := RealRaw.one_div_antitone_of_pos hp hm
  change (1/((11/4:Rat)^41))≤((RealRaw.positiveReciprocal cmGrowthValue163 25).compute m).hi
  rw [RealRaw.positiveReciprocal_compute cmGrowthValue163 25 (by decide +kernel) m]
  exact h

/-- The actual CM nome has a negative real part bounded away from zero. -/
theorem nome_cm163_real_upper_negative :
    (nome.eval cmScalar163 cmPoint163_upper).val.realPart.Le
      (RealRaw.ofRat (-(1/((11/4:Rat)^41)))) := by
  have he := realPart_equiv nome_cm163_reciprocal
  have hn : (neg (ofRealRaw cmNomeMagnitude163)).realPart.Le
      (RealRaw.ofRat (-(1/((11/4:Rat)^41)))) := by
    intro n m
    have h := cmNomeMagnitude163_lower_sharp 0 n
    change (1/((11/4:Rat)^41))≤(cmNomeMagnitude163.compute n).hi at h
    change -(cmNomeMagnitude163.compute n).hi≤ -(1/((11/4:Rat)^41))
    grind only
  exact RealRaw.le_trans (realPart_valid (neg_valid (ofRealRaw_valid _ cmNomeMagnitude163_valid)))
    (RealRaw.le_of_equiv (realPart_valid (nome.eval cmScalar163 cmPoint163_upper).property)
      (realPart_valid (neg_valid (ofRealRaw_valid _ cmNomeMagnitude163_valid))) he) hn

/-- The actual CM j versus growth error has a strictly negative real part. -/
theorem cmJGrowthError163_real_upper_negative :
    cmJGrowthError163.val.realPart.Le (RealRaw.ofRat (-1/100000000000000)) := by
  let q := nome.eval cmScalar163 cmPoint163_upper
  let s : Scalar := ⟨add linearError.val (scaleRat 196884 q.val),
    add_valid linearError.property (scaleRat_valid q.property)⟩
  have hs : s.val.realPart.Le (RealRaw.ofRat (-1/100000000000000)) := by
    intro n m
    have he := cmJValue163_linear_laurent_bound.2.1 n 0
    change (linearError.val.compute n).lo.re≤(1/10000000000000000000000:Rat) at he
    have hq := nome_cm163_real_upper_negative n 0
    change (q.val.compute n).lo.re≤ -(1/((11/4:Rat)^41)) at hq
    have hm := Rat.mul_le_mul_of_nonneg_left hq (show (0:Rat)≤196884 by decide +kernel)
    have hc : (1/10000000000000000000000:Rat)+196884* (-(1/((11/4:Rat)^41)))≤ -1/100000000000000 := by decide +kernel
    change (linearError.val.compute n).lo.re+196884*(q.val.compute n).lo.re≤(-1/100000000000000:Rat)
    grind only
  have hi := RealRaw.le_of_equiv (realPart_valid cmJGrowthError163.property) (realPart_valid s.property)
    (realPart_equiv (equiv_symm error_decomposition))
  exact RealRaw.le_trans (realPart_valid s.property) hi hs

/-- The positive real deficit relative to the actual CM j value. -/
def cmJGrowthDeficit163 : RealRaw := RealRaw.neg cmJGrowthError163.val.realPart

theorem cmJGrowthDeficit163_valid : cmJGrowthDeficit163.Valid :=
  RealRaw.neg_valid (realPart_valid cmJGrowthError163.property)

/-- A positive lower bound for the actual CM j growth deficit. -/
theorem cmJGrowthDeficit163_lower :
    (RealRaw.ofRat (1/100000000000000)).Le cmJGrowthDeficit163 := by
  intro n m
  have h := cmJGrowthError163_real_upper_negative m 0
  change (cmJGrowthError163.val.compute m).lo.re≤(-1/100000000000000:Rat) at h
  change (1/100000000000000:Rat)≤ -(cmJGrowthError163.val.compute m).lo.re
  grind only

/-- The actual CM j growth deficit is strictly below a trillionth. -/
theorem cmJGrowthDeficit163_upper :
    cmJGrowthDeficit163.Le (RealRaw.ofRat (9/10000000000000)) := by
  intro n m
  have h := cmJGrowthError163_small.1 0 n
  change -(9/10000000000000:Rat)≤(cmJGrowthError163.val.compute n).hi.re at h
  change -(cmJGrowthError163.val.compute n).hi.re≤(9/10000000000000:Rat)
  grind only

/-- Strict positivity follows from the constructed positive lower bound and convergence. -/
theorem cmJGrowthDeficit163_positive : cmJGrowthDeficit163.Pos := by
  obtain ⟨N,hN⟩ := cmJGrowthDeficit163_valid.2.2 (⟨1/1000000000000000,by decide +kernel⟩ : QPos)
  have hw := hN N (Nat.le_refl N)
  have hl := cmJGrowthDeficit163_lower 0 N
  change (1/100000000000000:Rat)≤(cmJGrowthDeficit163.compute N).hi at hl
  unfold QInterval.width at hw
  refine ⟨N,?_⟩
  change 0<(cmJGrowthDeficit163.compute N).lo
  grind only

/-- The represented deficit from the integer occurring in the discriminant-163 example. -/
def cmIntegerGrowthDeficit163 : RealRaw :=
  RealRaw.add (RealRaw.ofRat 262537412640768744) (RealRaw.neg cmGrowthValue163)

theorem cmIntegerGrowthDeficit163_valid : cmIntegerGrowthDeficit163.Valid :=
  RealRaw.add_valid (RealRaw.ofRat_valid _) (RealRaw.neg_valid (realPart_valid (entireExponentialValue cmGrowthExponent163).property))

/-- The CM value identity, when proved, identifies the actual j deficit with the integer deficit. -/
theorem cmIntegerGrowthDeficit163_agreement_of_cm_value
    (hcm : cmJValue163.val.Equiv (ofQComplex ⟨-((640320:Rat)^3),0⟩)) :
    cmJGrowthDeficit163.Equiv cmIntegerGrowthDeficit163 := by
  let t : Scalar := ⟨add (neg (entireExponentialValue cmGrowthExponent163).val) (ofQComplex ⟨744,0⟩),
    add_valid (neg_valid (entireExponentialValue cmGrowthExponent163).property) (ofQComplex_valid _)⟩
  have he := RealRaw.neg_equiv (realPart_equiv
    (FunctionTheory.sub_congr hcm (equiv_refl t.val t.property)))
  have hc : (RealRaw.neg (sub (ofQComplex ⟨-((640320:Rat)^3),0⟩) t.val).realPart).Equiv
      cmIntegerGrowthDeficit163 := by
    intro n
    apply (RealRaw.compareAt_overlap_iff _ _ n n).mpr
    have ho := RealRaw.interval_order_of_valid cmGrowthValue163
      (realPart_valid (entireExponentialValue cmGrowthExponent163).property) n
    have hk : -(-((640320:Rat)^3))+744=262537412640768744 := by decide +kernel
    change (-( -((640320:Rat)^3)+ -(-(cmGrowthValue163.compute n).hi+744))≤
        262537412640768744+ -(cmGrowthValue163.compute n).lo) ∧
      (262537412640768744+ -(cmGrowthValue163.compute n).hi≤
        -( -((640320:Rat)^3)+ -(-(cmGrowthValue163.compute n).lo+744)))
    constructor <;> grind only
  exact RealRaw.equiv_trans cmJGrowthDeficit163_valid
    (RealRaw.neg_valid (realPart_valid (sub_valid (ofQComplex_valid _) t.property)))
    cmIntegerGrowthDeficit163_valid he hc

/-- The proved analytic estimates imply the number-theoretic deficit bounds once the exact CM value is established. -/
theorem cmIntegerGrowthDeficit163_bounds_of_cm_value
    (hcm : cmJValue163.val.Equiv (ofQComplex ⟨-((640320:Rat)^3),0⟩)) :
    (RealRaw.ofRat (1/100000000000000)).Le cmIntegerGrowthDeficit163 ∧
      cmIntegerGrowthDeficit163.Le (RealRaw.ofRat (9/10000000000000)) := by
  have he := cmIntegerGrowthDeficit163_agreement_of_cm_value hcm
  constructor
  · exact RealRaw.le_trans cmJGrowthDeficit163_valid cmJGrowthDeficit163_lower
      (RealRaw.le_of_equiv cmJGrowthDeficit163_valid cmIntegerGrowthDeficit163_valid he)
  · exact RealRaw.le_trans cmJGrowthDeficit163_valid
      (RealRaw.le_of_equiv cmIntegerGrowthDeficit163_valid cmJGrowthDeficit163_valid (RealRaw.equiv_symm he))
      cmJGrowthDeficit163_upper

end ComputableAnalysis.ModularForms
