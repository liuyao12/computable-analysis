import ComputableAnalysis.ModularForms.Hecke41DyadicFiniteEdgeAgreement
import ComputableAnalysis.ModularForms.Hecke41SquareKernelContour

/-! Exact finite contour agreement and the resulting quantitative limit error. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem hecke41DyadicFiniteContour_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val)
    (n : Nat) (es : List HalfEdge) :
    (hecke41DyadicKernelContourSample k a ha R hR n es).val.Equiv
      (hecke41SquareKernelEdgeList k a ha R (2^n) (Nat.pow_pos (by decide +kernel))
        (Rat.le_trans hR (minRadius_left _ _)) es).val := by
  induction es with
  | nil => exact equiv_refl _ (ofQComplex_valid _)
  | cons e es ih =>
    exact add_equiv (hecke41DyadicOrientedFiniteEdge_agreement k a ha e R hR n) ih

theorem hecke41ContourLimit_finite_error (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val)
    (n : Nat) (es : List HalfEdge) :
    Small (sub (hecke41DyadicKernelContourLimit k a ha R hR es).val
      (hecke41SquareKernelEdgeList k a ha R (2^n) (Nat.pow_pos (by decide +kernel))
        (Rat.le_trans hR (minRadius_left _ _)) es).val)
      ((es.length:Rat)*(2*hecke41SquareKernelTail k a ha R n*R.val)) := by
  have he := FunctionTheory.sub_congr
    (equiv_refl _ (hecke41DyadicKernelContourLimit k a ha R hR es).property)
    (hecke41DyadicFiniteContour_agreement k a ha R hR n es)
  exact Small.congr
    (sub_valid (hecke41DyadicKernelContourLimit k a ha R hR es).property
      (hecke41DyadicKernelContourSample k a ha R hR n es).property)
    (sub_valid (hecke41DyadicKernelContourLimit k a ha R hR es).property
      (hecke41SquareKernelEdgeList k a ha R (2^n) (Nat.pow_pos (by decide +kernel))
        (Rat.le_trans hR (minRadius_left _ _)) es).property)
    he (hecke41DyadicKernelContourLimit_sample_error k a ha R hR n es)

end ComputableAnalysis.ModularForms
