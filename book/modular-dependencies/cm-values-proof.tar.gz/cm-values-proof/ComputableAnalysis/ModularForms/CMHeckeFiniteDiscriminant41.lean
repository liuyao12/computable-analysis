import ComputableAnalysis.ModularForms.LatticeJTransformation
import ComputableAnalysis.ModularForms.LatticeJNormalizedFourier
import ComputableAnalysis.ModularForms.CMHeckeExponentialBounds41
import ComputableAnalysis.ModularForms.NomeInverseGrowth
import ComputableAnalysis.ModularForms.NomeDiscriminantWideNonvanishing

/-! Constructed nonzero Fourier discriminants at every transformed finite CM correspondence point. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- Actual transformed finite correspondence point. -/
def cmHeckeFiniteReducedPoint41 (i : Fin 41) : Scalar :=
  fractionalLinear (cmHeckeReduction41 ⟨i.val,by omega⟩)
    (hecke41Point ⟨i.val,by omega⟩ cmScalar163)
    (hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper)

theorem cmHeckeFiniteReducedPoint41_upper (i : Fin 41) :
    InUpperHalfPlane (cmHeckeFiniteReducedPoint41 i).val :=
  fractionalLinear_mem _ _ _

/-- Point-specific actual growth exponential lower bounds. -/
theorem cmHeckeFiniteGrowth41_exponential_lower (i : Fin 41) :
    (RealRaw.ofRat (cmHeckeExponentialBounds41 i).1).Le
      (entireExponentialValue ⟨ofRealRaw (nomeHeightGrowth (cmHeckeFiniteReducedPoint41 i)),
        ofRealRaw_valid _ (nomeHeightGrowth_valid _)⟩).val.realPart := by
  let w := cmHeckeFiniteReducedPoint41 i
  have hb : (RealRaw.ofRat (cmHeckeLowerExponentialInput41 i+1/1000)).Le (nomeHeightGrowth w) := by
    have h := (cmHeckePoint41_growth_bounds i).1
    unfold cmHeckeLowerExponentialInput41
    have he (x : Rat) : x-1/1000+1/1000=x := by grind only
    rw [he]
    exact h
  have hm := entireExponential_real_strict_lower_comparison _ (nomeHeightGrowth_valid w)
    (cmHeckeLowerExponentialInput41 i) (1/1000)
    (cmHeckeExponentialBudget41_valid i).1 (by decide +kernel) hb
  exact RealRaw.le_trans (realPart_valid (entireExponentialValue _).property)
    (cmHeckeLowerExponentialInput41_lower i) hm

/-- Point-specific actual double-growth exponential upper bounds. -/
theorem cmHeckeFiniteGrowth41_double_exponential_upper (i : Fin 41) :
    (entireExponentialValue ⟨ofRealRaw (RealRaw.scaleRat 2 (nomeHeightGrowth (cmHeckeFiniteReducedPoint41 i))),
      ofRealRaw_valid _ (RealRaw.scaleRat_valid (nomeHeightGrowth_valid _))⟩).val.realPart.Le
        (RealRaw.ofRat ((cmHeckeExponentialBounds41 i).2*(cmHeckeExponentialBounds41 i).2)) := by
  let w := cmHeckeFiniteReducedPoint41 i
  let x := RealRaw.scaleRat 2 (nomeHeightGrowth w)
  have hx : x.Valid := RealRaw.scaleRat_valid (nomeHeightGrowth_valid w)
  have hl : (RealRaw.ofRat 12).Le x := by
    intro n m
    have h := cmHeckePoint41_nomeGrowth_lower_sharp i 0 m
    change (328287/52600:Rat)≤((nomeHeightGrowth w).compute m).hi at h
    change (12:Rat)≤(x.compute m).hi
    simp only [x,RealRaw.scaleRat,RealRaw.scaleRatCompute,if_pos (show (0:Rat)≤2 by decide +kernel)]
    grind only
  have hp : x.Pos := by
    obtain ⟨N,hN⟩ := hx.2.2 (⟨1,by decide +kernel⟩ : QPos)
    have hw := hN N (Nat.le_refl N)
    have hh := hl 0 N
    change (12:Rat)≤(x.compute N).hi at hh
    unfold QInterval.width at hw
    refine ⟨N,?_⟩
    change 0<(x.compute N).lo
    grind only
  have h0 : (RealRaw.ofRat 0).Le x := by
    intro n m
    have h := hl 0 m
    change (12:Rat)≤(x.compute m).hi at h
    change (0:Rat)≤(x.compute m).hi
    grind only
  have hb : x.Le (RealRaw.ofRat (cmHeckeUpperDoubleExponentialInput41 i-1/500)) := by
    intro n m
    have h := (cmHeckePoint41_growth_bounds i).2 n 0
    change ((nomeHeightGrowth w).compute n).lo≤
      (41984/25)*((QuadraticOrder163.norm (cmHeckeDenominatorOrder41 i):Rat)⁻¹) at h
    change (x.compute n).lo≤cmHeckeUpperDoubleExponentialInput41 i-1/500
    simp only [x,RealRaw.scaleRat,RealRaw.scaleRatCompute,
      if_pos (show (0:Rat)≤2 by decide +kernel),cmHeckeUpperDoubleExponentialInput41]
    grind only
  have hm := entireExponential_real_strict_upper_comparison x hx hp h0
    (cmHeckeUpperDoubleExponentialInput41 i) (1/500) (by decide +kernel) hb
  exact RealRaw.le_trans (realPart_valid (entireExponentialValue _).property) hm
    (cmHeckeUpperDoubleExponentialInput41_upper i)

private theorem radius_guards : ∀ i : Fin 41,
    let (L,B) := cmHeckeExponentialBounds41 i
    0<L ∧ 0≤1/L ∧ 128*(1/L)≤(1:Rat)/2 ∧ 1/L≤(1:Rat)/512 ∧ 0≤B := by
  decide +kernel

/-- Each actual transformed point has its certified point-specific nome radius. -/
theorem cmHeckeFiniteNome41_small (i : Fin 41) :
    Small (nome.eval (cmHeckeFiniteReducedPoint41 i) (cmHeckeFiniteReducedPoint41_upper i)).val
      (1/(cmHeckeExponentialBounds41 i).1) :=
  nome_small_of_growth_exponential_lower _ _ _ (radius_guards i).1
    (cmHeckeFiniteGrowth41_exponential_lower i)

/-- Each actual transformed point has its certified point-specific nome reciprocal bound. -/
theorem cmHeckeFiniteNome41_inverse_small (i : Fin 41) :
    Small (RepresentedReciprocal.inverse
      (nome.eval (cmHeckeFiniteReducedPoint41 i) (cmHeckeFiniteReducedPoint41_upper i))
      (nome_nonzero _ _)).val (cmHeckeExponentialBounds41 i).2 :=
  nome_inverse_small_of_double_growth_upper _ _ _ (radius_guards i).2.2.2.2
    (cmHeckeFiniteGrowth41_double_exponential_upper i)

/-- Constructed normalized Fourier discriminant at the actual transformed finite point. -/
def cmHeckeFiniteFourierDiscriminant41 (i : Fin 41) : Scalar :=
  nomeModularDiscriminant
    (nome.eval (cmHeckeFiniteReducedPoint41 i) (cmHeckeFiniteReducedPoint41_upper i))
    (1/(cmHeckeExponentialBounds41 i).1) (radius_guards i).2.1 (radius_guards i).2.2.1
    (cmHeckeFiniteNome41_small i)

/-- All transformed finite CM correspondence discriminants are actually nonzero. -/
theorem cmHeckeFiniteFourierDiscriminant41_nonzero (i : Fin 41) :
    NonzeroBoxSearch.Nonzero (cmHeckeFiniteFourierDiscriminant41 i) :=
  nomeModularDiscriminant_wide_nonzero _ _ _ (radius_guards i).2.1 (radius_guards i).2.2.1
    (cmHeckeFiniteNome41_small i) (radius_guards i).2.2.2.1 (nome_nonzero _ _)
    (radius_guards i).2.2.2.2 (cmHeckeFiniteNome41_inverse_small i)
    (cmHeckeExponentialBounds41_guards i).2.2

/-- A constructed nonzero normalized Fourier discriminant justifies the actual lattice j evaluator. -/
theorem latticeJMap_domain_of_fourier_nonzero (z : Scalar) (hz : InUpperHalfPlane z.val)
    (r : Rat) (hr : 0≤r) (hg : 128*r≤(1:Rat)/2) (hq : Small (nome.eval z hz).val r)
    (hd : NonzeroBoxSearch.Nonzero (nomeModularDiscriminant (nome.eval z hz) r hr hg hq)) :
    latticeJMap.domain z := by
  let P : Scalar := ⟨LocalODE.power geometricPiScalar.val 12,LocalODE.power_valid _ geometricPiScalar.property 12⟩
  let F := nomeModularDiscriminant (nome.eval z hz) r hr hg hq
  let D : Scalar := ⟨mul P.val F.val,mul_valid P.property F.property⟩
  have hp : NonzeroBoxSearch.Nonzero P := scalar_power_nonzero _ geometricPiScalar_nonzero 12
  have hm : NonzeroBoxSearch.Nonzero D := scalar_mul_nonzero _ _ hp hd
  have hs := scalar_scale_nonzero D hm 4096 (by decide +kernel)
  have hn := (NonzeroBoxSearch.nonzero_congr (latticeDiscriminantMap.eval z hz)
    ⟨scaleRat 4096 D.val,scaleRat_valid D.property⟩
    (latticeDiscriminantMap_normalized_fourier z hz r hr hg hq)).mpr hs
  exact latticeJMap_domain z |>.mpr ⟨hz,hn⟩

/-- The actual lattice j evaluator is defined at every transformed finite CM correspondence point. -/
theorem cmHeckeFiniteReducedPoint41_j_domain (i : Fin 41) :
    latticeJMap.domain (cmHeckeFiniteReducedPoint41 i) :=
  latticeJMap_domain_of_fourier_nonzero _ (cmHeckeFiniteReducedPoint41_upper i) _
    (radius_guards i).2.1 (radius_guards i).2.2.1 (cmHeckeFiniteNome41_small i)
    (cmHeckeFiniteFourierDiscriminant41_nonzero i)

/-- The actual lattice j evaluator is defined at every original finite CM correspondence point. -/
theorem cmHeckeFinitePoint41_j_domain (i : Fin 41) :
    latticeJMap.domain (hecke41Point ⟨i.val,by omega⟩ cmScalar163) := by
  let g := cmHeckeReduction41 ⟨i.val,by omega⟩
  let z := hecke41Point ⟨i.val,by omega⟩ cmScalar163
  let hz := hecke41Point_upper ⟨i.val,by omega⟩ cmScalar163 cmPoint163_upper
  let w := cmHeckeFiniteReducedPoint41 i
  have hw := cmHeckeFiniteReducedPoint41_j_domain i
  have hh := latticeJMap_action_mem (SL2Z.inverse g) w hw
  have he := fractionalLinear_inverse_left g z hz
  exact (latticeJMap.domain_congr (fractionalLinear (SL2Z.inverse g) w hw.1) z he).mp hh

end ComputableAnalysis.ModularForms
