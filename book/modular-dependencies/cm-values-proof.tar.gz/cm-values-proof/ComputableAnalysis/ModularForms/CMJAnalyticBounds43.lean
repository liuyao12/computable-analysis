import ComputableAnalysis.ModularForms.CMExponentialBounds43
import ComputableAnalysis.ModularForms.PositiveReciprocalAgreement
import ComputableAnalysis.ModularForms.LatticeJFourierReality
import ComputableAnalysis.ModularForms.LatticeJLaurentEstimate
import ComputableAnalysis.ModularForms.NomeDiscriminantSharperLeadingTerm
import ComputableAnalysis.ModularForms.ScalarPerturbationInverseBound

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

theorem cmGrowthValue43_lower : (RealRaw.ofRat 750000000).Le cmGrowthValue43 := by
  intro n m
  have h := cmGrowthExponential43_lower_sharp_power 0 m
  change (31/4:Rat)^10≤(cmGrowthValue43.compute m).hi at h
  exact Rat.le_trans (show (750000000:Rat)≤(31/4:Rat)^10 by decide +kernel) h

theorem cmGrowthValue43_upper : cmGrowthValue43.Le (RealRaw.ofRat 1400000000) := by
  intro n m
  have h := cmGrowthExponential43_upper_sharp_power n 0
  change (cmGrowthValue43.compute n).lo≤(41/5:Rat)^10 at h
  exact Rat.le_trans h (show (41/5:Rat)^10≤1400000000 by decide +kernel)

theorem cmGrowthExponential43_imag_zero :
    (entireExponentialValue cmGrowthExponent43).val.imagPart.Equiv (RealRaw.ofRat 0) := by
  have he := entireExponentialValue_congr cmGrowthExponent43
    ⟨ofRealRaw cmGrowthReal43,ofRealRaw_valid _ cmGrowthReal43_valid⟩ cmGrowthExponent43_real
  exact RealRaw.equiv_trans (imagPart_valid (entireExponentialValue cmGrowthExponent43).property)
    (imagPart_valid (entireExponentialValue _).property) (RealRaw.ofRat_valid _)
    (imagPart_equiv he) (entireExponential_real_imag_zero _ cmGrowthReal43_valid)
def cmNomeMagnitude43 : RealRaw := RealRaw.positiveReciprocal cmGrowthValue43 750000000

theorem cmNomeMagnitude43_valid : cmNomeMagnitude43.Valid :=
  RealRaw.positiveReciprocal_valid _ _ (realPart_valid (entireExponentialValue cmGrowthExponent43).property)
    (by decide) (fun n => cmGrowthValue43_lower 0 n)

theorem nome_cm43_reciprocal : (nome.eval cmScalar43 cmPoint43_upper).val.Equiv
    (neg (ofRealRaw cmNomeMagnitude43)) := by
  have hg := equiv_real_embedding (entireExponentialValue cmGrowthExponent43)
    cmGrowthExponential43_imag_zero
  have hi := positiveReciprocal_mul_identity cmGrowthValue43
    (realPart_valid (entireExponentialValue cmGrowthExponent43).property) 750000000 (by decide)
    cmGrowthValue43_lower
  have he := real_embedding_mul cmGrowthValue43 cmNomeMagnitude43
    (realPart_valid (entireExponentialValue cmGrowthExponent43).property) cmNomeMagnitude43_valid
  have hunit := ofRealRaw_equiv_of_equiv
    (x := RealRaw.mul cmGrowthValue43 cmNomeMagnitude43) (y := RealRaw.one)
    (RealRaw.mul_valid (realPart_valid (entireExponentialValue cmGrowthExponent43).property) cmNomeMagnitude43_valid)
    (RealRaw.ofRat_valid 1) hi
  have hgr := equiv_trans
    (mul_valid (ofRealRaw_valid _ (realPart_valid (entireExponentialValue cmGrowthExponent43).property))
      (ofRealRaw_valid _ cmNomeMagnitude43_valid))
    (ofRealRaw_valid _ (RealRaw.mul_valid (realPart_valid (entireExponentialValue cmGrowthExponent43).property) cmNomeMagnitude43_valid))
    (ofRealRaw_valid RealRaw.one (RealRaw.ofRat_valid 1)) he hunit
  have hq := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := mul_valid (nome.eval cmScalar43 cmPoint43_upper).property (entireExponentialValue cmGrowthExponent43).property)
    (hright := ofQComplex_valid _) nome_cm43_growth_product
  have hgv := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := (entireExponentialValue cmGrowthExponent43).property)
    (hright := ofRealRaw_valid _ (realPart_valid (entireExponentialValue cmGrowthExponent43).property)) hg
  have hrv := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := mul_valid (ofRealRaw_valid _ (realPart_valid (entireExponentialValue cmGrowthExponent43).property))
      (ofRealRaw_valid _ cmNomeMagnitude43_valid)) (hright := ofRealRaw_valid RealRaw.one (RealRaw.ofRat_valid 1)) hgr
  apply ComplexRawQuotient.equiv_of_ofRaw_eq (hleft := (nome.eval cmScalar43 cmPoint43_upper).property)
    (hright := neg_valid (ofRealRaw_valid _ cmNomeMagnitude43_valid))
  let q := ComplexRawQuotient.ofRaw (nome.eval cmScalar43 cmPoint43_upper).val
    (nome.eval cmScalar43 cmPoint43_upper).property
  let g := ComplexRawQuotient.ofRaw (ofRealRaw cmGrowthValue43)
    (ofRealRaw_valid _ (realPart_valid (entireExponentialValue cmGrowthExponent43).property))
  let r := ComplexRawQuotient.ofRaw (ofRealRaw cmNomeMagnitude43) (ofRealRaw_valid _ cmNomeMagnitude43_valid)
  change g*r=1 at hrv
  change q*ComplexRawQuotient.ofRaw (entireExponentialValue cmGrowthExponent43).val
    (entireExponentialValue cmGrowthExponent43).property = ComplexRawQuotient.ofQComplex ⟨-1,0⟩ at hq
  rw [hgv] at hq
  have hneg : ComplexRawQuotient.ofQComplex ⟨-1,0⟩ = -(1:ScalarAlgebra.Value) := rfl
  rw [hneg] at hq
  change q*g= -(1:ScalarAlgebra.Value) at hq
  change q = -r
  grind only


theorem nome_cm43_small : Small (nome.eval cmScalar43 cmPoint43_upper).val (1/750000000) :=
  Small.congr (neg_valid (ofRealRaw_valid _ cmNomeMagnitude43_valid))
    (nome.eval cmScalar43 cmPoint43_upper).property (equiv_symm nome_cm43_reciprocal)
    (SeriesLimitLaws.small_neg (positiveReciprocal_embedding_small cmGrowthValue43
      (realPart_valid (entireExponentialValue cmGrowthExponent43).property)
      750000000 (by decide +kernel) cmGrowthValue43_lower))

theorem nome_cm43_imag_zero :
    (nome.eval cmScalar43 cmPoint43_upper).val.imagPart.Equiv (RealRaw.ofRat 0) := by
  have he := imagPart_equiv nome_cm43_reciprocal
  have hz : (neg (ofRealRaw cmNomeMagnitude43)).imagPart.Equiv (RealRaw.ofRat 0) := by
    intro n
    apply (RealRaw.compareAt_overlap_iff _ _ n n).mpr
    change (-(0:Rat)≤0 ∧ 0≤ -(0:Rat))
    decide +kernel
  exact RealRaw.equiv_trans (imagPart_valid (nome.eval cmScalar43 cmPoint43_upper).property)
    (imagPart_valid (neg_valid (ofRealRaw_valid _ cmNomeMagnitude43_valid)))
    (RealRaw.ofRat_valid 0) he hz

theorem cmJValue43_real_embedding : cmJValue43.val.Equiv (ofRealRaw cmJValue43.val.realPart) :=
  equiv_real_embedding cmJValue43 (latticeJMap_imag_zero_of_real_nome cmScalar43
    (latticeJMap_global_domain _ cmPoint43_upper) (1/750000000)
    (by decide +kernel) (by decide +kernel) nome_cm43_small nome_cm43_imag_zero)
private theorem negative_growth_inverse (Q G : ScalarAlgebra.Value) (h : Q*G= -1) : Q*(-G)=1 := by
  grind only

/-- The actual CM nome reciprocal is exactly the negative actual CM growth exponential. -/
theorem cmNomeInverse43_growth :
    (RepresentedReciprocal.inverse (nome.eval cmScalar43 cmPoint43_upper)
      (nome_nonzero cmScalar43 cmPoint43_upper)).val.Equiv
      (neg (entireExponentialValue cmGrowthExponent43).val) := by
  let q := nome.eval cmScalar43 cmPoint43_upper
  let g := entireExponentialValue cmGrowthExponent43
  let v : Scalar := ⟨neg g.val,neg_valid g.property⟩
  apply RepresentedReciprocal.inverse_unique q (nome_nonzero cmScalar43 cmPoint43_upper) v
  have h := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := mul_valid q.property g.property) (hright := ofQComplex_valid _) nome_cm43_growth_product
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := mul_valid q.property v.property) (hright := ofQComplex_valid _)
  let Q := ComplexRawQuotient.ofRaw q.val q.property
  let G := ComplexRawQuotient.ofRaw g.val g.property
  change Q*G= -1 at h
  change Q*(-G)=1
  exact negative_growth_inverse Q G h

/-- The actual real CM growth exponential is coordinate bounded by the checked rational power. -/
theorem cmGrowthExponential43_small_upper_power :
    Small (entireExponentialValue cmGrowthExponent43).val (1400000000:Rat) := by
  have hb : Small (ofRealRaw cmGrowthValue43) (1400000000:Rat) := by
    refine ⟨?_,?_,?_,?_⟩
    · intro n m
      have hl := cmGrowthValue43_lower 0 m
      change (750000000:Rat)≤(cmGrowthValue43.compute m).hi at hl
      change -(1400000000:Rat)≤(cmGrowthValue43.compute m).hi
      have hc : -(1400000000:Rat)≤750000000 := by decide +kernel
      exact Rat.le_trans hc hl
    · exact cmGrowthValue43_upper
    · intro n m
      change -(1400000000:Rat)≤0
      decide +kernel
    · intro n m
      change (0:Rat)≤(8:Rat)^26
      decide +kernel
  exact Small.congr
    (ofRealRaw_valid _ (realPart_valid (entireExponentialValue cmGrowthExponent43).property))
    (entireExponentialValue cmGrowthExponent43).property
    (equiv_symm (equiv_real_embedding (entireExponentialValue cmGrowthExponent43)
      cmGrowthExponential43_imag_zero)) hb

/-- A concrete justified coordinate bound for the actual CM nome reciprocal. -/
theorem cmNomeInverse43_bound :
    Small (RepresentedReciprocal.inverse (nome.eval cmScalar43 cmPoint43_upper)
      (nome_nonzero cmScalar43 cmPoint43_upper)).val (1400000000:Rat) :=
  Small.congr (neg_valid (entireExponentialValue cmGrowthExponent43).property)
    (RepresentedReciprocal.inverse (nome.eval cmScalar43 cmPoint43_upper)
      (nome_nonzero cmScalar43 cmPoint43_upper)).property
    (equiv_symm cmNomeInverse43_growth)
    (SeriesLimitLaws.small_neg cmGrowthExponential43_small_upper_power)


/-- The actual Fourier quotient has a proved Laurent error below four. -/
theorem cmJValue43_laurent_bound :
    Small (sub cmJValue43.val
      (add (RepresentedReciprocal.inverse (nome.eval cmScalar43 cmPoint43_upper)
        (nome_nonzero cmScalar43 cmPoint43_upper)).val (ofQComplex ⟨744,0⟩))) 4 := by
  let q := nome.eval cmScalar43 cmPoint43_upper
  let d := nomeModularDiscriminant q (1/750000000) (by decide +kernel) (by decide +kernel) nome_cm43_small
  have hd := nomeModularDiscriminant_sharp_linear_bound q (1/750000000)
    (by decide +kernel) (by decide +kernel) nome_cm43_small (by decide +kernel)
  have hv := scalar_perturbation_inverse_bound q d (nome_nonzero _ _)
    (latticeJMap_fourier_discriminant_nonzero cmScalar43 (latticeJMap_global_domain _ cmPoint43_upper)
      (1/750000000) (by decide +kernel) (by decide +kernel) nome_cm43_small)
    1400000000 (103*(1/750000000)*(1/750000000))
    (by decide +kernel) (by decide +kernel) cmNomeInverse43_bound hd (by decide +kernel)
  exact (latticeJMap_laurent_bound cmScalar43 (latticeJMap_global_domain _ cmPoint43_upper)
    (1/750000000) (by decide +kernel) (by decide +kernel) nome_cm43_small (by decide +kernel)
    1400000000 (8*1400000000) (by decide +kernel) (by decide +kernel)
    cmNomeInverse43_bound hv).mono (by decide +kernel)

def cmJGrowthError43 : Scalar :=
  ⟨sub cmJValue43.val (add (neg (entireExponentialValue cmGrowthExponent43).val) (ofQComplex ⟨744,0⟩)),
    sub_valid cmJValue43.property (add_valid (neg_valid (entireExponentialValue cmGrowthExponent43).property)
      (ofQComplex_valid _))⟩

theorem cmJGrowthError43_small : Small cmJGrowthError43.val 4 := by
  have he := FunctionTheory.sub_congr (equiv_refl _ cmJValue43.property)
    (ComplexRaw.add_equiv cmNomeInverse43_growth (equiv_refl _ (ofQComplex_valid ⟨744,0⟩)))
  exact Small.congr
    (sub_valid cmJValue43.property (add_valid
      (RepresentedReciprocal.inverse (nome.eval cmScalar43 cmPoint43_upper) (nome_nonzero _ _)).property
      (ofQComplex_valid _))) cmJGrowthError43.property he cmJValue43_laurent_bound
private def mainTerm : RealRaw := RealRaw.add (RealRaw.neg cmGrowthValue43) (RealRaw.ofRat 744)
private theorem main_valid : mainTerm.Valid :=
  RealRaw.add_valid (RealRaw.neg_valid (realPart_valid (entireExponentialValue cmGrowthExponent43).property))
    (RealRaw.ofRat_valid _)

private theorem error_agreement :
    cmJGrowthError43.val.realPart.Equiv (RealRaw.sub cmJValue43.val.realPart mainTerm) := by
  intro n
  apply (RealRaw.compareAt_overlap_iff _ _ n n).2
  have ho := RealRaw.interval_order_of_valid (RealRaw.sub cmJValue43.val.realPart mainTerm)
    (RealRaw.sub_valid (realPart_valid cmJValue43.property) main_valid) n
  change (cmJGrowthError43.val.realPart.compute n).lo≤
      ((RealRaw.sub cmJValue43.val.realPart mainTerm).compute n).hi ∧
    ((RealRaw.sub cmJValue43.val.realPart mainTerm).compute n).lo≤
      (cmJGrowthError43.val.realPart.compute n).hi
  simpa [cmJGrowthError43,mainTerm,cmGrowthValue43,ComplexRaw.realPart,
    ComplexRaw.sub,ComplexRaw.add,ComplexRaw.neg,ComplexRaw.ofQComplex,
    QBox.add,QBox.neg,QComplex.add,RealRaw.sub,RealRaw.subCompute,
    RealRaw.add,RealRaw.addCompute,RealRaw.neg,RealRaw.negCompute,RealRaw.ofRat,
    Rat.sub_eq_add_neg] using And.intro ho ho

/-- Exact reconstruction from the proved Laurent main term and actual error. -/
theorem cmJValue43_real_reconstruction :
    (RealRaw.add cmJGrowthError43.val.realPart mainTerm).Equiv cmJValue43.val.realPart :=
  RealRaw.equiv_trans (RealRaw.add_valid (realPart_valid cmJGrowthError43.property) main_valid)
    (RealRaw.add_valid (RealRaw.sub_valid (realPart_valid cmJValue43.property) main_valid) main_valid)
    (realPart_valid cmJValue43.property)
    (RealRaw.add_equiv (realPart_valid cmJGrowthError43.property)
      (RealRaw.sub_valid (realPart_valid cmJValue43.property) main_valid)
      main_valid main_valid error_agreement (RealRaw.equiv_refl mainTerm main_valid))
    (RealRaw.sub_add_cancel_equiv (realPart_valid cmJValue43.property) main_valid)

/-- The actual CM real coordinate lies in the checked quotient-isolation interval. -/
theorem cmJValue43_real_isolation_bounds :
    (RealRaw.ofRat (-1500000000)).Le cmJValue43.val.realPart ∧
      cmJValue43.val.realPart.Le (RealRaw.ofRat (-750000000)) := by
  have hv := RealRaw.add_valid (realPart_valid cmJGrowthError43.property) main_valid
  constructor
  · apply RealRaw.le_trans hv _
      (RealRaw.le_of_equiv hv (realPart_valid cmJValue43.property) cmJValue43_real_reconstruction)
    intro n m
    have he := cmJGrowthError43_small.1 0 m
    have hg := cmGrowthValue43_upper m 0
    change -(4:Rat)≤(cmJGrowthError43.val.realPart.compute m).hi at he
    change (cmGrowthValue43.compute m).lo≤1400000000 at hg
    change (-1500000000:Rat)≤
      (cmJGrowthError43.val.realPart.compute m).hi+(-(cmGrowthValue43.compute m).lo+744)
    grind only
  · apply RealRaw.le_trans hv
      (RealRaw.le_of_equiv (realPart_valid cmJValue43.property) hv
        (RealRaw.equiv_symm cmJValue43_real_reconstruction))
    intro n m
    have he := cmJGrowthError43_small.2.1 n 0
    have hg := cmGrowthExponential43_lower_sharp_power 0 n
    change (cmJGrowthError43.val.realPart.compute n).lo≤(4:Rat) at he
    change ((31/4:Rat)^10)≤(cmGrowthValue43.compute n).hi at hg
    change (cmJGrowthError43.val.realPart.compute n).lo+(-(cmGrowthValue43.compute n).hi+744)≤
      (-750000000:Rat)
    grind only


/-- The actual CM coordinate stays at least 255 below the interval's upper endpoint. -/
theorem cmJValue43_real_isolation_upper_margin :
    cmJValue43.val.realPart.Le (RealRaw.ofRat (-750000255)) := by
  have hv := RealRaw.add_valid (realPart_valid cmJGrowthError43.property) main_valid
  apply RealRaw.le_trans hv
    (RealRaw.le_of_equiv (realPart_valid cmJValue43.property) hv
      (RealRaw.equiv_symm cmJValue43_real_reconstruction))
  intro n m
  have he := cmJGrowthError43_small.2.1 n 0
  have hg := cmGrowthExponential43_lower_sharp_power 0 n
  change (cmJGrowthError43.val.realPart.compute n).lo≤(4:Rat) at he
  change ((31/4:Rat)^10)≤(cmGrowthValue43.compute n).hi at hg
  change (cmJGrowthError43.val.realPart.compute n).lo+(-(cmGrowthValue43.compute n).hi+744)≤
    (-750000255:Rat)
  grind only


end ComputableAnalysis.ModularForms
