import ComputableAnalysis.ModularForms.CoefficientConvolutionAlgebra
import ComputableAnalysis.ModularForms.IntegerCauchyCoefficientEnumeration

namespace ComputableAnalysis.ModularForms.CoefficientConvolutionAlgebra

/-- Specialization of the finite-recursive product recovers the existing
executable integer Cauchy coefficient at every degree. -/
theorem product_integer_agreement (a b : Coefficients) (n : Nat) :
    product a b n=integerSeriesProduct a b n := by
  rw [integerSeriesProduct_ofFn]
  induction n generalizing a with
  | zero => simp [product,integerCoefficientListSum]
  | succ n ih =>
    rw [List.ofFn_succ]
    simp only [integerCoefficientListSum,Fin.val_zero,Nat.sub_zero]
    rw [product]
    have he : (fun i : Fin (n+1) => a i.succ.val*b (n+1-i.succ.val)) =
        (fun i : Fin (n+1) => tail a i.val*b (n-i.val)) := by
      funext i
      change a (i.val+1)*b (n+1-(i.val+1))=a (i.val+1)*b (n-i.val)
      rw [show n+1-(i.val+1)=n-i.val by omega]
    rw [he,ih]

end ComputableAnalysis.ModularForms.CoefficientConvolutionAlgebra
