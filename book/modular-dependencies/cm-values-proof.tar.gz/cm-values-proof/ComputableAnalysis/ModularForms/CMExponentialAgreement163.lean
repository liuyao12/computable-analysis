import ComputableAnalysis.ExponentialComputations.API
import ComputableAnalysis.ModularForms.CMJNearIntegerError163

/-! Exact agreement of the CM growth exponential with the current function API.
This analytic bridge is independent of the finite CM integer arithmetic. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory
namespace EC163
open ExponentialComputations

/-- The computable argument `pi*sqrt(163)`: twice the geometric half-pi
times the independently validated represented square root. -/
def input : RealInput := ⟨cmGrowthReal163,cmGrowthReal163_valid⟩

theorem complex_exp_agreement :
    (entireExponentialValue cmGrowthExponent163).val.Equiv
      (ExponentialComputations.Complex.exp (realAxis input)).val :=
  entireExponentialValue_congr _ _ cmGrowthExponent163_real

theorem real_exp_agreement : cmGrowthValue163.Equiv (exp input).val :=
  realPart_equiv complex_exp_agreement

/-- Agreement for any registered algorithm and any equivalent valid name
of this irrational input. No numerical precision or chart is supplied. -/
theorem implementation_agreement (f : Implementation) (x : RealInput)
    (hx : x.val.Equiv input.val) : (f.realEval x).val.Equiv cmGrowthValue163 :=
  RealRaw.equiv_trans (f.realEval x).property (exp x).property
    (realPart_valid (entireExponentialValue cmGrowthExponent163).property)
    (f.realEval_agrees x)
    (RealRaw.equiv_trans (exp x).property (exp input).property
      (realPart_valid (entireExponentialValue cmGrowthExponent163).property)
      (exp_congr x input hx) (RealRaw.equiv_symm real_exp_agreement))

/-- The actual deficit computed through a selected current API evaluator. -/
def deficit (f : Implementation) (x : RealInput) : RealRaw :=
  RealRaw.add (RealRaw.ofRat 262537412640768744) (RealRaw.neg (f.realEval x).val)

theorem deficit_valid (f : Implementation) (x : RealInput) : (deficit f x).Valid :=
  RealRaw.add_valid (RealRaw.ofRat_valid _) (RealRaw.neg_valid (f.realEval x).property)

theorem deficit_agreement (f : Implementation) (x : RealInput)
    (hx : x.val.Equiv input.val) : (deficit f x).Equiv cmIntegerGrowthDeficit163 :=
  RealRaw.add_equiv (RealRaw.ofRat_valid _) (RealRaw.ofRat_valid _)
    (RealRaw.neg_valid (f.realEval x).property)
    (RealRaw.neg_valid (realPart_valid (entireExponentialValue cmGrowthExponent163).property))
    (RealRaw.equiv_refl _ (RealRaw.ofRat_valid _))
    (RealRaw.neg_equiv (implementation_agreement f x hx))

/-- Transport the analytic error bound once the CM integer value is supplied.
The unconditional arithmetic instance is constructed in the endpoint module. -/
theorem deficit_bounds_of_cm_value (f : Implementation) (x : RealInput)
    (hx : x.val.Equiv input.val)
    (hcm : cmJValue163.val.Equiv (ofQComplex ⟨-((640320:Rat)^3),0⟩)) :
    (RealRaw.ofRat (1/100000000000000)).Le (deficit f x) ∧
      (deficit f x).Le (RealRaw.ofRat (9/10000000000000)) := by
  have h := deficit_agreement f x hx
  have hb := cmIntegerGrowthDeficit163_bounds_of_cm_value hcm
  constructor
  · exact RealRaw.le_trans cmIntegerGrowthDeficit163_valid hb.1
      (RealRaw.le_of_equiv cmIntegerGrowthDeficit163_valid (deficit_valid f x) (RealRaw.equiv_symm h))
  · exact RealRaw.le_trans cmIntegerGrowthDeficit163_valid
      (RealRaw.le_of_equiv (deficit_valid f x) cmIntegerGrowthDeficit163_valid h)
      hb.2

end EC163
end ComputableAnalysis.ModularForms
