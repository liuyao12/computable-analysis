import ComputableAnalysis.ModularForms.IntegerHeckeCombinedAnalyticAgreement41

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

private def symClass (xs : List Scalar) (k : Nat) : ScalarAlgebra.Value :=
  ComplexRawQuotient.ofRaw (representedElementarySymmetric41 xs k) (representedElementarySymmetric41_valid xs k)

private theorem swap_class (x y : Scalar) (xs : List Scalar) (k : Nat) :
    symClass (y::x::xs) k=symClass (x::y::xs) k := by
  cases k with
  | zero => rfl
  | succ k =>
    cases k with
    | zero =>
      let X := ComplexRawQuotient.ofRaw x.val x.property
      let Y := ComplexRawQuotient.ofRaw y.val y.property
      change (symClass xs 1+X*symClass xs 0)+Y*symClass (x::xs) 0=
        (symClass xs 1+Y*symClass xs 0)+X*symClass (y::xs) 0
      have hz : symClass xs 0=1 := by cases xs <;> rfl
      rw [hz]
      change (symClass xs 1+X*1)+Y*1=(symClass xs 1+Y*1)+X*1
      grind only
    | succ k =>
      let X := ComplexRawQuotient.ofRaw x.val x.property
      let Y := ComplexRawQuotient.ofRaw y.val y.property
      change (symClass xs (k+2)+X*symClass xs (k+1))+Y*(symClass xs (k+1)+X*symClass xs k)=
        (symClass xs (k+2)+Y*symClass xs (k+1))+X*(symClass xs (k+1)+Y*symClass xs k)
      grind only

private theorem perm_class {xs ys : List Scalar} (h : xs.Perm ys) (k : Nat) :
    symClass xs k=symClass ys k := by
  induction h generalizing k with
  | nil => rfl
  | cons x h ih =>
    cases k with
    | zero => rfl
    | succ k =>
      change symClass _ (k+1)+ComplexRawQuotient.ofRaw x.val x.property*symClass _ k=
        symClass _ (k+1)+ComplexRawQuotient.ofRaw x.val x.property*symClass _ k
      rw [ih (k+1),ih k]
  | swap x y xs => exact swap_class x y xs k
  | trans h₁ h₂ ih₁ ih₂ => exact Eq.trans (ih₁ k) (ih₂ k)

/-- Every represented elementary symmetric sum is independent of the supplied
factor ordering, at arbitrary valid represented values. -/
theorem representedElementarySymmetric41_perm {xs ys : List Scalar} (h : xs.Perm ys) (k : Nat) :
    (representedElementarySymmetric41 xs k).Equiv (representedElementarySymmetric41 ys k) :=
  ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := representedElementarySymmetric41_valid xs k)
    (hright := representedElementarySymmetric41_valid ys k) (perm_class h k)

end ComputableAnalysis.ModularForms
