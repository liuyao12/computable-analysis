import ComputableAnalysis.ModularForms.CMNomeInverseBound163
import ComputableAnalysis.ModularForms.CMExponentialSharpLowerBound163

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- The actual real CM growth exponential is coordinate bounded by the checked rational power. -/
theorem cmGrowthExponential163_small_sharp_upper_power :
    Small (entireExponentialValue cmGrowthExponent163).val ((11/4:Rat)^41) := by
  have hb : Small (ofRealRaw cmGrowthValue163) ((11/4:Rat)^41) := by
    refine ⟨?_,?_,?_,?_⟩
    · intro n m
      have hl := cmGrowthExponential163_lower_twentyFive 0 m
      change (25:Rat)≤(cmGrowthValue163.compute m).hi at hl
      change -((11/4:Rat)^41)≤(cmGrowthValue163.compute m).hi
      have hc : -((11/4:Rat)^41)≤25 := by decide +kernel
      exact Rat.le_trans hc hl
    · exact cmGrowthExponential163_upper_sharp_power
    · intro n m
      change -((11/4:Rat)^41)≤0
      decide +kernel
    · intro n m
      change (0:Rat)≤(11/4:Rat)^41
      decide +kernel
  exact Small.congr
    (ofRealRaw_valid _ (realPart_valid (entireExponentialValue cmGrowthExponent163).property))
    (entireExponentialValue cmGrowthExponent163).property
    (equiv_symm (equiv_real_embedding (entireExponentialValue cmGrowthExponent163)
      cmGrowthExponential163_imag_zero)) hb

/-- A concrete justified coordinate bound for the actual CM nome reciprocal. -/
theorem cmNomeInverse163_sharp_bound :
    Small (RepresentedReciprocal.inverse (nome.eval cmScalar163 cmPoint163_upper)
      (nome_nonzero cmScalar163 cmPoint163_upper)).val ((11/4:Rat)^41) :=
  Small.congr (neg_valid (entireExponentialValue cmGrowthExponent163).property)
    (RepresentedReciprocal.inverse (nome.eval cmScalar163 cmPoint163_upper)
      (nome_nonzero cmScalar163 cmPoint163_upper)).property
    (equiv_symm cmNomeInverse163_growth)
    (SeriesLimitLaws.small_neg cmGrowthExponential163_small_sharp_upper_power)

end ComputableAnalysis.ModularForms
