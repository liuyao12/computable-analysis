import ComputableAnalysis.ModularForms.CMNome43
import ComputableAnalysis.ModularForms.CMGrowthTightBounds163

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- The actual represented square root has the rational lower bound \(131/20\). -/
theorem sqrt43_lower_rational : (RealRaw.ofRat (131/20)).Le sqrt43 := by
  intro n m
  have hs := sqrtRaw_stage_spec 43 (by unfold sqrtDomain; decide +kernel) m
  exact hs.le_hi_of_sq_le (r := 131/20) (by decide +kernel)

/-- The actual represented square root has the rational upper bound \(164/25\). -/
theorem sqrt43_upper_rational : sqrt43.Le (RealRaw.ofRat (164/25)) := by
  intro n m
  have hs := sqrtRaw_stage_spec 43 (by unfold sqrtDomain; decide +kernel) n
  exact hs.lo_le_of_sq_le (r := 164/25) (by decide +kernel) (by decide +kernel)

/-- The actual CM growth exponent has a rational lower bound strictly above twenty. -/
theorem cmGrowthReal43_lower_tight : (RealRaw.ofRat (20567/1000)).Le cmGrowthReal43 := by
  intro n m
  have ho := RealRaw.interval_order_of_valid _ GeometricPiRotation.halfPi_valid m
  have hr := RealRaw.interval_order_of_valid _ sqrt43_valid m
  have hl := sqrt43_lower_rational 0 m
  change (131/20:Rat)≤(sqrt43.compute m).hi at hl
  have hp := QBox.mulRealInterval_contains ho (Rat.le_refl) hr (Rat.le_refl)
  have h1 := halfPi_lower_onePointFiveSeven 0 m
  change (157/100:Rat)≤(GeometricPiRotation.halfPi.compute m).hi at h1
  have hn : 0≤(sqrt43.compute m).hi := Rat.le_trans (by decide +kernel) hl
  have hm := Rat.mul_le_mul_of_nonneg_right h1 hn
  have hh := Rat.mul_le_mul_of_nonneg_left hl (show (0:Rat)≤157/100 by decide +kernel)
  have hc : (20567/2000:Rat)≤(157/100)*(131/20) := by decide +kernel
  have ht : (20567/2000:Rat)≤(QBox.mulRealInterval (GeometricPiRotation.halfPi.compute m).lo
      (GeometricPiRotation.halfPi.compute m).hi (sqrt43.compute m).lo (sqrt43.compute m).hi).hi := by
    have hprod := Rat.le_trans hc (Rat.le_trans hh hm)
    grind only
  have hs := Rat.mul_le_mul_of_nonneg_left ht (show (0:Rat)≤2 by decide +kernel)
  change (20567/1000:Rat)≤2*(QBox.mulRealInterval (GeometricPiRotation.halfPi.compute m).lo
    (GeometricPiRotation.halfPi.compute m).hi (sqrt43.compute m).lo (sqrt43.compute m).hi).hi
  have hlast : (20567/1000:Rat)=2*(20567/2000) := by decide +kernel
  rw [hlast]
  exact hs

/-- The actual CM growth exponent has a rational upper bound strictly below twenty-one. -/
theorem cmGrowthReal43_upper_tight : cmGrowthReal43.Le (RealRaw.ofRat (5248/250)) := by
  intro n m
  have ho := RealRaw.interval_order_of_valid _ GeometricPiRotation.halfPi_valid n
  have hr := RealRaw.interval_order_of_valid _ sqrt43_valid n
  have hl := sqrt43_upper_rational n 0
  change (sqrt43.compute n).lo≤(164/25:Rat) at hl
  have hp := QBox.mulRealInterval_contains (Rat.le_refl) ho (Rat.le_refl) hr
  have h1 := halfPi_upper_eight_fifths n 0
  change (GeometricPiRotation.halfPi.compute n).lo≤(8/5:Rat) at h1
  have hn : 0≤(sqrt43.compute n).lo := (sqrtRaw_stage_spec 43 (by unfold sqrtDomain; decide +kernel) n).1
  have hm := Rat.mul_le_mul_of_nonneg_right h1 hn
  have ht := Rat.mul_le_mul_of_nonneg_left hl (show (0:Rat)≤8/5 by decide +kernel)
  have hc : (8/5:Rat)*(164/25)=5248/500 := by decide +kernel
  have hb : (QBox.mulRealInterval (GeometricPiRotation.halfPi.compute n).lo
      (GeometricPiRotation.halfPi.compute n).hi (sqrt43.compute n).lo (sqrt43.compute n).hi).lo≤5248/500 := by
    have hprod := Rat.le_trans hm ht
    rw [hc] at hprod
    grind only
  have hs := Rat.mul_le_mul_of_nonneg_left hb (show (0:Rat)≤2 by decide +kernel)
  have hlast : (2:Rat)*(5248/500)≤5248/250 := by decide +kernel
  change 2*(QBox.mulRealInterval (GeometricPiRotation.halfPi.compute n).lo
    (GeometricPiRotation.halfPi.compute n).hi (sqrt43.compute n).lo (sqrt43.compute n).hi).lo≤(5248/250:Rat)
  exact Rat.le_trans hs hlast


end ComputableAnalysis.ModularForms
