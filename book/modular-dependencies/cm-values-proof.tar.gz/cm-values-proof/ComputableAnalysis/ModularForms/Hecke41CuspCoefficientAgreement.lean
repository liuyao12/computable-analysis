import ComputableAnalysis.ModularForms.Hecke41NomeQuadraticCuspHolomorphic

/-! Exact recovery of actual correspondence coefficients from the holomorphic cusp extension. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

theorem hecke41NomeDescended_upper_agreement (k m : Nat) (z : Scalar)
    (hz : hecke41CommonDomain z) (hq : hecke41NomePuncturedDomain (nome.eval z hz.1)) :
    ((hecke41NomeDescended k m).eval (nome.eval z hz.1) hq).val.Equiv
      ((hecke41WeightedCoefficient k m).value z hz).val := by
  have hc := hecke41NomeCoveredValue_chart_agreement k m (nome.eval z hz.1) hq.1
    (LocalODE.interior_bound hecke41NomeCoverRadius.val _ hq.2) z hz
    (hecke41NomeChart_center_mem k m z hz)
  exact equiv_trans ((hecke41NomeDescended k m).eval (nome.eval z hz.1) hq).property
    ((hecke41NomeChart k m z hz).eval (nome.eval z hz.1) (hecke41NomeChart_center_mem k m z hz)).property
    ((hecke41WeightedCoefficient k m).value z hz).property hc
    (hecke41NomeChart_center k m z hz)

theorem hecke41QuadraticCusp_upper_weighted_coefficient (k : Nat) (z : Scalar)
    (hz : hecke41CommonDomain z) (hq : hecke41NomePuncturedDomain (nome.eval z hz.1)) :
    ((hecke41NomeQuadraticCuspMap k).eval (nome.eval z hz.1) hq.2).val.Equiv
      (mul (LocalODE.power (nome.eval z hz.1).val 10002)
        ((hecke41PolynomialCoefficient k).value z hz).val) := by
  have ha := hecke41NomeQuadraticCuspMap_punctured_agreement k (nome.eval z hz.1) hq
  have hb := hecke41NomeDescended_upper_agreement k 10002 z hz hq
  have hc := hecke41WeightedCoefficient_value k 10002 z hz
  exact equiv_trans ((hecke41NomeQuadraticCuspMap k).eval (nome.eval z hz.1) hq.2).property
    ((hecke41NomeDescended k 10002).eval (nome.eval z hz.1) hq).property
    (mul_valid (LocalODE.power_valid _ (nome.eval z hz.1).property 10002)
      ((hecke41PolynomialCoefficient k).value z hz).property) ha
    (equiv_trans ((hecke41NomeDescended k 10002).eval (nome.eval z hz.1) hq).property
      ((hecke41WeightedCoefficient k 10002).value z hz).property
      (mul_valid (LocalODE.power_valid _ (nome.eval z hz.1).property 10002)
        ((hecke41PolynomialCoefficient k).value z hz).property) hb hc)

end ComputableAnalysis.ModularForms
