import ComputableAnalysis.ModularForms.Hecke41DyadicGridAgreement

/-! Exact fixed-velocity transport through flat and dyadic averages. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem gridScalarSum_mul_right (d : Scalar) (f : Nat → Scalar) (M : Nat) :
    (gridScalarSum M (fun v => scalarProduct (f v) d)).val.Equiv
      (scalarProduct (gridScalarSum M f) d).val := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (gridScalarSum M (fun v => scalarProduct (f v) d)).property)
    (hright := (scalarProduct (gridScalarSum M f) d).property)
  change gridScalarValue (gridScalarSum M (fun v => scalarProduct (f v) d))=
    gridScalarValue (gridScalarSum M f)*gridScalarValue d
  simp only [gridScalarSum_value]
  let D := gridScalarValue d
  let F := fun v => gridScalarValue (f v)
  change gridValueSum M (fun v => F v*D)=gridValueSum M F*D
  induction M with
  | zero => simp only [gridValueSum]; grind only
  | succ M ih => simp only [gridValueSum,ih]; grind only

theorem weightedMidpointSum_mul_right (d : Scalar) (f : Rat → Scalar) (M : Nat) (r : Rat) :
    (weightedMidpointSum (fun u => scalarProduct (f u) d) M r).val.Equiv
      (scalarProduct (weightedMidpointSum f M r) d).val := by
  have hs := gridScalarSum_mul_right d (fun v => f (squareMidpointParameter M v)) M
  have hh := representedScale_congr
    (gridScalarSum M (fun v => scalarProduct (f (squareMidpointParameter M v)) d))
    (scalarProduct (gridScalarSum M (fun v => f (squareMidpointParameter M v))) d) r hs
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (weightedMidpointSum (fun u => scalarProduct (f u) d) M r).property)
    (hright := (scalarProduct (weightedMidpointSum f M r) d).property)
  have hv := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := (weightedMidpointSum (fun u => scalarProduct (f u) d) M r).property)
    (hright := scaleRat_valid (scalarProduct (gridScalarSum M (fun v => f (squareMidpointParameter M v))) d).property) hh
  rw [hv]
  exact (ComplexRawQuotient.scaleRat_mul r
    (gridScalarValue (gridScalarSum M (fun v => f (squareMidpointParameter M v)))) (gridScalarValue d))


theorem dyadicAverage_velocity_transport (f : Rat → Scalar) (d : Scalar) (n : Nat) :
    (scalarProduct (dyadicSampleAverage f ⟨0,1⟩ n) d).val.Equiv
      (weightedMidpointSum (fun u => scalarProduct (f u) d) (2^n)
        (1/((2^n:Nat):Rat))).val := by
  have hs := mul_equiv (dyadicSampleAverage f ⟨0,1⟩ n).property
    (weightedMidpointSum f (2^n) (1/((2^n:Nat):Rat))).property d.property d.property
    (dyadicSampleAverage_weightedMidpoint_agreement f n)
    (equiv_refl d.val d.property)
  exact equiv_trans (scalarProduct (dyadicSampleAverage f ⟨0,1⟩ n) d).property
    (scalarProduct (weightedMidpointSum f (2^n) (1/((2^n:Nat):Rat))) d).property
    (weightedMidpointSum (fun u => scalarProduct (f u) d) (2^n) (1/((2^n:Nat):Rat))).property
    hs (equiv_symm (weightedMidpointSum_mul_right d f (2^n) (1/((2^n:Nat):Rat))))

end ComputableAnalysis.ModularForms
