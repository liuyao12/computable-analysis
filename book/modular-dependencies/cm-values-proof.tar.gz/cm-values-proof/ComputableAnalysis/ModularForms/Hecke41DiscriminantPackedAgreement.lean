import ComputableAnalysis.ModularForms.IntegerJSeries
import ComputableAnalysis.ModularForms.Hecke41DiscriminantPackedData
import ComputableAnalysis.ModularForms.Hecke41DiscriminantMagnitude
import ComputableAnalysis.ModularForms.PackedCoefficientMagnitude

namespace ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem candidate_bound : ∀ a∈hecke41DiscriminantCandidate,
    a.natAbs≤1207441533568463972 := by decide +kernel

theorem hecke41Discriminant_actual :
    discriminantList 1723 1722=hecke41DiscriminantCandidate := by
  apply discriminantList_single_witness _ (2^3500) 1723 1722
    (by decide +kernel) (by decide) (by decide) (by decide +kernel)
  · intro n hn
    have h := coefficient_natAbs_bound _ _ candidate_bound n
    have hc := Rat.natCast_le_natCast.mpr h
    have hd := hecke41Discriminant_degree_ceiling n hn
    grind only
  · exact Int.dvd_of_emod_eq_zero hecke41Discriminant_residue_checked

/-- The supplied full denominator witness gives the actual Delta unit
coefficients at every degree used by the degree-41 computation. -/
theorem hecke41Discriminant_coefficient_actual (n : Nat) (hn : n<1723) :
    coefficient hecke41DiscriminantCandidate n=integerDiscriminantUnitCoefficients n := by
  rw [←hecke41Discriminant_actual]
  exact discriminantList_tau 1723 1722 n hn (by omega)

end ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct
