import ComputableAnalysis.ModularForms.AutomorphyFactor

/-! Exact weighted automorphy cocycles for executable represented powers. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert

theorem represented_power_congr (x y : Scalar) (hxy : x.val.Equiv y.val) (n : Nat) :
    (LocalODE.power x.val n).Equiv (LocalODE.power y.val n) := by
  induction n with
  | zero => exact equiv_refl _ (ofQComplex_valid _)
  | succ n ih =>
    exact mul_equiv (LocalODE.power_valid _ x.property n)
      (LocalODE.power_valid _ y.property n) x.property y.property ih hxy

theorem represented_power_product (x y : Scalar) (n : Nat) :
    (LocalODE.power (mul x.val y.val) n).Equiv
      (mul (LocalODE.power x.val n) (LocalODE.power y.val n)) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := LocalODE.power_valid _ (mul_valid x.property y.property) n)
    (hright := mul_valid (LocalODE.power_valid _ x.property n) (LocalODE.power_valid _ y.property n))
  change ComplexRawQuotient.ofRaw (LocalODE.power (mul x.val y.val) n) _ =
    ComplexRawQuotient.ofRaw (LocalODE.power x.val n) (LocalODE.power_valid _ x.property n) *
    ComplexRawQuotient.ofRaw (LocalODE.power y.val n) (LocalODE.power_valid _ y.property n)
  rw [ExponentialDiagonal.power_class _ (mul_valid x.property y.property) n,
    ExponentialDiagonal.power_class x.val x.property n,
    ExponentialDiagonal.power_class y.val y.property n]
  change (ComplexRawQuotient.ofRaw x.val x.property * ComplexRawQuotient.ofRaw y.val y.property)^n = _
  induction n with
  | zero => change (1 : ScalarAlgebra.Value)=1*1; grind
  | succ n ih =>
    change ((ComplexRawQuotient.ofRaw x.val x.property * ComplexRawQuotient.ofRaw y.val y.property)^n)*
      (ComplexRawQuotient.ofRaw x.val x.property * ComplexRawQuotient.ofRaw y.val y.property) =
      ((ComplexRawQuotient.ofRaw x.val x.property)^n * ComplexRawQuotient.ofRaw x.val x.property) *
      ((ComplexRawQuotient.ofRaw y.val y.property)^n * ComplexRawQuotient.ofRaw y.val y.property)
    rw [ih]
    grind

def automorphyWeight (k : Nat) (g : SL2Z) (z : Scalar) : Scalar :=
  ⟨LocalODE.power (automorphyFactor g z).val k,
    LocalODE.power_valid _ (automorphyFactor g z).property k⟩

theorem represented_power_add (x : Scalar) (k l : Nat) :
    (LocalODE.power x.val (k+l)).Equiv
      (mul (LocalODE.power x.val k) (LocalODE.power x.val l)) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := LocalODE.power_valid _ x.property (k+l))
    (hright := mul_valid (LocalODE.power_valid _ x.property k) (LocalODE.power_valid _ x.property l))
  change ComplexRawQuotient.ofRaw (LocalODE.power x.val (k+l)) _ =
    ComplexRawQuotient.ofRaw (LocalODE.power x.val k) (LocalODE.power_valid _ x.property k) *
    ComplexRawQuotient.ofRaw (LocalODE.power x.val l) (LocalODE.power_valid _ x.property l)
  rw [ExponentialDiagonal.power_class x.val x.property (k+l),
    ExponentialDiagonal.power_class x.val x.property k,
    ExponentialDiagonal.power_class x.val x.property l]
  induction l with
  | zero => change _ = _ * (1 : ScalarAlgebra.Value); grind
  | succ l ih =>
    rw [Nat.add_succ]
    change (ComplexRawQuotient.ofRaw x.val x.property)^(k+l) * ComplexRawQuotient.ofRaw x.val x.property =
      (ComplexRawQuotient.ofRaw x.val x.property)^k *
        ((ComplexRawQuotient.ofRaw x.val x.property)^l * ComplexRawQuotient.ofRaw x.val x.property)
    rw [ih]
    grind

theorem automorphyWeight_add (k l : Nat) (g : SL2Z) (z : Scalar) :
    (automorphyWeight (k+l) g z).val.Equiv
      (mul (automorphyWeight k g z).val (automorphyWeight l g z).val) :=
  represented_power_add (automorphyFactor g z) k l

theorem automorphyWeight_cocycle (k : Nat) (g h : SL2Z) (z : Scalar)
    (hz : InUpperHalfPlane z.val) :
    (automorphyWeight k (SL2Z.multiply g h) z).val.Equiv
      (mul (automorphyWeight k g (fractionalLinear h z hz)).val (automorphyWeight k h z).val) := by
  let a := automorphyFactor g (fractionalLinear h z hz)
  let b := automorphyFactor h z
  let p : Scalar := ⟨mul a.val b.val,mul_valid a.property b.property⟩
  exact equiv_trans (automorphyWeight k (SL2Z.multiply g h) z).property
    (LocalODE.power_valid _ p.property k)
    (mul_valid (automorphyWeight k g (fractionalLinear h z hz)).property
      (automorphyWeight k h z).property)
    (represented_power_congr (automorphyFactor (SL2Z.multiply g h) z) p
      (automorphyFactor_cocycle g h z hz) k)
    (represented_power_product a b k)

end ComputableAnalysis.ModularForms
