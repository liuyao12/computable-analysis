import ComputableAnalysis.ModularForms.Hecke41Holomorphic
import ComputableAnalysis.FTA.RootPolynomialBounds
import ComputableAnalysis.ModularForms.LatticeJSizeBound
import ComputableAnalysis.RiemannHilbert.DomainHolomorphicSums

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
open RepresentedPolynomial

/-- Constructed holomorphic maps on the actual common correspondence domain. -/
structure Hecke41HolomorphicFunction where
  map : DomainFunctions.Map
  domain_eq : map.domain = hecke41CommonDomain
  holomorphic : Holomorphic map

namespace Hecke41HolomorphicFunction

def value (f : Hecke41HolomorphicFunction) (z : Scalar) (hz : hecke41CommonDomain z) : Scalar :=
  f.map.eval z (by rw [f.domain_eq]; exact hz)

def constant (c : ComplexCert) : Hecke41HolomorphicFunction :=
  ⟨constantOn hecke41CommonDomain hecke41CommonDomain_openData.invariant ⟨c.raw,c.valid⟩,
    rfl,constantOn_holomorphic hecke41CommonDomain_openData ⟨c.raw,c.valid⟩⟩

def j (i : Fin 42) : Hecke41HolomorphicFunction :=
  ⟨hecke41CommonJMap i,rfl,hecke41CommonJMap_holomorphic i⟩

private theorem domain_imp (f g : Hecke41HolomorphicFunction) : ∀ z, f.map.domain z → g.map.domain z := by
  rw [f.domain_eq,g.domain_eq]
  exact fun _ h => h

def add (f g : Hecke41HolomorphicFunction) : Hecke41HolomorphicFunction :=
  ⟨sumOn f.map g.map (domain_imp f g),f.domain_eq,
    f.holomorphic.sumOn g.holomorphic (domain_imp f g)⟩

def mul (f g : Hecke41HolomorphicFunction) : Hecke41HolomorphicFunction :=
  ⟨productOn f.map g.map (domain_imp f g),f.domain_eq,
    f.holomorphic.productOn g.holomorphic (domain_imp f g)⟩

def neg (f : Hecke41HolomorphicFunction) : Hecke41HolomorphicFunction :=
  ⟨negate f.map,f.domain_eq,f.holomorphic.negate⟩

end Hecke41HolomorphicFunction

/-- Holomorphic coefficient functions for any supplied list of actual Hecke indices. -/
def hecke41CoefficientFunction : List (Fin 42) → Nat → Hecke41HolomorphicFunction
  | [], 0 => .constant one
  | [], _+1 => .constant RepresentedPolynomial.zero
  | i::is, 0 => .mul (.neg (.j i)) (hecke41CoefficientFunction is 0)
  | i::is, k+1 => .add (.mul (.neg (.j i)) (hecke41CoefficientFunction is (k+1)))
      (hecke41CoefficientFunction is k)

/-- Exact bridge from constructed holomorphic functions to the existing literal
represented polynomial coefficients, including zero coefficients beyond its degree. -/
theorem hecke41CoefficientFunction_value (is : List (Fin 42)) (k : Nat)
    (z : Scalar) (hz : hecke41CommonDomain z) :
    ((hecke41CoefficientFunction is k).value z hz).val.Equiv
      (coefficient (rootPolynomial (is.map (hecke41JCert z hz.2))) k).raw := by
  induction is generalizing k with
  | nil =>
      cases k with
      | zero => exact equiv_refl _ one.valid
      | succ k => exact equiv_refl _ RepresentedPolynomial.zero.valid
  | cons i is ih =>
      cases k with
      | zero =>
          refine equiv_trans ((hecke41CoefficientFunction (i::is) 0).value z hz).property
            (RepresentedPolynomial.mul (RepresentedPolynomial.neg (hecke41JCert z hz.2 i))
              (coefficient (rootPolynomial (is.map (hecke41JCert z hz.2))) 0)).valid
            (coefficient (rootPolynomial ((i::is).map (hecke41JCert z hz.2))) 0).valid
            ?_ (equiv_symm (coefficient_linearMultiply_zero _ _))
          exact mul_equiv (neg_valid ((hecke41CommonJMap i).eval z hz).property)
            (neg_valid (hecke41JCert z hz.2 i).valid)
            ((hecke41CoefficientFunction is 0).value z hz).property
            (coefficient (rootPolynomial (is.map (hecke41JCert z hz.2))) 0).valid
            (neg_equiv (hecke41CommonJMap_eval i z hz)) (ih 0)
      | succ k =>
          refine equiv_trans ((hecke41CoefficientFunction (i::is) (k+1)).value z hz).property
            (RepresentedPolynomial.add (RepresentedPolynomial.mul (RepresentedPolynomial.neg (hecke41JCert z hz.2 i))
              (coefficient (rootPolynomial (is.map (hecke41JCert z hz.2))) (k+1)))
              (coefficient (rootPolynomial (is.map (hecke41JCert z hz.2))) k)).valid
            (coefficient (rootPolynomial ((i::is).map (hecke41JCert z hz.2))) (k+1)).valid
            ?_ (equiv_symm (coefficient_linearMultiply_succ _ _ k))
          exact add_equiv (mul_equiv (neg_valid ((hecke41CommonJMap i).eval z hz).property)
            (neg_valid (hecke41JCert z hz.2 i).valid)
            ((hecke41CoefficientFunction is (k+1)).value z hz).property
            (coefficient (rootPolynomial (is.map (hecke41JCert z hz.2))) (k+1)).valid
            (neg_equiv (hecke41CommonJMap_eval i z hz)) (ih (k+1))) (ih k)

/-- All coefficient functions of the actual correspondence polynomial. -/
def hecke41PolynomialCoefficient (k : Nat) : Hecke41HolomorphicFunction :=
  hecke41CoefficientFunction (List.ofFn (fun i : Fin 42 => i)) k

theorem hecke41PolynomialCoefficient_value (k : Nat) (z : Scalar) (hz : hecke41CommonDomain z) :
    ((hecke41PolynomialCoefficient k).value z hz).val.Equiv
      (coefficient (hecke41RootPolynomial z hz.2) k).raw := by
  have h := hecke41CoefficientFunction_value (List.ofFn (fun i : Fin 42 => i)) k z hz
  simpa [List.map_ofFn,Function.comp_def,hecke41RootPolynomial,hecke41PolynomialCoefficient] using h

/-- The common analytic domain is preserved by every modular matrix. -/
theorem hecke41CommonDomain_modular (g : SL2Z) (z : Scalar) (hz : hecke41CommonDomain z) :
    hecke41CommonDomain (fractionalLinear g z hz.1) :=
  ⟨fractionalLinear_mem g z hz.1, hecke41RootPolynomial_modular_domain g z hz.1 hz.2⟩

/-- The actual holomorphic coefficient functions are modular invariant. -/
theorem hecke41PolynomialCoefficient_modular (k : Nat) (g : SL2Z) (z : Scalar)
    (hz : hecke41CommonDomain z) :
    ((hecke41PolynomialCoefficient k).value (fractionalLinear g z hz.1)
      (hecke41CommonDomain_modular g z hz)).val.Equiv
      ((hecke41PolynomialCoefficient k).value z hz).val := by
  have h₁ := hecke41PolynomialCoefficient_value k (fractionalLinear g z hz.1)
    (hecke41CommonDomain_modular g z hz)
  have h₂ := coefficient_equiv (hecke41RootPolynomial_modular_coefficients g z hz.1 hz.2) k
  have h₃ := hecke41PolynomialCoefficient_value k z hz
  exact equiv_trans ((hecke41PolynomialCoefficient k).value (fractionalLinear g z hz.1)
    (hecke41CommonDomain_modular g z hz)).property
    (coefficient (hecke41RootPolynomial (fractionalLinear g z hz.1)
      (hecke41RootPolynomial_modular_domain g z hz.1 hz.2)) k).valid
    ((hecke41PolynomialCoefficient k).value z hz).property h₁
    (equiv_trans (coefficient (hecke41RootPolynomial (fractionalLinear g z hz.1)
      (hecke41RootPolynomial_modular_domain g z hz.1 hz.2)) k).valid
      (coefficient (hecke41RootPolynomial z hz.2) k).valid
      ((hecke41PolynomialCoefficient k).value z hz).property h₂ (equiv_symm h₃))

/-- Quantitative coefficient control from bounds on the actual correspondence j values. -/
theorem hecke41PolynomialCoefficient_small (k : Nat) (z : Scalar) (hz : hecke41CommonDomain z)
    (B : Rat) (hB : 0 ≤ B) (hj : ∀ i, Small (hecke41JCert z hz.2 i).raw B) :
    Small ((hecke41PolynomialCoefficient k).value z hz).val ((1+2*B)^42) := by
  have hr : ∀ r ∈ List.ofFn (hecke41JCert z hz.2), Small r.raw B := by
    intro r hm
    obtain ⟨i, hi⟩ := List.mem_ofFn.mp hm
    subst r
    exact hj i
  have hb := rootPolynomial_coefficient_small (List.ofFn (hecke41JCert z hz.2)) B hB hr k
  simp only [List.length_ofFn] at hb
  exact Small.congr (coefficient (hecke41RootPolynomial z hz.2) k).valid
    ((hecke41PolynomialCoefficient k).value z hz).property
    (equiv_symm (hecke41PolynomialCoefficient_value k z hz)) hb

/-- Coefficient control directly from actual nome and nome reciprocal bounds. -/
theorem hecke41PolynomialCoefficient_nome_bound (k : Nat) (z : Scalar) (hz : hecke41CommonDomain z)
    (r B : Rat) (hr : 0≤r) (hg : 128*r≤(1:Rat)/2) (hs : r≤(1:Rat)/65536) (hB : 0≤B)
    (hq : ∀ i, Small (nome.eval (hecke41Point i z) (hz.2 i).1).val r)
    (hu : ∀ i, Small (RepresentedReciprocal.inverse
      (nome.eval (hecke41Point i z) (hz.2 i).1)
      (nome_nonzero (hecke41Point i z) (hz.2 i).1)).val B)
    (hguard : 440*r*r*B≤(1:Rat)/8) :
    Small ((hecke41PolynomialCoefficient k).value z hz).val
      ((1+2*(B+744+512000000*r*r*r*B*B))^42) := by
  have hE : 0≤512000000*r*r*r*B*B :=
    Rat.mul_nonneg (Rat.mul_nonneg (Rat.mul_nonneg (Rat.mul_nonneg
      (Rat.mul_nonneg (by decide +kernel) hr) hr) hr) hB) hB
  apply hecke41PolynomialCoefficient_small k z hz _ (by grind)
  intro i
  exact latticeJMap_size_bound (hecke41Point i z) (hz.2 i) r B hr hg (hq i) hs hB (hu i) hguard

end ComputableAnalysis.ModularForms
