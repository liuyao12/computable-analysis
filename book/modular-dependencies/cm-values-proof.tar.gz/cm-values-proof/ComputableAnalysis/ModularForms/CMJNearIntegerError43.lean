import ComputableAnalysis.ModularForms.CMJLinearLaurentEstimate43

/-! Magnitude and sign of the actual CM j error, without assuming the CM integer identity. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

private def linearError : Scalar :=
  let q := nome.eval cmScalar43 cmPoint43_upper
  let u := RepresentedReciprocal.inverse q (nome_nonzero cmScalar43 cmPoint43_upper)
  ⟨sub cmJValue43.val (add (add u.val (ofQComplex ⟨744,0⟩)) (scaleRat 196884 q.val)),
    sub_valid cmJValue43.property (add_valid (add_valid u.property (ofQComplex_valid _))
      (scaleRat_valid q.property))⟩

private theorem cancellation (J U K L : ScalarAlgebra.Value) :
    (J-((U+K)+L))+L=J-(U+K) := by grind only

private theorem error_decomposition :
    (add linearError.val (scaleRat 196884 (nome.eval cmScalar43 cmPoint43_upper).val)).Equiv
      cmJGrowthError43.val := by
  let q := nome.eval cmScalar43 cmPoint43_upper
  let u := RepresentedReciprocal.inverse q (nome_nonzero cmScalar43 cmPoint43_upper)
  have hc : (add linearError.val (scaleRat 196884 q.val)).Equiv
      (sub cmJValue43.val (add u.val (ofQComplex ⟨744,0⟩))) := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := add_valid linearError.property (scaleRat_valid q.property))
      (hright := sub_valid cmJValue43.property (add_valid u.property (ofQComplex_valid _)))
    let J := ComplexRawQuotient.ofRaw cmJValue43.val cmJValue43.property
    let U := ComplexRawQuotient.ofRaw u.val u.property
    let K := ComplexRawQuotient.ofQComplex ⟨744,0⟩
    let L := ComplexRawQuotient.scaleRat 196884 (ComplexRawQuotient.ofRaw q.val q.property)
    change (J-((U+K)+L))+L=J-(U+K)
    exact cancellation J U K L
  have hn := FunctionTheory.sub_congr (equiv_refl cmJValue43.val cmJValue43.property)
    (ComplexRaw.add_equiv cmNomeInverse43_growth (equiv_refl _ (ofQComplex_valid ⟨744,0⟩)))
  exact equiv_trans (add_valid linearError.property (scaleRat_valid q.property))
    (sub_valid cmJValue43.property (add_valid u.property (ofQComplex_valid _)))
    cmJGrowthError43.property hc hn

/-- The actual CM j versus growth error is below the desired three ten-thousandths. -/
theorem cmJGrowthError43_small_sharp : Small cmJGrowthError43.val (3/10000) := by
  have h := LocalODE.small_add cmJValue43_linear_laurent_bound
    (LocalODE.small_scale (show (0:Rat)≤196884 by decide +kernel) nome_cm43_small)
  have hb := Small.congr
    (add_valid linearError.property (scaleRat_valid (nome.eval cmScalar43 cmPoint43_upper).property))
    cmJGrowthError43.property error_decomposition h
  exact hb.mono (by decide +kernel)

/-- The actual CM nome magnitude is separated from zero using the checked growth upper bound. -/
theorem cmNomeMagnitude43_lower_sharp :
    (RealRaw.ofRat (1/(1400000000:Rat))).Le cmNomeMagnitude43 := by
  intro n m
  have hx := cmGrowthValue43_upper m 0
  change (cmGrowthValue43.compute m).lo≤(1400000000:Rat) at hx
  have hm : maxRat2 (cmGrowthValue43.compute m).lo 750000000≤(1400000000:Rat) := by
    unfold maxRat2
    split
    · exact (show (750000000:Rat)≤(1400000000:Rat) by decide +kernel)
    · exact hx
  have hp : 0<maxRat2 (cmGrowthValue43.compute m).lo 750000000 := by
    unfold maxRat2
    split <;> grind only
  have h := RealRaw.one_div_antitone_of_pos hp hm
  change (1/(1400000000:Rat))≤((RealRaw.positiveReciprocal cmGrowthValue43 750000000).compute m).hi
  rw [RealRaw.positiveReciprocal_compute cmGrowthValue43 750000000 (by decide +kernel) m]
  exact h

/-- The actual CM nome has a negative real part bounded away from zero. -/
theorem nome_cm43_real_upper_negative :
    (nome.eval cmScalar43 cmPoint43_upper).val.realPart.Le
      (RealRaw.ofRat (-(1/(1400000000:Rat)))) := by
  have he := realPart_equiv nome_cm43_reciprocal
  have hn : (neg (ofRealRaw cmNomeMagnitude43)).realPart.Le
      (RealRaw.ofRat (-(1/(1400000000:Rat)))) := by
    intro n m
    have h := cmNomeMagnitude43_lower_sharp 0 n
    change (1/(1400000000:Rat))≤(cmNomeMagnitude43.compute n).hi at h
    change -(cmNomeMagnitude43.compute n).hi≤ -(1/(1400000000:Rat))
    grind only
  exact RealRaw.le_trans (realPart_valid (neg_valid (ofRealRaw_valid _ cmNomeMagnitude43_valid)))
    (RealRaw.le_of_equiv (realPart_valid (nome.eval cmScalar43 cmPoint43_upper).property)
      (realPart_valid (neg_valid (ofRealRaw_valid _ cmNomeMagnitude43_valid))) he) hn

/-- The actual CM j versus growth error has a strictly negative real part. -/
theorem cmJGrowthError43_real_upper_negative :
    cmJGrowthError43.val.realPart.Le (RealRaw.ofRat (-1/10000)) := by
  let q := nome.eval cmScalar43 cmPoint43_upper
  let s : Scalar := ⟨add linearError.val (scaleRat 196884 q.val),
    add_valid linearError.property (scaleRat_valid q.property)⟩
  have hs : s.val.realPart.Le (RealRaw.ofRat (-1/10000)) := by
    intro n m
    have he := cmJValue43_linear_laurent_bound.2.1 n 0
    change (linearError.val.compute n).lo.re≤(1/1000000:Rat) at he
    have hq := nome_cm43_real_upper_negative n 0
    change (q.val.compute n).lo.re≤ -(1/(1400000000:Rat)) at hq
    have hm := Rat.mul_le_mul_of_nonneg_left hq (show (0:Rat)≤196884 by decide +kernel)
    have hc : (1/1000000:Rat)+196884* (-(1/(1400000000:Rat)))≤ -1/10000 := by decide +kernel
    change (linearError.val.compute n).lo.re+196884*(q.val.compute n).lo.re≤(-1/10000:Rat)
    grind only
  have hi := RealRaw.le_of_equiv (realPart_valid cmJGrowthError43.property) (realPart_valid s.property)
    (realPart_equiv (equiv_symm error_decomposition))
  exact RealRaw.le_trans (realPart_valid s.property) hi hs

/-- The positive real deficit relative to the actual CM j value. -/
def cmJGrowthDeficit43 : RealRaw := RealRaw.neg cmJGrowthError43.val.realPart

theorem cmJGrowthDeficit43_valid : cmJGrowthDeficit43.Valid :=
  RealRaw.neg_valid (realPart_valid cmJGrowthError43.property)

/-- A positive lower bound for the actual CM j growth deficit. -/
theorem cmJGrowthDeficit43_lower :
    (RealRaw.ofRat (1/10000)).Le cmJGrowthDeficit43 := by
  intro n m
  have h := cmJGrowthError43_real_upper_negative m 0
  change (cmJGrowthError43.val.compute m).lo.re≤(-1/10000:Rat) at h
  change (1/10000:Rat)≤ -(cmJGrowthError43.val.compute m).lo.re
  grind only

/-- The actual CM j growth deficit is at most three ten-thousandths. -/
theorem cmJGrowthDeficit43_upper :
    cmJGrowthDeficit43.Le (RealRaw.ofRat (3/10000)) := by
  intro n m
  have h := cmJGrowthError43_small_sharp.1 0 n
  change -(3/10000:Rat)≤(cmJGrowthError43.val.compute n).hi.re at h
  change -(cmJGrowthError43.val.compute n).hi.re≤(3/10000:Rat)
  grind only

/-- Strict positivity follows from the constructed positive lower bound and convergence. -/
theorem cmJGrowthDeficit43_positive : cmJGrowthDeficit43.Pos := by
  obtain ⟨N,hN⟩ := cmJGrowthDeficit43_valid.2.2 (⟨1/100000,by decide +kernel⟩ : QPos)
  have hw := hN N (Nat.le_refl N)
  have hl := cmJGrowthDeficit43_lower 0 N
  change (1/10000:Rat)≤(cmJGrowthDeficit43.compute N).hi at hl
  unfold QInterval.width at hw
  refine ⟨N,?_⟩
  change 0<(cmJGrowthDeficit43.compute N).lo
  grind only

/-- The represented deficit from the integer occurring in the discriminant-43 example. -/
def cmIntegerGrowthDeficit43 : RealRaw :=
  RealRaw.add (RealRaw.ofRat 884736744) (RealRaw.neg cmGrowthValue43)

theorem cmIntegerGrowthDeficit43_valid : cmIntegerGrowthDeficit43.Valid :=
  RealRaw.add_valid (RealRaw.ofRat_valid _) (RealRaw.neg_valid (realPart_valid (entireExponentialValue cmGrowthExponent43).property))

/-- The CM value identity, when proved, identifies the actual j deficit with the integer deficit. -/
theorem cmIntegerGrowthDeficit43_agreement_of_cm_value
    (hcm : cmJValue43.val.Equiv (ofQComplex ⟨-((960:Rat)^3),0⟩)) :
    cmJGrowthDeficit43.Equiv cmIntegerGrowthDeficit43 := by
  let t : Scalar := ⟨add (neg (entireExponentialValue cmGrowthExponent43).val) (ofQComplex ⟨744,0⟩),
    add_valid (neg_valid (entireExponentialValue cmGrowthExponent43).property) (ofQComplex_valid _)⟩
  have he := RealRaw.neg_equiv (realPart_equiv
    (FunctionTheory.sub_congr hcm (equiv_refl t.val t.property)))
  have hc : (RealRaw.neg (sub (ofQComplex ⟨-((960:Rat)^3),0⟩) t.val).realPart).Equiv
      cmIntegerGrowthDeficit43 := by
    intro n
    apply (RealRaw.compareAt_overlap_iff _ _ n n).mpr
    have ho := RealRaw.interval_order_of_valid cmGrowthValue43
      (realPart_valid (entireExponentialValue cmGrowthExponent43).property) n
    have hk : -(-((960:Rat)^3))+744=884736744 := by decide +kernel
    change (-( -((960:Rat)^3)+ -(-(cmGrowthValue43.compute n).hi+744))≤
        884736744+ -(cmGrowthValue43.compute n).lo) ∧
      (884736744+ -(cmGrowthValue43.compute n).hi≤
        -( -((960:Rat)^3)+ -(-(cmGrowthValue43.compute n).lo+744)))
    constructor <;> grind only
  exact RealRaw.equiv_trans cmJGrowthDeficit43_valid
    (RealRaw.neg_valid (realPart_valid (sub_valid (ofQComplex_valid _) t.property)))
    cmIntegerGrowthDeficit43_valid he hc

/-- The proved analytic estimates imply the number-theoretic deficit bounds once the exact CM value is established. -/
theorem cmIntegerGrowthDeficit43_bounds_of_cm_value
    (hcm : cmJValue43.val.Equiv (ofQComplex ⟨-((960:Rat)^3),0⟩)) :
    (RealRaw.ofRat (1/10000)).Le cmIntegerGrowthDeficit43 ∧
      cmIntegerGrowthDeficit43.Le (RealRaw.ofRat (3/10000)) := by
  have he := cmIntegerGrowthDeficit43_agreement_of_cm_value hcm
  constructor
  · exact RealRaw.le_trans cmJGrowthDeficit43_valid cmJGrowthDeficit43_lower
      (RealRaw.le_of_equiv cmJGrowthDeficit43_valid cmIntegerGrowthDeficit43_valid he)
  · exact RealRaw.le_trans cmJGrowthDeficit43_valid
      (RealRaw.le_of_equiv cmIntegerGrowthDeficit43_valid cmJGrowthDeficit43_valid (RealRaw.equiv_symm he))
      cmJGrowthDeficit43_upper

end ComputableAnalysis.ModularForms
