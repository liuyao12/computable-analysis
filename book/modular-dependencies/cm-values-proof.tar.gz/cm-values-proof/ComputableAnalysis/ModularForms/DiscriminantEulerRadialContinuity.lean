import ComputableAnalysis.ModularForms.PositiveRadialScale
import ComputableAnalysis.ModularForms.UnitIntervalRationalBound
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- Actual divided-discrepancy values on the full represented positive radial segment. -/
def discriminantEulerRadialValues (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R a b : Rat) (hR : 0≤R) (ha : 0<a) (hab : a≤b) (hqr : Small q.val R)
    (hs : b*R≤(1:Rat)/65536) (u : UnitInterval.Point) : Scalar :=
  discriminantEulerDividedMap.eval
    (RepresentedAffineSegment.point (rationalScaledScalar a q) (rationalScaledScalar b q) u)
    (representedRadialSegment_puncturedDomain q hq R a b hR ha hab hqr hs u)
/-- Quantitative continuity of the actual radial values at every represented parameter. -/
noncomputable def discriminantEulerRadialValues_continuous (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R a b : Rat) (hR : 0≤R) (ha : 0<a) (hab : a≤b) (hqr : Small q.val R)
    (hs : b*R≤(1:Rat)/65536) :
    UnitInterval.ScalarContinuousData (discriminantEulerRadialValues q hq R a b hR ha hab hqr hs) := by
  let p := rationalScaledScalar a q
  let z := rationalScaledScalar b q
  let F := DomainFunctions.compose discriminantEulerDividedMap (RepresentedAffineSegment.function p z)
  let hF := discriminantEulerDividedMap_holomorphic.compose
    (DomainFunctions.affine_holomorphic p (Centered.offset p z))
  have hm (u : UnitInterval.Point) : F.domain (UnitInterval.scalar u) :=
    ⟨trivial,representedRadialSegment_puncturedDomain q hq R a b hR ha hab hqr hs u⟩
  exact UnitInterval.ofDomainContinuous F hF.continuous hm
/-- Uniform rational parameter bounds control the actual whole radial segment. -/
theorem discriminantEulerRadialValues_bound_of_rational (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R a b : Rat) (hR : 0≤R) (ha : 0<a) (hab : a≤b) (hqr : Small q.val R)
    (hs : b*R≤(1:Rat)/65536) (B : Rat)
    (hb : ∀ r h0 h1, Small (discriminantEulerRadialValues q hq R a b hR ha hab hqr hs
      (UnitInterval.rational r h0 h1)).val B) :
    ∀ u, Small (discriminantEulerRadialValues q hq R a b hR ha hab hqr hs u).val B :=
  unitInterval_bound_of_rational _ (discriminantEulerRadialValues_continuous q hq R a b hR ha hab hqr hs) B hb
/-- Concrete uniform bound on all represented parameters, independent of the left anchor scale. -/
theorem discriminantEulerRadialValues_bound (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R S a b : Rat) (hR : 0≤R) (hS : 0≤S) (ha : 0<a) (hab : a≤b) (hqr : Small q.val R)
    (hi : Small (RepresentedReciprocal.inverse q hq).val S) (hs : b*R≤(1:Rat)/65536) :
    ∀ u, Small (discriminantEulerRadialValues q hq R a b hR ha hab hqr hs u).val (21072*S*R*R*b) := by
  apply discriminantEulerRadialValues_bound_of_rational
  intro r h0 h1
  have hc0 : 0<a+(b-a)*r := by
    have hh := Rat.mul_nonneg (show 0≤b-a by grind only) h0
    grind only
  have hc1 : a+(b-a)*r≤b := by
    have hh := Rat.mul_le_mul_of_nonneg_left h1 (show 0≤b-a by grind only)
    grind only
  have hcs := Rat.le_trans (Rat.mul_le_mul_of_nonneg_right hc1 hR) hs
  let c := a+(b-a)*r
  have he := equiv_trans
    (RepresentedAffineSegment.point (rationalScaledScalar a q) (rationalScaledScalar b q) (UnitInterval.rational r h0 h1)).property
    (AffineSegment.point (rationalScaledScalar a q) (rationalScaledScalar b q) r).property
    (rationalScaledScalar c q).property
    (RepresentedAffineSegment.rational_agreement _ _ r h0 h1) (rationalRadialSegment_point q a b r)
  let hc : discriminantEulerDividedMap.domain (rationalScaledScalar c q) :=
    ⟨rationalScaledScalar_nonzero c (Rat.ne_of_gt hc0) q hq,
      rationalScaledScalar_nomeDomain q R c hR (Rat.le_of_lt hc0) hqr hcs⟩
  have hv := discriminantEulerDividedMap.eval_congr _ _
    (representedRadialSegment_puncturedDomain q hq R a b hR ha hab hqr hs _) hc he
  have hb := discriminantEulerDividedMap_radial_decay q hq R S c hR hS hc0 hqr hi hcs
  have hh := Small.congr (discriminantEulerDividedMap.eval (rationalScaledScalar c q) hc).property
    (discriminantEulerRadialValues q hq R a b hR ha hab hqr hs (UnitInterval.rational r h0 h1)).property
    (equiv_symm hv) hb
  apply hh.mono
  exact Rat.mul_le_mul_of_nonneg_left hc1
    (Rat.mul_nonneg (Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hS) hR) hR)
end ComputableAnalysis.ModularForms
