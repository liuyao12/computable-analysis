import ComputableAnalysis.ModularForms.CommonOuterHalfEdgeConcatenation
import ComputableAnalysis.ModularForms.SquareFrameWeightedSides
import ComputableAnalysis.ModularForms.Hecke41KernelFrameTiles

/-! Outer Cartesian bottom-edge samples for an arbitrary supplied density. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem common_outer_bottom_sample (f : QComplex → Scalar) (R : QPos)
    (M k v : Nat) (hM : 0<M) :
    (rectangleGridHorizontal f (squareFrameTile R k 0) M v 0).val.Equiv
      (scaleRat (1/(2*(M:Rat)))
        (commonSquareEdgeDensity f ⟨.south,true⟩ (squareFrameOuterRadius R)
          (((k:Rat)-2+squareMidpointParameter M v)/2)).val) := by
  unfold rectangleGridHorizontal
  rw [squareFrame_outer_bottom_point R M k v hM,(squareFrameTile_grid_steps R M k 0).1]
  change (scalarProduct (f (cartesianSquarePoint ⟨.south,true⟩ (2*R.val)
    (((k:Rat)-2+squareMidpointParameter M v)/2)))
    (rationalRectangleScalar ⟨R.val/(M:Rat),0⟩)).val.Equiv _
  rw [cartesianSquarePoint_agreement]
  have hw : (⟨R.val/(M:Rat),0⟩ : QComplex)=
      QComplex.scaleRat (1/(2*(M:Rat)))
        (QComplex.scaleRat (2*R.val) (velocity ⟨.south,true⟩)) := by
    simp only [velocity,rotation,orientation,↓reduceIte,QComplex.mul,QComplex.scaleRat,
      QComplex.mk.injEq,Rat.div_def,Rat.inv_mul_rev]
    constructor <;> grind only
  rw [hw]
  exact rationalWeightedSample_scale _ _ _

theorem common_outer_bottom_tile_average (f : QComplex → Scalar) (R : QPos)
    (M k : Nat) (hM : 0<M) :
    (squareFrameHorizontalEdge f R M k 0).val.Equiv
      (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.south,true⟩
        (squareFrameOuterRadius R) (((k:Rat)-2+u)/2)) M (1/(2*(M:Rat)))).val := by
  let density := fun v => commonSquareEdgeDensity f ⟨.south,true⟩
    (squareFrameOuterRadius R) (((k:Rat)-2+squareMidpointParameter M v)/2)
  let weighted := fun v => (⟨scaleRat (1/(2*(M:Rat))) (density v).val,
    scaleRat_valid (density v).property⟩ : Scalar)
  have hs : ∀ v, (rectangleGridHorizontal f (squareFrameTile R k 0) M v 0).val.Equiv
      (weighted v).val := by
    intro v
    exact common_outer_bottom_sample f R M k v hM
  exact equiv_trans (squareFrameHorizontalEdge f R M k 0).property
    (gridScalarSum M weighted).property
    (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.south,true⟩
      (squareFrameOuterRadius R) (((k:Rat)-2+u)/2)) M (1/(2*(M:Rat)))).property
    (gridScalarSum_congr M _ weighted hs)
    (gridScalarSum_scale (1/(2*(M:Rat))) density M)

theorem common_outer_bottom_upper_average (f : QComplex → Scalar) (R : QPos)
    (M : Nat) (hM : 0<M) :
    (scalarSum (squareFrameHorizontalEdge f R M 2 0)
      (squareFrameHorizontalEdge f R M 3 0)).val.Equiv
      (commonSquareKernelAverage f ⟨.south,true⟩ (squareFrameOuterRadius R) (2*M)).val := by
  have h0 := common_outer_bottom_tile_average f R M 2 hM
  have h1 := common_outer_bottom_tile_average f R M 3 hM
  have p0 (u : Rat) : (((2:Nat):Rat)-2+u)/2=u/2 := by
    change (2-2+u)/2=u/2
    grind only
  have p1 (u : Rat) : (((3:Nat):Rat)-2+u)/2=(1+u)/2 := by
    change (3-2+u)/2=(1+u)/2
    grind only
  have hr : 1/(2*(M:Rat))=1/((2*M:Nat):Rat) := by
    rw [Rat.natCast_mul]
    rfl
  simp only [p0,hr] at h0
  simp only [p1,hr] at h1
  exact equiv_trans (scalarSum (squareFrameHorizontalEdge f R M 2 0)
    (squareFrameHorizontalEdge f R M 3 0)).property
    (scalarSum
      (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.south,true⟩
        (squareFrameOuterRadius R) (u/2)) M (1/((2*M:Nat):Rat)))
      (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.south,true⟩
        (squareFrameOuterRadius R) ((1+u)/2)) M (1/((2*M:Nat):Rat)))).property
    (commonSquareKernelAverage f ⟨.south,true⟩ (squareFrameOuterRadius R) (2*M)).property
    (add_equiv h0 h1)
    (commonSquareKernelAverage_midpoint_split f ⟨.south,true⟩ (squareFrameOuterRadius R) M hM)

end ComputableAnalysis.ModularForms
