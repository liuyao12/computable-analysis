import ComputableAnalysis.ModularForms.CMGrowthBounds43
import ComputableAnalysis.ModularForms.RealExponentialPositiveGapOrder
import ComputableAnalysis.ModularForms.RationalExponentialPowerBounds

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory ComplexExponentialApproximation DomainFunctions

/-- A kernel-checked finite power-series box proves the actual lower bound at 41/20. -/
theorem entireExponential_rational_twentyOneFortieth_lower :
    (RealRaw.ofRat (31/4)).Le
      (entireExponentialValue ⟨ofQComplex ⟨41/20,0⟩,ofQComplex_valid _⟩).val.realPart := by
  let f := exponentialRawAt ⟨41/20,0⟩ 3
  have hz : QComplex.normBound (⟨41/20,0⟩ : QComplex)≤(3:Rat) := by decide +kernel
  have hf : f.Valid := exponentialRawAt_valid (by decide +kernel) hz
  have hbox : (31/4:Rat)≤(f.compute 6).lo.re := by decide +kernel
  have hl : (RealRaw.ofRat (31/4)).Le f.realPart := by
    intro n m
    have h := RealRaw.le_refl f.realPart (realPart_valid hf) 6 m
    change (31/4:Rat)≤(f.compute m).hi.re
    exact Rat.le_trans hbox h
  have he := ComplexRaw.realPart_equiv (entireExponential_legacy_rational ⟨41/20,0⟩ 3 (by decide +kernel) hz)
  exact RealRaw.le_trans (realPart_valid hf) hl
    (RealRaw.le_of_equiv (realPart_valid hf) (realPart_valid (entireExponentialValue _).property)
      (RealRaw.equiv_symm he))

/-- A kernel-checked finite power-series box proves the actual upper bound at 21/10. -/
theorem entireExponential_rational_twentyOneTenths_upper :
    (entireExponentialValue ⟨ofQComplex ⟨21/10,0⟩,ofQComplex_valid _⟩).val.realPart.Le
      (RealRaw.ofRat (41/5)) := by
  let f := exponentialRawAt ⟨21/10,0⟩ 3
  have hz : QComplex.normBound (⟨21/10,0⟩ : QComplex)≤(3:Rat) := by decide +kernel
  have hf : f.Valid := exponentialRawAt_valid (by decide +kernel) hz
  have hbox : (f.compute 6).hi.re≤(41/5:Rat) := by decide +kernel
  have hl : f.realPart.Le (RealRaw.ofRat (41/5)) := by
    intro n m
    have h := RealRaw.le_refl f.realPart (realPart_valid hf) n 6
    change (f.compute n).lo.re≤41/5
    exact Rat.le_trans h hbox
  have he := ComplexRaw.realPart_equiv (entireExponential_legacy_rational ⟨21/10,0⟩ 3 (by decide +kernel) hz)
  exact RealRaw.le_trans (realPart_valid hf)
    (RealRaw.le_of_equiv (realPart_valid (entireExponentialValue _).property) (realPart_valid hf) he) hl



def cmGrowthValue43 : RealRaw := (entireExponentialValue cmGrowthExponent43).val.realPart

theorem entireExponential_rational_twentyOne_upper :
    (entireExponentialValue ⟨ofQComplex ⟨21,0⟩,ofQComplex_valid _⟩).val.realPart.Le
      (RealRaw.ofRat ((41/5:Rat)^10)) := by
  have h := entireExponential_rational_nat_power_upper (21/10) (41/5) 10
    (by decide +kernel) (by decide +kernel) entireExponential_rational_twentyOneTenths_upper
  rw [show ((10:Nat):Rat)*(21/10)=(21:Rat) by decide +kernel] at h
  exact h

theorem entireExponential_rational_twentyPointFive_lower :
    (RealRaw.ofRat ((31/4:Rat)^10)).Le
      (entireExponentialValue ⟨ofQComplex ⟨41/2,0⟩,ofQComplex_valid _⟩).val.realPart := by
  have h := entireExponential_rational_nat_power_lower (41/20) (31/4) 10
    (by decide +kernel) entireExponential_rational_twentyOneFortieth_lower
  rw [show ((10:Nat):Rat)*(41/20)=(41/2:Rat) by decide +kernel] at h
  exact h

theorem cmGrowthReal43_positive : cmGrowthReal43.Pos := by
  obtain ⟨N,hN⟩ := cmGrowthReal43_valid.2.2 (⟨1,by decide⟩ : QPos)
  have hw := hN N (Nat.le_refl N)
  have hl := cmGrowthReal43_lower_tight 0 N
  change (20567/1000:Rat)≤(cmGrowthReal43.compute N).hi at hl
  unfold QInterval.width at hw
  exact ⟨N,by change 0<(cmGrowthReal43.compute N).lo; grind only⟩

theorem cmGrowthReal43_nonnegative : (RealRaw.ofRat 0).Le cmGrowthReal43 := by
  intro n m
  have h := cmGrowthReal43_lower_tight 0 m
  change (20567/1000:Rat)≤(cmGrowthReal43.compute m).hi at h
  change (0:Rat)≤(cmGrowthReal43.compute m).hi
  grind only

def cmGrowthGapToTwentyOne43 : RealRaw := RealRaw.add (RealRaw.ofRat 21) (RealRaw.neg cmGrowthReal43)

theorem cmGrowthGapToTwentyOne43_valid : cmGrowthGapToTwentyOne43.Valid :=
  RealRaw.add_valid (RealRaw.ofRat_valid 21) (RealRaw.neg_valid cmGrowthReal43_valid)

theorem cmGrowthGapToTwentyOne43_lower_margin : (RealRaw.ofRat (1/125)).Le cmGrowthGapToTwentyOne43 := by
  intro n m
  have h := cmGrowthReal43_upper_tight m 0
  change (cmGrowthReal43.compute m).lo≤(5248/250:Rat) at h
  change (1/125:Rat)≤21+ -(cmGrowthReal43.compute m).lo
  grind only

theorem cmGrowthGapToTwentyOne43_positive : cmGrowthGapToTwentyOne43.Pos := by
  obtain ⟨N,hN⟩ := cmGrowthGapToTwentyOne43_valid.2.2 (⟨1/1000,by decide +kernel⟩ : QPos)
  have hw := hN N (Nat.le_refl N)
  have hl := cmGrowthGapToTwentyOne43_lower_margin 0 N
  change (1/125:Rat)≤(cmGrowthGapToTwentyOne43.compute N).hi at hl
  unfold QInterval.width at hw
  refine ⟨N,?_⟩
  change 0<(cmGrowthGapToTwentyOne43.compute N).lo
  grind only

private theorem real_gap_sum :
    (add (ofRealRaw cmGrowthReal43) (ofRealRaw cmGrowthGapToTwentyOne43)).Equiv (ofQComplex ⟨21,0⟩) := by
  intro n
  apply (compareAt_overlap_iff _ _ n n).mpr
  have ho := RealRaw.interval_order_of_valid _ cmGrowthReal43_valid n
  simp only [add,ofRealRaw,cmGrowthGapToTwentyOne43,RealRaw.add,RealRaw.addCompute,
    RealRaw.neg,RealRaw.negCompute,RealRaw.ofRat,QBox.add,QComplex.add,ofQComplex,QBox.point,
    QBox.Overlaps,QComplex.le_def,Rat.add_zero]
  change ((cmGrowthReal43.compute n).lo+(21+ -(cmGrowthReal43.compute n).hi)≤21 ∧ (0:Rat)≤0) ∧
    (21≤(cmGrowthReal43.compute n).hi+(21+ -(cmGrowthReal43.compute n).lo) ∧ (0:Rat)≤0)
  constructor <;> constructor <;> grind only

/-- The actual CM growth exponential is bounded above by the justified rational power. -/
theorem cmGrowthExponential43_upper_sharp_power :
    cmGrowthValue43.Le (RealRaw.ofRat ((41/5:Rat)^10)) := by
  let X : Scalar := ⟨ofRealRaw cmGrowthReal43,ofRealRaw_valid _ cmGrowthReal43_valid⟩
  let D : Scalar := ⟨ofRealRaw cmGrowthGapToTwentyOne43,ofRealRaw_valid _ cmGrowthGapToTwentyOne43_valid⟩
  have hx0 : (RealRaw.ofRat 0).Le cmGrowthReal43 := by
    intro n m
    have h := cmGrowthReal43_lower_tight 0 m
    change (20567/1000:Rat)≤(cmGrowthReal43.compute m).hi at h
    change (0:Rat)≤(cmGrowthReal43.compute m).hi
    grind only
  have hd0 : (RealRaw.ofRat 0).Le cmGrowthGapToTwentyOne43 := by
    intro n m
    have h := cmGrowthGapToTwentyOne43_lower_margin 0 m
    change (1/125:Rat)≤(cmGrowthGapToTwentyOne43.compute m).hi at h
    change (0:Rat)≤(cmGrowthGapToTwentyOne43.compute m).hi
    grind only
  have hm := entireExponential_real_positive_gap_order cmGrowthReal43 cmGrowthGapToTwentyOne43
    cmGrowthReal43_valid cmGrowthGapToTwentyOne43_valid cmGrowthReal43_positive
    cmGrowthGapToTwentyOne43_positive hx0 hd0
  have hc := ComplexRaw.realPart_equiv (entireExponentialValue_congr cmGrowthExponent43 X cmGrowthExponent43_real)
  have hs := ComplexRaw.realPart_equiv (entireExponentialValue_congr (scalarSum X D)
    ⟨ofQComplex ⟨21,0⟩,ofQComplex_valid _⟩ real_gap_sum)
  exact RealRaw.le_trans (realPart_valid (entireExponentialValue X).property)
    (RealRaw.le_of_equiv (realPart_valid (entireExponentialValue cmGrowthExponent43).property)
      (realPart_valid (entireExponentialValue X).property) hc)
    (RealRaw.le_trans (realPart_valid (entireExponentialValue (scalarSum X D)).property) hm
      (RealRaw.le_trans (realPart_valid (entireExponentialValue ⟨ofQComplex ⟨21,0⟩,ofQComplex_valid _⟩).property)
        (RealRaw.le_of_equiv (realPart_valid (entireExponentialValue (scalarSum X D)).property)
          (realPart_valid (entireExponentialValue ⟨ofQComplex ⟨21,0⟩,ofQComplex_valid _⟩).property) hs)
        entireExponential_rational_twentyOne_upper))


def cmGrowthGapFromTwentyPointFive43 : RealRaw := RealRaw.add cmGrowthReal43 (RealRaw.ofRat (-41/2))

theorem cmGrowthGapFromTwentyPointFive43_valid : cmGrowthGapFromTwentyPointFive43.Valid :=
  RealRaw.add_valid cmGrowthReal43_valid (RealRaw.ofRat_valid (-41/2))

theorem cmGrowthGapFromTwentyPointFive43_lower : (RealRaw.ofRat (67/1000)).Le cmGrowthGapFromTwentyPointFive43 := by
  intro n m
  have h := cmGrowthReal43_lower_tight 0 m
  change (20567/1000:Rat)≤(cmGrowthReal43.compute m).hi at h
  change (67/1000:Rat)≤(cmGrowthReal43.compute m).hi+(-41/2)
  grind only

theorem cmGrowthGapFromTwentyPointFive43_positive : cmGrowthGapFromTwentyPointFive43.Pos := by
  obtain ⟨N,hN⟩ := cmGrowthGapFromTwentyPointFive43_valid.2.2 (⟨1/1000,by decide +kernel⟩ : QPos)
  have hw := hN N (Nat.le_refl N)
  have hl := cmGrowthGapFromTwentyPointFive43_lower 0 N
  change (67/1000:Rat)≤(cmGrowthGapFromTwentyPointFive43.compute N).hi at hl
  unfold QInterval.width at hw
  refine ⟨N,?_⟩
  change 0<(cmGrowthGapFromTwentyPointFive43.compute N).lo
  grind only

private theorem gap_sum :
    (add (ofRealRaw (RealRaw.ofRat (41/2))) (ofRealRaw cmGrowthGapFromTwentyPointFive43)).Equiv
      (ofRealRaw cmGrowthReal43) := by
  intro n
  apply (compareAt_overlap_iff _ _ n n).mpr
  have ho := RealRaw.interval_order_of_valid _ cmGrowthReal43_valid n
  simp only [add,ofRealRaw,cmGrowthGapFromTwentyPointFive43,RealRaw.add,RealRaw.addCompute,
    RealRaw.ofRat,QBox.add,QComplex.add,QBox.Overlaps,QComplex.le_def,Rat.add_zero]
  constructor <;> constructor <;> grind only

private theorem rational_embedding :
    (ofQComplex ⟨41/2,0⟩).Equiv (ofRealRaw (RealRaw.ofRat (41/2))) := by
  intro n
  apply (compareAt_overlap_iff _ _ n n).mpr
  simp [ofQComplex,ofRealRaw,RealRaw.ofRat,QBox.point,QBox.Overlaps,QComplex.le_def]

/-- A sharp rational lower bound for the actual CM growth exponential. -/
theorem cmGrowthExponential43_lower_sharp_power :
    (RealRaw.ofRat ((31/4:Rat)^10)).Le cmGrowthValue43 := by
  let X : Scalar := ⟨ofRealRaw (RealRaw.ofRat (41/2)),ofRealRaw_valid _ (RealRaw.ofRat_valid (41/2))⟩
  let D : Scalar := ⟨ofRealRaw cmGrowthGapFromTwentyPointFive43,ofRealRaw_valid _ cmGrowthGapFromTwentyPointFive43_valid⟩
  have hx0 : (RealRaw.ofRat 0).Le (RealRaw.ofRat (41/2)) := by intro n m; change (0:Rat)≤41/2; decide +kernel
  have hd0 : (RealRaw.ofRat 0).Le cmGrowthGapFromTwentyPointFive43 := by
    intro n m
    have h := cmGrowthGapFromTwentyPointFive43_lower 0 m
    change (67/1000:Rat)≤(cmGrowthGapFromTwentyPointFive43.compute m).hi at h
    change (0:Rat)≤(cmGrowthGapFromTwentyPointFive43.compute m).hi
    grind only
  have hm := entireExponential_real_positive_gap_order (RealRaw.ofRat (41/2)) cmGrowthGapFromTwentyPointFive43
    (RealRaw.ofRat_valid (41/2)) cmGrowthGapFromTwentyPointFive43_valid (by exact ⟨0,by decide +kernel⟩)
    cmGrowthGapFromTwentyPointFive43_positive hx0 hd0
  have hc := realPart_equiv (entireExponentialValue_congr
    ⟨ofQComplex ⟨41/2,0⟩,ofQComplex_valid _⟩ X rational_embedding)
  have he : (scalarSum X D).val.Equiv cmGrowthExponent43.val :=
    equiv_trans (scalarSum X D).property (ofRealRaw_valid _ cmGrowthReal43_valid)
      cmGrowthExponent43.property gap_sum (equiv_symm cmGrowthExponent43_real)
  have hs := realPart_equiv (entireExponentialValue_congr (scalarSum X D) cmGrowthExponent43 he)
  exact RealRaw.le_trans (realPart_valid (entireExponentialValue _).property)
    entireExponential_rational_twentyPointFive_lower
    (RealRaw.le_trans (realPart_valid (entireExponentialValue X).property)
      (RealRaw.le_of_equiv (realPart_valid (entireExponentialValue _).property)
        (realPart_valid (entireExponentialValue X).property) hc)
      (RealRaw.le_trans (realPart_valid (entireExponentialValue (scalarSum X D)).property) hm
        (RealRaw.le_of_equiv (realPart_valid (entireExponentialValue (scalarSum X D)).property)
          (realPart_valid (entireExponentialValue cmGrowthExponent43).property) hs)))


end ComputableAnalysis.ModularForms
