import ComputableAnalysis.ModularForms.CMJExactValueFromNewton163

namespace ComputableAnalysis.ModularForms
open RiemannHilbert PackedIntegerPolynomialProduct

/-- The CM modular function domain is independent of the represented name. -/
theorem latticeJMap_domain_at_cm_equivalent (z : Scalar)
    (hz : z.val.Equiv cmPoint163) : latticeJMap.domain z :=
  (latticeJMap.domain_congr z cmScalar163 hz).mpr latticeJMap_cm_domain

/-- The exact CM integer value for every equivalent valid represented point.
The arithmetic premise is the same concrete Newton prefix as for the canonical name. -/
theorem latticeJMap_cm_equivalent_value_of_newton
    (hnewton : ∀ k n, k≤41 → n<1723 → hecke41ExpandedNewtonCandidate k n=
      integerOrbitNewtonCoefficient41 integerJWeightedCoefficients 40 k n)
    (z : Scalar) (hz : z.val.Equiv cmPoint163) :
    (latticeJMap.eval z (latticeJMap_domain_at_cm_equivalent z hz)).val.Equiv
      (ComplexRaw.ofQComplex ⟨-((640320:Rat)^3),0⟩) := by
  exact ComplexRaw.equiv_trans
    (latticeJMap.eval z (latticeJMap_domain_at_cm_equivalent z hz)).property
    cmJValue163.property (ComplexRaw.ofQComplex_valid _)
    (latticeJMap.eval_congr z cmScalar163 _ latticeJMap_cm_domain hz)
    (cmJValue163_exact_value_of_newton hnewton)

end ComputableAnalysis.ModularForms
