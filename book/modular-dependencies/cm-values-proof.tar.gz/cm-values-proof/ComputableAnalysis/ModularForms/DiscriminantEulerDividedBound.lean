import ComputableAnalysis.ModularForms.DiscriminantEulerCoefficientBound
import ComputableAnalysis.ModularForms.DiscriminantEulerDifferenceBound
import ComputableAnalysis.RiemannHilbert.ReciprocalLocalBounds
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- Quantitative size of the actual divided discrepancy from a justified reciprocal bound. -/
theorem discriminantEulerDividedMap_bound (q : Scalar) (hq : discriminantEulerDividedMap.domain q)
    (r s : Rat) (hr : 0≤r) (hs : 0≤s) (hg : 128*r≤(1:Rat)/2) (hqr : Small q.val r)
    (hsmall : r≤(1:Rat)/65536) (hi : Small (RepresentedReciprocal.inverse q hq.1).val s) :
    Small (discriminantEulerDividedMap.eval q hq).val (21072*s*r*r) := by
  have hh := discriminantEulerDifferenceMap_quadratic_bound q hq.2 r hr hg hqr hsmall
  have hc : 0≤10536*r*r := Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hr) hr
  have hm := Small.mul (RepresentedReciprocal.inverse q hq.1).property
    (discriminantEulerDifferenceMap.eval q hq.2).property hs hc hi hh
  apply hm.mono
  grind only
/-- The constructed reciprocal supplies a concrete bound without extra caller evidence. -/
theorem discriminantEulerDividedMap_constructed_bound (q : Scalar) (hq : discriminantEulerDividedMap.domain q)
    (r : Rat) (hr : 0≤r) (hg : 128*r≤(1:Rat)/2) (hqr : Small q.val r)
    (hsmall : r≤(1:Rat)/65536) :
    Small (discriminantEulerDividedMap.eval q hq).val
      (21072*ReciprocalLocalBounds.bound q hq.1*r*r) :=
  discriminantEulerDividedMap_bound q hq r (ReciprocalLocalBounds.bound q hq.1) hr
    (Rat.le_of_lt (ReciprocalLocalBounds.bound_pos q hq.1)) hg hqr hsmall
    (ReciprocalLocalBounds.inverse_small q hq.1)
/-- Quantitative derivative bound from the actual homogeneous equation. -/
theorem discriminantEulerDividedMap_derivative_bound (q : Scalar) (hq : discriminantEulerDividedMap.domain q)
    (B : Rat) (hB : 0≤B) (hK : Small (discriminantEulerDividedMap.eval q hq).val B) :
    Small (discriminantEulerDividedMap_holomorphic.derivative q hq).val (768*B) := by
  have hm := Small.mul (discriminantEulerRegularCoefficient q hq.2).property
    (discriminantEulerDividedMap.eval q hq).property (by decide +kernel) hB
    (discriminantEulerRegularCoefficient_bound q hq.2) hK
  have hh := Small.congr
    (mul_valid (discriminantEulerRegularCoefficient q hq.2).property (discriminantEulerDividedMap.eval q hq).property)
    (discriminantEulerDividedMap_holomorphic.derivative q hq).property
    (equiv_symm (discriminantEulerDividedMap_boundedEquation q hq)) hm
  apply hh.mono
  grind only
end ComputableAnalysis.ModularForms
