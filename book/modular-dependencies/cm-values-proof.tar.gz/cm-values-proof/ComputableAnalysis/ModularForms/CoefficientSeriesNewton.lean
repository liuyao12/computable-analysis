import ComputableAnalysis.ModularForms.CoefficientSeriesRing
import ComputableAnalysis.ModularForms.FiniteRingNewton

namespace ComputableAnalysis.ModularForms.CoefficientConvolutionAlgebra
attribute [local instance] Lean.Grind.Semiring.natCast Lean.Grind.Ring.intCast
variable {R : Type} [Lean.Grind.CommRing R]

private theorem sum_coefficient (f : Nat → Value R) (k n : Nat) :
    (FiniteRingNewton.finiteValueSum f k).coefficient n =
      FiniteRingNewton.finiteValueSum (fun i => (f i).coefficient n) k := by
  induction k with
  | zero => change constant (0:R) n=0; cases n <;> rfl
  | succ k ih =>
    change (FiniteRingNewton.finiteValueSum f k).coefficient n+(f k).coefficient n=
      FiniteRingNewton.finiteValueSum (fun i => (f i).coefficient n) k+(f k).coefficient n
    rw [ih]

/-- Newton's identity at each literal coefficient degree of supplied
series. The convolution is finite and all ring laws have been proved. -/
theorem signedSymmetric_coefficient_newton (xs : List (Value R)) (k n : Nat) :
    (NatCast.natCast k:R)*(FiniteRingNewton.finiteSignedSymmetric xs k).coefficient n +
      FiniteRingNewton.finiteValueSum (fun i => product
        (FiniteRingNewton.finiteSignedSymmetric xs i).coefficient
        (FiniteRingNewton.finitePowerSum xs (k-i)).coefficient n) k=0 := by
  have h := congrArg (fun a : Value R => a.coefficient n)
    (FiniteRingNewton.finiteSignedSymmetric_newton xs k)
  change product (constant (NatCast.natCast k:R))
      (FiniteRingNewton.finiteSignedSymmetric xs k).coefficient n +
    (FiniteRingNewton.finiteValueSum (fun i =>
      FiniteRingNewton.finiteSignedSymmetric xs i*FiniteRingNewton.finitePowerSum xs (k-i)) k).coefficient n =
      constant (0:R) n at h
  rw [product_constant_left,sum_coefficient] at h
  have hz : constant (0:R) n=0 := by cases n <;> rfl
  rw [hz] at h
  exact h

/-- Unsigned Newton reconstruction at each coefficient degree, retaining
its explicit alternating-sign factors. -/
theorem unsignedSymmetric_coefficient_newton (xs : List (Value R)) (k n : Nat) :
    (NatCast.natCast k:R)*(FiniteRingNewton.finiteUnsignedSymmetric xs k).coefficient n +
      FiniteRingNewton.finiteValueSum (fun i => product
        (FiniteRingNewton.finiteUnsignedSymmetric xs i).coefficient
        (((-1:Value R)^(k-i))*FiniteRingNewton.finitePowerSum xs (k-i)).coefficient n) k=0 := by
  have h := congrArg (fun a : Value R => a.coefficient n)
    (FiniteRingNewton.finiteUnsignedSymmetric_newton xs k)
  change product (constant (NatCast.natCast k:R))
      (FiniteRingNewton.finiteUnsignedSymmetric xs k).coefficient n +
    (FiniteRingNewton.finiteValueSum (fun i =>
      FiniteRingNewton.finiteUnsignedSymmetric xs i*
        (((-1:Value R)^(k-i))*FiniteRingNewton.finitePowerSum xs (k-i))) k).coefficient n =
      constant (0:R) n at h
  rw [product_constant_left,sum_coefficient] at h
  have hz : constant (0:R) n=0 := by cases n <;> rfl
  rw [hz] at h
  exact h

end ComputableAnalysis.ModularForms.CoefficientConvolutionAlgebra
