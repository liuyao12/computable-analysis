import ComputableAnalysis.ModularForms.CommonInnerSquareContourAssembly

import ComputableAnalysis.ModularForms.DyadicAverageVelocityTransport
import ComputableAnalysis.ModularForms.Hecke41SquareKernelAverage
import ComputableAnalysis.ModularForms.Hecke41DyadicKernelContour

/-! Actual dyadic Hecke edge sampling agrees with the existing finite edge average. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem scalarProduct_right_negation (x y : Scalar) :
    (scalarProduct x (scalarNeg y)).val.Equiv (neg (scalarProduct x y).val) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (scalarProduct x (scalarNeg y)).property)
    (hright := neg_valid (scalarProduct x y).property)
  change gridScalarValue x * gridScalarValue (scalarNeg y)=
    gridScalarValue (scalarNeg (scalarProduct x y))
  simp only [gridScalarValue_scalarNeg]
  change gridScalarValue x * (-gridScalarValue y)= -(gridScalarValue x * gridScalarValue y)
  grind only

theorem hecke41DyadicFiniteEdge_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) (n : Nat) :
    (scalarProduct (hecke41SquareKernelDyadicAverage k a ha edge R hR n)
      (rationalRectangleScalar (QComplex.scaleRat R.val (velocity edge)))).val.Equiv
      (hecke41SquareKernelAverage k a ha edge R (2^n) (Nat.pow_pos (by decide +kernel))
        (Rat.le_trans hR (minRadius_left _ _))).val := by
  let f := hecke41SquareKernelUnitSample k a ha edge R hR
  let v := rationalRectangleScalar (QComplex.scaleRat R.val (velocity edge))
  let M := 2^n
  have hM : 0<M := Nat.pow_pos (by decide +kernel)
  have hs := dyadicAverage_velocity_transport f v n
  have he : ∀ j, ∀ hj : j<M, (f (squareMidpointParameter M j)).val.Equiv
      (scalarProduct ((hecke41NomeDescended k 10000).eval
        (Centered.translate a (rationalRectangleScalar
          (QComplex.scaleRat R.val (point edge (squareMidpointParameter M j)))))
        (hecke41SquareEdge_domain k a ha edge R (Rat.le_trans hR (minRadius_left _ _)) _
          (squareMidpointParameter_unit M j hM hj).1
          (squareMidpointParameter_unit M j hM hj).2))
        (rationalSquaredKernel (QComplex.scaleRat R.val (point edge (squareMidpointParameter M j))))).val := by
    intro j hj
    have hu := squareMidpointParameter_unit M j hM hj
    dsimp only [f,hecke41SquareKernelUnitSample]
    rw [dif_pos hu]
    exact equiv_refl _ (hecke41SquareKernelSample k a ha edge R hR _ hu.1 hu.2).property
  have ht := hecke41SquareKernelAverage_sample_agreement k a ha edge R M hM
    (Rat.le_trans hR (minRadius_left _ _)) (fun j => f (squareMidpointParameter M j)) he
  simp only [Rat.div_def,Rat.one_mul] at hs
  exact equiv_trans (scalarProduct (hecke41SquareKernelDyadicAverage k a ha edge R hR n) v).property
    (weightedMidpointSum (fun u => scalarProduct (f u) v) M ((M:Rat)⁻¹)).property
    (hecke41SquareKernelAverage k a ha edge R M hM (Rat.le_trans hR (minRadius_left _ _))).property hs ht

theorem hecke41DyadicOrientedFiniteEdge_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) (n : Nat) :
    (hecke41DyadicKernelEdgeSample k a ha edge R hR n).val.Equiv
      (if edge.upper then
        hecke41SquareKernelAverage k a ha edge R (2^n) (Nat.pow_pos (by decide +kernel))
          (Rat.le_trans hR (minRadius_left _ _))
       else scalarNeg (hecke41SquareKernelAverage k a ha edge R (2^n)
         (Nat.pow_pos (by decide +kernel)) (Rat.le_trans hR (minRadius_left _ _)))).val := by
  have hs := hecke41DyadicFiniteEdge_agreement k a ha edge R hR n
  unfold hecke41DyadicKernelEdgeSample squareOrientedVelocity
  cases h : edge.upper
  · simp only [h,Bool.false_eq_true,↓reduceIte]
    let x := hecke41SquareKernelDyadicAverage k a ha edge R hR n
    let y := rationalRectangleScalar (QComplex.scaleRat R.val (velocity edge))
    exact equiv_trans (scalarProduct x (scalarNeg y)).property
      (neg_valid (scalarProduct x y).property)
      (neg_valid (hecke41SquareKernelAverage k a ha edge R (2^n)
        (Nat.pow_pos (by decide +kernel)) (Rat.le_trans hR (minRadius_left _ _))).property)
      (scalarProduct_right_negation x y) (neg_equiv hs)
  · simp only [h,↓reduceIte]
    exact hs

end ComputableAnalysis.ModularForms
