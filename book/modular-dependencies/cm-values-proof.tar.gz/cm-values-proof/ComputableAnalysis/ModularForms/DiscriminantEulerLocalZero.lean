import ComputableAnalysis.ModularForms.DiscriminantEulerRadialZero
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- Actual divided discrepancy is zero at every nonzero represented nome in the explicit small disk. -/
theorem discriminantEulerDividedMap_local_zero (q : Scalar)
    (hq : discriminantEulerDividedMap.domain q) (hsmall : Small q.val ((1:Rat)/65536)) :
    (discriminantEulerDividedMap.eval q hq).val.Equiv zero := by
  let S := ReciprocalLocalBounds.bound q hq.1
  have he : (rationalScaledScalar 1 q).val.Equiv q.val := scaleRat_one_equiv q.val q.property
  have hz := (discriminantEulerDividedMap.domain_congr _ _ he).mpr hq
  have hh := discriminantEulerRadial_zero q hq.1 (1/65536) S 1
    (by decide +kernel) (ReciprocalLocalBounds.bound_pos q hq.1) (by decide +kernel)
    hsmall (ReciprocalLocalBounds.inverse_small q hq.1) (by decide +kernel)
    (by decide +kernel) 1 (by decide +kernel) (by decide +kernel) hz
  have hv := discriminantEulerDividedMap.eval_congr _ _ hz hq he
  exact equiv_trans (discriminantEulerDividedMap.eval q hq).property
    (discriminantEulerDividedMap.eval (rationalScaledScalar 1 q) hz).property
    (ofQComplex_valid _) (equiv_symm hv) hh

/-- Multiplication recovers exact zero discrepancy for actual Eisenstein and Euler discriminants. -/
theorem discriminantEulerDifferenceMap_local_nonzero_zero (q : Scalar)
    (hq : discriminantEulerDividedMap.domain q) (hsmall : Small q.val ((1:Rat)/65536)) :
    (discriminantEulerDifferenceMap.eval q hq.2).val.Equiv zero := by
  have hk := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := (discriminantEulerDividedMap.eval q hq).property) (hright := ofQComplex_valid _)
    (discriminantEulerDividedMap_local_zero q hq hsmall)
  have hr := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := mul_valid q.property (discriminantEulerDividedMap.eval q hq).property)
    (hright := (discriminantEulerDifferenceMap.eval q hq.2).property)
    (discriminantEulerDividedMap_recovery q hq)
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (discriminantEulerDifferenceMap.eval q hq.2).property) (hright := ofQComplex_valid _)
  change ComplexRawQuotient.ofRaw (discriminantEulerDividedMap.eval q hq).val
    (discriminantEulerDividedMap.eval q hq).property=0 at hk
  change ComplexRawQuotient.ofRaw q.val q.property *
    ComplexRawQuotient.ofRaw (discriminantEulerDividedMap.eval q hq).val
      (discriminantEulerDividedMap.eval q hq).property =
    ComplexRawQuotient.ofRaw (discriminantEulerDifferenceMap.eval q hq.2).val
      (discriminantEulerDifferenceMap.eval q hq.2).property at hr
  change ComplexRawQuotient.ofRaw (discriminantEulerDifferenceMap.eval q hq.2).val
    (discriminantEulerDifferenceMap.eval q hq.2).property=0
  rw [hk] at hr
  grind only
/-- Exact local agreement includes every representation of the origin. -/
theorem discriminantEulerDifferenceMap_local_zero (q : Scalar) (hq : tauEulerNomeDomain q)
    (hsmall : Small q.val ((1:Rat)/65536)) :
    (discriminantEulerDifferenceMap.eval q hq).val.Equiv zero := by
  classical
  by_cases hz : q.val.Equiv zero
  · exact discriminantEulerDifferenceMap_at_zero q hq hz
  · exact discriminantEulerDifferenceMap_local_nonzero_zero q ⟨hz,hq⟩ hsmall

/-- The actual normalized Eisenstein discriminant equals the actual Euler product locally. -/
theorem nomeNormalizedDiscriminantMap_local_euler_agreement (q : Scalar)
    (hq : tauEulerNomeDomain q) (hsmall : Small q.val ((1:Rat)/65536)) :
    (nomeNormalizedDiscriminantMap.eval q hq).val.Equiv (tauNormalizedEulerMap.eval q hq).val := by
  have hh := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := (discriminantEulerDifferenceMap.eval q hq).property) (hright := ofQComplex_valid _)
    (discriminantEulerDifferenceMap_local_zero q hq hsmall)
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (nomeNormalizedDiscriminantMap.eval q hq).property)
    (hright := (tauNormalizedEulerMap.eval q hq).property)
  change ComplexRawQuotient.ofRaw (nomeNormalizedDiscriminantMap.eval q hq).val
      (nomeNormalizedDiscriminantMap.eval q hq).property +
    -ComplexRawQuotient.ofRaw (tauNormalizedEulerMap.eval q hq).val
      (tauNormalizedEulerMap.eval q hq).property=0 at hh
  grind only
end ComputableAnalysis.ModularForms
