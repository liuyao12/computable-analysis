import ComputableAnalysis.ModularForms.Hecke41NormalizedCauchyDerivative
import ComputableAnalysis.ModularForms.Hecke41NomeDerivativeBounds

/-! Constructed base derivative estimates in the cusp weight recurrence. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

def hecke41CauchyDerivativeRate (S : QPos) : Rat :=
  2*(64*(2*(2:Rat)^10000)*(1/S.val))*scalarBound cauchyNormalizationScalar

theorem hecke41CauchyDerivativeRate_nonneg (S : QPos) : 0≤hecke41CauchyDerivativeRate S := by
  have hi : 0≤1/S.val := by
    rw [Rat.div_def,Rat.one_mul]
    exact Rat.le_of_lt (Rat.inv_pos.mpr S.property)
  have hC : 0≤64*(2*(2:Rat)^10000)*(1/S.val) :=
    Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel)
      (Rat.mul_nonneg (by decide +kernel) (Rat.pow_nonneg (by decide +kernel)))) hi
  exact Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hC)
    (Rat.le_of_lt (scalarBound_pos cauchyNormalizationScalar))

theorem hecke41NomeLinearDerivative_cauchy_bound (k : Nat) (q : Scalar)
    (hq : hecke41NomePuncturedDomain q) (S : QPos)
    (hS : S.val≤(hecke41NomeDerivativeNeighborhood k 10000 q hq).val)
    (R : Rat) (hR : 0≤R) (hqR : Small q.val R) :
    Small ((hecke41NomeDescended_holomorphic k 10001).derivative q hq).val
      (2*hecke41CauchyDerivativeRate S*R+2*(2:Rat)^10000) :=
  hecke41NomeDescended_linear_derivative_bound k q hq R (hecke41CauchyDerivativeRate S)
    hR (hecke41CauchyDerivativeRate_nonneg S) hqR (hecke41NomeDerivative_cauchy_bound k q hq S hS)

theorem hecke41NomeQuadraticDerivative_cauchy_bound (k : Nat) (q : Scalar)
    (hq : hecke41NomePuncturedDomain q) (S : QPos)
    (hS : S.val≤(hecke41NomeDerivativeNeighborhood k 10000 q hq).val)
    (R : Rat) (hR : 0≤R) (hqR : Small q.val R) :
    Small ((hecke41NomeDescended_holomorphic k 10002).derivative q hq).val
      (4*hecke41CauchyDerivativeRate S*R*R+4*(2*(2:Rat)^10000)*R) :=
  hecke41NomeDescended_quadratic_derivative_bound k q hq R (hecke41CauchyDerivativeRate S)
    hR (hecke41CauchyDerivativeRate_nonneg S) hqR (hecke41NomeDerivative_cauchy_bound k q hq S hS)

end ComputableAnalysis.ModularForms
