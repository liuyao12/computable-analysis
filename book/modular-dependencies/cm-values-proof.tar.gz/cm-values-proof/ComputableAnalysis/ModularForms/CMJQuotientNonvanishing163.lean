import ComputableAnalysis.ModularForms.CMJIsolationSubstitution163
import ComputableAnalysis.ModularForms.Hecke41QuotientNonvanishing
import ComputableAnalysis.ModularForms.LatticeJFourierReality

namespace ComputableAnalysis.ModularForms
open RiemannHilbert PackedIntegerPolynomialProduct

/-- The remaining candidate quotient does not vanish at the actual CM j
value, using the constructed substitution and proved analytic bounds. -/
theorem cmJValue163_candidate_quotient_nonzero :
    integerPolynomialClass hecke41DiagonalCandidateQuotient
      (ComplexRawQuotient.ofRaw cmJValue163.val cmJValue163.property)≠0 := by
  have he : ComplexRawQuotient.ofRaw cmJValue163.val cmJValue163.property=
      realAxisClass cmJValue163.val.realPart (ComplexRaw.realPart_valid cmJValue163.property) :=
    ComplexRawQuotient.ofRaw_eq_ofRaw cmJValue163_real_embedding
  rw [he]
  exact hecke41Quotient_class_nonzero_of_substitution cmJIsolationParameter163
    cmJIsolationParameter163_valid cmJIsolationParameter163_nonnegative _
    cmJIsolationParameter163_substitution

end ComputableAnalysis.ModularForms
