import ComputableAnalysis.RiemannHilbert.DomainProductRule
import ComputableAnalysis.ModularForms.EntireNomeKernelClassification
import ComputableAnalysis.ModularForms.NomeIntegerScaling

/-! Multiplicative laws for the actual entire nome evaluator. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

/-- Addition of represented inputs multiplies their actual entire nomes. -/
theorem entireNomeMap_addition (z w : Scalar) :
    (entireNomeMap.eval (scalarSum z w) (entireNomeMap_mem _)).val.Equiv
      (mul (entireNomeMap.eval z (entireNomeMap_mem z)).val
        (entireNomeMap.eval w (entireNomeMap_mem w)).val) := by
  let a := scalarProduct nomeSlope z
  let b := scalarProduct nomeSlope w
  have he : (scalarProduct nomeSlope (scalarSum z w)).val.Equiv (scalarSum a b).val := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := (scalarProduct nomeSlope (scalarSum z w)).property)
      (hright := (scalarSum a b).property)
    change ComplexRawQuotient.ofRaw nomeSlope.val nomeSlope.property *
      (ComplexRawQuotient.ofRaw z.val z.property + ComplexRawQuotient.ofRaw w.val w.property)=
      ComplexRawQuotient.ofRaw nomeSlope.val nomeSlope.property * ComplexRawQuotient.ofRaw z.val z.property +
      ComplexRawQuotient.ofRaw nomeSlope.val nomeSlope.property * ComplexRawQuotient.ofRaw w.val w.property
    grind only
  have h1 := entireNomeMap_exponent (scalarSum z w)
  have h2 := entireExponentialValue_congr _ _ he
  have h3 := equiv_symm (entireExponential_addition a b)
  have h4 := mul_equiv (entireExponentialValue a).property
    (entireNomeMap.eval z (entireNomeMap_mem z)).property
    (entireExponentialValue b).property (entireNomeMap.eval w (entireNomeMap_mem w)).property
    (equiv_symm (entireNomeMap_exponent z)) (equiv_symm (entireNomeMap_exponent w))
  exact equiv_trans (entireNomeMap.eval (scalarSum z w) (entireNomeMap_mem _)).property
    (entireExponentialValue (scalarProduct nomeSlope (scalarSum z w))).property
    (mul_valid (entireNomeMap.eval z (entireNomeMap_mem z)).property
      (entireNomeMap.eval w (entireNomeMap_mem w)).property) h1
    (equiv_trans (entireExponentialValue (scalarProduct nomeSlope (scalarSum z w))).property
      (entireExponentialValue (scalarSum a b)).property
      (mul_valid (entireNomeMap.eval z (entireNomeMap_mem z)).property
        (entireNomeMap.eval w (entireNomeMap_mem w)).property) h2
      (equiv_trans (entireExponentialValue (scalarSum a b)).property
        (mul_valid (entireExponentialValue a).property (entireExponentialValue b).property)
        (mul_valid (entireNomeMap.eval z (entireNomeMap_mem z)).property
          (entireNomeMap.eval w (entireNomeMap_mem w)).property) h3 h4))

/-- Natural scaling takes powers of the entire nome, without an upper-half-plane restriction. -/
theorem entireNomeMap_integerScale (z : Scalar) (n : Nat) :
    (entireNomeMap.eval (integerScaleScalar z (n:Int)) (entireNomeMap_mem _)).val.Equiv
      (LocalODE.power (entireNomeMap.eval z (entireNomeMap_mem z)).val n) := by
  have he : (scalarProduct nomeSlope (integerScaleScalar z (n:Int))).val.Equiv
      (integerScaleScalar (scalarProduct nomeSlope z) (n:Int)).val := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := (scalarProduct nomeSlope (integerScaleScalar z (n:Int))).property)
      (hright := (integerScaleScalar (scalarProduct nomeSlope z) (n:Int)).property)
    change ComplexRawQuotient.ofRaw nomeSlope.val nomeSlope.property *
      ComplexRawQuotient.ofRaw (integerAffine (n:Int) 0 z.val) (integerAffine_valid _ _ z.property) =
      ComplexRawQuotient.ofRaw (integerAffine (n:Int) 0 (scalarProduct nomeSlope z).val) (integerAffine_valid _ _ (scalarProduct nomeSlope z).property)
    rw [integerAffine_class,integerAffine_class]
    change ComplexRawQuotient.ofRaw nomeSlope.val nomeSlope.property *
      (((n:Int):ScalarAlgebra.Value) * ComplexRawQuotient.ofRaw z.val z.property + ((0:Int):ScalarAlgebra.Value))=
      ((n:Int):ScalarAlgebra.Value) * (ComplexRawQuotient.ofRaw nomeSlope.val nomeSlope.property *
        ComplexRawQuotient.ofRaw z.val z.property) + ((0:Int):ScalarAlgebra.Value)
    grind only
  have h1 := entireNomeMap_exponent (integerScaleScalar z (n:Int))
  have h2 := entireExponentialValue_congr _ _ he
  have h3 := entireExponential_integerScale (scalarProduct nomeSlope z) n
  have h4 := LocalODE.power_congr _ _ (entireExponentialValue (scalarProduct nomeSlope z)).property
    (entireNomeMap.eval z (entireNomeMap_mem z)).property
    (equiv_symm (entireNomeMap_exponent z)) n
  exact equiv_trans (entireNomeMap.eval (integerScaleScalar z (n:Int)) (entireNomeMap_mem _)).property
    (entireExponentialValue (scalarProduct nomeSlope (integerScaleScalar z (n:Int)))).property
    (LocalODE.power_valid _ (entireNomeMap.eval z (entireNomeMap_mem z)).property n) h1
    (equiv_trans (entireExponentialValue (scalarProduct nomeSlope (integerScaleScalar z (n:Int)))).property
      (entireExponentialValue (integerScaleScalar (scalarProduct nomeSlope z) (n:Int))).property
      (LocalODE.power_valid _ (entireNomeMap.eval z (entireNomeMap_mem z)).property n) h2
      (equiv_trans (entireExponentialValue (integerScaleScalar (scalarProduct nomeSlope z) (n:Int))).property
        (LocalODE.power_valid _ (entireExponentialValue (scalarProduct nomeSlope z)).property n)
        (LocalODE.power_valid _ (entireNomeMap.eval z (entireNomeMap_mem z)).property n) h3 h4))

end ComputableAnalysis.ModularForms
