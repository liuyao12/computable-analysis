import ComputableAnalysis.ModularForms.CommonOuterHalfEdgeConcatenation
import ComputableAnalysis.ModularForms.SquareFrameWeightedSides
import ComputableAnalysis.ModularForms.Hecke41KernelFrameTiles

/-! Outer Cartesian left-edge samples for an arbitrary supplied density. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem common_outer_left_sample (f : QComplex → Scalar) (R : QPos)
    (M k v : Nat) (hM : 0<M) :
    (rectangleGridVertical f (squareFrameTile R 0 k) M 0 v).val.Equiv
      (scaleRat (-1/(2*(M:Rat)))
        (commonSquareEdgeDensity f ⟨.west,true⟩ (squareFrameOuterRadius R)
          ((2-(k:Rat)-squareMidpointParameter M v)/2)).val) := by
  unfold rectangleGridVertical
  rw [squareFrame_outer_left_point R M k v hM,(squareFrameTile_grid_steps R M 0 k).2]
  change (scalarProduct (f (cartesianSquarePoint ⟨.west,true⟩ (2*R.val)
    ((2-(k:Rat)-squareMidpointParameter M v)/2)))
    (rationalRectangleScalar ⟨0,R.val/(M:Rat)⟩)).val.Equiv _
  rw [cartesianSquarePoint_agreement]
  have hw : (⟨0,R.val/(M:Rat)⟩ : QComplex)=
      QComplex.scaleRat (-1/(2*(M:Rat)))
        (QComplex.scaleRat (2*R.val) (velocity ⟨.west,true⟩)) := by
    simp only [velocity,rotation,orientation,↓reduceIte,QComplex.mul,QComplex.scaleRat,
      QComplex.mk.injEq,Rat.div_def,Rat.inv_mul_rev]
    constructor <;> grind only
  rw [hw]
  exact rationalWeightedSample_scale _ _ _

theorem common_outer_left_tile_average (f : QComplex → Scalar) (R : QPos)
    (M k : Nat) (hM : 0<M) :
    (squareFrameVerticalEdge f R M 0 k).val.Equiv
      (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.west,true⟩
        (squareFrameOuterRadius R) ((2-(k:Rat)-u)/2)) M (-1/(2*(M:Rat)))).val := by
  let density := fun v => commonSquareEdgeDensity f ⟨.west,true⟩
    (squareFrameOuterRadius R) ((2-(k:Rat)-squareMidpointParameter M v)/2)
  let weighted := fun v => (⟨scaleRat (-1/(2*(M:Rat))) (density v).val,
    scaleRat_valid (density v).property⟩ : Scalar)
  have hs : ∀ v, (rectangleGridVertical f (squareFrameTile R 0 k) M 0 v).val.Equiv
      (weighted v).val := by
    intro v
    exact common_outer_left_sample f R M k v hM
  exact equiv_trans (squareFrameVerticalEdge f R M 0 k).property
    (gridScalarSum M weighted).property
    (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.west,true⟩
      (squareFrameOuterRadius R) ((2-(k:Rat)-u)/2)) M (-1/(2*(M:Rat)))).property
    (gridScalarSum_congr M _ weighted hs)
    (gridScalarSum_scale (-1/(2*(M:Rat))) density M)

end ComputableAnalysis.ModularForms
