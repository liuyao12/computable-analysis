import ComputableAnalysis.ModularForms.PunctureSafeRectangles

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

theorem representedRectangle_small (J : QInterval × QInterval) (B : Rat)
    (hxl : -B≤J.1.lo) (hxu : J.1.hi≤B) (hyl : -B≤J.2.lo) (hyu : J.2.hi≤B)
    (z : Scalar) (hz : representedRectangleContains J z) : Small z.val B := by
  refine ⟨?_,?_,?_,?_⟩
  · intro n m
    have hb := hz.1 0 m
    exact Rat.le_trans hxl hb
  · intro m n
    have hb := hz.2.1 m 0
    exact Rat.le_trans hb hxu
  · intro n m
    have hb := hz.2.2.1 0 m
    exact Rat.le_trans hyl hb
  · intro m n
    have hb := hz.2.2.2 m 0
    exact Rat.le_trans hb hyu

end ComputableAnalysis.ModularForms
