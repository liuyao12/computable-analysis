import ComputableAnalysis.ModularForms.DiscriminantEulerOriginDerivative
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- The quotient-rule numerator for the discrepancy is controlled by the actual Lambert sum.
This identity includes the origin and does not require an inverse nome. -/
theorem discriminantEulerDifferenceMap_regularized (q : Scalar) (hq : tauEulerNomeDomain q) :
    (sub (mul q.val (discriminantEulerDifferenceMap_holomorphic.derivative q hq).val)
      (discriminantEulerDifferenceMap.eval q hq).val).Equiv
      (scaleRat (-24) (mul (tauLambertValue q hq).val (discriminantEulerDifferenceMap.eval q hq).val)) := by
  let H := discriminantEulerDifferenceMap.eval q hq
  let D := discriminantEulerDifferenceMap_holomorphic.derivative q hq
  let L := tauLambertValue q hq
  have hh := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := mul_valid q.property D.property)
    (hright := mul_valid (tauWeightTwoNomeMap.eval q hq).property H.property)
    (discriminantEulerDifferenceMap_theta q hq)
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := sub_valid (mul_valid q.property D.property) H.property)
    (hright := scaleRat_valid (mul_valid L.property H.property))
  let h := ComplexRawQuotient.ofRaw H.val H.property
  let d := ComplexRawQuotient.ofRaw D.val D.property
  let l := ComplexRawQuotient.ofRaw L.val L.property
  let z := ComplexRawQuotient.ofRaw q.val q.property
  change z*d=(1-ComplexRawQuotient.scaleRat 24 l)*h at hh
  change z*d-h=ComplexRawQuotient.scaleRat (-24) (l*h)
  rw [ComplexRawQuotient.scaleRat_mul,←ComplexRawQuotient.neg_scaleRat]
  grind only
end ComputableAnalysis.ModularForms
