import ComputableAnalysis.ModularForms.CommonOuterSquareLowerDensity
import ComputableAnalysis.ModularForms.CommonInnerSquareContourAssembly

/-! Signed reflected finite-sum assembly of the lower-right outer half edge. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem gridScalarSum_negation (f : Nat → Scalar) (M : Nat) :
    (gridScalarSum M (fun v => scalarNeg (f v))).val.Equiv
      (neg (gridScalarSum M f).val) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (gridScalarSum M (fun v => scalarNeg (f v))).property)
    (hright := neg_valid (gridScalarSum M f).property)
  change gridScalarValue (gridScalarSum M (fun v => scalarNeg (f v)))=
    gridScalarValue (scalarNeg (gridScalarSum M f))
  simp only [gridScalarSum_value,gridScalarValue_scalarNeg]
  induction M with
  | zero => simp only [gridValueSum]; grind only
  | succ M ih => simp only [gridValueSum,ih]; grind only

theorem scaleRat_negation (z : Scalar) (r : Rat) :
    (scaleRat r (neg z.val)).Equiv (neg (scaleRat r z.val)) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := scaleRat_valid (neg_valid z.property))
    (hright := neg_valid (scaleRat_valid z.property))
  rw [ComplexRawQuotient.ofRaw_scaleRat r (neg z.val) (neg_valid z.property),
    ComplexRawQuotient.ofRaw_neg z.val z.property,
    ComplexRawQuotient.ofRaw_neg (scaleRat r z.val) (scaleRat_valid z.property),
    ComplexRawQuotient.ofRaw_scaleRat r z.val z.property,
    ComplexRawQuotient.neg_scaleRat,ComplexRawQuotient.neg_eq_scaleRat_neg_one,
    ComplexRawQuotient.scaleRat_scaleRat]
  congr 1
  grind only

theorem commonEastShiftedAverage_agreement (f : QComplex → Scalar)
    (S : QPos) (M : Nat) (hM : 0<M) :
    (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.east,true⟩ S (u-1))
      M (1/(M:Rat))).val.Equiv
      (neg (commonSquareKernelAverage f ⟨.east,false⟩ S M).val) := by
  let d := fun v => commonSquareEdgeDensity f ⟨.east,false⟩ S
    (1-squareMidpointParameter M v)
  have hs := gridScalarSum_congr M _ (fun v => scalarNeg (d v))
    (fun v => commonSquareEastDensity_lower_reflection f S (squareMidpointParameter M v))
  have ht := gridScalarSum_negation d M
  have hn := scaleRat_negation (gridScalarSum M d) (1/(M:Rat))
  have ha := scaleRat_equiv (r := 1/(M:Rat))
    (equiv_trans (gridScalarSum M (fun v => commonSquareEdgeDensity f ⟨.east,true⟩ S (squareMidpointParameter M v-1))).property
      (gridScalarSum M (fun v => scalarNeg (d v))).property
      (neg_valid (gridScalarSum M d).property) hs ht)
  have hb := neg_equiv (commonReflectedSquareAverage_agreement f ⟨.east,false⟩ S M hM)
  exact equiv_trans
    (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.east,true⟩ S (u-1)) M (1/(M:Rat))).property
    (scaleRat_valid (neg_valid (gridScalarSum M d).property))
    (neg_valid (commonSquareKernelAverage f ⟨.east,false⟩ S M).property) ha
    (equiv_trans (scaleRat_valid (neg_valid (gridScalarSum M d).property))
      (neg_valid (commonReflectedSquareAverage f ⟨.east,false⟩ S M).property)
      (neg_valid (commonSquareKernelAverage f ⟨.east,false⟩ S M).property) hn hb)

theorem common_outer_right_lower_average (f : QComplex → Scalar) (R : QPos)
    (M : Nat) (hM : 0<M) :
    (scalarSum (squareFrameVerticalEdge f R M 4 0)
      (squareFrameVerticalEdge f R M 4 1)).val.Equiv
      (neg (commonSquareKernelAverage f ⟨.east,false⟩ (squareFrameOuterRadius R) (2*M)).val) := by
  let C := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.east,true⟩
    (squareFrameOuterRadius R) (u-1)) (2*M) (1/((2*M:Nat):Rat))
  exact equiv_trans (scalarSum (squareFrameVerticalEdge f R M 4 0)
    (squareFrameVerticalEdge f R M 4 1)).property C.property
    (neg_valid (commonSquareKernelAverage f ⟨.east,false⟩ (squareFrameOuterRadius R) (2*M)).property)
    (common_outer_right_lower_concatenation f R M hM)
    (commonEastShiftedAverage_agreement f (squareFrameOuterRadius R) (2*M) (by omega))

end ComputableAnalysis.ModularForms
