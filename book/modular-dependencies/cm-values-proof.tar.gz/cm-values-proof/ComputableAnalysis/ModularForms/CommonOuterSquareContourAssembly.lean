import ComputableAnalysis.ModularForms.CommonOuterReverseLowerConcatenation
import ComputableAnalysis.ModularForms.CommonOuterBottomLowerAssembly

/-! Exact full outer square contour assembly for supplied samplers. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem commonOuterSquareContour_agreement (f : QComplex → Scalar) (R : QPos)
    (M : Nat) (hM : 0<M) :
    (frameScalarRectBoundary (squareFrameHorizontalEdge f R M)
      (squareFrameVerticalEdge f R M) 0 0 4 4).val.Equiv
      (commonSquareKernelEdgeList f (squareFrameOuterRadius R) (2*M) PDE.CauchyContour.square).val := by
  let H := squareFrameHorizontalEdge f R M
  let V := squareFrameVerticalEdge f R M
  let A := fun e => commonSquareKernelAverage f e (squareFrameOuterRadius R) (2*M)
  have value {x y : Scalar} (he : x.val.Equiv y.val) : gridScalarValue x=gridScalarValue y :=
    ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := x.property) (hright := y.property) he
  have negative {x y : Scalar} (he : x.val.Equiv (neg y.val)) :
      gridScalarValue x= -gridScalarValue y := by
    have hv := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := x.property)
      (hright := neg_valid y.property) he
    rw [ComplexRawQuotient.ofRaw_neg _ y.property] at hv
    exact hv
  have he0 : gridScalarValue (scalarSum (V 4 0) (V 4 1))= -gridScalarValue (A ⟨.east,false⟩) :=
    negative (common_outer_right_lower_average f R M hM)
  have he1 : gridScalarValue (scalarSum (V 4 2) (V 4 3))= gridScalarValue (A ⟨.east,true⟩) :=
    value (common_outer_right_upper_average f R M hM)
  have hs0 : gridScalarValue (scalarSum (H 0 0) (H 1 0))= -gridScalarValue (A ⟨.south,false⟩) :=
    negative (common_outer_bottom_lower_average f R M hM)
  have hs1 : gridScalarValue (scalarSum (H 2 0) (H 3 0))= gridScalarValue (A ⟨.south,true⟩) :=
    value (common_outer_bottom_upper_average f R M hM)
  have hn0 : gridScalarValue (scalarSum (H 2 4) (H 3 4))= gridScalarValue (A ⟨.north,false⟩) :=
    value (common_outer_top_lower_average f R M hM)
  have hn1 : gridScalarValue (scalarSum (H 0 4) (H 1 4))= -gridScalarValue (A ⟨.north,true⟩) :=
    negative (common_outer_top_upper_average f R M hM)
  have hw0 : gridScalarValue (scalarSum (V 0 2) (V 0 3))= gridScalarValue (A ⟨.west,false⟩) :=
    value (common_outer_left_lower_average f R M hM)
  have hw1 : gridScalarValue (scalarSum (V 0 0) (V 0 1))= -gridScalarValue (A ⟨.west,true⟩) :=
    negative (common_outer_left_upper_average f R M hM)
  simp only [gridScalarValue_add] at he0 he1 hs0 hs1 hn0 hn1 hw0 hw1
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (frameScalarRectBoundary H V 0 0 4 4).property)
    (hright := (commonSquareKernelEdgeList f (squareFrameOuterRadius R) (2*M) PDE.CauchyContour.square).property)
  change gridScalarValue (frameScalarRectBoundary H V 0 0 4 4)=
    gridScalarValue (commonSquareKernelEdgeList f (squareFrameOuterRadius R) (2*M) PDE.CauchyContour.square)
  rw [frameScalarRectBoundary_value,commonSquareEdgeListValue_agreement]
  simp only [frameValueRectBoundary,gridValueBoundary,gridValueSum,PDE.CauchyContour.square,
    commonSquareEdgeListValue,Bool.false_eq_true,↓reduceIte]
  dsimp only [A] at he0 he1 hs0 hs1 hn0 hn1 hw0 hw1
  grind only

theorem hecke41OuterSquareContour_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (B R : QPos)
    (hB : B.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (hR : (squareFrameOuterRadius R).val≤B.val) (M : Nat) (hM : 0<M) :
    (frameScalarRectBoundary
      (squareFrameHorizontalEdge (hecke41KernelSquareSample k a ha B hB) R M)
      (squareFrameVerticalEdge (hecke41KernelSquareSample k a ha B hB) R M) 0 0 4 4).val.Equiv
      (hecke41SquareKernelEdgeList k a ha (squareFrameOuterRadius R) (2*M) (by omega) (Rat.le_trans hR hB) PDE.CauchyContour.square).val :=
  equiv_trans
    (frameScalarRectBoundary
      (squareFrameHorizontalEdge (hecke41KernelSquareSample k a ha B hB) R M)
      (squareFrameVerticalEdge (hecke41KernelSquareSample k a ha B hB) R M) 0 0 4 4).property
    (commonSquareKernelEdgeList (hecke41KernelSquareSample k a ha B hB) (squareFrameOuterRadius R) (2*M) PDE.CauchyContour.square).property
    (hecke41SquareKernelEdgeList k a ha (squareFrameOuterRadius R) (2*M) (by omega) (Rat.le_trans hR hB) PDE.CauchyContour.square).property
    (commonOuterSquareContour_agreement _ R M hM)
    (hecke41CommonSquare_edge_list_agreement k a ha B (squareFrameOuterRadius R) hB hR (2*M) (by omega) PDE.CauchyContour.square)

end ComputableAnalysis.ModularForms
