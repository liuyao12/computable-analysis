import ComputableAnalysis.ModularForms.QuantitativeNonzeroNeighborhood

/-! Finite rational tests for computing through the nome puncture. A narrow
box either certifies a nonzero input or certifies the actual zero-limit bound.
This is not yet a constructed holomorphic extension. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert

private theorem separated_nonzero (q : Scalar) (n : Nat)
    (h : NonzeroBoxSearch.separated (q.val.compute n)) : NonzeroBoxSearch.Nonzero q := by
  intro he
  have ho := (compareAt_overlap_iff q.val zero n n).1 (he n)
  change ((q.val.compute n).lo.re ≤ 0 ∧ (q.val.compute n).lo.im ≤ 0) ∧
    (0 ≤ (q.val.compute n).hi.re ∧ 0 ≤ (q.val.compute n).hi.im) at ho
  unfold NonzeroBoxSearch.separated at h
  grind

private theorem unseparated_small (q : Scalar) (n : Nat) (R : QPos)
    (h : ¬ NonzeroBoxSearch.separated (q.val.compute n))
    (hw : (q.val.compute n).width ≤ R.val)
    (hh : (q.val.compute n).height ≤ R.val) : Small q.val R.val := by
  have hb := LocalODE.small_from_box q.val q.property n
  apply hb.mono
  unfold NonzeroBoxSearch.separated at h
  change (q.val.compute n).hi.re-(q.val.compute n).lo.re ≤ R.val at hw
  change (q.val.compute n).hi.im-(q.val.compute n).lo.im ≤ R.val at hh
  change max 0 (max (-(q.val.compute n).lo.re)
    (max (q.val.compute n).hi.re (max (-(q.val.compute n).lo.im)
      (q.val.compute n).hi.im))) ≤ R.val
  have hp := Rat.le_of_lt R.property
  grind

/-- An executable precision stage for the finite cusp decision. -/
def finiteNonzeroGateStage (q : Scalar) (eps : QPos) : Nat :=
  PrecisionSearch.stage q.val q.property eps

/-- The finite decision uses rational coordinates, never equality to zero. -/
def finiteNonzeroGate (q : Scalar) (eps : QPos) : Bool :=
  NonzeroBoxSearch.good q (finiteNonzeroGateStage q eps)

/-- A successful finite test supplies the genuine nonzero evidence needed
by the already constructed descended evaluator. -/
theorem finiteNonzeroGate_nonzero (q : Scalar) (eps : QPos)
    (h : finiteNonzeroGate q eps = true) : NonzeroBoxSearch.Nonzero q := by
  apply separated_nonzero q (finiteNonzeroGateStage q eps)
  simpa only [finiteNonzeroGate, NonzeroBoxSearch.good, decide_eq_true_eq] using h

/-- Every representation of exact zero takes the zero-candidate branch. -/
theorem finiteNonzeroGate_at_zero (q : Scalar) (eps : QPos)
    (hzero : q.val.Equiv zero) : finiteNonzeroGate q eps = false := by
  cases h : finiteNonzeroGate q eps with
  | false => rfl
  | true => exact False.elim (finiteNonzeroGate_nonzero q eps h hzero)

/-- An unsuccessful finite test bounds the actual input, even if its exact
value is nonzero. -/
theorem finiteNonzeroGate_small (q : Scalar) (eps : QPos)
    (h : finiteNonzeroGate q eps = false) :
    Small q.val eps.val := by
  apply unseparated_small q (finiteNonzeroGateStage q eps) eps
  · simpa only [finiteNonzeroGate, NonzeroBoxSearch.good, decide_eq_false_iff_not] using h
  · exact (PrecisionSearch.stage_spec q.val q.property eps).1
  · exact (PrecisionSearch.stage_spec q.val q.property eps).2


end ComputableAnalysis.ModularForms
