import ComputableAnalysis.ModularForms.CoefficientConvolutionAlgebra

namespace ComputableAnalysis.ModularForms.CoefficientConvolutionAlgebra
attribute [local instance] Lean.Grind.Semiring.natCast Lean.Grind.Ring.intCast
variable {R : Type} [Lean.Grind.CommRing R]

/-- Coefficient sequences with executable finite-degree multiplication. -/
structure Value (R : Type) where
  coefficient : Nat → R

theorem Value.ext {a b : Value R} (h : a.coefficient=b.coefficient) : a=b := by
  cases a; cases b; cases h; rfl

instance : Add (Value R) := ⟨fun a b => ⟨fun n => a.coefficient n+b.coefficient n⟩⟩
instance : Mul (Value R) := ⟨fun a b => ⟨product a.coefficient b.coefficient⟩⟩
instance : Neg (Value R) := ⟨fun a => ⟨fun n => -a.coefficient n⟩⟩
instance : Sub (Value R) := ⟨fun a b => ⟨fun n => a.coefficient n-b.coefficient n⟩⟩
instance : NatCast (Value R) := ⟨fun n => ⟨constant (NatCast.natCast n)⟩⟩
instance (n : Nat) : OfNat (Value R) n := ⟨⟨constant (OfNat.ofNat n)⟩⟩
instance : IntCast (Value R) := ⟨fun n => ⟨constant (Int.cast n)⟩⟩
instance : SMul Nat (Value R) := ⟨fun n a => ⟨fun i => (NatCast.natCast n:R)*a.coefficient i⟩⟩
instance : SMul Int (Value R) := ⟨fun n a => ⟨fun i => (Int.cast n:R)*a.coefficient i⟩⟩

def power (a : Value R) : Nat → Value R
  | 0 => 1
  | n+1 => power a n*a
instance : HPow (Value R) Nat (Value R) := ⟨power⟩

instance : Lean.Grind.CommRing (Value R) where
  add_zero a := by
    apply Value.ext; funext n
    change a.coefficient n+constant (0:R) n=a.coefficient n
    cases n <;> simp only [constant] <;> grind only
  add_comm a b := by apply Value.ext; funext n; change a.coefficient n+b.coefficient n=b.coefficient n+a.coefficient n; grind only
  add_assoc a b c := by apply Value.ext; funext n; change (a.coefficient n+b.coefficient n)+c.coefficient n=a.coefficient n+(b.coefficient n+c.coefficient n); grind only
  mul_assoc a b c := by apply Value.ext; funext n; exact product_assoc a.coefficient b.coefficient c.coefficient n
  mul_comm a b := by apply Value.ext; funext n; exact product_comm a.coefficient b.coefficient n
  mul_one a := by
    apply Value.ext; funext n
    change product a.coefficient (constant (1:R)) n=a.coefficient n
    rw [product_comm,product_constant_left]
    grind only
  one_mul a := by
    apply Value.ext; funext n
    change product (constant (1:R)) a.coefficient n=a.coefficient n
    rw [product_constant_left]
    grind only
  left_distrib a b c := by apply Value.ext; funext n; exact product_add_right a.coefficient b.coefficient c.coefficient n
  right_distrib a b c := by apply Value.ext; funext n; exact product_add_left a.coefficient b.coefficient c.coefficient n
  zero_mul a := by
    apply Value.ext; funext n
    change product (constant (0:R)) a.coefficient n=constant (0:R) n
    have hz : constant (0:R)=(fun _ => (0:R)) := by funext i; cases i <;> rfl
    rw [hz,product_zero_left]
  mul_zero a := by
    apply Value.ext; funext n
    change product a.coefficient (constant (0:R)) n=constant (0:R) n
    rw [product_comm]
    have hz : constant (0:R)=(fun _ => (0:R)) := by funext i; cases i <;> rfl
    rw [hz,product_zero_left]
  pow_zero a := rfl
  pow_succ a n := rfl
  ofNat_succ n := by
    apply Value.ext; funext i
    change constant (OfNat.ofNat (n+1):R) i=constant (OfNat.ofNat n:R) i+constant (1:R) i
    cases i with
    | zero => exact Lean.Grind.Semiring.ofNat_succ n
    | succ i => change (0:R)=0+0; grind only
  ofNat_eq_natCast n := by
    apply Value.ext; funext i
    change constant (OfNat.ofNat n:R) i=constant (NatCast.natCast n:R) i
    rw [Lean.Grind.Semiring.ofNat_eq_natCast]
  nsmul_eq_natCast_mul n a := by
    apply Value.ext; funext i
    change (NatCast.natCast n:R)*a.coefficient i=product (constant (NatCast.natCast n:R)) a.coefficient i
    exact (product_constant_left _ _ _).symm
  neg_add_cancel a := by
    apply Value.ext; funext n
    change -a.coefficient n+a.coefficient n=constant (0:R) n
    cases n <;> simp only [constant] <;> grind only
  sub_eq_add_neg a b := by apply Value.ext; funext n; change a.coefficient n-b.coefficient n=a.coefficient n+ -b.coefficient n; grind only
  neg_zsmul n a := by
    apply Value.ext; funext i
    change (Int.cast (-n):R)*a.coefficient i= -((Int.cast n:R)*a.coefficient i)
    grind only
  zsmul_natCast_eq_nsmul n a := by
    apply Value.ext; funext i
    change (Int.cast (n:Int):R)*a.coefficient i=(NatCast.natCast n:R)*a.coefficient i
    rw [Lean.Grind.Ring.intCast_natCast]
  intCast_ofNat n := by
    apply Value.ext; funext i
    change constant (Int.cast (OfNat.ofNat (α:=Int) n):R) i=constant (OfNat.ofNat n:R) i
    rw [Lean.Grind.Ring.intCast_ofNat]
  intCast_neg n := by
    apply Value.ext; funext i
    change constant (Int.cast (-n):R) i= -constant (Int.cast n:R) i
    cases i <;> simp only [constant] <;> grind only

end ComputableAnalysis.ModularForms.CoefficientConvolutionAlgebra
