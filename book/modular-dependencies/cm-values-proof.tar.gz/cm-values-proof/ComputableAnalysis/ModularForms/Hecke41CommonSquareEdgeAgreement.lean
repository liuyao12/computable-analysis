import ComputableAnalysis.ModularForms.Hecke41KernelSquareSampler
import ComputableAnalysis.ModularForms.Hecke41SquareKernelContour
import ComputableAnalysis.ModularForms.RectangleDyadicBoundaryAgreement

/-! The common square sampler agrees with actual finite Hecke edge averages. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem hecke41CommonSquare_edge_sample_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (B S : QPos)
    (hB : B.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (hS : S.val≤B.val) (edge : HalfEdge) (u : Rat) (hu : 0≤u) (hu1 : u≤1) :
    (hecke41KernelSquareSample k a ha B hB (QComplex.scaleRat S.val (point edge u))).val.Equiv
      (scalarProduct ((hecke41NomeDescended k 10000).eval
        (Centered.translate a (rationalRectangleScalar (QComplex.scaleRat S.val (point edge u))))
        (hecke41SquareEdge_domain k a ha edge S (Rat.le_trans hS hB) u hu hu1))
        (rationalSquaredKernel (QComplex.scaleRat S.val (point edge u)))).val := by
  let q := QComplex.scaleRat S.val (point edge u)
  have hb := (scaledSquarePoint_small edge S.val u (Rat.le_of_lt S.property) hu hu1).mono hS
  have hq : rationalRectangleContains (rationalKernelSquare B) q :=
    ⟨hb.1 0 0,hb.2.1 0 0,hb.2.2.1 0 0,hb.2.2.2 0 0⟩
  have hne := scaledSquarePoint_normSq_nonzero edge u S.val S.property
  let hz := hecke41KernelSquare_rational_domain k a ha B hB q hq hne
  have hs := hecke41KernelSquareSample_agreement k a ha B hB q hq hne hz
  have he := hecke41CauchyIntegrandMap_rational_agreement k a q hne hz
    (hecke41SquareEdge_domain k a ha edge S (Rat.le_trans hS hB) u hu hu1)
  simp only [scalarProduct,rationalSquaredKernel]
  exact equiv_trans (hecke41KernelSquareSample k a ha B hB q).property
    ((hecke41CauchyIntegrandMap k a).eval (rationalRectangleScalar q) hz).property
    (mul_valid ((hecke41NomeDescended k 10000).eval
      (Centered.translate a (rationalRectangleScalar q))
      (hecke41SquareEdge_domain k a ha edge S (Rat.le_trans hS hB) u hu hu1)).property
      (mul_valid (ofQComplex_valid _) (ofQComplex_valid _))) hs he

def commonSquareKernelAverage (f : QComplex → Scalar) (edge : HalfEdge)
    (S : QPos) (M : Nat) : Scalar :=
  let sum := gridScalarSum M (fun n => scalarProduct
    (f (QComplex.scaleRat S.val (point edge (squareMidpointParameter M n))))
    (rationalRectangleScalar (QComplex.scaleRat S.val (velocity edge))))
  ⟨scaleRat (1/(M:Rat)) sum.val,scaleRat_valid sum.property⟩

theorem hecke41CommonSquare_edge_average_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (B S : QPos)
    (hB : B.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (hS : S.val≤B.val) (edge : HalfEdge) (M : Nat) (hM : 0<M) :
    (commonSquareKernelAverage (hecke41KernelSquareSample k a ha B hB) edge S M).val.Equiv
      (hecke41SquareKernelAverage k a ha edge S M hM (Rat.le_trans hS hB)).val := by
  dsimp only [commonSquareKernelAverage]
  simp only [Rat.div_def,Rat.one_mul]
  exact hecke41SquareKernelAverage_sample_agreement k a ha edge S M hM (Rat.le_trans hS hB)
    (fun n => hecke41KernelSquareSample k a ha B hB
      (QComplex.scaleRat S.val (point edge (squareMidpointParameter M n))))
    (fun n hn => hecke41CommonSquare_edge_sample_agreement k a ha B S hB hS edge
      (squareMidpointParameter M n) (squareMidpointParameter_unit M n hM hn).1
      (squareMidpointParameter_unit M n hM hn).2)

def commonSquareKernelEdgeList (f : QComplex → Scalar) (S : QPos) (M : Nat) :
    List HalfEdge → Scalar
  | [] => ⟨zero,ofQComplex_valid _⟩
  | e::es =>
    let v := commonSquareKernelAverage f e S M
    scalarSum (if e.upper then v else scalarNeg v) (commonSquareKernelEdgeList f S M es)

theorem hecke41CommonSquare_edge_list_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (B S : QPos)
    (hB : B.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (hS : S.val≤B.val) (M : Nat) (hM : 0<M) (es : List HalfEdge) :
    (commonSquareKernelEdgeList (hecke41KernelSquareSample k a ha B hB) S M es).val.Equiv
      (hecke41SquareKernelEdgeList k a ha S M hM (Rat.le_trans hS hB) es).val := by
  induction es with
  | nil => exact equiv_refl _ (ofQComplex_valid _)
  | cons e es ih =>
    have hv := hecke41CommonSquare_edge_average_agreement k a ha B S hB hS e M hM
    cases h : e.upper
    · simpa only [commonSquareKernelEdgeList,hecke41SquareKernelEdgeList,h,
        Bool.false_eq_true,↓reduceIte,scalarSum,scalarNeg] using add_equiv (neg_equiv hv) ih
    · simpa only [commonSquareKernelEdgeList,hecke41SquareKernelEdgeList,h,
        ↓reduceIte,scalarSum] using add_equiv hv ih

end ComputableAnalysis.ModularForms
