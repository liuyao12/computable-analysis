import ComputableAnalysis.ModularForms.DiscriminantIntegerPeriodicity
namespace ComputableAnalysis.ModularForms
set_option maxHeartbeats 2000000
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- Translating the input advances the rational affine discriminant offset. -/
theorem discriminantAffinePullback_translate_one (r b : Rat) (hr : 0<r)
    (z : Scalar) (hz : InUpperHalfPlane z.val) :
    ((discriminantAffinePullback r b hr).eval ⟨translate 1 z.val,translate_valid _ z.property⟩
      (translate_mem _ hz)).val.Equiv ((discriminantAffinePullback r (b+1) hr).eval z hz).val := by
  exact normalizedLatticeDiscriminantMap.eval_congr
    ((rationalAffineMap r b).eval (⟨translate 1 z.val,translate_valid _ z.property⟩ : Scalar) (translate_mem 1 hz))
    ((rationalAffineMap r (b+1)).eval z hz)
    (rationalAffineMap_upper r b hr (⟨translate 1 z.val,translate_valid _ z.property⟩ : Scalar) (translate_mem 1 hz))
    (rationalAffineMap_upper r (b+1) hr z hz)
    (scaleRat_equiv (r := r) (translate_compose b 1 z.property))
private theorem rationalClass (c : Rat) : ComplexRawQuotient.ofQComplex ⟨c,0⟩=
    ComplexRawQuotient.scaleRat c 1 := by
  have hh := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := mul_valid (ofQComplex_valid _) (show one.Valid from ofQComplex_valid _))
    (hright := scaleRat_valid (show one.Valid from ofQComplex_valid _))
    (rationalReal_mul_scale c (⟨one,ofQComplex_valid _⟩ : Scalar))
  change ComplexRawQuotient.ofQComplex ⟨c,0⟩*1=ComplexRawQuotient.scaleRat c 1 at hh
  grind only
/-- Actual affine points separate their offset after rational scaling. -/
theorem rationalAffineMap_scaled_offset (r b : Rat) (z : Scalar) (hz : InUpperHalfPlane z.val) :
    ((rationalAffineMap r b).eval z hz).val.Equiv
      (translate (r*b) ((rationalAffineMap r 0).eval z hz).val) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := ((rationalAffineMap r b).eval z hz).property)
    (hright := translate_valid _ ((rationalAffineMap r 0).eval z hz).property)
  let v := ComplexRawQuotient.ofRaw z.val z.property
  change ComplexRawQuotient.scaleRat r (v+ComplexRawQuotient.ofQComplex ⟨b,0⟩)=
    ComplexRawQuotient.scaleRat r (v+ComplexRawQuotient.ofQComplex ⟨0,0⟩)+ComplexRawQuotient.ofQComplex ⟨r*b,0⟩
  rw [rationalClass b,rationalClass 0,rationalClass (r*b),ComplexRawQuotient.scaleRat_add,
    ComplexRawQuotient.scaleRat_scaleRat]
  have hz0 : ComplexRawQuotient.scaleRat 0 (1:ComplexRawQuotient.Value)=0 :=
    ComplexRawQuotient.scaleRat_zeroScalar _
  rw [hz0]
  grind only

/-- The last affine term of the Hecke correspondence wraps to the first by actual periodicity. -/
theorem discriminantHeckeAffine_wrap (p : Nat) (hp : 0<(p:Rat)) (z : Scalar)
    (hz : InUpperHalfPlane z.val) :
    ((discriminantAffinePullback (1/(p:Rat)) (p:Rat) (by
      rw [Rat.div_def,Rat.one_mul]; exact Rat.inv_pos.mpr hp)).eval z hz).val.Equiv
    ((discriminantAffinePullback (1/(p:Rat)) 0 (by
      rw [Rat.div_def,Rat.one_mul]; exact Rat.inv_pos.mpr hp)).eval z hz).val := by
  let r : Rat := 1/(p:Rat)
  have hr : 0<r := by dsimp [r]; rw [Rat.div_def,Rat.one_mul]; exact Rat.inv_pos.mpr hp
  let w := (rationalAffineMap r 0).eval z hz
  have hw := rationalAffineMap_upper r 0 hr z hz
  have he := rationalAffineMap_scaled_offset r (p:Rat) z hz
  have hc : r*(p:Rat)=1 := by
    dsimp [r]; rw [Rat.div_def,Rat.one_mul]; exact Rat.inv_mul_cancel _ (Rat.ne_of_gt hp)
  rw [hc] at he
  have hv := normalizedLatticeDiscriminantMap.eval_congr ((rationalAffineMap r (p:Rat)).eval z hz)
    (⟨translate 1 w.val,translate_valid _ w.property⟩ : Scalar)
    (rationalAffineMap_upper r (p:Rat) hr z hz) (translate_mem 1 hw) he
  exact equiv_trans ((discriminantAffinePullback r (p:Rat) hr).eval z hz).property
    (normalizedLatticeDiscriminantMap.eval ⟨translate 1 w.val,translate_valid _ w.property⟩ (translate_mem 1 hw)).property
    ((discriminantAffinePullback r 0 hr).eval z hz).property hv
    (normalizedLatticeDiscriminantMap_integer_periodic w hw 1)
end ComputableAnalysis.ModularForms
