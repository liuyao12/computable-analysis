import ComputableAnalysis.ModularForms.Hecke41ExpansionContourPolynomialAgreement

/-! Actual constructed contour values are reconstructed by their coefficient polynomials. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

private theorem difference_add (x p y : Scalar) :
    (add (sub x.val p.val) (sub p.val y.val)).Equiv (sub x.val y.val) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := add_valid (sub_valid x.property p.property) (sub_valid p.property y.property))
    (hright := sub_valid x.property y.property)
  let X := gridScalarValue x
  let P := gridScalarValue p
  let Y := gridScalarValue y
  change (X-P)+(P-Y)=X-Y
  grind only

theorem hecke41CoefficientContourPolynomial_converges_to_shifted_contour (k : Nat) (a b : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R B S : QPos)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (hRS : R.val≤S.val) (hSB : S.val≤B.val)
    (r : Rat) (hr : 0≤r) (hR : r<R.val) (hb : Small b.val r) (hsmall : 8*r≤S.val)
    (hd : S.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val)
    (es : List HalfEdge) (eps : QPos) :
    ∃ N, ∀ n, N≤n → Small
      (sub (hecke41ShiftedPoleContourLimit k a b ha R B S hB hRS hSB r hR hb hd es).val
        (hecke41CoefficientContourPolynomial k a b ha S (Rat.le_trans hSB hB) hd es n).val) eps.val := by
  obtain ⟨N,L,hNL⟩ := hecke41ShiftedPoleExpansionFiniteContour_approximates_limit k a b ha R B S
    hB hRS hSB r hr hR hb hsmall hd es (halfError eps)
  refine ⟨N,fun n hn => ?_⟩
  obtain ⟨K,hK⟩ := hecke41FiniteCoefficientContourPolynomial_converges k a b ha S
    (Rat.le_trans hSB hB) hd es n (halfError eps)
  let j := max L K
  let x := hecke41ShiftedPoleContourLimit k a b ha R B S hB hRS hSB r hR hb hd es
  let y := hecke41CoefficientContourPolynomial k a b ha S (Rat.le_trans hSB hB) hd es n
  let p := hecke41FiniteCoefficientContourPolynomial k a b ha S (Rat.le_trans hSB hB)
    (2^j) (Nat.pow_pos (by decide +kernel)) es n
  let q := hecke41ShiftedPoleExpansionFiniteContour k a b ha S (Rat.le_trans hSB hB)
    (2^j) (Nat.pow_pos (by decide +kernel)) n es
  have he := hecke41ShiftedPoleExpansionFiniteContour_polynomial_agreement k a b ha S
    (Rat.le_trans hSB hB) (2^j) (Nat.pow_pos (by decide +kernel)) es n
  have hx := Small.congr (sub_valid x.property q.property) (sub_valid x.property p.property)
    (FunctionTheory.sub_congr (equiv_refl x.val x.property) he)
    (hNL n hn j (Nat.le_max_left _ _))
  have hy := RepresentedCauchySum.small_sub_symm y.val p.val (halfError eps).val
    (hK j (Nat.le_max_right _ _))
  have hm := LocalODE.small_add hx hy
  have ht := Small.congr (add_valid (sub_valid x.property p.property) (sub_valid p.property y.property))
    (sub_valid x.property y.property) (difference_add x p y) hm
  have hh : (halfError eps).val+(halfError eps).val=eps.val := by
    have h := halfError_identity eps
    grind only
  rw [hh] at ht
  exact ht

end ComputableAnalysis.ModularForms
