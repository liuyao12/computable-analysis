import ComputableAnalysis.ModularForms.DiscriminantEulerDifference
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- Quantitative matching of the Euler discriminant's leading term. -/
theorem tauNormalizedEulerMap_linear_bound (q : Scalar) (hq : tauEulerNomeDomain q)
    (r : Rat) (hr : 0≤r) (hs : r≤(1:Rat)/1024) (hqr : Small q.val r) :
    Small (sub (tauNormalizedEulerMap.eval q hq).val q.val) (1536*r*r) := by
  let P := tauEulerProduct q r hr hs hqr
  have hp := tauEulerProduct_close_prefix q r hr hs hqr 0
  have hb : Small (sub P.val one) (768*r) := by
    simp only [finiteDiscriminantEulerProduct,Nat.zero_add,Rat.pow_one] at hp
    apply hp.mono
    grind only
  have hm := Small.mul (sub_valid P.property (ofQComplex_valid _)) q.property
    (Rat.mul_nonneg (by decide +kernel) hr) hr hb hqr
  have he : (mul (sub P.val one) q.val).Equiv (sub (tauNormalizedEulerMap.eval q hq).val q.val) := by
    have ha := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := (tauEulerNomeMap.eval q hq).property)
      (hright := P.property) (tauEulerNomeMap_agreement q hq r hr hs hqr)
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := mul_valid (sub_valid P.property (ofQComplex_valid _)) q.property)
      (hright := sub_valid (tauNormalizedEulerMap.eval q hq).property q.property)
    let p := ComplexRawQuotient.ofRaw P.val P.property
    let a := ComplexRawQuotient.ofRaw (tauEulerNomeMap.eval q hq).val (tauEulerNomeMap.eval q hq).property
    let z := ComplexRawQuotient.ofRaw q.val q.property
    change a=p at ha
    change (p-1)*z=a*z-z
    grind only
  have hh := Small.congr (mul_valid (sub_valid P.property (ofQComplex_valid _)) q.property)
    (sub_valid (tauNormalizedEulerMap.eval q hq).property q.property) he hm
  apply hh.mono
  grind only
/-- The actual discrepancy has second-order vanishing with an explicit rational bound. -/
theorem discriminantEulerDifferenceMap_quadratic_bound (q : Scalar) (hq : tauEulerNomeDomain q)
    (r : Rat) (hr : 0≤r) (hg : 128*r≤(1:Rat)/2) (hqr : Small q.val r)
    (hs : r≤(1:Rat)/65536) :
    Small (discriminantEulerDifferenceMap.eval q hq).val (10536*r*r) := by
  have hmax : r≤(1:Rat)/1024 := Rat.le_trans hs (by decide +kernel)
  have ha := nomeNormalizedDiscriminantMap_linear_bound q hq r hr hg hqr hs
  have hb := tauNormalizedEulerMap_linear_bound q hq r hr hmax hqr
  have hh := SeriesLimitLaws.small_sub ha hb
  have he : (sub (sub (nomeNormalizedDiscriminantMap.eval q hq).val q.val)
      (sub (tauNormalizedEulerMap.eval q hq).val q.val)).Equiv (discriminantEulerDifferenceMap.eval q hq).val := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := sub_valid (sub_valid (nomeNormalizedDiscriminantMap.eval q hq).property q.property)
        (sub_valid (tauNormalizedEulerMap.eval q hq).property q.property))
      (hright := (discriminantEulerDifferenceMap.eval q hq).property)
    let a := ComplexRawQuotient.ofRaw (nomeNormalizedDiscriminantMap.eval q hq).val (nomeNormalizedDiscriminantMap.eval q hq).property
    let b := ComplexRawQuotient.ofRaw (tauNormalizedEulerMap.eval q hq).val (tauNormalizedEulerMap.eval q hq).property
    let z := ComplexRawQuotient.ofRaw q.val q.property
    change (a-z)-(b-z)=a+ -b
    grind only
  have h := Small.congr
    (sub_valid (sub_valid (nomeNormalizedDiscriminantMap.eval q hq).property q.property)
      (sub_valid (tauNormalizedEulerMap.eval q hq).property q.property))
    (discriminantEulerDifferenceMap.eval q hq).property he hh
  apply h.mono
  grind only
/-- Every valid representation of the origin gives zero discrepancy. -/
theorem discriminantEulerDifferenceMap_at_zero (q : Scalar) (hq : tauEulerNomeDomain q)
    (hz : q.val.Equiv zero) :
    (discriminantEulerDifferenceMap.eval q hq).val.Equiv zero := by
  have hq0 : Small q.val 0 := Small.congr (ofQComplex_valid _) q.property
    (equiv_symm hz) (Small.zero Rat.le_refl)
  have h := discriminantEulerDifferenceMap_quadratic_bound q hq 0 Rat.le_refl
    (by decide +kernel) hq0 (by decide +kernel)
  have hh : Small (discriminantEulerDifferenceMap.eval q hq).val 0 := by
    simpa only [Rat.mul_zero] using h
  have he := SeriesLimitLaws.small_sub hh (Small.zero (by decide +kernel : (0:Rat)≤0))
  exact SeriesLimitLaws.equiv_of_small_sub_zero _ _ (by simpa only [Rat.add_zero] using he)
/-- Rational rescaling exposes the linear decay supplied by second-order vanishing. -/
theorem discriminantEulerDifferenceMap_rescaled_bound (q : Scalar) (hq : tauEulerNomeDomain q)
    (r : Rat) (hr : 0<r) (hg : 128*r≤(1:Rat)/2) (hqr : Small q.val r)
    (hs : r≤(1:Rat)/65536) :
    Small (scaleRat r⁻¹ (discriminantEulerDifferenceMap.eval q hq).val) (21072*r) := by
  have h := discriminantEulerDifferenceMap_quadratic_bound q hq r (Rat.le_of_lt hr) hg hqr hs
  have hc : 0≤10536*r*r := Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) (Rat.le_of_lt hr)) (Rat.le_of_lt hr)
  have hi : 0≤r⁻¹ := Rat.le_of_lt (Rat.inv_pos.mpr hr)
  have hh := LocalODE.small_scale (c := r⁻¹) hi h
  apply hh.mono
  have he : r*r⁻¹=1 := Rat.mul_inv_cancel r (Rat.ne_of_gt hr)
  have heq : r⁻¹*(10536*r*r)=10536*r := by
    calc r⁻¹*(10536*r*r)=10536*r*(r*r⁻¹) := by rw [Rat.mul_assoc]; grind only
         _ =10536*r := by rw [he,Rat.mul_one]
  rw [heq]
  have hp := Rat.mul_nonneg (by decide +kernel : (0:Rat)≤10536) (Rat.le_of_lt hr)
  grind only
end ComputableAnalysis.ModularForms
