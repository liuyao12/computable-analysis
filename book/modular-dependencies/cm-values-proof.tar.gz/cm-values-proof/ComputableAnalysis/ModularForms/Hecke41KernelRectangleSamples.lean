import ComputableAnalysis.ModularForms.Hecke41KernelRectangleDomain
import ComputableAnalysis.ModularForms.PuncturedKernelMidpointCycle

/-! Executable actual rectangle samples and genuine affine-model errors. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

instance rationalRectangleContains_decidable (J : QInterval × QInterval) (q : QComplex) :
    Decidable (rationalRectangleContains J q) := by
  unfold rationalRectangleContains
  infer_instance

def hecke41KernelRectangleSample (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (J : QInterval × QInterval) (R B : QPos) (hs : rectangleSeparated J R)
    (hxl : -B.val≤J.1.lo) (hxu : J.1.hi≤B.val)
    (hyl : -B.val≤J.2.lo) (hyu : J.2.hi≤B.val)
    (hB : B.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val) (q : QComplex) : Scalar :=
  if h : rationalRectangleContains J q then
    (hecke41CauchyIntegrandMap k a).eval (rationalRectangleScalar q)
      (hecke41KernelRectangle_domain k a ha J R B hs hxl hxu hyl hyu hB _ (rationalRectangle_represented_mem J q h))
  else ⟨zero,ofQComplex_valid _⟩

theorem hecke41KernelRectangleSample_agreement (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (J : QInterval × QInterval) (R B : QPos) (hs : rectangleSeparated J R)
    (hxl : -B.val≤J.1.lo) (hxu : J.1.hi≤B.val)
    (hyl : -B.val≤J.2.lo) (hyu : J.2.hi≤B.val)
    (hB : B.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (q : QComplex) (hq : rationalRectangleContains J q)
    (hz : (hecke41CauchyIntegrandMap k a).domain (rationalRectangleScalar q)) :
    ((hecke41CauchyIntegrandMap k a).eval (rationalRectangleScalar q) hz).val.Equiv
      (hecke41KernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB q).val := by
  simp only [hecke41KernelRectangleSample,dif_pos hq]
  exact equiv_refl _ ((hecke41CauchyIntegrandMap k a).eval (rationalRectangleScalar q) hz).property

theorem hecke41KernelRectangleSample_model_error (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (J : QInterval × QInterval) (R B : QPos) (hs : rectangleSeparated J R)
    (hxl : -B.val≤J.1.lo) (hxu : J.1.hi≤B.val)
    (hyl : -B.val≤J.2.lo) (hyu : J.2.hi≤B.val)
    (hB : B.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (c : Scalar) (hc : (hecke41CauchyIntegrandMap k a).domain c)
    (p q : QComplex) (hp : rationalRectangleContains J p) (hq : rationalRectangleContains J q)
    (W eps : QPos) (hd : Small (sub (ofQComplex q) (ofQComplex p)) W.val)
    (hpc : Small (Centered.offset c (rationalRectangleScalar p)).val
      ((hecke41CauchyIntegrandMap_holomorphic k a).continuousDerivative.delta c hc eps).val)
    (hqc : Small (Centered.offset c (rationalRectangleScalar q)).val
      ((hecke41CauchyIntegrandMap_holomorphic k a).continuousDerivative.delta c hc eps).val) :
    Small (sub (hecke41KernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB q).val
      (affineMidpointModel (hecke41KernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB p)
        ((hecke41CauchyIntegrandMap_holomorphic k a).derivative c hc)
        (Centered.offset (rationalRectangleScalar p) (rationalRectangleScalar q))).val)
      (4*eps.val*W.val) := by
  let f := hecke41CauchyIntegrandMap k a
  let hf := hecke41CauchyIntegrandMap_holomorphic k a
  let d := hf.derivative c hc
  let P := rationalRectangleScalar p
  let Q := rationalRectangleScalar q
  have hP : f.domain P := hecke41KernelRectangle_domain k a ha J R B hs hxl hxu hyl hyu hB P
    (rationalRectangle_represented_mem J p hp)
  have hQ : f.domain Q := hecke41KernelRectangle_domain k a ha J R B hs hxl hxu hyl hyu hB Q
    (rationalRectangle_represented_mem J q hq)
  have hr := domainNeighborhood_segment_remainder_bound f hf c P Q hc hP hQ W eps
    (fun t => hecke41KernelRectangle_domain k a ha J R B hs hxl hxu hyl hyu hB _
      (representedAffine_rational_rectangle_mem J p q hp hq t)) hd hpc hqc
  have hb := Small.congr (remainder_valid f P hP d Q hQ)
    (sub_valid (f.eval Q hQ).property (affineMidpointModel (f.eval P hP) d (Centered.offset P Q)).property)
    (equiv_symm (localAffineModel_error_equiv f P d Q hP hQ)) hr
  simp only [hecke41KernelRectangleSample,dif_pos hp,dif_pos hq]
  exact hb


theorem hecke41KernelRectangleSample_cycle_bound (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (J : QInterval × QInterval) (R B : QPos) (hs : rectangleSeparated J R)
    (hxl : -B.val≤J.1.lo) (hxu : J.1.hi≤B.val)
    (hyl : -B.val≤J.2.lo) (hyu : J.2.hi≤B.val)
    (hB : B.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (c : Scalar) (hc : (hecke41CauchyIntegrandMap k a).domain c) (eps H : QPos)
    (hX : J.1.lo≤J.1.hi) (hY : J.2.lo≤J.2.hi)
    (hx : J.1.width≤2*H.val) (hy : J.2.width≤2*H.val)
    (hnear : ∀ q : QComplex, rationalRectangleContains J q →
      Small (Centered.offset c (rationalRectangleScalar q)).val
        ((hecke41CauchyIntegrandMap_holomorphic k a).continuousDerivative.delta c hc eps).val) :
    Small (fullRectangleMidpointCycle (hecke41KernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB) J).val
      (64*eps.val*H.val*H.val) := by
  have hm := (rectangleMidpoints_mem J hX hY).1
  have hb := rectangleSampleModel_full_cycle_bound (hecke41KernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB) J
    ((hecke41CauchyIntegrandMap_holomorphic k a).derivative c hc) (4*eps.val*H.val) H
    (Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) (Rat.le_of_lt eps.property))
      (Rat.le_of_lt H.property)) hX hY hx hy
    (fun q hq hd => hecke41KernelRectangleSample_model_error k a ha J R B hs hxl hxu hyl hyu hB c hc
      (rectangleCenter J) q hm hq H eps hd (hnear _ hm) (hnear _ hq))
  have he : 16*(4*eps.val*H.val)*H.val=64*eps.val*H.val*H.val := by grind only
  rw [he] at hb
  exact hb

end ComputableAnalysis.ModularForms
