import ComputableAnalysis.ModularForms.Hecke41SimplePoleShrinkingRadius
import ComputableAnalysis.ModularForms.Hecke41SimplePoleShrinkingApproximation

/-! Cauchy value reconstruction for the actual weighted nome coefficient. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

private theorem difference_add (x p y : Scalar) :
    (add (sub x.val p.val) (sub p.val y.val)).Equiv (sub x.val y.val) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := add_valid (sub_valid x.property p.property) (sub_valid p.property y.property))
    (hright := sub_valid x.property y.property)
  change (gridScalarValue x-gridScalarValue p)+(gridScalarValue p-gridScalarValue y)=
    gridScalarValue x-gridScalarValue y
  grind only

theorem hecke41SimplePoleContourLimit_cauchy_value (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hg : R.val≤(hecke41NomeGeometricRadius a ha).val)
    (hd : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) :
    (hecke41SimplePoleContourLimit k a ha R hg hd PDE.CauchyContour.square).val.Equiv
      (scalarProduct ((hecke41NomeDescended k 10000).eval a ha) ⟨twoPiI,twoPiI_valid⟩).val := by
  let x := hecke41SimplePoleContourLimit k a ha R hg hd PDE.CauchyContour.square
  let y := scalarProduct ((hecke41NomeDescended k 10000).eval a ha) ⟨twoPiI,twoPiI_valid⟩
  apply SeriesLimitLaws.equiv_of_small_sub_zero
  apply SeriesLimitLaws.small_closed (sub x.val y.val) 0
    (fun j => 2*(RepresentedCauchySum.error j).val)
    (SeriesLimitLaws.shrinks_scale _ RepresentedCauchySum.error_shrinks 2 (by decide +kernel))
  intro j
  let eps := RepresentedCauchySum.error j
  obtain ⟨K,hK⟩ := squareShrinkingRadius_shrinks R (hecke41SimplePoleApproximationRadius k a ha eps)
  let S := squareShrinkingRadius R K
  let hSg := Rat.le_trans (squareShrinkingRadius_le R K) hg
  let hSd := Rat.le_trans (squareShrinkingRadius_le R K) hd
  let hS := hK K (Nat.le_refl K)
  let z := hecke41SimplePoleContourLimit k a ha S hSg hSd PDE.CauchyContour.square
  obtain ⟨X,hX⟩ := hecke41SimplePoleFiniteSquare_converges k a ha S hSg hSd eps
  obtain ⟨Y,hY⟩ := hecke41SimplePole_actual_shrinking_approximation k a ha eps
  let n := max X Y
  let p := hecke41SimplePoleFiniteContour false k a ha S hSg (2^n)
    (Nat.pow_pos (by decide +kernel)) PDE.CauchyContour.square
  have hp : Small (sub p.val y.val) eps.val := hY S hS n (Nat.le_max_right _ _)
  have hb := LocalODE.small_add (hX n (Nat.le_max_left _ _)) hp
  have hz := Small.congr
    (add_valid (sub_valid z.property p.property) (sub_valid p.property y.property))
    (sub_valid z.property y.property) (difference_add z p y) hb
  have he := FunctionTheory.sub_congr
    (equiv_symm (hecke41SimplePoleContourLimit_shrinking_radius k a ha R hg hd K))
    (equiv_refl _ y.property)
  have ht := Small.congr (sub_valid z.property y.property) (sub_valid x.property y.property) he hz
  have hr (e : Rat) : e+e=0+2*e := by grind only
  rw [hr] at ht
  exact ht

end ComputableAnalysis.ModularForms
