import ComputableAnalysis.ModularForms.Hecke41UniformCuspDerivativeBounds

/-! A quantitative zero limit for the actual quadratic-weight nome derivative. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

def hecke41CuspDerivativeRate : QPos :=
  ⟨hecke41QuadraticCuspDerivativeCoefficient+1,by
    have hp := hecke41QuadraticCuspDerivativeCoefficient_nonneg
    grind only⟩

def hecke41CuspDerivativeZeroRadius (eps : QPos) : QPos :=
  minRadius (⟨hecke41NomeCoverRadius.val/4,by
    rw [Rat.div_def]
    exact Rat.mul_pos hecke41NomeCoverRadius.property (by decide +kernel)⟩ : QPos)
    (divideRadius eps hecke41CuspDerivativeRate)

theorem hecke41NomeQuadraticDerivative_zero_limit (eps : QPos) (k : Nat) (q : Scalar)
    (hq : hecke41NomePuncturedDomain q)
    (hs : Small q.val (hecke41CuspDerivativeZeroRadius eps).val) :
    Small ((hecke41NomeDescended_holomorphic k 10002).derivative q hq).val eps.val := by
  have hn : Small q.val (hecke41NomeCoverRadius.val/4) := hs.mono (minRadius_left _ _)
  have hb := hecke41NomeQuadraticDerivative_uniform_cusp_bound k q hq hn
    (hecke41CuspDerivativeZeroRadius eps).val (Rat.le_of_lt (hecke41CuspDerivativeZeroRadius eps).property) hs
  apply hb.mono
  have hr := minRadius_right
    (⟨hecke41NomeCoverRadius.val/4,by
      rw [Rat.div_def]
      exact Rat.mul_pos hecke41NomeCoverRadius.property (by decide +kernel)⟩ : QPos)
    (divideRadius eps hecke41CuspDerivativeRate)
  have hm := Rat.mul_le_mul_of_nonneg_left hr (Rat.le_of_lt hecke41CuspDerivativeRate.property)
  rw [divideRadius_identity] at hm
  have hc : hecke41QuadraticCuspDerivativeCoefficient≤hecke41CuspDerivativeRate.val := by
    change hecke41QuadraticCuspDerivativeCoefficient≤hecke41QuadraticCuspDerivativeCoefficient+1
    grind only
  exact Rat.le_trans (Rat.mul_le_mul_of_nonneg_right hc
    (Rat.le_of_lt (hecke41CuspDerivativeZeroRadius eps).property)) hm

end ComputableAnalysis.ModularForms
