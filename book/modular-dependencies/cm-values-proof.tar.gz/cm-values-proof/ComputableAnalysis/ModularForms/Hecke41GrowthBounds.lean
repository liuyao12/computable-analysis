import ComputableAnalysis.ModularForms.Hecke41CoefficientHolomorphic
import ComputableAnalysis.ModularForms.CMHeckeFiniteDiscriminant41
import ComputableAnalysis.ModularForms.NomeGrowthRadius
import ComputableAnalysis.ModularForms.NomeInverseGrowth

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- Actual exponential of the nome height growth, as a represented real. -/
def nomeGrowthExponential (z : Scalar) : RealRaw :=
  (entireExponentialValue ⟨ofRealRaw (nomeHeightGrowth z),
    ofRealRaw_valid _ (nomeHeightGrowth_valid z)⟩).val.realPart

def nomeDoubleGrowthExponential (z : Scalar) : RealRaw :=
  (entireExponentialValue ⟨ofRealRaw (RealRaw.scaleRat 2 (nomeHeightGrowth z)),
    ofRealRaw_valid _ (RealRaw.scaleRat_valid (nomeHeightGrowth_valid z))⟩).val.realPart

/-- Growth estimates construct the actual lattice j domain; no j-domain
or discriminant reciprocal is assumed. -/
theorem latticeJMap_growth_domain (z : Scalar) (hz : InUpperHalfPlane z.val)
    (L B : Rat) (hL : 0<L) (hB : 0≤B) (hs : 1/L≤(1:Rat)/65536)
    (hguard : 440*(1/L)*(1/L)*B≤(1:Rat)/8)
    (hl : (RealRaw.ofRat L).Le (nomeGrowthExponential z))
    (hb : (nomeDoubleGrowthExponential z).Le (RealRaw.ofRat (B*B))) : latticeJMap.domain z := by
  have hr : 0≤1/L := by
    rw [Rat.div_def,Rat.one_mul]
    exact Rat.le_of_lt (Rat.inv_pos.mpr hL)
  have hg : 128*(1/L)≤(1:Rat)/2 := by grind
  have hq := nome_small_of_growth_exponential_lower z hz L hL hl
  have hu := nome_inverse_small_of_double_growth_upper z hz B hB hb
  have hd := nomeModularDiscriminant_wide_nonzero (nome.eval z hz) (1/L) B hr hg hq
    (show 1/L≤(1:Rat)/512 by grind) (nome_nonzero z hz) hB hu (by grind)
  exact latticeJMap_domain_of_fourier_nonzero z hz (1/L) hr hg hq hd

/-- Actual j size control from real height-growth exponential estimates. -/
theorem latticeJMap_growth_size (z : Scalar) (hz : InUpperHalfPlane z.val)
    (L B : Rat) (hL : 0<L) (hB : 0≤B) (hs : 1/L≤(1:Rat)/65536)
    (hguard : 440*(1/L)*(1/L)*B≤(1:Rat)/8)
    (hl : (RealRaw.ofRat L).Le (nomeGrowthExponential z))
    (hb : (nomeDoubleGrowthExponential z).Le (RealRaw.ofRat (B*B))) :
    Small (latticeJMap.eval z (latticeJMap_growth_domain z hz L B hL hB hs hguard hl hb)).val
      (B+744+512000000*(1/L)*(1/L)*(1/L)*B*B) := by
  have hr : 0≤1/L := by
    rw [Rat.div_def,Rat.one_mul]
    exact Rat.le_of_lt (Rat.inv_pos.mpr hL)
  have hg : 128*(1/L)≤(1:Rat)/2 := by grind
  exact latticeJMap_size_bound z _ (1/L) B hr hg
    (nome_small_of_growth_exponential_lower z hz L hL hl) hs hB
    (nome_inverse_small_of_double_growth_upper z hz B hB hb) hguard

/-- Heterogeneous growth bounds construct all actual correspondence evaluator domains. -/
theorem hecke41CommonDomain_of_growth (z : Scalar) (hz : InUpperHalfPlane z.val)
    (L B : Fin 42 → Rat) (hL : ∀ i, 0<L i) (hB : ∀ i, 0≤B i)
    (hs : ∀ i, 1/L i≤(1:Rat)/65536)
    (hguard : ∀ i, 440*(1/L i)*(1/L i)*B i≤(1:Rat)/8)
    (hl : ∀ i, (RealRaw.ofRat (L i)).Le (nomeGrowthExponential (hecke41Point i z)))
    (hb : ∀ i, (nomeDoubleGrowthExponential (hecke41Point i z)).Le (RealRaw.ofRat (B i*B i))) :
    hecke41CommonDomain z :=
  ⟨hz,fun i => latticeJMap_growth_domain (hecke41Point i z) (hecke41Point_upper i z hz)
    (L i) (B i) (hL i) (hB i) (hs i) (hguard i) (hl i) (hb i)⟩

/-- Coefficient bounds with domains constructed from actual growth estimates,
using separate bounds for each affine or dilation point. -/
theorem hecke41PolynomialCoefficient_growth_bound (k : Nat) (z : Scalar) (hz : InUpperHalfPlane z.val)
    (L B : Fin 42 → Rat) (hL : ∀ i, 0<L i) (hB : ∀ i, 0≤B i)
    (hs : ∀ i, 1/L i≤(1:Rat)/65536)
    (hguard : ∀ i, 440*(1/L i)*(1/L i)*B i≤(1:Rat)/8)
    (hl : ∀ i, (RealRaw.ofRat (L i)).Le (nomeGrowthExponential (hecke41Point i z)))
    (hb : ∀ i, (nomeDoubleGrowthExponential (hecke41Point i z)).Le (RealRaw.ofRat (B i*B i)))
    (J : Rat) (hJ : 0≤J)
    (hc : ∀ i, B i+744+512000000*(1/L i)*(1/L i)*(1/L i)*B i*B i≤J) :
    Small ((hecke41PolynomialCoefficient k).value z
      (hecke41CommonDomain_of_growth z hz L B hL hB hs hguard hl hb)).val ((1+2*J)^42) := by
  apply hecke41PolynomialCoefficient_small k z _ J hJ
  intro i
  exact (latticeJMap_growth_size (hecke41Point i z) (hecke41Point_upper i z hz)
    (L i) (B i) (hL i) (hB i) (hs i) (hguard i) (hl i) (hb i)).mono (hc i)

end ComputableAnalysis.ModularForms
