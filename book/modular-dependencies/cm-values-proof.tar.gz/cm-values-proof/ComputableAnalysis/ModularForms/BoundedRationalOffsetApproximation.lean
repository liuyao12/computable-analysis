import ComputableAnalysis.RiemannHilbert.RationalNeighborhoods
import ComputableAnalysis.ModularForms.Hecke41NomeHolomorphicDescent

/-! Executable rational offset approximation with value bounds and actual domain preservation. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

def boundedRationalOffset (b : Scalar) (r s : Rat) (hrs : r<s) (eps : QPos) : QComplex :=
  ScalarTopology.rationalCenter b (QPos.minimum eps ⟨s-r,by grind only⟩)

theorem boundedRationalOffset_error (b : Scalar) (r s : Rat) (hrs : r<s) (eps : QPos) :
    Small (sub b.val (rationalRectangleScalar (boundedRationalOffset b r s hrs eps)).val) eps.val := by
  let eta := QPos.minimum eps (⟨s-r,by grind only⟩ : QPos)
  have he := ScalarTopology.rationalCenter_error b eta
  have hq := ScalarTopology.quarterRadius_identity eta
  have hp := eta.property
  have hl := QPos.minimum_le_left eps (⟨s-r,by grind only⟩ : QPos)
  exact he.mono (by change (ScalarTopology.quarterRadius eta).val≤eps.val; grind only)

theorem boundedRationalOffset_bound (b : Scalar) (r s : Rat) (hrs : r<s)
    (hb : Small b.val r) (eps : QPos) :
    Small (rationalRectangleScalar (boundedRationalOffset b r s hrs eps)).val s := by
  let eta := QPos.minimum eps (⟨s-r,by grind only⟩ : QPos)
  let q := rationalRectangleScalar (boundedRationalOffset b r s hrs eps)
  have he := ScalarTopology.rationalCenter_error b eta
  have hq := ScalarTopology.quarterRadius_identity eta
  have hp := eta.property
  have hl := QPos.minimum_le_right eps (⟨s-r,by grind only⟩ : QPos)
  have hs := LocalODE.small_add hb (SeriesLimitLaws.small_neg he)
  have hidentity : (add b.val (neg (sub b.val q.val))).Equiv q.val := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := add_valid b.property (neg_valid (sub_valid b.property q.property))) (hright := q.property)
    let B := ComplexRawQuotient.ofRaw b.val b.property
    let Q := ComplexRawQuotient.ofRaw q.val q.property
    change B+ -(B-Q)=Q
    grind only
  have h := Small.congr (add_valid b.property (neg_valid (sub_valid b.property q.property))) q.property hidentity hs
  exact h.mono (by change r+(ScalarTopology.quarterRadius eta).val≤s; grind only)

private theorem translated_difference (a x y : Scalar) :
    (sub x.val y.val).Equiv (sub (Centered.translate a x).val (Centered.translate a y).val) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq (hleft := sub_valid x.property y.property)
    (hright := sub_valid (Centered.translate a x).property (Centered.translate a y).property)
  let A := ComplexRawQuotient.ofRaw a.val a.property
  let X := ComplexRawQuotient.ofRaw x.val x.property
  let Y := ComplexRawQuotient.ofRaw y.val y.property
  change X-Y=(A+X)-(A+Y)
  grind only

theorem boundedRationalOffset_preserves_domain (D : Scalar → Prop) (hD : ScalarTopology.OpenData D) (a b : Scalar) (r s : Rat) (hrs : r<s)
    (hb : Small b.val r) (hab : D (Centered.translate a b)) (eps : QPos) :
    ∃ c : QComplex, Small (sub b.val (rationalRectangleScalar c).val) eps.val ∧
      Small (rationalRectangleScalar c).val s ∧ D (Centered.translate a (rationalRectangleScalar c)) := by
  let rho := hD.radius (Centered.translate a b) hab
  let eta := QPos.minimum eps rho
  let c := boundedRationalOffset b r s hrs eta
  let q := rationalRectangleScalar c
  have he := boundedRationalOffset_error b r s hrs eta
  have hq := boundedRationalOffset_bound b r s hrs hb eta
  have hrho := QPos.minimum_le_right eps rho
  have hclose := RepresentedCauchySum.small_sub_symm b.val q.val eta.val he
  have ht := Small.congr (sub_valid q.property b.property)
    (sub_valid (Centered.translate a q).property (Centered.translate a b).property)
    (translated_difference a q b) hclose
  refine ⟨c,he.mono (QPos.minimum_le_left eps rho),hq,?_⟩
  exact hD.inside (Centered.translate a b) hab (Centered.translate a q)
    (ht.mono hrho)

theorem hecke41Nome_bounded_rational_offset (a b : Scalar) (r s : Rat) (hrs : r<s)
    (hb : Small b.val r) (hab : hecke41NomePuncturedDomain (Centered.translate a b)) (eps : QPos) :
    ∃ c : QComplex, Small (sub b.val (rationalRectangleScalar c).val) eps.val ∧
      Small (rationalRectangleScalar c).val s ∧ hecke41NomePuncturedDomain (Centered.translate a (rationalRectangleScalar c)) :=
  boundedRationalOffset_preserves_domain hecke41NomePuncturedDomain hecke41NomePuncturedDomain_openData a b r s hrs hb hab eps

end ComputableAnalysis.ModularForms
