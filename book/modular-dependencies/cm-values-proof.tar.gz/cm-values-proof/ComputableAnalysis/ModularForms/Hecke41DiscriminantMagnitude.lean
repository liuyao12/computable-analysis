import ComputableAnalysis.ModularForms.DiscriminantWeightedMassBound

namespace ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct

/-- Closed integer/rational arithmetic verifying the chosen packing base
against the proved degree bound and the candidate magnitude ceiling. -/
theorem hecke41Discriminant_magnitude_ceiling :
    (3/2:Rat)^24*(4:Rat)^1723+(1207441533568463972:Rat)<
      (((2^3500:Int).natAbs):Rat) := by
  decide +kernel

/-- All requested degrees obey the same checked packing-base ceiling. -/
theorem hecke41Discriminant_degree_ceiling (n : Nat) (hn : n<1723) :
    (3/2:Rat)^24*(4:Rat)^n+(1207441533568463972:Rat)<
      (((2^3500:Int).natAbs):Rat) := by
  have hpow : (4:Rat)^n≤(4:Rat)^1723 := by
    change ((4:Nat):Rat)^n≤((4:Nat):Rat)^1723
    rw [←Rat.natCast_pow,←Rat.natCast_pow]
    exact Rat.natCast_le_natCast.mpr (Nat.pow_le_pow_of_le (by decide : 1<4) (by omega))
  have hr : (0:Rat)≤3/2 := by decide +kernel
  have hc := nonneg_radius_power (3/2) hr 24
  have h := Rat.mul_le_mul_of_nonneg_left hpow hc
  have hmax := hecke41Discriminant_magnitude_ceiling
  grind only

end ComputableAnalysis.ModularForms.PackedIntegerPolynomialProduct
