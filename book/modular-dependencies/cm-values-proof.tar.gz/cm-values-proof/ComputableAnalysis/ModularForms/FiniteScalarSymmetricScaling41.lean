import ComputableAnalysis.ModularForms.IntegerAffineHeckeSymmetricLimit41

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

def symmetricScaledScalar41 (q x : Scalar) : Scalar :=
  ⟨mul q.val x.val,mul_valid q.property x.property⟩

private def symClass (xs : List Scalar) (k : Nat) : ScalarAlgebra.Value :=
  ComplexRawQuotient.ofRaw (representedElementarySymmetric41 xs k) (representedElementarySymmetric41_valid xs k)

private theorem scale_class (q : Scalar) (xs : List Scalar) (k : Nat) :
    symClass (xs.map (symmetricScaledScalar41 q)) k=
      (ComplexRawQuotient.ofRaw q.val q.property)^k*symClass xs k := by
  induction xs generalizing k with
  | nil =>
    cases k with
    | zero => change (1 : ScalarAlgebra.Value)=1*1; grind only
    | succ k => change (0 : ScalarAlgebra.Value)=_^ (k+1)*0; grind only
  | cons x xs ih =>
    cases k with
    | zero => change (1 : ScalarAlgebra.Value)=1*1; grind only
    | succ k =>
      let Q := ComplexRawQuotient.ofRaw q.val q.property
      let X := ComplexRawQuotient.ofRaw x.val x.property
      change symClass (xs.map (symmetricScaledScalar41 q)) (k+1)+
        (Q*X)*symClass (xs.map (symmetricScaledScalar41 q)) k=
        Q^(k+1)*(symClass xs (k+1)+X*symClass xs k)
      rw [ih (k+1),ih k]
      change Q^k*Q*symClass xs (k+1)+(Q*X)*(Q^k*symClass xs k)=
        (Q^k*Q)*(symClass xs (k+1)+X*symClass xs k)
      grind only

/-- Scaling all represented factors by a common scalar scales symmetric
 degree k by the actual kth power, for arbitrary valid represented factors. -/
theorem representedElementarySymmetric41_scaling (q : Scalar) (xs : List Scalar) (k : Nat) :
    (representedElementarySymmetric41 (xs.map (symmetricScaledScalar41 q)) k).Equiv
      (mul (LocalODE.power q.val k) (representedElementarySymmetric41 xs k)) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := representedElementarySymmetric41_valid _ k)
    (hright := mul_valid (LocalODE.power_valid _ q.property k) (representedElementarySymmetric41_valid xs k))
  rw [ComplexRawQuotient.ofRaw_mul,ScalarAlgebra.ofRaw_power q.val q.property k]
  · exact scale_class q xs k
  · exact LocalODE.power_valid _ q.property k

end ComputableAnalysis.ModularForms
