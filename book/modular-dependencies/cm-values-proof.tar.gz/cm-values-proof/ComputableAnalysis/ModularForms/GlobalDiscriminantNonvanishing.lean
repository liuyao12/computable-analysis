import ComputableAnalysis.ModularForms.ModularReductionTermination
import ComputableAnalysis.ModularForms.ReducedHeightNomeDomain
import ComputableAnalysis.ModularForms.WideLatticeDiscriminantNonvanishing

/-! Global nonvanishing of the actual lattice discriminant from executable modular reduction and the proved Euler chart. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory
set_option maxRecDepth 4000

/-- The constructed reduction matrix sends every represented input to height at least three quarters. -/
theorem modularReductionMatrix_height (z : UpperPoint) :
    (RealRaw.ofRat (3/4)).Le
      (fractionalLinear (modularReductionMatrix z) z.val z.property).val.imagPart := by
  have he := imagPart_equiv (modularReducedPoint_action z)
  exact RealRaw.le_trans (imagPart_valid (modularReducedPoint z).val.property)
    (modularReducedPoint_height z)
    (RealRaw.le_of_equiv (imagPart_valid (modularReducedPoint z).val.property)
      (imagPart_valid (fractionalLinear (modularReductionMatrix z) z.val z.property).property) he)

/-- Reduction constructs the full wider Euler chart for every represented upper-plane input. -/
theorem modularReductionMatrix_nome_domain (z : UpperPoint) :
    wideLambertFifthDomain
      (nome.eval (fractionalLinear (modularReductionMatrix z) z.val z.property)
        (fractionalLinear_mem _ _ _)) :=
  nome_reduced_height_wide_domain _ (fractionalLinear_mem _ _ _) (modularReductionMatrix_height z)

/-- The actual normalized lattice discriminant is nonzero everywhere in the represented upper half-plane. -/
theorem normalizedLatticeDiscriminantMap_global_nonzero (z : Scalar) (hz : InUpperHalfPlane z.val) :
    NonzeroBoxSearch.Nonzero (normalizedLatticeDiscriminantMap.eval z hz) :=
  normalizedLatticeDiscriminantMap_nonzero_of_transformed_wide_disk
    (modularReductionMatrix ⟨z,hz⟩) z hz (modularReductionMatrix_nome_domain ⟨z,hz⟩)

/-- The actual unnormalized lattice discriminant is globally nonzero as well. -/
theorem latticeDiscriminantMap_global_nonzero (z : Scalar) (hz : InUpperHalfPlane z.val) :
    NonzeroBoxSearch.Nonzero (latticeDiscriminantMap.eval z hz) :=
  (normalizedLatticeDiscriminantMap_nonzero_iff z hz).mp
    (normalizedLatticeDiscriminantMap_global_nonzero z hz)

/-- The actual lattice j evaluator has its complete mathematical upper-plane domain. -/
theorem latticeJMap_global_domain (z : Scalar) (hz : InUpperHalfPlane z.val) :
    latticeJMap.domain z := ⟨hz,latticeDiscriminantMap_global_nonzero z hz⟩

theorem latticeJMap_domain_iff_upper (z : Scalar) : latticeJMap.domain z ↔ InUpperHalfPlane z.val :=
  ⟨fun h => h.1,latticeJMap_global_domain z⟩

/-- Every actual prime-Hecke discrepancy quotient has its full upper-plane domain. -/
theorem discriminantPrimeHeckeDifferenceQuotient_global_domain (p : Nat) (hp : 0<(p:Rat))
    (z : Scalar) (hz : InUpperHalfPlane z.val) :
    (discriminantPrimeHeckeDifferenceQuotient p hp).domain z :=
  ⟨hz,normalizedLatticeDiscriminantMap_global_nonzero z hz⟩

end ComputableAnalysis.ModularForms
