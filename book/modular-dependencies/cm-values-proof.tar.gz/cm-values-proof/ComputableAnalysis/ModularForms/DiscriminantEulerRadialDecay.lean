import ComputableAnalysis.ModularForms.DiscriminantEulerDividedBound
import ComputableAnalysis.ModularForms.RationalScalingReciprocal
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- The actual divided discrepancy decays linearly along each positive rational radial scaling.
All radius and reciprocal bounds concern supplied represented values. -/
theorem discriminantEulerDividedMap_radial_bound (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R S t : Rat) (hR : 0≤R) (hS : 0≤S) (ht : 0<t) (hqr : Small q.val R)
    (hi : Small (RepresentedReciprocal.inverse q hq).val S)
    (hsmall : t*R≤(1:Rat)/65536)
    (hd : tauEulerNomeDomain (rationalScaledScalar t q)) :
    Small (discriminantEulerDividedMap.eval (rationalScaledScalar t q)
      ⟨rationalScaledScalar_nonzero t (Rat.ne_of_gt ht) q hq,hd⟩).val (21072*S*R*R*t) := by
  have htr : 0≤t*R := Rat.mul_nonneg (Rat.le_of_lt ht) hR
  have hts : 0≤t⁻¹*S := Rat.mul_nonneg (Rat.le_of_lt (Rat.inv_pos.mpr ht)) hS
  have hz := LocalODE.small_scale (c := t) (Rat.le_of_lt ht) hqr
  have hgi : 128*(t*R)≤(1:Rat)/2 := by grind only
  have hinv := rationalScaledScalar_inverse_bound t ht q hq S hi
  have hh := discriminantEulerDividedMap_bound (rationalScaledScalar t q)
    ⟨rationalScaledScalar_nonzero t (Rat.ne_of_gt ht) q hq,hd⟩ (t*R) (t⁻¹*S)
    htr hts hgi hz hsmall hinv
  apply hh.mono
  have he : t*t⁻¹=1 := Rat.mul_inv_cancel t (Rat.ne_of_gt ht)
  calc 21072*(t⁻¹*S)*(t*R)*(t*R)=21072*S*R*R*t*(t*t⁻¹) := by grind only
       _ =21072*S*R*R*t := by rw [he,Rat.mul_one]
       _ ≤21072*S*R*R*t := Rat.le_refl
/-- The actual derivative has the same radial decay, with the checked coefficient constant. -/
theorem discriminantEulerDividedMap_radial_derivative_bound (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R S t : Rat) (hR : 0≤R) (hS : 0≤S) (ht : 0<t) (hqr : Small q.val R)
    (hi : Small (RepresentedReciprocal.inverse q hq).val S)
    (hsmall : t*R≤(1:Rat)/65536)
    (hd : tauEulerNomeDomain (rationalScaledScalar t q)) :
    Small (discriminantEulerDividedMap_holomorphic.derivative (rationalScaledScalar t q)
      ⟨rationalScaledScalar_nonzero t (Rat.ne_of_gt ht) q hq,hd⟩).val (768*(21072*S*R*R*t)) := by
  apply discriminantEulerDividedMap_derivative_bound
  · exact Rat.mul_nonneg (Rat.mul_nonneg (Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hS) hR) hR) (Rat.le_of_lt ht)
  · exact discriminantEulerDividedMap_radial_bound q hq R S t hR hS ht hqr hi hsmall hd
/-- Small rational radial points have constructed nome-domain evidence. -/
theorem rationalScaledScalar_nomeDomain (q : Scalar) (R t : Rat) (hR : 0≤R) (ht : 0≤t)
    (hqr : Small q.val R) (hs : t*R≤(1:Rat)/65536) :
    tauEulerNomeDomain (rationalScaledScalar t q) := by
  refine ⟨t*R,Rat.mul_nonneg ht hR,?_,LocalODE.small_scale ht hqr⟩
  have hh : (1:Rat)/65536<(1:Rat)/1024 := by decide +kernel
  grind only
/-- The radial bound with all domain and nonvanishing evidence constructed. -/
theorem discriminantEulerDividedMap_radial_decay (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R S t : Rat) (hR : 0≤R) (hS : 0≤S) (ht : 0<t) (hqr : Small q.val R)
    (hi : Small (RepresentedReciprocal.inverse q hq).val S) (hs : t*R≤(1:Rat)/65536) :
    Small (discriminantEulerDividedMap.eval (rationalScaledScalar t q)
      ⟨rationalScaledScalar_nonzero t (Rat.ne_of_gt ht) q hq,
        rationalScaledScalar_nomeDomain q R t hR (Rat.le_of_lt ht) hqr hs⟩).val (21072*S*R*R*t) :=
  discriminantEulerDividedMap_radial_bound q hq R S t hR hS ht hqr hi hs
    (rationalScaledScalar_nomeDomain q R t hR (Rat.le_of_lt ht) hqr hs)
/-- Every supplied shrinking positive rational radial schedule gives actual convergence to zero.
The domain witnesses are constructed rather than required of the schedule. -/
theorem discriminantEulerDividedMap_radial_limit (q : Scalar) (hq : NonzeroBoxSearch.Nonzero q)
    (R S : Rat) (hR : 0≤R) (hS : 0≤S) (hqr : Small q.val R)
    (hi : Small (RepresentedReciprocal.inverse q hq).val S)
    (t : Nat → Rat) (ht : ∀ n, 0<t n) (hs : ∀ n, t n*R≤(1:Rat)/65536)
    (hlim : ShrinksToZero t) :
    ∀ eps : QPos, ∃ N : Nat, ∀ n, N≤n →
      Small (discriminantEulerDividedMap.eval (rationalScaledScalar (t n) q)
        ⟨rationalScaledScalar_nonzero (t n) (Rat.ne_of_gt (ht n)) q hq,
          rationalScaledScalar_nomeDomain q R (t n) hR (Rat.le_of_lt (ht n)) hqr (hs n)⟩).val eps.val := by
  have hc : 0≤21072*S*R*R := Rat.mul_nonneg (Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) hS) hR) hR
  have hl := SeriesLimitLaws.shrinks_scale t hlim (21072*S*R*R) hc
  intro eps
  obtain ⟨N,hN⟩ := hl eps
  refine ⟨N,?_⟩
  intro n hn
  exact (discriminantEulerDividedMap_radial_decay q hq R S (t n) hR hS (ht n) hqr hi (hs n)).mono (hN n hn)
end ComputableAnalysis.ModularForms
