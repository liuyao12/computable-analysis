import ComputableAnalysis.ModularForms.Hecke41RationalHeight
import ComputableAnalysis.ModularForms.RationalExponentialPowerBounds
import ComputableAnalysis.ModularForms.RealExponentialSmallSharpBounds

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory
set_option maxRecDepth 8192
set_option maxHeartbeats 4000000

def hecke41CuspLowerExponent (i : Fin 42) : Nat := if i.val=41 then 77000 else 45
def hecke41CuspUpperExponent (i : Fin 42) : Nat := if i.val=41 then 158000 else 96
def hecke41CuspL (i : Fin 42) : Rat := 2^hecke41CuspLowerExponent i
def hecke41CuspB (i : Fin 42) : Rat := 3^(hecke41CuspUpperExponent i / 2)

private theorem exponential_one_lower : (RealRaw.ofRat 2).Le
    (entireExponentialValue ⟨ofQComplex ⟨1,0⟩,ofQComplex_valid _⟩).val.realPart :=
  by simpa only [show (1:Rat)+1=2 by decide +kernel] using
    entireExponential_rational_real_linear_lower 1 (by decide +kernel)

private theorem exponential_one_upper :
    (entireExponentialValue ⟨ofQComplex ⟨1,0⟩,ofQComplex_valid _⟩).val.realPart.Le (RealRaw.ofRat 3) :=
  RealRaw.le_trans (show (RealRaw.ofRat (11/4)).Valid from RealRaw.ofRat_valid _) entireExponential_rational_one_upper_eleven_quarters
    (fun _ _ => show (11/4:Rat)≤3 by decide +kernel)

theorem hecke41Cusp_lower_exponential (i : Fin 42) : (RealRaw.ofRat (hecke41CuspL i)).Le
    (entireExponentialValue ⟨ofQComplex ⟨(hecke41CuspLowerExponent i:Rat),0⟩,ofQComplex_valid _⟩).val.realPart := by
  simpa only [Rat.mul_one,hecke41CuspL] using entireExponential_rational_nat_power_lower 1 2
    (hecke41CuspLowerExponent i) (by decide +kernel) exponential_one_lower

theorem hecke41Cusp_upper_exponential (i : Fin 42) :
    (entireExponentialValue ⟨ofQComplex ⟨(hecke41CuspUpperExponent i:Rat),0⟩,ofQComplex_valid _⟩).val.realPart.Le
      (RealRaw.ofRat (hecke41CuspB i*hecke41CuspB i)) := by
  have h := entireExponential_rational_nat_power_upper 1 3 (hecke41CuspUpperExponent i)
    (by decide +kernel) (by decide +kernel) exponential_one_upper
  simp only [Rat.mul_one] at h
  have he : (3:Rat)^hecke41CuspUpperExponent i = hecke41CuspB i*hecke41CuspB i := by
    by_cases hi : i.val=41
    · simp only [hecke41CuspUpperExponent,hecke41CuspB,if_pos hi]
      decide +kernel
    · simp only [hecke41CuspUpperExponent,hecke41CuspB,if_neg hi]
      decide +kernel
  rw [he] at h
  exact h

theorem hecke41Cusp_guards (i : Fin 42) :
    0<hecke41CuspL i ∧ 0≤hecke41CuspB i ∧ 1/hecke41CuspL i≤(1:Rat)/65536 ∧
      440*(1/hecke41CuspL i)*(1/hecke41CuspL i)*hecke41CuspB i≤(1:Rat)/8 := by
  by_cases hi : i.val=41
  · simp only [hecke41CuspL,hecke41CuspB,hecke41CuspLowerExponent,hecke41CuspUpperExponent,if_pos hi]
    decide +kernel
  · simp only [hecke41CuspL,hecke41CuspB,hecke41CuspLowerExponent,hecke41CuspUpperExponent,if_neg hi]
    decide +kernel

/-- Every represented point in this explicit high cusp band has all actual
correspondence j evaluators justified, with no supplied exponential estimates. -/
theorem hecke41CommonDomain_cusp_band (z : Scalar) (hz : InUpperHalfPlane z.val)
    (hl : (RealRaw.ofRat 300).Le z.val.imagPart) (hu : z.val.imagPart.Le (RealRaw.ofRat 301)) :
    hecke41CommonDomain z := by
  apply hecke41CommonDomain_of_rational_height z hz 300 301 (1/2)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) hl hu
    (fun i => (hecke41CuspLowerExponent i:Rat)) (fun i => (hecke41CuspUpperExponent i:Rat))
    hecke41CuspL hecke41CuspB
  · intro i; unfold hecke41CuspLowerExponent; split <;> decide +kernel
  · intro i; exact (hecke41Cusp_guards i).1
  · intro i; exact (hecke41Cusp_guards i).2.1
  · intro i
    by_cases hi : i.val=41
    · simp only [hecke41CuspLowerExponent,hecke41HeightFactor,if_pos hi]; decide +kernel
    · simp only [hecke41CuspLowerExponent,hecke41HeightFactor,if_neg hi]; decide +kernel
  · intro i
    by_cases hi : i.val=41
    · simp only [hecke41CuspUpperExponent,hecke41HeightFactor,if_pos hi]; decide +kernel
    · simp only [hecke41CuspUpperExponent,hecke41HeightFactor,if_neg hi]; decide +kernel
  · intro i; exact (hecke41Cusp_guards i).2.2.1
  · intro i; exact (hecke41Cusp_guards i).2.2.2
  · exact hecke41Cusp_lower_exponential
  · exact hecke41Cusp_upper_exponential

end ComputableAnalysis.ModularForms
