import ComputableAnalysis.ModularForms.NomeDiscriminantSharperLeadingTerm
import ComputableAnalysis.ModularForms.CMNomeSharpInverseBound163
import ComputableAnalysis.ModularForms.CMJDomain163
import ComputableAnalysis.ModularForms.ScalarPerturbationInverseBound

/-! An actual CM discriminant reciprocal bound from the sharper nome comparison. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- The actual CM Fourier discriminant has the tighter quadratic nome error at the proved sharper radius. -/
theorem cmFourierDiscriminant163_nome_bound_fiftySeven :
    Small (sub cmFourierDiscriminant163.val (nome.eval cmScalar163 cmPoint163_upper).val)
      (103*(1/144115188075855872)*(1/144115188075855872)) := by
  let q := nome.eval cmScalar163 cmPoint163_upper
  let d := nomeModularDiscriminant q (1/144115188075855872) (by decide +kernel) (by decide +kernel)
    nome_cm163_small_fiftySeven_power
  have hd := nomeModularDiscriminant_sharp_linear_bound q (1/144115188075855872) (by decide +kernel)
    (by decide +kernel) nome_cm163_small_fiftySeven_power (by decide +kernel)
  have he := nomeModularDiscriminant_congr q q (1/144115188075855872) (1/68719476736)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    nome_cm163_small_fiftySeven_power nome_cm163_small_thirtySix_power (equiv_refl q.val q.property)
  exact Small.congr (sub_valid d.property q.property) (sub_valid cmFourierDiscriminant163.property q.property)
    (FunctionTheory.sub_congr he (equiv_refl q.val q.property)) hd

/-- The actual CM Fourier discriminant reciprocal has a constructed, justified coordinate bound. -/
theorem cmFourierDiscriminantInverse163_sharp_bound :
    Small (RepresentedReciprocal.inverse cmFourierDiscriminant163 cmFourierDiscriminant163_nonzero).val
      (8*((11/4:Rat)^41)) :=
  scalar_perturbation_inverse_bound (nome.eval cmScalar163 cmPoint163_upper) cmFourierDiscriminant163
    (nome_nonzero cmScalar163 cmPoint163_upper) cmFourierDiscriminant163_nonzero
    ((11/4:Rat)^41) (103*(1/144115188075855872)*(1/144115188075855872))
    (by decide +kernel) (by decide +kernel) cmNomeInverse163_sharp_bound
    cmFourierDiscriminant163_nome_bound_fiftySeven (by decide +kernel)

end ComputableAnalysis.ModularForms
