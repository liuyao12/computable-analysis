import ComputableAnalysis.ModularForms.CommonOuterSquareRightSamples
import ComputableAnalysis.ModularForms.CommonInnerSquareSignedAverages

/-! Reflection and signed velocity for the outer lower-right density. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem commonSquareEastDensity_lower_reflection (f : QComplex → Scalar)
    (S : QPos) (u : Rat) :
    (commonSquareEdgeDensity f ⟨.east,true⟩ S (u-1)).val.Equiv
      (neg (commonSquareEdgeDensity f ⟨.east,false⟩ S (1-u)).val) := by
  have hp : point ⟨.east,true⟩ (u-1)=point ⟨.east,false⟩ (1-u) := by
    simp only [point,rotation,orientation,Bool.false_eq_true,↓reduceIte,QComplex.mul,
      QComplex.mk.injEq]
    constructor <;> grind only
  have hv : QComplex.scaleRat S.val (velocity ⟨.east,false⟩)=
      QComplex.scaleRat (-1) (QComplex.scaleRat S.val (velocity ⟨.east,true⟩)) := by
    simp only [velocity,rotation,orientation,Bool.false_eq_true,↓reduceIte,
      QComplex.mul,QComplex.scaleRat,QComplex.mk.injEq]
    constructor <;> grind only
  let z := f (QComplex.scaleRat S.val (point ⟨.east,false⟩ (1-u)))
  let q := QComplex.scaleRat S.val (velocity ⟨.east,true⟩)
  have hs := rationalWeightedSample_scale z q (-1)
  have hn := negativeScale_equiv_negScale (scalarProduct z (rationalRectangleScalar q)) 1
  have ho := scaleRat_one_equiv (scalarProduct z (rationalRectangleScalar q)).val
    (scalarProduct z (rationalRectangleScalar q)).property
  have he := equiv_trans
    (scalarProduct z (rationalRectangleScalar (QComplex.scaleRat (-1) q))).property
    (scaleRat_valid (scalarProduct z (rationalRectangleScalar q)).property)
    (neg_valid (scaleRat_valid (scalarProduct z (rationalRectangleScalar q)).property)) hs hn
  have ht := equiv_trans
    (scalarProduct z (rationalRectangleScalar (QComplex.scaleRat (-1) q))).property
    (neg_valid (scaleRat_valid (scalarProduct z (rationalRectangleScalar q)).property))
    (neg_valid (scalarProduct z (rationalRectangleScalar q)).property) he (neg_equiv ho)
  have hr := neg_equiv ht
  have hd : (neg (neg (scalarProduct z (rationalRectangleScalar q)).val)).Equiv
      (scalarProduct z (rationalRectangleScalar q)).val := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := neg_valid (neg_valid (scalarProduct z (rationalRectangleScalar q)).property))
      (hright := (scalarProduct z (rationalRectangleScalar q)).property)
    rw [ComplexRawQuotient.ofRaw_neg,ComplexRawQuotient.ofRaw_neg,ComplexRawQuotient.neg_neg]
    all_goals first
      | exact (scalarProduct z (rationalRectangleScalar q)).property
      | exact neg_valid (scalarProduct z (rationalRectangleScalar q)).property
  unfold commonSquareEdgeDensity
  rw [hp,hv]
  exact equiv_symm (equiv_trans
    (neg_valid (scalarProduct z (rationalRectangleScalar (QComplex.scaleRat (-1) q))).property)
    (neg_valid (neg_valid (scalarProduct z (rationalRectangleScalar q)).property))
    (scalarProduct z (rationalRectangleScalar q)).property hr hd)

theorem common_outer_right_lower_concatenation (f : QComplex → Scalar) (R : QPos)
    (M : Nat) (hM : 0<M) :
    (scalarSum (squareFrameVerticalEdge f R M 4 0)
      (squareFrameVerticalEdge f R M 4 1)).val.Equiv
      (weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.east,true⟩
        (squareFrameOuterRadius R) (u-1)) (2*M) (1/((2*M:Nat):Rat))).val := by
  have h0 := common_outer_right_tile_average f R M 0 hM
  have h1 := common_outer_right_tile_average f R M 1 hM
  have p0 (u : Rat) : (((0:Nat):Rat)-2+u)/2=u/2-1 := by
    change (0-2+u)/2=u/2-1
    grind only
  have p1 (u : Rat) : (((1:Nat):Rat)-2+u)/2=(1+u)/2-1 := by
    change (1-2+u)/2=(1+u)/2-1
    grind only
  have hr : 1/(2*(M:Rat))=1/((2*M:Nat):Rat) := by
    rw [Rat.natCast_mul]
    rfl
  simp only [p0,hr] at h0
  simp only [p1,hr] at h1
  let A := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.east,true⟩
    (squareFrameOuterRadius R) (u/2-1)) M (1/((2*M:Nat):Rat))
  let B := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.east,true⟩
    (squareFrameOuterRadius R) ((1+u)/2-1)) M (1/((2*M:Nat):Rat))
  let C := weightedMidpointSum (fun u => commonSquareEdgeDensity f ⟨.east,true⟩
    (squareFrameOuterRadius R) (u-1)) (2*M) (1/((2*M:Nat):Rat))
  exact equiv_trans (scalarSum (squareFrameVerticalEdge f R M 4 0)
    (squareFrameVerticalEdge f R M 4 1)).property (scalarSum A B).property C.property
    (add_equiv h0 h1)
    (weightedSquareMidpointSum_concat (fun u => commonSquareEdgeDensity f ⟨.east,true⟩
      (squareFrameOuterRadius R) (u-1)) M hM _)

end ComputableAnalysis.ModularForms
