import ComputableAnalysis.ModularForms.Hecke41CuspPoleBound

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory
set_option maxRecDepth 8192

def hecke41CuspZeroError (n : Nat) : Rat := 4*(2:Rat)^10000*hecke41InputNomeRadius n

/-- The supplied uniform pole-growth bound gives actual zero decay after one extra nome factor. -/
theorem hecke41PolynomialCoefficient_cusp_zero_bound (k n : Nat) (z : Scalar)
    (hz : InUpperHalfPlane z.val)
    (hl : (RealRaw.ofRat (300*((n+1:Nat):Rat))).Le z.val.imagPart)
    (hu : z.val.imagPart.Le (RealRaw.ofRat (301*((n+1:Nat):Rat)))) :
    Small (mul (LocalODE.power (nome.eval z hz).val 10001)
      ((hecke41PolynomialCoefficient k).value z (hecke41CommonDomain_cusp_family n z hz hl hu)).val)
      (hecke41CuspZeroError n) := by
  let q := nome.eval z hz
  let c := (hecke41PolynomialCoefficient k).value z (hecke41CommonDomain_cusp_family n z hz hl hu)
  have hq := nome_hecke41_cusp_family_small n z hz hl
  have hc := hecke41PolynomialCoefficient_fixed_nome_bound k n z hz hl hu
  have hr : 0≤hecke41InputNomeRadius n := by
    unfold hecke41InputNomeRadius
    rw [Rat.div_def,Rat.one_mul]
    exact Rat.le_of_lt (Rat.inv_pos.mpr (Rat.pow_pos (Rat.pow_pos (show (0:Rat)<2 by decide +kernel))))
  have hb := Small.mul q.property (mul_valid (LocalODE.power_valid q.val q.property 10000) c.property)
    hr (Rat.mul_nonneg (show (0:Rat)≤2 by decide +kernel) (Rat.pow_nonneg (show (0:Rat)≤2 by decide +kernel))) hq hc
  have he : (mul q.val (mul (LocalODE.power q.val 10000) c.val)).Equiv
      (mul (LocalODE.power q.val 10001) c.val) := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
    let Q := ComplexRawQuotient.ofRaw q.val q.property
    let P := ComplexRawQuotient.ofRaw (LocalODE.power q.val 10000) (LocalODE.power_valid q.val q.property 10000)
    let C := ComplexRawQuotient.ofRaw c.val c.property
    change Q*(P*C)=(P*Q)*C
    grind only
  have h := Small.congr (mul_valid q.property (mul_valid (LocalODE.power_valid q.val q.property 10000) c.property))
    (mul_valid (LocalODE.power_valid q.val q.property 10001) c.property) he hb
  have heq : 2*hecke41InputNomeRadius n*(2*(2:Rat)^10000)=hecke41CuspZeroError n := by
    unfold hecke41CuspZeroError
    grind only
  rw [heq] at h
  exact h

/-- Explicit error schedule for the zero value at the cusp. -/
theorem hecke41CuspZeroError_shrinks : ShrinksToZero hecke41CuspZeroError := by
  let a : Rat := 2^1800
  let q : Rat := 1/a
  have ha : 0<a := Rat.pow_pos (by decide +kernel)
  have hq : 0≤q := by dsimp [q]; rw [Rat.div_def,Rat.one_mul]; exact Rat.le_of_lt (Rat.inv_pos.mpr ha)
  have hh : q≤(1:Rat)/2 := by decide +kernel
  have h := LocalODE.tail_bound_shrinks ((2:Rat)^10000) q (Rat.pow_nonneg (by decide +kernel)) hq hh
  intro eps
  obtain ⟨N,hN⟩ := h eps
  refine ⟨N,?_⟩
  intro m hm
  have hb := hN (m+1) (by omega)
  unfold hecke41CuspZeroError hecke41InputNomeRadius
  rw [rational_reciprocal_power _ ha]
  exact hb

/-- Uniform actual zero convergence across all coefficient indices and sufficiently high bands. -/
theorem hecke41PolynomialCoefficient_cusp_zero_uniform (eps : QPos) :
    ∃ N : Nat, ∀ n, N≤n → ∀ k (z : Scalar) (hz : InUpperHalfPlane z.val)
      (hl : (RealRaw.ofRat (300*((n+1:Nat):Rat))).Le z.val.imagPart)
      (hu : z.val.imagPart.Le (RealRaw.ofRat (301*((n+1:Nat):Rat)))),
      Small (mul (LocalODE.power (nome.eval z hz).val 10001)
        ((hecke41PolynomialCoefficient k).value z (hecke41CommonDomain_cusp_family n z hz hl hu)).val) eps.val := by
  obtain ⟨N,hN⟩ := hecke41CuspZeroError_shrinks eps
  exact ⟨N,fun n hn k z hz hl hu => (hecke41PolynomialCoefficient_cusp_zero_bound k n z hz hl hu).mono (hN n hn)⟩

end ComputableAnalysis.ModularForms
