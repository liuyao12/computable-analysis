import ComputableAnalysis.ModularForms.CMPoint43
import ComputableAnalysis.ModularForms.CMNome163
import ComputableAnalysis.ModularForms.RealExponentialReciprocalBound

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory

/-- The exponent representing minus pi times sqrt(43). -/
def cmDecayExponent43 : Scalar :=
  ⟨neg (scaleRat 2 (mul geometricHalfPiRealScalar.val sqrt43Complex)),
    neg_valid (scaleRat_valid (mul_valid geometricHalfPiRealScalar.property sqrt43Complex_valid))⟩

theorem cmNomeExponent43_decomposition :
    (nomeExponentMap.eval cmScalar43 cmPoint43_upper).val.Equiv
      (add cmDecayExponent43.val imaginaryPiScalar.val) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (nomeExponentMap.eval cmScalar43 cmPoint43_upper).property)
    (hright := add_valid cmDecayExponent43.property imaginaryPiScalar.property)
  let p := ComplexRawQuotient.ofRaw geometricHalfPiRealScalar.val geometricHalfPiRealScalar.property
  let r := sqrt43Value
  let i := imaginaryUnitValue
  have hi := mulI_class geometricHalfPiRealScalar
  have hcm := cmPoint43Value_formula
  change ComplexRawQuotient.ofRaw cmPoint43 cmPoint43_valid =
    ComplexRawQuotient.scaleRat (1/2) (1+i*r) at hcm
  change ComplexRawQuotient.scaleRat 4
    (ComplexRawQuotient.ofRaw (mulI geometricHalfPiRealScalar.val)
      (mulI_valid geometricHalfPiRealScalar.property)) *
    ComplexRawQuotient.ofRaw cmPoint43 cmPoint43_valid =
    -ComplexRawQuotient.scaleRat 2 (p*r) +
    ComplexRawQuotient.scaleRat 2
      (ComplexRawQuotient.ofRaw (mulI geometricHalfPiRealScalar.val)
        (mulI_valid geometricHalfPiRealScalar.property))
  rw [hi,hcm,ComplexRawQuotient.mul_scaleRat,← ComplexRawQuotient.scaleRat_mul,
    ComplexRawQuotient.scaleRat_scaleRat]
  have hc : (1/2:Rat)*4=2 := by decide +kernel
  rw [hc]
  have h2 (v : ScalarAlgebra.Value) : ComplexRawQuotient.scaleRat 2 v=(2:ScalarAlgebra.Value)*v :=
    ScalarAlgebra.scale_natural 2 v
  rw [h2,h2,h2]
  have hs := imaginaryUnitValue_square
  have hneg : (((-1):Int):ScalarAlgebra.Value) = -(1:ScalarAlgebra.Value) := by
    grind only
  rw [hneg] at hs
  grind only

theorem nome_cm43_negative_exponential :
    (nome.eval cmScalar43 cmPoint43_upper).val.Equiv
      (neg (entireExponentialValue cmDecayExponent43).val) := by
  let x : Scalar := ⟨add cmDecayExponent43.val imaginaryPiScalar.val,
    add_valid cmDecayExponent43.property imaginaryPiScalar.property⟩
  exact equiv_trans (nome.eval cmScalar43 cmPoint43_upper).property
    (entireExponentialValue x).property (neg_valid (entireExponentialValue cmDecayExponent43).property)
    (entireExponentialValue_congr _ x cmNomeExponent43_decomposition)
    (entireExponential_add_imaginaryPi cmDecayExponent43)

/-- The corresponding exponent representing pi times sqrt(43). -/
def cmGrowthExponent43 : Scalar :=
  ⟨neg cmDecayExponent43.val,neg_valid cmDecayExponent43.property⟩

theorem nome_cm43_growth_product :
    (mul (nome.eval cmScalar43 cmPoint43_upper).val
      (entireExponentialValue cmGrowthExponent43).val).Equiv (ofQComplex ⟨-1,0⟩) := by
  have hn := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := (nome.eval cmScalar43 cmPoint43_upper).property)
    (hright := neg_valid (entireExponentialValue cmDecayExponent43).property) nome_cm43_negative_exponential
  have hi := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := mul_valid (entireExponentialValue cmDecayExponent43).property
      (entireExponentialValue cmGrowthExponent43).property) (hright := ofQComplex_valid _)
    (entireExponential_inverse cmDecayExponent43)
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := mul_valid (nome.eval cmScalar43 cmPoint43_upper).property
      (entireExponentialValue cmGrowthExponent43).property) (hright := ofQComplex_valid _)
  let d := ComplexRawQuotient.ofRaw (entireExponentialValue cmDecayExponent43).val
    (entireExponentialValue cmDecayExponent43).property
  let g := ComplexRawQuotient.ofRaw (entireExponentialValue cmGrowthExponent43).val
    (entireExponentialValue cmGrowthExponent43).property
  change ComplexRawQuotient.ofRaw (nome.eval cmScalar43 cmPoint43_upper).val
    (nome.eval cmScalar43 cmPoint43_upper).property = -d at hn
  change d*g=1 at hi
  change ComplexRawQuotient.ofRaw (nome.eval cmScalar43 cmPoint43_upper).val
    (nome.eval cmScalar43 cmPoint43_upper).property *g = ComplexRawQuotient.ofQComplex ⟨-1,0⟩
  have hc : ComplexRawQuotient.ofQComplex ⟨-1,0⟩ = -(1:ScalarAlgebra.Value) := rfl
  rw [hn,hc]
  grind only

end ComputableAnalysis.ModularForms

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert

def cmGrowthReal43 : RealRaw :=
  RealRaw.scaleRat 2 (RealRaw.mul GeometricPiRotation.halfPi sqrt43)

theorem cmGrowthReal43_valid : cmGrowthReal43.Valid :=
  RealRaw.scaleRat_valid (r := 2) (RealRaw.mul_valid GeometricPiRotation.halfPi_valid sqrt43_valid)

private theorem realScale_two (x : RealRaw) (hx : x.Valid) :
    (scaleRat 2 (ofRealRaw x)).Equiv (ofRealRaw (RealRaw.scaleRat 2 x)) := by
  intro n
  apply (compareAt_overlap_iff _ _ n n).mpr
  have ho := RealRaw.interval_order_of_valid x hx n
  simp only [scaleRat,ofRealRaw,QBox.scaleRat,RealRaw.scaleRat,RealRaw.scaleRatCompute,
    if_pos (show (0:Rat)≤2 by decide),QBox.Overlaps,QComplex.le_def]
  have hm := Rat.mul_le_mul_of_nonneg_left ho (show (0:Rat)≤2 by decide)
  constructor <;> constructor <;> (try simp only [Rat.mul_zero]) <;> first | exact hm | exact Rat.le_refl

theorem cmGrowthExponent43_real : cmGrowthExponent43.val.Equiv (ofRealRaw cmGrowthReal43) := by
  have hm := real_embedding_mul GeometricPiRotation.halfPi sqrt43
    GeometricPiRotation.halfPi_valid sqrt43_valid
  have hs := scaleRat_equiv (r := 2) hm
  have he := equiv_trans
    (scaleRat_valid (mul_valid geometricHalfPiRealScalar.property sqrt43Complex_valid))
    (scaleRat_valid (ofRealRaw_valid _ (RealRaw.mul_valid GeometricPiRotation.halfPi_valid sqrt43_valid)))
    (ofRealRaw_valid _ cmGrowthReal43_valid) hs
    (realScale_two _ (RealRaw.mul_valid GeometricPiRotation.halfPi_valid sqrt43_valid))
  have hn : cmGrowthExponent43.val.Equiv
      (scaleRat 2 (mul geometricHalfPiRealScalar.val sqrt43Complex)) := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := cmGrowthExponent43.property)
      (hright := scaleRat_valid (mul_valid geometricHalfPiRealScalar.property sqrt43Complex_valid))
    change -(-ComplexRawQuotient.scaleRat 2
      (ComplexRawQuotient.ofRaw geometricHalfPiRealScalar.val geometricHalfPiRealScalar.property *
        ComplexRawQuotient.ofRaw sqrt43Complex sqrt43Complex_valid)) =
      ComplexRawQuotient.scaleRat 2
      (ComplexRawQuotient.ofRaw geometricHalfPiRealScalar.val geometricHalfPiRealScalar.property *
        ComplexRawQuotient.ofRaw sqrt43Complex sqrt43Complex_valid)
    grind only
  exact equiv_trans cmGrowthExponent43.property
    (scaleRat_valid (mul_valid geometricHalfPiRealScalar.property sqrt43Complex_valid))
    (ofRealRaw_valid _ cmGrowthReal43_valid) hn he

theorem nome_cm43_real_growth_product :
    (mul (nome.eval cmScalar43 cmPoint43_upper).val
      (entireExponentialValue ⟨ofRealRaw cmGrowthReal43,ofRealRaw_valid _ cmGrowthReal43_valid⟩).val).Equiv
      (ofQComplex ⟨-1,0⟩) := by
  have he := entireExponentialValue_congr cmGrowthExponent43
    ⟨ofRealRaw cmGrowthReal43,ofRealRaw_valid _ cmGrowthReal43_valid⟩ cmGrowthExponent43_real
  have hm := mul_equiv (nome.eval cmScalar43 cmPoint43_upper).property
    (nome.eval cmScalar43 cmPoint43_upper).property
    (entireExponentialValue cmGrowthExponent43).property (entireExponentialValue _).property
    (equiv_refl _ (nome.eval cmScalar43 cmPoint43_upper).property) he
  exact equiv_trans (mul_valid (nome.eval cmScalar43 cmPoint43_upper).property (entireExponentialValue _).property)
    (mul_valid (nome.eval cmScalar43 cmPoint43_upper).property (entireExponentialValue cmGrowthExponent43).property)
    (ofQComplex_valid _) (equiv_symm hm) nome_cm43_growth_product

end ComputableAnalysis.ModularForms
