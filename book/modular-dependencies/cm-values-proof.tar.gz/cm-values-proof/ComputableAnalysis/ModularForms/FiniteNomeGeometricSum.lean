import ComputableAnalysis.ModularForms.NomeRootPrimitivity
import ComputableAnalysis.RiemannHilbert.RepresentedReciprocal
namespace ComputableAnalysis.ModularForms
set_option maxHeartbeats 2000000
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

/-- Literal finite geometric prefix on a represented scalar. -/
def representedNomeGeometricSum (q : Scalar) : Nat → Scalar
  | 0 => ⟨zero,ofQComplex_valid _⟩
  | N+1 => scalarSum (representedNomeGeometricSum q N)
    ⟨LocalODE.power q.val N,LocalODE.power_valid _ q.property N⟩

/-- The finite prefix satisfies the exact geometric telescoping identity. -/
theorem representedNomeGeometricSum_telescoping (q : Scalar) (N : Nat) :
    (mul (sub q.val one) (representedNomeGeometricSum q N).val).Equiv
      (sub (LocalODE.power q.val N) one) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := mul_valid (sub_valid q.property (ofQComplex_valid _)) (representedNomeGeometricSum q N).property)
    (hright := sub_valid (LocalODE.power_valid _ q.property N) (ofQComplex_valid _))
  let Q := ComplexRawQuotient.ofRaw q.val q.property
  change (Q-1)*ComplexRawQuotient.ofRaw (representedNomeGeometricSum q N).val (representedNomeGeometricSum q N).property =
    ComplexRawQuotient.ofRaw (LocalODE.power q.val N) (LocalODE.power_valid _ q.property N)-1
  rw [ScalarAlgebra.ofRaw_power q.val q.property N]
  induction N with
  | zero => change (Q-1)*0=Q^0-1; grind only
  | succ N ih =>
    change (Q-1)*(ComplexRawQuotient.ofRaw (representedNomeGeometricSum q N).val (representedNomeGeometricSum q N).property+
      ComplexRawQuotient.ofRaw (LocalODE.power q.val N) (LocalODE.power_valid _ q.property N))=Q^(N+1)-1
    rw [ScalarAlgebra.ofRaw_power q.val q.property N]
    grind only

/-- A nontrivial actual root of unity has zero finite geometric sum. -/
theorem representedNomeGeometricSum_zero (q : Scalar) (N : Nat)
    (hn : ¬q.val.Equiv one) (hp : (LocalODE.power q.val N).Equiv one) :
    (representedNomeGeometricSum q N).val.Equiv zero := by
  let d : Scalar := ⟨sub q.val one,sub_valid q.property (ofQComplex_valid _)⟩
  have hd : NonzeroBoxSearch.Nonzero d := by
    intro he
    apply hn
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := q.property) (hright := ofQComplex_valid _)
    have h := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := d.property) (hright := ofQComplex_valid _) he
    let Q := ComplexRawQuotient.ofRaw q.val q.property
    change Q-1=0 at h
    change Q=1
    grind only
  let o : Scalar := ⟨zero,ofQComplex_valid _⟩
  apply RepresentedReciprocal.mul_cancel d hd (representedNomeGeometricSum q N) o
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := mul_valid d.property (representedNomeGeometricSum q N).property)
    (hright := mul_valid d.property o.property)
  have ht := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := mul_valid (sub_valid q.property (ofQComplex_valid _)) (representedNomeGeometricSum q N).property)
    (hright := sub_valid (LocalODE.power_valid _ q.property N) (ofQComplex_valid _))
    (representedNomeGeometricSum_telescoping q N)
  have hh := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := LocalODE.power_valid _ q.property N) (hright := ofQComplex_valid _) hp
  let Q := ComplexRawQuotient.ofRaw q.val q.property
  let S := ComplexRawQuotient.ofRaw (representedNomeGeometricSum q N).val (representedNomeGeometricSum q N).property
  let P := ComplexRawQuotient.ofRaw (LocalODE.power q.val N) (LocalODE.power_valid _ q.property N)
  change (Q-1)*S=P-1 at ht
  change P=1 at hh
  change (Q-1)*S=(Q-1)*0
  grind only

/-- The actual constructed primitive root cancels over one whole period. -/
theorem nomeRootOfUnity_geometric_sum_zero (p : Nat) (hp : 0<(p:Rat)) (hp1 : 1<p) :
    (representedNomeGeometricSum (nomeRootOfUnity p) p).val.Equiv zero := by
  apply representedNomeGeometricSum_zero _ _ _ (nomeRootOfUnity_power p hp)
  intro he
  have h := nomeRootOfUnity_primitive p 1 hp (by decide) hp1
  apply h
  have hc : (LocalODE.power (nomeRootOfUnity p).val 1).Equiv (nomeRootOfUnity p).val := by
    exact one_mul_equiv _ (nomeRootOfUnity p).property
  exact equiv_trans (LocalODE.power_valid _ (nomeRootOfUnity p).property 1)
    (nomeRootOfUnity p).property (ofQComplex_valid _) hc he
theorem nomeScalar_power_add (q : ScalarAlgebra.Value) (m n : Nat) : q^(m+n)=q^m*q^n := by
  induction n with
  | zero => change q^m=q^m*1; grind only
  | succ n ih =>
    change q^(m+n)*q=q^m*(q^n*q)
    rw [ih]
    grind only

theorem nomeScalar_power_mul (q : ScalarAlgebra.Value) (m n : Nat) : (q^m)^n=q^(m*n) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    change (q^m)^n*q^m=q^(m*(n+1))
    rw [ih,Nat.mul_succ,nomeScalar_power_add]

/-- A root phase raised to its index is one, for every Fourier exponent. -/
theorem nomeRootOfUnity_phase_period (p n : Nat) (hp : 0<(p:Rat)) :
    (LocalODE.power (LocalODE.power (nomeRootOfUnity p).val n) p).Equiv one := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := LocalODE.power_valid _ (LocalODE.power_valid _ (nomeRootOfUnity p).property n) p)
    (hright := ofQComplex_valid _)
  have h := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := LocalODE.power_valid _ (nomeRootOfUnity p).property p)
    (hright := ofQComplex_valid _) (nomeRootOfUnity_power p hp)
  rw [ScalarAlgebra.ofRaw_power _ (nomeRootOfUnity p).property p] at h
  rw [ScalarAlgebra.ofRaw_power _ (LocalODE.power_valid _ (nomeRootOfUnity p).property n) p,
    ScalarAlgebra.ofRaw_power _ (nomeRootOfUnity p).property n]
  let Q := ComplexRawQuotient.ofRaw (nomeRootOfUnity p).val (nomeRootOfUnity p).property
  change Q^p=1 at h
  change (Q^n)^p=1
  rw [nomeScalar_power_mul,Nat.mul_comm n p,←nomeScalar_power_mul,h]
  induction n with
  | zero => rfl
  | succ n ih => change (1:ScalarAlgebra.Value)^n*1=1; grind only

/-- Every nondivisible Fourier exponent cancels across one full root period. -/
theorem nomeRootOfUnity_phase_sum_zero (p n : Nat) (hp : 0<(p:Rat)) (hn : ¬p ∣ n) :
    (representedNomeGeometricSum ⟨LocalODE.power (nomeRootOfUnity p).val n,
      LocalODE.power_valid _ (nomeRootOfUnity p).property n⟩ p).val.Equiv zero := by
  exact representedNomeGeometricSum_zero
    ⟨LocalODE.power (nomeRootOfUnity p).val n,LocalODE.power_valid _ (nomeRootOfUnity p).property n⟩ p
    (fun h => hn ((nomeRootOfUnity_power_one_iff p n hp).mp h))
    (nomeRootOfUnity_phase_period p n hp)

/-- A supplied unit phase has exactly the rational count as its finite sum. -/
theorem representedNomeGeometricSum_one (q : Scalar) (hq : q.val.Equiv one) (N : Nat) :
    (representedNomeGeometricSum q N).val.Equiv (nomeRationalPoint (N:Rat)).val := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (representedNomeGeometricSum q N).property) (hright := (nomeRationalPoint (N:Rat)).property)
  have h := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := q.property) (hright := ofQComplex_valid _) hq
  have hc := integer_constant (N:Int)
  rw [Rat.intCast_natCast] at hc
  change ComplexRawQuotient.ofRaw (representedNomeGeometricSum q N).val _=
    ComplexRawQuotient.ofQComplex ⟨(N:Rat),0⟩
  rw [hc]
  have hnat : ((N:Int):ScalarAlgebra.Value)=(N:ScalarAlgebra.Value) := by
    change ComplexRawQuotient.scaleRat ((N:Int):Rat) 1=ScalarAlgebra.natural N
    rw [Rat.intCast_natCast,←ScalarAlgebra.natural_scale]
  rw [hnat]
  clear hc hnat
  change ComplexRawQuotient.ofRaw q.val q.property=1 at h
  induction N with
  | zero => rfl
  | succ N ih =>
    change ComplexRawQuotient.ofRaw (representedNomeGeometricSum q N).val (representedNomeGeometricSum q N).property+
      ComplexRawQuotient.ofRaw (LocalODE.power q.val N) (LocalODE.power_valid _ q.property N)=(N+1:Nat)
    rw [ScalarAlgebra.ofRaw_power q.val q.property N,h,ih]
    have hn : ((N+1:Nat):ScalarAlgebra.Value)=(N:ScalarAlgebra.Value)+1 := ScalarAlgebra.natural_succ N
    rw [hn]
    have hp1 : (1:ScalarAlgebra.Value)^N=1 := by
      clear ih hn
      induction N with
      | zero => rfl
      | succ N ih => change (1:ScalarAlgebra.Value)^N*1=1; grind only
    rw [hp1]

/-- Divisible Fourier exponents contribute the exact period count. -/
theorem nomeRootOfUnity_phase_sum_count (p n : Nat) (hp : 0<(p:Rat)) (hn : p ∣ n) :
    (representedNomeGeometricSum ⟨LocalODE.power (nomeRootOfUnity p).val n,
      LocalODE.power_valid _ (nomeRootOfUnity p).property n⟩ p).val.Equiv
      (nomeRationalPoint (p:Rat)).val :=
  representedNomeGeometricSum_one
    ⟨LocalODE.power (nomeRootOfUnity p).val n,LocalODE.power_valid _ (nomeRootOfUnity p).property n⟩
    ((nomeRootOfUnity_power_one_iff p n hp).mpr hn) p

end ComputableAnalysis.ModularForms
