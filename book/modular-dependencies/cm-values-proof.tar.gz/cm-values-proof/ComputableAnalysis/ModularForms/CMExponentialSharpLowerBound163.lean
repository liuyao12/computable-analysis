import ComputableAnalysis.ModularForms.CMExponentialSharpUpperBound163

/-! Power-amplified decay at the actual discriminant-163 CM point. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

def cmGrowthGapFromForty163 : RealRaw := RealRaw.add cmGrowthReal163 (RealRaw.ofRat (-40))

theorem cmGrowthGapFromForty163_valid : cmGrowthGapFromForty163.Valid :=
  RealRaw.add_valid cmGrowthReal163_valid (RealRaw.ofRat_valid (-40))

theorem cmGrowthGapFromForty163_lower : (RealRaw.ofRat (7/200)).Le cmGrowthGapFromForty163 := by
  intro n m
  have h := cmGrowthReal163_lower_tight 0 m
  change (8007/200:Rat)≤(cmGrowthReal163.compute m).hi at h
  change (7/200:Rat)≤(cmGrowthReal163.compute m).hi+(-40)
  grind only

theorem cmGrowthGapFromForty163_positive : cmGrowthGapFromForty163.Pos := by
  obtain ⟨N,hN⟩ := cmGrowthGapFromForty163_valid.2.2 (⟨1/100,by decide +kernel⟩ : QPos)
  have hw := hN N (Nat.le_refl N)
  have hl := cmGrowthGapFromForty163_lower 0 N
  change (7/200:Rat)≤(cmGrowthGapFromForty163.compute N).hi at hl
  unfold QInterval.width at hw
  refine ⟨N,?_⟩
  change 0<(cmGrowthGapFromForty163.compute N).lo
  grind only

private theorem gap_sum :
    (add (ofRealRaw (RealRaw.ofRat 40)) (ofRealRaw cmGrowthGapFromForty163)).Equiv
      (ofRealRaw cmGrowthReal163) := by
  intro n
  apply (compareAt_overlap_iff _ _ n n).mpr
  have ho := RealRaw.interval_order_of_valid _ cmGrowthReal163_valid n
  simp only [add,ofRealRaw,cmGrowthGapFromForty163,RealRaw.add,RealRaw.addCompute,
    RealRaw.ofRat,QBox.add,QComplex.add,QBox.Overlaps,QComplex.le_def,Rat.add_zero]
  constructor <;> constructor <;> grind only

private theorem rational_embedding :
    (ofQComplex ⟨40,0⟩).Equiv (ofRealRaw (RealRaw.ofRat 40)) := by
  intro n
  apply (compareAt_overlap_iff _ _ n n).mpr
  simp [ofQComplex,ofRealRaw,RealRaw.ofRat,QBox.point,QBox.Overlaps,QComplex.le_def]

/-- A sharp rational lower bound for the actual CM growth exponential. -/
theorem cmGrowthExponential163_lower_sharp_power :
    (RealRaw.ofRat ((737/100:Rat)^20)).Le cmGrowthValue163 := by
  let X : Scalar := ⟨ofRealRaw (RealRaw.ofRat 40),ofRealRaw_valid _ (RealRaw.ofRat_valid 40)⟩
  let D : Scalar := ⟨ofRealRaw cmGrowthGapFromForty163,ofRealRaw_valid _ cmGrowthGapFromForty163_valid⟩
  have hx0 : (RealRaw.ofRat 0).Le (RealRaw.ofRat 40) := by intro n m; change (0:Rat)≤40; decide +kernel
  have hd0 : (RealRaw.ofRat 0).Le cmGrowthGapFromForty163 := by
    intro n m
    have h := cmGrowthGapFromForty163_lower 0 m
    change (7/200:Rat)≤(cmGrowthGapFromForty163.compute m).hi at h
    change (0:Rat)≤(cmGrowthGapFromForty163.compute m).hi
    grind only
  have hm := entireExponential_real_positive_gap_order (RealRaw.ofRat 40) cmGrowthGapFromForty163
    (RealRaw.ofRat_valid 40) cmGrowthGapFromForty163_valid (by exact ⟨0,by decide +kernel⟩)
    cmGrowthGapFromForty163_positive hx0 hd0
  have hc := realPart_equiv (entireExponentialValue_congr
    ⟨ofQComplex ⟨40,0⟩,ofQComplex_valid _⟩ X rational_embedding)
  have he : (scalarSum X D).val.Equiv cmGrowthExponent163.val :=
    equiv_trans (scalarSum X D).property (ofRealRaw_valid _ cmGrowthReal163_valid)
      cmGrowthExponent163.property gap_sum (equiv_symm cmGrowthExponent163_real)
  have hs := realPart_equiv (entireExponentialValue_congr (scalarSum X D) cmGrowthExponent163 he)
  exact RealRaw.le_trans (realPart_valid (entireExponentialValue _).property)
    entireExponential_rational_forty_lower
    (RealRaw.le_trans (realPart_valid (entireExponentialValue X).property)
      (RealRaw.le_of_equiv (realPart_valid (entireExponentialValue _).property)
        (realPart_valid (entireExponentialValue X).property) hc)
      (RealRaw.le_trans (realPart_valid (entireExponentialValue (scalarSum X D)).property) hm
        (RealRaw.le_of_equiv (realPart_valid (entireExponentialValue (scalarSum X D)).property)
          (realPart_valid (entireExponentialValue cmGrowthExponent163).property) hs)))

/-- The actual CM nome has the inverse of the sharp exponential lower bound as radius. -/
theorem nome_cm163_small_sharp_power :
    Small (nome.eval cmScalar163 cmPoint163_upper).val (1/((737/100:Rat)^20)) :=
  nome_cm163_small_of_growth ((737/100:Rat)^20) (by decide +kernel)
    cmGrowthExponential163_lower_sharp_power

/-- A convenient dyadic lower bound for the actual CM growth exponential. -/
theorem cmGrowthExponential163_lower_fiftySeven_power :
    (RealRaw.ofRat 144115188075855872).Le cmGrowthValue163 := by
  intro n m
  have h := cmGrowthExponential163_lower_sharp_power 0 m
  change (737/100:Rat)^20≤(cmGrowthValue163.compute m).hi at h
  exact Rat.le_trans (show (144115188075855872:Rat)≤(737/100:Rat)^20 by decide +kernel) h

/-- The actual discriminant-163 nome has radius at most the inverse fifty-seventh binary power. -/
theorem nome_cm163_small_fiftySeven_power :
    Small (nome.eval cmScalar163 cmPoint163_upper).val (1/144115188075855872) :=
  nome_cm163_small_of_growth 144115188075855872 (by decide +kernel)
    cmGrowthExponential163_lower_fiftySeven_power

end ComputableAnalysis.ModularForms
