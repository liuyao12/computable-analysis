import ComputableAnalysis.ModularForms.Hecke41CuspFamily

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory
set_option maxRecDepth 8192

private theorem rational_band_cover (lo hi : Rat) (hl : 90300≤lo) (hw : hi-lo≤1) :
    ∃ n : Nat, 300*((n+1:Nat):Rat)≤lo ∧ hi≤301*((n+1:Nat):Rat) := by
  let j := (lo/300).floor
  have hj : (301:Int)≤j := Rat.le_floor_iff.mpr (by
    change (301:Rat)≤lo/300
    rw [Rat.div_def]
    grind)
  have hnat : (j.toNat:Int)=j := Int.toNat_of_nonneg (by omega)
  have hcast : (j.toNat:Rat)=(j:Rat) := by exact_mod_cast hnat
  have hmin : (301:Rat)≤(j:Rat) := by exact_mod_cast hj
  have hlo := Rat.floor_le (lo/300)
  have hhi := Rat.lt_floor_add_one (lo/300)
  change (j:Rat)≤lo/300 at hlo
  change lo/300<((j+1:Int):Rat) at hhi
  rw [Rat.div_def] at hlo hhi
  have hadd : ((j+1:Int):Rat)=(j:Rat)+1 := by simp
  rw [hadd] at hhi
  have hk : 1≤j.toNat := by omega
  refine ⟨j.toNat-1,?_,?_⟩
  · rw [Nat.sub_add_cancel hk,hcast]
    grind
  · rw [Nat.sub_add_cancel hk,hcast]
    grind

/-- An effective shrinking enclosure selects a member of the checked cusp family. -/
theorem real_high_cusp_band (x : RealRaw) (hx : x.Valid)
    (hl : (RealRaw.ofRat 90600).Le x) :
    ∃ n : Nat, (RealRaw.ofRat (300*((n+1:Nat):Rat))).Le x ∧
      x.Le (RealRaw.ofRat (301*((n+1:Nat):Rat))) := by
  obtain ⟨N,hN⟩ := hx.2.2 (⟨1,by decide +kernel⟩ : QPos)
  have hw := hN N (Nat.le_refl N)
  have hh := hl 0 N
  change (90600:Rat)≤(x.compute N).hi at hh
  unfold QInterval.width at hw
  obtain ⟨k,hlo,hhi⟩ := rational_band_cover (x.compute N).lo (x.compute N).hi (by grind) hw
  refine ⟨k,?_,?_⟩
  · intro n m
    have h₁ := hx.2.1 N (max N m) (Nat.le_max_left _ _)
    have h₂ := hx.2.1 m (max N m) (Nat.le_max_right _ _)
    change 300*((k+1:Nat):Rat)≤(x.compute m).hi
    grind only
  · intro n m
    have h₁ := hx.2.1 N (max N n) (Nat.le_max_left _ _)
    have h₂ := hx.2.1 n (max N n) (Nat.le_max_right _ _)
    change (x.compute n).lo≤301*((k+1:Nat):Rat)
    grind only

/-- All actual correspondence j evaluators are justified above a fixed cusp threshold. -/
theorem hecke41CommonDomain_high_cusp (z : Scalar) (hz : InUpperHalfPlane z.val)
    (hl : (RealRaw.ofRat 90600).Le z.val.imagPart) : hecke41CommonDomain z := by
  obtain ⟨n,hlo,hhi⟩ := real_high_cusp_band z.val.imagPart (imagPart_valid z.property) hl
  exact hecke41CommonDomain_cusp_family n z hz hlo hhi

end ComputableAnalysis.ModularForms
