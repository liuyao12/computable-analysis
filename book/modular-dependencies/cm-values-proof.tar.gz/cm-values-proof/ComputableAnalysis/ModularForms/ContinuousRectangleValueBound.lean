import ComputableAnalysis.ModularForms.GlobalModularRectangleDomain

namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

/-- Classical proof-facing comparison with a rational cut; no executable real-order decision is asserted. -/
theorem representedReal_rational_cut (x : RealRaw) (hx : x.Valid) (c : Rat) :
    x.Le (RealRaw.ofRat c) ∨ (RealRaw.ofRat c).Le x := by
  classical
  by_cases h : x.Le (RealRaw.ofRat c)
  · exact Or.inl h
  · right
    have hn : ∃ n, c < (x.compute n).lo := by
      apply Classical.byContradiction
      intro hn
      apply h
      intro n m
      change (x.compute n).lo ≤ c
      grind only
    obtain ⟨n, hn⟩ := hn
    intro i j
    have ho := RealRaw.le_refl x hx n j
    change c ≤ (x.compute j).hi
    exact Rat.le_trans (Rat.le_of_lt hn) ho

/-- Every represented rectangle point belongs to one of its four closed subrectangles. -/
theorem representedRectangle_bisect_mem (J : QInterval × QInterval) (z : Scalar)
    (hz : representedRectangleContains J z) :
    ∃ r : Bool × Bool, representedRectangleContains (bisectRectangle J r) z := by
  rcases representedReal_rational_cut z.val.realPart (realPart_valid z.property) J.1.midpoint with hx | hx <;>
    rcases representedReal_rational_cut z.val.imagPart (imagPart_valid z.property) J.2.midpoint with hy | hy
  · exact ⟨(false,false), hz.1,hx,hz.2.2.1,hy⟩
  · exact ⟨(false,true), hz.1,hx,hy,hz.2.2.2⟩
  · exact ⟨(true,false), hx,hz.2.1,hz.2.2.1,hy⟩
  · exact ⟨(true,true), hx,hz.2.1,hy,hz.2.2.2⟩

/-- Endpoint neighborhood inequalities control every represented point, including irrational coordinates. -/
theorem rectangleNear_represented_displacement (K : QInterval × QInterval)
    (x y : RealRaw) (eps : QPos) (hX : K.1.lo ≤ K.1.hi) (hY : K.2.lo ≤ K.2.hi)
    (hx : intervalNear K.1 x eps) (hy : intervalNear K.2 y eps)
    (z : Scalar) (hz : representedRectangleContains K z) :
    Small (sub z.val (coordinateComplex x y)) eps.val := by
  have hxl := (hx K.1.lo (Rat.le_refl) hX).2
  have hxu := (hx K.1.hi hX (Rat.le_refl)).1
  have hyl := (hy K.2.lo (Rat.le_refl) hY).2
  have hyu := (hy K.2.hi hY (Rat.le_refl)).1
  refine ⟨?_,?_,?_,?_⟩
  · intro n m
    have h1 := hz.1 0 m
    have h2 := hxl m 0
    change K.1.lo ≤ (z.val.compute m).hi.re at h1
    change (x.compute m).lo ≤ K.1.lo + eps.val at h2
    change -eps.val ≤ (z.val.compute m).hi.re + -(x.compute m).lo
    grind only
  · intro n m
    have h1 := hz.2.1 n 0
    have h2 := hxu 0 n
    change (z.val.compute n).lo.re ≤ K.1.hi at h1
    change K.1.hi - eps.val ≤ (x.compute n).hi at h2
    change (z.val.compute n).lo.re + -(x.compute n).hi ≤ eps.val
    grind only
  · intro n m
    have h1 := hz.2.2.1 0 m
    have h2 := hyl m 0
    change K.2.lo ≤ (z.val.compute m).hi.im at h1
    change (y.compute m).lo ≤ K.2.lo + eps.val at h2
    change -eps.val ≤ (z.val.compute m).hi.im + -(y.compute m).lo
    grind only
  · intro n m
    have h1 := hz.2.2.2 n 0
    have h2 := hyu 0 n
    change (z.val.compute n).lo.im ≤ K.2.hi at h1
    change K.2.hi - eps.val ≤ (y.compute n).hi at h2
    change (z.val.compute n).lo.im + -(y.compute n).hi ≤ eps.val
    grind only

/-- Actual continuous values are rationally bounded on a supplied represented rectangle domain. -/
theorem continuous_rectangle_value_bound (f : DomainFunctions.Map) (hf : Holomorphic f)
    (J : QInterval × QInterval) (hX : J.1.lo ≤ J.1.hi) (hY : J.2.lo ≤ J.2.hi)
    (hdom : ∀ z : Scalar, representedRectangleContains J z → f.domain z) :
    ∃ B : QPos, ∀ (z : Scalar), representedRectangleContains J z →
      ∀ hz : f.domain z, Small (f.eval z hz).val B.val := by
  let good := fun K : QInterval × QInterval => ∃ B : QPos,
    ∀ z : Scalar, representedRectangleContains K z → ∀ hz : f.domain z,
      Small (f.eval z hz).val B.val
  change good J
  apply represented_rectangle_cover good J hX hY
  · intro K ll lr rl rr
    obtain ⟨Bll,hll⟩ := ll
    obtain ⟨Blr,hlr⟩ := lr
    obtain ⟨Brl,hrl⟩ := rl
    obtain ⟨Brr,hrr⟩ := rr
    let B : QPos := ⟨Bll.val+Blr.val+Brl.val+Brr.val, by
      have := Bll.property; have := Blr.property; have := Brl.property; have := Brr.property
      grind only⟩
    refine ⟨B, ?_⟩
    intro z hz hzf
    obtain ⟨⟨r,s⟩,hr⟩ := representedRectangle_bisect_mem K z hz
    have h1 := Bll.property; have h2 := Blr.property; have h3 := Brl.property; have h4 := Brr.property
    cases r <;> cases s
    · exact (hll z hr hzf).mono (by dsimp [B]; grind only)
    · exact (hlr z hr hzf).mono (by dsimp [B]; grind only)
    · exact (hrl z hr hzf).mono (by dsimp [B]; grind only)
    · exact (hrr z hr hzf).mono (by dsimp [B]; grind only)
  · intro x y hx hy hxl hxu hyl hyu
    let a : Scalar := ⟨coordinateComplex x y, coordinateComplex_valid x y hx hy⟩
    let ha := hdom a ⟨hxl,hxu,hyl,hyu⟩
    let one : QPos := ⟨1, by decide +kernel⟩
    let d := hf.continuous.delta a ha one
    refine ⟨d, ?_⟩
    intro K hKx hKy
    let B : QPos := ⟨scalarBound (f.eval a ha)+1, by have := scalarBound_pos (f.eval a ha); grind only⟩
    refine ⟨B, ?_⟩
    intro z hz hzf
    have hKX : K.1.lo ≤ K.1.hi := by
      have h := RealRaw.le_trans (realPart_valid z.property) hz.1 hz.2.1 0 0
      exact h
    have hKY : K.2.lo ≤ K.2.hi := by
      have h := RealRaw.le_trans (imagPart_valid z.property) hz.2.2.1 hz.2.2.2 0 0
      exact h
    have hn := rectangleNear_represented_displacement K x y d hKX hKY hKx hKy z hz
    have he := hf.continuous.estimate a ha one z hzf hn
    have hs := LocalODE.small_add (scalar_small (f.eval a ha)) he
    apply Small.congr
      (add_valid (f.eval a ha).property (sub_valid (f.eval z hzf).property (f.eval a ha).property))
      (f.eval z hzf).property _ hs
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
    change ComplexRawQuotient.ofRaw (f.eval a ha).val (f.eval a ha).property +
      (ComplexRawQuotient.ofRaw (f.eval z hzf).val (f.eval z hzf).property -
        ComplexRawQuotient.ofRaw (f.eval a ha).val (f.eval a ha).property) =
      ComplexRawQuotient.ofRaw (f.eval z hzf).val (f.eval z hzf).property
    grind only

end ComputableAnalysis.ModularForms
