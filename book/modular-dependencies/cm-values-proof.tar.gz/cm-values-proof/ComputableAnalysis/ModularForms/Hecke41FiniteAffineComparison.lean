import ComputableAnalysis.ModularForms.NormalizedGridDifference
import ComputableAnalysis.ModularForms.Hecke41SquareAffineDensityAgreement
import ComputableAnalysis.ModularForms.ActualSquareContourAffineAgreement

/-! Finite normalized actual-to-affine edge comparison. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def hecke41SquareComparisonGridDensity (affine : Bool) (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (edge : HalfEdge) (R : QPos)
    (hR : R.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (M : Nat) (hM : 0<M) (j : Nat) : Scalar :=
  let u := squareMidpointParameter M (j%M)
  let hu := squareMidpointParameter_unit M (j%M) hM (Nat.mod_lt j hM)
  let w := rationalRectangleScalar (QComplex.scaleRat R.val (point edge u))
  let v := if affine then suppliedAffineValue ((hecke41NomeDescended k 10000).eval a ha)
      ((hecke41NomeDescended_holomorphic k 10000).derivative a ha) w
    else (hecke41NomeDescended k 10000).eval (Centered.translate a w)
      (hecke41SquareEdge_domain k a ha edge R hR u hu.1 hu.2)
  suppliedSquareDensity v edge R u

theorem hecke41FiniteAffineEdge_difference_bound (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (edge : HalfEdge) (R eps : QPos)
    (hR : R.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (hDelta : R.val≤(((hecke41NomeDescended_holomorphic k 10000).atPoint a ha).delta eps).val)
    (M : Nat) (hM : 0<M) :
    Small (sub (scaleRat ((M:Rat)⁻¹) (gridScalarSum M
        (hecke41SquareComparisonGridDensity false k a ha edge R hR M hM)).val)
      (scaleRat ((M:Rat)⁻¹) (gridScalarSum M
        (hecke41SquareComparisonGridDensity true k a ha edge R hR M hM)).val)) (8*eps.val) := by
  apply normalizedGridDifference_bound _ _ M hM (8*eps.val)
    (Rat.mul_nonneg (by decide +kernel) (Rat.le_of_lt eps.property))
  intro j hj
  dsimp only [hecke41SquareComparisonGridDensity]
  simp only [Bool.false_eq_true,↓reduceIte]
  exact hecke41SquareAffineDensity_difference_bound k a ha edge R eps hR hDelta _
    (squareMidpointParameter_unit M (j%M) hM (Nat.mod_lt j hM)).1
    (squareMidpointParameter_unit M (j%M) hM (Nat.mod_lt j hM)).2

end ComputableAnalysis.ModularForms
