import ComputableAnalysis.ModularForms.RepresentedSequenceLimitComparison
import ComputableAnalysis.ModularForms.Hecke41FiniteContourConvergence
import ComputableAnalysis.ModularForms.Hecke41SquareRadiusComparison

/-! Exact doubled-radius invariance of the constructed actual Hecke contour value. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem hecke41ContourLimit_doubled_radius (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : (squareFrameOuterRadius R).val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) :
    (hecke41DyadicKernelContourLimit k a ha (squareFrameOuterRadius R) hR PDE.CauchyContour.square).val.Equiv
      (hecke41DyadicKernelContourLimit k a ha R
        (Rat.le_trans (squareFrameRadius_le_outer R) hR) PDE.CauchyContour.square).val := by
  let hSmall := Rat.le_trans (squareFrameRadius_le_outer R) hR
  let p := fun n => hecke41SquareKernelEdgeList k a ha (squareFrameOuterRadius R) (2^(n+1))
    (Nat.pow_pos (by decide +kernel)) (Rat.le_trans hR (minRadius_left _ _)) PDE.CauchyContour.square
  let q := fun n => hecke41SquareKernelEdgeList k a ha R (2^n)
    (Nat.pow_pos (by decide +kernel)) (Rat.le_trans hSmall (minRadius_left _ _)) PDE.CauchyContour.square
  apply representedSequenceLimit_comparison p q
  · intro eps
    obtain ⟨N,hN⟩ := hecke41FiniteSquareContour_converges k a ha (squareFrameOuterRadius R) hR eps
    exact ⟨N,fun n hn => hN (n+1) (by omega)⟩
  · exact hecke41FiniteSquareContour_converges k a ha R hSmall
  · intro eps
    obtain ⟨N,hN⟩ := hecke41SquareContour_doubled_radius_difference_converges_zero k a ha R
      (Rat.le_trans hR (minRadius_left _ _)) eps
    refine ⟨N, ?_⟩
    intro n hn
    have hb := hN n hn
    have he : 2*(2^n)=2^(n+1) := by rw [Nat.pow_succ]; omega
    simpa only [he] using hb

end ComputableAnalysis.ModularForms
