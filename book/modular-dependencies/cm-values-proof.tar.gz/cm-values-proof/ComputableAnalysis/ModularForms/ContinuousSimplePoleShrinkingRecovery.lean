import ComputableAnalysis.ModularForms.ContinuousSimplePoleCentralResidue

namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

/-- Actual finite simple-pole square quadrature recovers the center residue as
the square shrinks and the midpoint count increases. Continuity suffices for
this local approximation; contour-radius agreement is a separate analytic law. -/
theorem continuousSimplePoleSquare_shrinking_recovery (F : DomainFunctions.Map)
    (hop : OpenDomain F) (hf : ContinuousOn F.domain F.eval) (a : Scalar) (ha : F.domain a)
    (eps : QPos) :
    ∃ rho : QPos, ∃ N, ∀ (R : QPos) (hR : R.val ≤ rho.val), ∀ n, N ≤ n →
      ∃ hdom : R.val ≤ (hop.radius a ha).val,
        Small (sub (continuousSimplePoleFiniteContour false F hop a ha R hdom (2^n)
          (Nat.pow_pos (by decide +kernel)) square).val
          (scalarProduct (F.eval a ha) ⟨twoPiI,twoPiI_valid⟩).val) eps.val := by
  let eta := divideRadius eps ⟨16,by decide +kernel⟩
  let rho := minRadius (hop.radius a ha) (hf.delta a ha (halfError eta))
  obtain ⟨N,hN⟩ := continuousSimplePoleCentralSquare_uniform_convergence F hop a ha (halfError eps)
  refine ⟨rho,N,?_⟩
  intro R hR n hn
  let hd := Rat.le_trans hR (minRadius_left _ _)
  let hc := Rat.le_trans hR (minRadius_right _ _)
  let X := continuousSimplePoleFiniteContour false F hop a ha R hd (2^n)
    (Nat.pow_pos (by decide +kernel)) square
  let C := continuousSimplePoleFiniteContour true F hop a ha R hd (2^n)
    (Nat.pow_pos (by decide +kernel)) square
  let V := scalarProduct (F.eval a ha) ⟨twoPiI,twoPiI_valid⟩
  have hXC := continuousSimplePoleSquare_central_error F hop hf a ha R eta hd hc (2^n)
    (Nat.pow_pos (by decide +kernel))
  have hVC := hN n hn R hd
  have hCV : Small (sub C.val V.val) (halfError eps).val := by
    have he : (neg (sub V.val C.val)).Equiv (sub C.val V.val) := by
      apply ComplexRawQuotient.equiv_of_ofRaw_eq
        (hleft := neg_valid (sub_valid V.property C.property)) (hright := sub_valid C.property V.property)
      change -(gridScalarValue V-gridScalarValue C)=gridScalarValue C-gridScalarValue V
      grind only
    exact Small.congr (neg_valid (sub_valid V.property C.property)) (sub_valid C.property V.property)
      he (SeriesLimitLaws.small_neg hVC)
  have he : (add (sub X.val C.val) (sub C.val V.val)).Equiv (sub X.val V.val) := by
    apply ComplexRawQuotient.equiv_of_ofRaw_eq
      (hleft := add_valid (sub_valid X.property C.property) (sub_valid C.property V.property))
      (hright := sub_valid X.property V.property)
    change (gridScalarValue X-gridScalarValue C)+(gridScalarValue C-gridScalarValue V)=
      gridScalarValue X-gridScalarValue V
    grind only
  have hsum := Small.congr
    (add_valid (sub_valid X.property C.property) (sub_valid C.property V.property))
    (sub_valid X.property V.property) he (LocalODE.small_add hXC hCV)
  have h16 := divideRadius_identity eps ⟨16,by decide +kernel⟩
  have h2 := halfError_identity eps
  have herr : 8*eta.val+(halfError eps).val=eps.val := by
    change 16*eta.val=eps.val at h16
    grind only
  rw [herr] at hsum
  exact ⟨hd,hsum⟩

end ComputableAnalysis.ModularForms
