import ComputableAnalysis.ModularForms.ActionComposition
import ComputableAnalysis.ModularForms.ExponentialDiagonal

/-! The actual automorphy factor and its exact cocycle for represented
upper-half-plane inputs. These are algebraic laws, not assumed modularity. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert

def automorphyFactor (g : SL2Z) (z : Scalar) : Scalar :=
  ⟨integerAffine g.c g.d z.val,integerAffine_valid _ _ z.property⟩

theorem automorphyFactor_congr (g : SL2Z) (z w : Scalar) (hzw : z.val.Equiv w.val) :
    (automorphyFactor g z).val.Equiv (automorphyFactor g w).val :=
  integerAffine_equiv g.c g.d hzw

theorem automorphyFactor_nonzero (g : SL2Z) (z : Scalar) (hz : InUpperHalfPlane z.val) :
    NonzeroBoxSearch.Nonzero (automorphyFactor g z) := denominator_nonzero g z hz

/-- The denominator of a composite matrix is the product of the two
denominators evaluated along its actual fractional-linear action. -/
theorem automorphyFactor_cocycle (g h : SL2Z) (z : Scalar) (hz : InUpperHalfPlane z.val) :
    (automorphyFactor (SL2Z.multiply g h) z).val.Equiv
      (mul (automorphyFactor g (fractionalLinear h z hz)).val (automorphyFactor h z).val) := by
  let y := fractionalLinear h z hz
  have hy := ComplexRawQuotient.ofRaw_eq_ofRaw
    (hleft := mul_valid (integerAffine_valid _ _ z.property) y.property)
    (hright := integerAffine_valid _ _ z.property) (fractionalLinear_cancel h z hz)
  change ComplexRawQuotient.ofRaw (integerAffine h.c h.d z.val) (integerAffine_valid _ _ z.property) *
    ComplexRawQuotient.ofRaw y.val y.property =
    ComplexRawQuotient.ofRaw (integerAffine h.a h.b z.val) (integerAffine_valid _ _ z.property) at hy
  simp only [integerAffine_class] at hy
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := (automorphyFactor (SL2Z.multiply g h) z).property)
    (hright := mul_valid (automorphyFactor g y).property (automorphyFactor h z).property)
  change ComplexRawQuotient.ofRaw (integerAffine (SL2Z.multiply g h).c (SL2Z.multiply g h).d z.val)
    (integerAffine_valid _ _ z.property) =
    ComplexRawQuotient.ofRaw (integerAffine g.c g.d y.val) (integerAffine_valid _ _ y.property) *
    ComplexRawQuotient.ofRaw (integerAffine h.c h.d z.val) (integerAffine_valid _ _ z.property)
  simp only [integerAffine_class,SL2Z.multiply]
  grind

theorem automorphyFactor_identity (z : Scalar) :
    (automorphyFactor SL2Z.identity z).val.Equiv one := integerAffine_zero 1 z

end ComputableAnalysis.ModularForms
