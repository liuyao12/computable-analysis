import ComputableAnalysis.ModularForms.NomeDiscriminantMapFourierAgreement
import ComputableAnalysis.ModularForms.TauNormalizedDifferential
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- The actual discrepancy between the Eisenstein and Euler discriminants. -/
def discriminantEulerDifferenceMap : DomainFunctions.Map :=
  sumOn nomeNormalizedDiscriminantMap (DomainFunctions.negate tauNormalizedEulerMap) (fun _ h => h)
noncomputable def discriminantEulerDifferenceMap_holomorphic : Holomorphic discriminantEulerDifferenceMap :=
  nomeNormalizedDiscriminantMap_holomorphic.sumOn tauNormalizedEulerMap_holomorphic.negate (fun _ h => h)
/-- The discrepancy satisfies the homogeneous theta equation. No agreement is assumed. -/
theorem discriminantEulerDifferenceMap_theta (q : Scalar) (hq : tauEulerNomeDomain q) :
    (mul q.val (discriminantEulerDifferenceMap_holomorphic.derivative q hq).val).Equiv
      (mul (tauWeightTwoNomeMap.eval q hq).val (discriminantEulerDifferenceMap.eval q hq).val) := by
  let A := nomeNormalizedDiscriminantMap.eval q hq
  let B := tauNormalizedEulerMap.eval q hq
  let E := tauWeightTwoNomeMap.eval q hq
  let D := nomeNormalizedDiscriminantMap_holomorphic.derivative q hq
  let F := tauNormalizedEulerMap_holomorphic.derivative q hq
  have ha := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := mul_valid q.property D.property)
    (hright := mul_valid E.property A.property) (nomeNormalizedDiscriminantMap_theta q hq)
  have hb := ComplexRawQuotient.ofRaw_eq_ofRaw (hleft := mul_valid q.property F.property)
    (hright := mul_valid (tauWeightTwoNomeValue q hq).property B.property)
    (tauNormalizedEulerMap_differential_identity q hq)
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := mul_valid q.property (discriminantEulerDifferenceMap_holomorphic.derivative q hq).property)
    (hright := mul_valid E.property (discriminantEulerDifferenceMap.eval q hq).property)
  let a := ComplexRawQuotient.ofRaw A.val A.property
  let b := ComplexRawQuotient.ofRaw B.val B.property
  let e := ComplexRawQuotient.ofRaw E.val E.property
  let d := ComplexRawQuotient.ofRaw D.val D.property
  let f := ComplexRawQuotient.ofRaw F.val F.property
  let z := ComplexRawQuotient.ofRaw q.val q.property
  change z*d=e*a at ha
  change z*f=e*b at hb
  change z*(d+ -f)=e*(a+ -b)
  grind only
end ComputableAnalysis.ModularForms
