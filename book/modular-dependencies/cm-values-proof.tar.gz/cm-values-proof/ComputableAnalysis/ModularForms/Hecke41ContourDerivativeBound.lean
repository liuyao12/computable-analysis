import ComputableAnalysis.ModularForms.Hecke41ContourDerivativeError

/-! Actual Cauchy derivative residue bounds inherited from finite contours. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

theorem convergentScalar_bound (x : Scalar) (p : Nat → Scalar) (B : Rat)
    (hp : ∀ n, Small (p n).val B)
    (hx : ∀ eps : QPos, ∃ N, ∀ n, N≤n → Small (sub x.val (p n).val) eps.val) :
    Small x.val B := by
  apply SeriesLimitLaws.small_closed x.val B (fun j => (RepresentedCauchySum.error j).val)
    RepresentedCauchySum.error_shrinks
  intro j
  obtain ⟨N,hN⟩ := hx (RepresentedCauchySum.error j)
  have hb := LocalODE.small_add (hp N) (hN N (Nat.le_refl N))
  exact Small.congr (add_valid (p N).property (sub_valid x.property (p N).property)) x.property
    (SeriesLimitLaws.add_difference x.val (p N).val x.property (p N).property) hb

theorem hecke41ContourLimit_bound (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) :
    Small (hecke41DyadicKernelContourLimit k a ha R hR PDE.CauchyContour.square).val
      (64*(2*(2:Rat)^10000)*(1/R.val)) := by
  apply convergentScalar_bound _
    (fun n => hecke41SquareKernelEdgeList k a ha R (2^n)
      (Nat.pow_pos (by decide +kernel)) (Rat.le_trans hR (minRadius_left _ _)) PDE.CauchyContour.square)
  · intro n
    have hb := hecke41SquareKernelEdgeList_bound k a ha R (2^n)
      (Nat.pow_pos (by decide +kernel)) (Rat.le_trans hR (minRadius_left _ _)) PDE.CauchyContour.square
    change Small _ (8*(8*(2*(2:Rat)^10000)*(1/R.val))) at hb
    have he (C S : Rat) : 8*(8*C*S)=64*C*S := by grind only
    rw [he] at hb
    exact hb
  · exact hecke41FiniteSquareContour_converges k a ha R hR

theorem hecke41DerivativeResidue_bound (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : R.val≤(hecke41NomeDerivativeNeighborhood k 10000 a ha).val) :
    Small (scalarProduct ((hecke41NomeDescended_holomorphic k 10000).derivative a ha)
      ⟨twoPiI,twoPiI_valid⟩).val (64*(2*(2:Rat)^10000)*(1/R.val)) :=
  Small.congr (hecke41DyadicKernelContourLimit k a ha R hR PDE.CauchyContour.square).property
    (scalarProduct ((hecke41NomeDescended_holomorphic k 10000).derivative a ha) ⟨twoPiI,twoPiI_valid⟩).property
    (hecke41ContourLimit_cauchy_derivative k a ha R hR) (hecke41ContourLimit_bound k a ha R hR)

end ComputableAnalysis.ModularForms
