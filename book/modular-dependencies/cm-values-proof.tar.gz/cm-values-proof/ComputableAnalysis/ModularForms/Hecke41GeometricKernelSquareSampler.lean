import ComputableAnalysis.ModularForms.Hecke41KernelSquareSampler
import ComputableAnalysis.ModularForms.Hecke41GeometricKernelBoundaryVanishing

/-! A common executable sampler for all tiles of a justified square. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

theorem hecke41GeometricKernelSquare_rational_domain (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (B : QPos)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (q : QComplex) (hq : rationalRectangleContains (rationalKernelSquare B) q)
    (hne : QComplex.normSq q≠0) :
    (hecke41CauchyIntegrandMap k a).domain (rationalRectangleScalar q) := by
  have hb := representedRectangle_small (rationalKernelSquare B) B.val
    Rat.le_refl Rat.le_refl Rat.le_refl Rat.le_refl (rationalRectangleScalar q)
    (rationalRectangle_represented_mem _ q hq)
  exact (hecke41CauchyIntegrandMap_domain k a _).2
    ⟨hecke41NomeGeometric_bounded_offset_domain a ha (rationalRectangleScalar q) B hB hb,
      rationalConstant_nonzero q hne⟩

def hecke41GeometricKernelSquareSample (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (B : QPos)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (q : QComplex) : Scalar :=
  if h : rationalRectangleContains (rationalKernelSquare B) q ∧ QComplex.normSq q≠0 then
    (hecke41CauchyIntegrandMap k a).eval (rationalRectangleScalar q)
      (hecke41GeometricKernelSquare_rational_domain k a ha B hB q h.1 h.2)
  else ⟨zero,ofQComplex_valid _⟩

theorem hecke41GeometricKernelSquareSample_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (B : QPos)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (q : QComplex) (hq : rationalRectangleContains (rationalKernelSquare B) q)
    (hne : QComplex.normSq q≠0)
    (hz : (hecke41CauchyIntegrandMap k a).domain (rationalRectangleScalar q)) :
    (hecke41GeometricKernelSquareSample k a ha B hB q).val.Equiv
      ((hecke41CauchyIntegrandMap k a).eval (rationalRectangleScalar q) hz).val := by
  simp only [hecke41GeometricKernelSquareSample,dif_pos (show rationalRectangleContains
    (rationalKernelSquare B) q ∧ QComplex.normSq q≠0 from ⟨hq,hne⟩)]
  exact equiv_refl _ ((hecke41CauchyIntegrandMap k a).eval (rationalRectangleScalar q) hz).property


theorem hecke41GeometricKernelSquareSample_rectangle_agreement (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (J : QInterval × QInterval) (R B : QPos)
    (hs : rectangleSeparated J R)
    (hxl : -B.val≤J.1.lo) (hxu : J.1.hi≤B.val)
    (hyl : -B.val≤J.2.lo) (hyu : J.2.hi≤B.val)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (q : QComplex) (hq : rationalRectangleContains J q) :
    (hecke41GeometricKernelSquareSample k a ha B hB q).val.Equiv
      (hecke41GeometricKernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB q).val := by
  have hsq : rationalRectangleContains (rationalKernelSquare B) q :=
    ⟨Rat.le_trans hxl hq.1,Rat.le_trans hq.2.1 hxu,
      Rat.le_trans hyl hq.2.2.1,Rat.le_trans hq.2.2.2 hyu⟩
  have hn := representedRectangle_nonzero J R hs (rationalRectangleScalar q)
    (rationalRectangle_represented_mem J q hq)
  have hne : QComplex.normSq q≠0 := by
    intro he
    have hz := QComplex.normSq_eq_zero_iff.mp he
    apply hn
    rw [hz]
    exact equiv_refl zero (ofQComplex_valid _)
  let hz := hecke41GeometricKernelRectangle_domain k a ha J R B hs hxl hxu hyl hyu hB _
    (rationalRectangle_represented_mem J q hq)
  have hsa := hecke41GeometricKernelSquareSample_agreement k a ha B hB q hsq hne hz
  have hra := hecke41GeometricKernelRectangleSample_agreement k a ha J R B hs hxl hxu hyl hyu hB q hq hz
  exact equiv_trans (hecke41GeometricKernelSquareSample k a ha B hB q).property
    ((hecke41CauchyIntegrandMap k a).eval (rationalRectangleScalar q) hz).property
    (hecke41GeometricKernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB q).property hsa hra

end ComputableAnalysis.ModularForms
