import ComputableAnalysis.ModularForms.DiscriminantHeckeAffineTranslation
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
set_option maxHeartbeats 2000000
/-- The dilation term is unchanged by unit translation of the represented input. -/
theorem discriminantHeckeDilation_translate_one (p : Nat) (hp : 0<(p:Rat))
    (z : Scalar) (hz : InUpperHalfPlane z.val) :
    ((discriminantAffinePullback (p:Rat) 0 hp).eval ⟨translate 1 z.val,translate_valid _ z.property⟩
      (translate_mem _ hz)).val.Equiv ((discriminantAffinePullback (p:Rat) 0 hp).eval z hz).val := by
  let w := (rationalAffineMap (p:Rat) 0).eval z hz
  have hw := rationalAffineMap_upper (p:Rat) 0 hp z hz
  have hs := discriminantAffinePullback_translate_one (p:Rat) 0 hp z hz
  simp only [Rat.zero_add] at hs
  have he := rationalAffineMap_scaled_offset (p:Rat) 1 z hz
  rw [Rat.mul_one] at he
  have hv := normalizedLatticeDiscriminantMap.eval_congr
    ((rationalAffineMap (p:Rat) 1).eval z hz)
    (⟨translate (p:Rat) w.val,translate_valid _ w.property⟩ : Scalar)
    (rationalAffineMap_upper (p:Rat) 1 hp z hz) (translate_mem _ hw) he
  have hpv := normalizedLatticeDiscriminantMap_integer_periodic w hw (p:Int)
  change (normalizedLatticeDiscriminantMap.eval (⟨translate (p:Rat) w.val,translate_valid _ w.property⟩ : Scalar) (translate_mem (p:Rat) hw)).val.Equiv
    (normalizedLatticeDiscriminantMap.eval w hw).val at hpv
  have hm := equiv_trans ((discriminantAffinePullback (p:Rat) 1 hp).eval z hz).property
    (normalizedLatticeDiscriminantMap.eval ⟨translate (p:Rat) w.val,translate_valid _ w.property⟩ (translate_mem _ hw)).property
    ((discriminantAffinePullback (p:Rat) 0 hp).eval z hz).property hv hpv
  exact equiv_trans
    ((discriminantAffinePullback (p:Rat) 0 hp).eval ⟨translate 1 z.val,translate_valid _ z.property⟩ (translate_mem _ hz)).property
    ((discriminantAffinePullback (p:Rat) 1 hp).eval z hz).property
    ((discriminantAffinePullback (p:Rat) 0 hp).eval z hz).property hs hm

/-- The actual positive-index Hecke operator on the discriminant is translation invariant. -/
theorem discriminantHeckeMap_translate_one (p : Nat) (hp : 0<(p:Rat))
    (z : Scalar) (hz : InUpperHalfPlane z.val) :
    ((discriminantHeckeMap p hp).eval ⟨translate 1 z.val,translate_valid _ z.property⟩
      (translate_mem _ hz)).val.Equiv ((discriminantHeckeMap p hp).eval z hz).val := by
  let w : Scalar := ⟨translate 1 z.val,translate_valid _ z.property⟩
  have hw : InUpperHalfPlane w.val := translate_mem _ hz
  let D := (discriminantAffinePullback (p:Rat) 0 hp).eval z hz
  let E := (discriminantAffinePullback (p:Rat) 0 hp).eval w hw
  let A := (discriminantHeckeAffineSum p hp p).eval z hz
  let B := (discriminantHeckeAffineSum p hp p).eval w hw
  let V : Scalar := ⟨add (scaleRat ((p:Rat)^11) D.val) (scaleRat (1/(p:Rat)) A.val),
    add_valid (scaleRat_valid D.property) (scaleRat_valid A.property)⟩
  let W : Scalar := ⟨add (scaleRat ((p:Rat)^11) E.val) (scaleRat (1/(p:Rat)) B.val),
    add_valid (scaleRat_valid E.property) (scaleRat_valid B.property)⟩
  have he : W.val.Equiv V.val :=
    add_equiv (scaleRat_equiv (r := (p:Rat)^11) (discriminantHeckeDilation_translate_one p hp z hz))
      (scaleRat_equiv (r := 1/(p:Rat)) (discriminantHeckeAffineSum_translate_one p hp z hz))
  exact equiv_trans ((discriminantHeckeMap p hp).eval w hw).property W.property
    ((discriminantHeckeMap p hp).eval z hz).property (discriminantHeckeMap_eval p hp w hw)
    (equiv_trans W.property V.property ((discriminantHeckeMap p hp).eval z hz).property he
      (equiv_symm (discriminantHeckeMap_eval p hp z hz)))
end ComputableAnalysis.ModularForms
