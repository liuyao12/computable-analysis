import ComputableAnalysis.ModularForms.CartesianSquareSignedPoints
import ComputableAnalysis.ModularForms.RationalWeightedSampleScaling
import ComputableAnalysis.ModularForms.RepresentedJoinedPartitionSum

/-! Exact tangent weights for Cartesian samples in signed square coordinates. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions PDE.CauchyContour

def signedSquareDensity (f : QComplex → Scalar) (S : QPos) (quarter : Quarter) (u : Rat) : Scalar :=
  scalarProduct (f (QComplex.scaleRat S.val (point ⟨quarter,true⟩ u)))
    (rationalRectangleScalar (QComplex.scaleRat S.val (velocity ⟨quarter,true⟩)))

theorem squareSignedInterval_cell_width_scaled (S : QPos) (I : QInterval) (M j : Nat) :
    S.val*(⟨rationalUniformPartition (squareSignedInterval S I) M j,
      rationalUniformPartition (squareSignedInterval S I) M (j+1)⟩ : QInterval).width=
      I.width/(M:Rat) := by
  rw [rationalUniformPartition_cell_width]
  have hn : S.val≠0 := Rat.ne_of_gt S.property
  have hlo : S.val*(I.lo/S.val)=I.lo := by rw [Rat.mul_comm]; exact Rat.div_mul_cancel hn
  have hhi : S.val*(I.hi/S.val)=I.hi := by rw [Rat.mul_comm]; exact Rat.div_mul_cancel hn
  unfold squareSignedInterval QInterval.width
  simp only [Rat.div_def] at hlo hhi ⊢
  grind only

theorem rectangleGridHorizontal_bottom_signed_weight (f : QComplex → Scalar)
    (S : QPos) (I : QInterval) (M j : Nat) :
    let cell : QInterval := ⟨rationalUniformPartition (squareSignedInterval S I) M j,
      rationalUniformPartition (squareSignedInterval S I) M (j+1)⟩
    (rectangleGridHorizontal f (I,⟨-S.val,S.val⟩) M j 0).val.Equiv
      (scaleRat (cell.width) (signedSquareDensity f S .south (cell.midpoint)).val) := by
  intro cell
  have hw := squareSignedInterval_cell_width_scaled S I M j
  have ht : (⟨rectangleGridStepX (I,⟨-S.val,S.val⟩) M,0⟩ : QComplex)=
      QComplex.scaleRat (cell.width) (QComplex.scaleRat S.val (velocity ⟨.south,true⟩)) := by
    simp only [rectangleGridStepX,rectangleGridStepY,QComplex.scaleRat,velocity,rotation,
      orientation,QComplex.mul,↓reduceIte,QComplex.mk.injEq]
    constructor <;> change _=_ <;> grind only
  unfold rectangleGridHorizontal
  rw [rectangleGridHorizontalPoint_bottom_signed,ht]
  exact rationalWeightedSample_scale _ _ _

theorem rectangleGridVertical_right_signed_weight (f : QComplex → Scalar)
    (S : QPos) (I : QInterval) (M j : Nat) :
    let cell : QInterval := ⟨rationalUniformPartition (squareSignedInterval S I) M j,
      rationalUniformPartition (squareSignedInterval S I) M (j+1)⟩
    (rectangleGridVertical f (⟨S.val,S.val⟩,I) M 0 j).val.Equiv
      (scaleRat (cell.width) (signedSquareDensity f S .east (cell.midpoint)).val) := by
  intro cell
  have hw := squareSignedInterval_cell_width_scaled S I M j
  have ht : (⟨0,rectangleGridStepY (⟨S.val,S.val⟩,I) M⟩ : QComplex)=
      QComplex.scaleRat (cell.width) (QComplex.scaleRat S.val (velocity ⟨.east,true⟩)) := by
    simp only [rectangleGridStepX,rectangleGridStepY,QComplex.scaleRat,velocity,rotation,
      orientation,QComplex.mul,↓reduceIte,QComplex.mk.injEq]
    constructor <;> change _=_ <;> grind only
  unfold rectangleGridVertical
  rw [rectangleGridVerticalPoint_right_signed,ht]
  exact rationalWeightedSample_scale _ _ _

theorem rectangleGridHorizontal_top_signed_weight (f : QComplex → Scalar)
    (S : QPos) (I : QInterval) (M j : Nat) :
    let cell : QInterval := ⟨rationalUniformPartition (squareSignedInterval S I) M j,
      rationalUniformPartition (squareSignedInterval S I) M (j+1)⟩
    (rectangleGridHorizontal f (I,⟨S.val,S.val⟩) M j 0).val.Equiv
      (scaleRat (-cell.width) (signedSquareDensity f S .north (-cell.midpoint)).val) := by
  intro cell
  have hw := squareSignedInterval_cell_width_scaled S I M j
  have ht : (⟨rectangleGridStepX (I,⟨S.val,S.val⟩) M,0⟩ : QComplex)=
      QComplex.scaleRat (-cell.width) (QComplex.scaleRat S.val (velocity ⟨.north,true⟩)) := by
    simp only [rectangleGridStepX,rectangleGridStepY,QComplex.scaleRat,velocity,rotation,
      orientation,QComplex.mul,↓reduceIte,QComplex.mk.injEq]
    constructor <;> change _=_ <;> grind only
  unfold rectangleGridHorizontal
  rw [rectangleGridHorizontalPoint_top_signed,ht]
  exact rationalWeightedSample_scale _ _ _

theorem rectangleGridVertical_left_signed_weight (f : QComplex → Scalar)
    (S : QPos) (I : QInterval) (M j : Nat) :
    let cell : QInterval := ⟨rationalUniformPartition (squareSignedInterval S I) M j,
      rationalUniformPartition (squareSignedInterval S I) M (j+1)⟩
    (rectangleGridVertical f (⟨-S.val,-S.val⟩,I) M 0 j).val.Equiv
      (scaleRat (-cell.width) (signedSquareDensity f S .west (-cell.midpoint)).val) := by
  intro cell
  have hw := squareSignedInterval_cell_width_scaled S I M j
  have ht : (⟨0,rectangleGridStepY (⟨-S.val,-S.val⟩,I) M⟩ : QComplex)=
      QComplex.scaleRat (-cell.width) (QComplex.scaleRat S.val (velocity ⟨.west,true⟩)) := by
    simp only [rectangleGridStepX,rectangleGridStepY,QComplex.scaleRat,velocity,rotation,
      orientation,QComplex.mul,↓reduceIte,QComplex.mk.injEq]
    constructor <;> change _=_ <;> grind only
  unfold rectangleGridVertical
  rw [rectangleGridVerticalPoint_left_signed,ht]
  exact rationalWeightedSample_scale _ _ _

theorem rectangleGridHorizontal_bottom_signed_sum (f : QComplex → Scalar)
    (S : QPos) (I : QInterval) (M : Nat) :
    let x := rationalUniformPartition (squareSignedInterval S I) M
    (gridScalarSum M (fun j => rectangleGridHorizontal f (I,⟨-S.val,S.val⟩) M j 0)).val.Equiv
      (rationalWeightedSampleSum
        (fun j => signedSquareDensity f S .south ((⟨x j,x (j+1)⟩ : QInterval).midpoint))
        (fun j => (⟨x j,x (j+1)⟩ : QInterval).width) M).val := by
  intro x
  apply gridScalarSum_congr
  intro j
  exact rectangleGridHorizontal_bottom_signed_weight f S I M j

theorem rectangleGridVertical_right_signed_sum (f : QComplex → Scalar)
    (S : QPos) (I : QInterval) (M : Nat) :
    let x := rationalUniformPartition (squareSignedInterval S I) M
    (gridScalarSum M (fun j => rectangleGridVertical f (⟨S.val,S.val⟩,I) M 0 j)).val.Equiv
      (rationalWeightedSampleSum
        (fun j => signedSquareDensity f S .east ((⟨x j,x (j+1)⟩ : QInterval).midpoint))
        (fun j => (⟨x j,x (j+1)⟩ : QInterval).width) M).val := by
  intro x
  apply gridScalarSum_congr
  intro j
  exact rectangleGridVertical_right_signed_weight f S I M j

theorem rectangleGridHorizontal_top_signed_sum (f : QComplex → Scalar)
    (S : QPos) (I : QInterval) (M : Nat) :
    let x := rationalUniformPartition (squareSignedInterval S I) M
    (gridScalarSum M (fun j => rectangleGridHorizontal f (I,⟨S.val,S.val⟩) M j 0)).val.Equiv
      (rationalWeightedSampleSum
        (fun j => signedSquareDensity f S .north (-(⟨x j,x (j+1)⟩ : QInterval).midpoint))
        (fun j => -(⟨x j,x (j+1)⟩ : QInterval).width) M).val := by
  intro x
  apply gridScalarSum_congr
  intro j
  exact rectangleGridHorizontal_top_signed_weight f S I M j

theorem rectangleGridVertical_left_signed_sum (f : QComplex → Scalar)
    (S : QPos) (I : QInterval) (M : Nat) :
    let x := rationalUniformPartition (squareSignedInterval S I) M
    (gridScalarSum M (fun j => rectangleGridVertical f (⟨-S.val,-S.val⟩,I) M 0 j)).val.Equiv
      (rationalWeightedSampleSum
        (fun j => signedSquareDensity f S .west (-(⟨x j,x (j+1)⟩ : QInterval).midpoint))
        (fun j => -(⟨x j,x (j+1)⟩ : QInterval).width) M).val := by
  intro x
  apply gridScalarSum_congr
  intro j
  exact rectangleGridVertical_left_signed_weight f S I M j

end ComputableAnalysis.ModularForms
