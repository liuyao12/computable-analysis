import ComputableAnalysis.ModularForms.BoundedRepresentedRectangle
import ComputableAnalysis.ModularForms.Hecke41SquareKernelAgreement
import ComputableAnalysis.ModularForms.DomainRectangleNeighborhoodCover

/-! Whole represented rectangle domains for the actual Hecke kernel. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions

theorem hecke41KernelRectangle_domain (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (J : QInterval × QInterval) (R B : QPos)
    (hs : rectangleSeparated J R)
    (hxl : -B.val≤J.1.lo) (hxu : J.1.hi≤B.val)
    (hyl : -B.val≤J.2.lo) (hyu : J.2.hi≤B.val)
    (hB : B.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (z : Scalar) (hz : representedRectangleContains J z) :
    (hecke41CauchyIntegrandMap k a).domain z := by
  have hb := representedRectangle_small J B.val hxl hxu hyl hyu z hz
  have hd := Small.congr z.property (Centered.offset a (Centered.translate a z)).property
    (equiv_symm (Centered.offset_translate a z)) hb
  exact (hecke41CauchyIntegrandMap_domain k a z).2
    ⟨(hecke41NomeDescended_holomorphic k 10000).openDomain.inside a ha
      (Centered.translate a z) (hd.mono hB),representedRectangle_nonzero J R hs z hz⟩

theorem hecke41KernelRectangle_neighborhood_cover (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (J : QInterval × QInterval) (R B eps : QPos)
    (hs : rectangleSeparated J R) (hX : J.1.lo≤J.1.hi) (hY : J.2.lo≤J.2.hi)
    (hxl : -B.val≤J.1.lo) (hxu : J.1.hi≤B.val)
    (hyl : -B.val≤J.2.lo) (hyu : J.2.hi≤B.val)
    (hB : B.val≤((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val) :
    DomainRectangleNeighborhoodCover (hecke41CauchyIntegrandMap k a)
      (hecke41CauchyIntegrandMap_holomorphic k a) eps J :=
  domain_rectangle_neighborhood_cover _ _ eps J hX hY
    (hecke41KernelRectangle_domain k a ha J R B hs hxl hxu hyl hyu hB)

end ComputableAnalysis.ModularForms
