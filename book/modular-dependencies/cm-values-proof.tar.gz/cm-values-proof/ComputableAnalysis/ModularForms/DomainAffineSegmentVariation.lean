import ComputableAnalysis.ModularForms.DomainSegmentBisectionJoin

/-! Whole-segment variation by represented rational bisection, retaining
actual segment domains. No uniform mesh-radius assumption is used. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

/-- A genuine derivative bound on the represented segment controls its
endpoint difference. Local error radii may vary freely along the segment. -/
theorem domain_affine_segment_variation (f : DomainFunctions.Map) (hf : Holomorphic f)
    (p q : Scalar) (hp : f.domain p) (hq : f.domain q)
    (mem : ∀ t : UnitInterval.Point, f.domain (RepresentedAffineSegment.point p q t))
    (B : Rat) (hB : 0≤B)
    (hbound : ∀ t : UnitInterval.Point,
      Small (hf.derivative (RepresentedAffineSegment.point p q t) (mem t)).val B)
    (W : QPos) (hd : Small (AffineSegment.displacement p q).val W.val) :
    Small (sub (f.eval q hq).val (f.eval p hp).val) ((2*B+2)*W.val) := by
  let rmem := domainSegment_rational_mem f p q mem
  have good : domainSegmentEndpointGood f p q rmem (2*B+2) W.val ⟨0,1⟩ := by
    apply bisection_cover_principle (domainSegmentEndpointGood f p q rmem (2*B+2) W.val) ⟨0,1⟩
      (domainSegmentEndpointGood_join f p q rmem (2*B+2) W.val)
    intro choice
    have hx := bisectionReal_enclosed (⟨0,1⟩ : QInterval) (by decide +kernel) choice 0
    let t : UnitInterval.Point := ⟨bisectionReal ⟨0,1⟩ choice,
      bisectionReal_valid ⟨0,1⟩ (by decide +kernel) choice,hx.1,hx.2⟩
    let a := RepresentedAffineSegment.point p q t
    let D := (hf.atPoint a (mem t)).delta halfDerivativeError
    let N := RationalMajorant.natRateStage (2*W.val) D
    let J := bisectionInterval ⟨0,1⟩ choice N
    have hw : J.width=((1:Rat)/2)^N := by
      have h := bisectionInterval_width (⟨0,1⟩ : QInterval) choice N
      simpa only [QInterval.width,show (1:Rat)-0=1 by decide +kernel,Rat.one_mul] using h
    have hwpos : 0<J.width := by
      rw [hw]
      exact Rat.pow_pos (by decide +kernel)
    have h2W : 0<2*W.val := Rat.mul_pos (by decide +kernel) W.property
    let H : QPos := ⟨2*W.val*J.width,Rat.mul_pos h2W hwpos⟩
    have hH : H.val≤D.val := by
      have hp := Rat.mul_le_mul_of_nonneg_left (RationalMajorant.half_pow_le_one_div_succ N)
        (Rat.le_of_lt h2W)
      have hr := RationalMajorant.natRateStage_spec_of_le (Rat.le_of_lt h2W) D (Nat.le_refl N)
      change 2*W.val*J.width≤D.val
      rw [hw]
      have he : (2*W.val)*(1/((N+1:Nat):Rat))=(2*W.val)/((N+1:Nat):Rat) := by
        rw [Rat.div_def,Rat.div_def,Rat.one_mul]
      rw [he] at hp
      exact Rat.le_trans hp hr
    have ho := bisectionInterval_ordered (⟨0,1⟩ : QInterval) (by decide +kernel) choice N
    have he := bisectionInterval_nested (⟨0,1⟩ : QInterval) (by decide +kernel)
      choice 0 N (Nat.zero_le N)
    have near (u : Rat) (hulo : J.lo≤u) (huhi : u≤J.hi) :
        Small (sub (AffineSegment.point p q u).val a.val) H.val := by
      have hn := bisectionReal_stage_neighborhood (⟨0,1⟩ : QInterval)
        (by decide +kernel) choice N u hulo huhi
      exact representedAffine_rational_neighborhood p q t u
        (Rat.le_trans he.1 hulo) (Rat.le_trans huhi he.2.2) W.val J.width
        (Rat.le_of_lt W.property) (Rat.le_of_lt hwpos) hd hn.1 hn.2
    have hz := near J.hi ho Rat.le_refl
    have hl := near J.lo Rat.le_refl ho
    have hdisp := AffineSegment.difference_bound p q W.val J.lo J.hi hd
      (by change 0≤J.width; exact Rat.le_of_lt hwpos)
    have hhi0 := Rat.le_trans he.1 ho
    have hlo1 := Rat.le_trans ho he.2.2
    have hv := domain_local_endpoint_variation f a
      (AffineSegment.point p q J.hi) (AffineSegment.point p q J.lo)
      (hf.derivative a (mem t)) (mem t)
      (rmem J.hi hhi0 he.2.2) (rmem J.lo he.1 hlo1)
      (hf.atPoint a (mem t)) B (J.width*W.val) hB
      (Rat.mul_nonneg (Rat.le_of_lt hwpos) (Rat.le_of_lt W.property))
      (hbound t) H hH hz hl hdisp
    refine ⟨N, ?_⟩
    intro _ _ _
    apply hv.mono
    change 2*B*(J.width*W.val)+2*W.val*J.width≤(2*B+2)*W.val*J.width
    grind only
  have hg := good (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have hw : (⟨0,1⟩ : QInterval).width=1 := by decide +kernel
  rw [hw,Rat.mul_one] at hg
  exact Small.congr
    (sub_valid (f.eval (AffineSegment.point p q 1) (rmem 1 (by decide +kernel) (by decide +kernel))).property
      (f.eval (AffineSegment.point p q 0) (rmem 0 (by decide +kernel) (by decide +kernel))).property)
    (sub_valid (f.eval q hq).property (f.eval p hp).property)
    (FunctionTheory.sub_congr
      (f.eval_congr _ _ _ hq (AffineSegment.point_one p q))
      (f.eval_congr _ _ _ hp (AffineSegment.point_zero p q))) hg

end ComputableAnalysis.ModularForms
