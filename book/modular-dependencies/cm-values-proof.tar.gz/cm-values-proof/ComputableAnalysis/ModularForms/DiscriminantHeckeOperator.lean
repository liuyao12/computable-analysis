import ComputableAnalysis.ModularForms.NormalizedDiscriminantCusp
import ComputableAnalysis.ModularForms.Hecke41Holomorphic
namespace ComputableAnalysis.ModularForms
set_option maxHeartbeats 2000000
open ComplexRaw RiemannHilbert FunctionTheory DomainFunctions
/-- Positive rational affine maps preserve the actual represented upper half-plane. -/
theorem rationalAffineMap_upper (r b : Rat) (hr : 0<r) (z : Scalar)
    (hz : InUpperHalfPlane z.val) : InUpperHalfPlane ((rationalAffineMap r b).eval z hz).val := by
  obtain ⟨N,hN⟩ := hz
  refine ⟨N,?_⟩
  simp only [rationalAffineMap,imagPart,scaleRat,QBox.scaleRat,
    if_pos (Rat.le_of_lt hr),translate,add,ofQComplex,QBox.add,QComplex.add]
  change 0<r*((z.val.compute N).lo.im+0)
  rw [Rat.add_zero]
  exact Rat.mul_pos hr hN

/-- The actual global discriminant evaluated at a positive rational affine point. -/
def discriminantAffinePullback (r b : Rat) (hr : 0<r) : DomainFunctions.Map :=
  onDomain (compose normalizedLatticeDiscriminantMap (rationalAffineMap r b))
    upperOpenData.invariant (fun z hz => ⟨hz,rationalAffineMap_upper r b hr z hz⟩)
def discriminantAffinePullback_holomorphic (r b : Rat) (hr : 0<r) :
    Holomorphic (discriminantAffinePullback r b hr) :=
  (normalizedLatticeDiscriminantMap_holomorphic.compose (rationalAffineMap_holomorphic r b)).onDomain
    upperOpenData (fun z hz => ⟨hz,rationalAffineMap_upper r b hr z hz⟩)
private def rationalConstantUpper (c : Rat) : DomainFunctions.Map :=
  constantOn (fun z => InUpperHalfPlane z.val) upperOpenData.invariant
    ⟨scaleRat c one,scaleRat_valid (ofQComplex_valid _)⟩
private def rationalConstantUpper_holomorphic (c : Rat) : Holomorphic (rationalConstantUpper c) :=
  constantOn_holomorphic upperOpenData ⟨scaleRat c one,scaleRat_valid (ofQComplex_valid _)⟩

private def discriminantHeckeAffineValue (p : Nat) (hp : 0<(p:Rat))
    (z : Scalar) (hz : InUpperHalfPlane z.val) : Nat → Scalar
  | 0 => ⟨zero,ofQComplex_valid _⟩
  | N+1 => scalarSum (discriminantHeckeAffineValue p hp z hz N)
      ((discriminantAffinePullback (1/(p:Rat)) (N:Rat) (by
        rw [Rat.div_def,Rat.one_mul]; exact Rat.inv_pos.mpr hp)).eval z hz)
private theorem discriminantHeckeAffineValue_congr (p : Nat) (hp : 0<(p:Rat))
    (z w : Scalar) (hz : InUpperHalfPlane z.val) (hw : InUpperHalfPlane w.val)
    (he : z.val.Equiv w.val) (N : Nat) :
    (discriminantHeckeAffineValue p hp z hz N).val.Equiv
      (discriminantHeckeAffineValue p hp w hw N).val := by
  induction N with
  | zero => exact equiv_refl _ (ofQComplex_valid _)
  | succ N ih => exact add_equiv ih ((discriminantAffinePullback _ _ _).eval_congr z w hz hw he)
/-- Literal finite sum of actual affine discriminant values, on the full upper half-plane. -/
def discriminantHeckeAffineSum (p : Nat) (hp : 0<(p:Rat)) (N : Nat) : DomainFunctions.Map where
  domain z := InUpperHalfPlane z.val
  eval z hz := discriminantHeckeAffineValue p hp z hz N
  domain_congr := upperOpenData.invariant
  eval_congr z w hz hw he := discriminantHeckeAffineValue_congr p hp z w hz hw he N
def discriminantHeckeAffineSum_holomorphic (p : Nat) (hp : 0<(p:Rat)) (N : Nat) :
    Holomorphic (discriminantHeckeAffineSum p hp N) := by
  induction N with
  | zero =>
    apply (constantOn_holomorphic upperOpenData (⟨zero,ofQComplex_valid _⟩ : Scalar)).transfer
      (discriminantHeckeAffineSum p hp 0) (fun _ h => h) ⟨upperRadius,upperRadius_inside⟩
    intro z hz
    exact equiv_refl _ (ofQComplex_valid _)
  | succ N ih =>
    apply (ih.sumOn (discriminantAffinePullback_holomorphic (1/(p:Rat)) (N:Rat) (by
      rw [Rat.div_def,Rat.one_mul]; exact Rat.inv_pos.mpr hp)) (fun _ h => h)).transfer
      (discriminantHeckeAffineSum p hp (N+1)) (fun _ h => h) ⟨upperRadius,upperRadius_inside⟩
    intro z hz
    exact equiv_refl _ (discriminantHeckeAffineValue p hp z hz (N+1)).property

/-- The literal finite affine sum starts at zero. -/
theorem discriminantHeckeAffineSum_zero (p : Nat) (hp : 0<(p:Rat))
    (z : Scalar) (hz : InUpperHalfPlane z.val) :
    ((discriminantHeckeAffineSum p hp 0).eval z hz).val.Equiv zero :=
  equiv_refl _ (ofQComplex_valid _)
/-- The literal finite affine sum adds the next actual correspondence value. -/
theorem discriminantHeckeAffineSum_succ (p : Nat) (hp : 0<(p:Rat))
    (N : Nat) (z : Scalar) (hz : InUpperHalfPlane z.val) :
    ((discriminantHeckeAffineSum p hp (N+1)).eval z hz).val.Equiv
      (add ((discriminantHeckeAffineSum p hp N).eval z hz).val
        ((discriminantAffinePullback (1/(p:Rat)) (N:Rat) (by
          rw [Rat.div_def,Rat.one_mul]; exact Rat.inv_pos.mpr hp)).eval z hz).val) :=
  equiv_refl _ (discriminantHeckeAffineValue p hp z hz (N+1)).property

private def discriminantHeckeDilation (p : Nat) (hp : 0<(p:Rat)) : DomainFunctions.Map :=
  productOn (rationalConstantUpper ((p:Rat)^11))
    (discriminantAffinePullback (p:Rat) 0 hp) (fun z h => (show InUpperHalfPlane z.val from h))
private def discriminantHeckeAverage (p : Nat) (hp : 0<(p:Rat)) : DomainFunctions.Map :=
  productOn (rationalConstantUpper (1/(p:Rat))) (discriminantHeckeAffineSum p hp p)
    (fun z h => (show InUpperHalfPlane z.val from h))
private def discriminantHeckeDilation_holomorphic (p : Nat) (hp : 0<(p:Rat)) :
    Holomorphic (discriminantHeckeDilation p hp) :=
  (rationalConstantUpper_holomorphic ((p:Rat)^11)).productOn
    (discriminantAffinePullback_holomorphic (p:Rat) 0 hp) (fun z h => (show InUpperHalfPlane z.val from h))
private def discriminantHeckeAverage_holomorphic (p : Nat) (hp : 0<(p:Rat)) :
    Holomorphic (discriminantHeckeAverage p hp) :=
  (rationalConstantUpper_holomorphic (1/(p:Rat))).productOn
    (discriminantHeckeAffineSum_holomorphic p hp p) (fun z h => (show InUpperHalfPlane z.val from h))
/-- The actual weight-twelve prime-index Hecke expression, defined for every positive index.
Its modular transformation and coefficient action are separate results. -/
def discriminantHeckeMap (p : Nat) (hp : 0<(p:Rat)) : DomainFunctions.Map :=
  sumOn (discriminantHeckeDilation p hp) (discriminantHeckeAverage p hp)
    (fun z h => (show InUpperHalfPlane z.val from h))
def discriminantHeckeMap_holomorphic (p : Nat) (hp : 0<(p:Rat)) : Holomorphic (discriminantHeckeMap p hp) :=
  (discriminantHeckeDilation_holomorphic p hp).sumOn (discriminantHeckeAverage_holomorphic p hp)
    (fun z h => (show InUpperHalfPlane z.val from h))
/-- The operator evaluates to the usual dilation term plus the affine average. -/
theorem discriminantHeckeMap_eval (p : Nat) (hp : 0<(p:Rat))
    (z : Scalar) (hz : InUpperHalfPlane z.val) :
    (discriminantHeckeMap p hp |>.eval z hz).val.Equiv
      (add (scaleRat ((p:Rat)^11) ((discriminantAffinePullback (p:Rat) 0 hp).eval z hz).val)
        (scaleRat (1/(p:Rat)) ((discriminantHeckeAffineSum p hp p).eval z hz).val)) := by
  apply ComplexRawQuotient.equiv_of_ofRaw_eq
    (hleft := ((discriminantHeckeMap p hp).eval z hz).property)
    (hright := add_valid
      (scaleRat_valid ((discriminantAffinePullback (p:Rat) 0 hp).eval z hz).property)
      (scaleRat_valid ((discriminantHeckeAffineSum p hp p).eval z hz).property))
  let d := ComplexRawQuotient.ofRaw ((discriminantAffinePullback (p:Rat) 0 hp).eval z hz).val
    ((discriminantAffinePullback (p:Rat) 0 hp).eval z hz).property
  let a := ComplexRawQuotient.ofRaw ((discriminantHeckeAffineSum p hp p).eval z hz).val
    ((discriminantHeckeAffineSum p hp p).eval z hz).property
  change ComplexRawQuotient.scaleRat ((p:Rat)^11) 1*d+ComplexRawQuotient.scaleRat (1/(p:Rat)) 1*a=
    ComplexRawQuotient.scaleRat ((p:Rat)^11) d+ComplexRawQuotient.scaleRat (1/(p:Rat)) a
  rw [←ComplexRawQuotient.scaleRat_mul,←ComplexRawQuotient.scaleRat_mul]
  congr 1 <;> congr 1 <;> grind only
end ComputableAnalysis.ModularForms
