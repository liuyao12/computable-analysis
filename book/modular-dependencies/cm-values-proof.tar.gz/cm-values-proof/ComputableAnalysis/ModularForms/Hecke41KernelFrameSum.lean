import ComputableAnalysis.ModularForms.Hecke41KernelFrameTiles

/-! Executable twelve-tile Hecke boundary sums and proved vanishing. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

instance squareFrameTileIndex_decidable (j l : Nat) : Decidable (squareFrameTileIndex j l) := by
  unfold squareFrameTileIndex
  infer_instance

def hecke41KernelFrameBoundarySample (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : (squareFrameOuterRadius R).val≤
      ((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val)
    (n j l : Nat) : Scalar :=
  if h : squareFrameTileIndex j l then hecke41KernelFrameTileBoundary k a ha R hR j l h n
  else ⟨zero,ofQComplex_valid _⟩

def hecke41KernelFrameBoundarySum (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : (squareFrameOuterRadius R).val≤
      ((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val) (n : Nat) : Scalar :=
  frameScalarSum (hecke41KernelFrameBoundarySample k a ha R hR n) 1 2 1 1 2 1

theorem hecke41KernelFrameBoundarySum_converges_zero (k : Nat) (a : Scalar)
    (ha : hecke41NomePuncturedDomain a) (R : QPos)
    (hR : (squareFrameOuterRadius R).val≤
      ((hecke41NomeDescended_holomorphic k 10000).openDomain.radius a ha).val) (eps : QPos) :
    ∃ N, ∀ n, N≤n → Small (hecke41KernelFrameBoundarySum k a ha R hR n).val eps.val := by
  let eta : QPos := ⟨eps.val/12,by
    rw [Rat.div_def]
    exact Rat.mul_pos eps.property (Rat.inv_pos.mpr (by decide +kernel))⟩
  obtain ⟨N,hN⟩ := hecke41KernelFrameTiles_uniform_depth k a ha R hR eta
  refine ⟨N, ?_⟩
  intro n hn
  have hb := frameScalarSum_bound (hecke41KernelFrameBoundarySample k a ha R hR n)
    1 2 1 1 2 1 eta.val (Rat.le_of_lt eta.property) (by
      intro j l hf
      have hi : squareFrameTileIndex j l := by
        unfold representedFrameCell at hf
        unfold squareFrameTileIndex
        omega
      simp only [hecke41KernelFrameBoundarySample,dif_pos hi]
      exact hN n hn j l hi)
  have he : ((representedFrameCellCount 1 2 1 1 2 1:Nat):Rat)*eta.val=eps.val := by
    change 12*(eps.val/12)=eps.val
    grind only
  rw [he] at hb
  exact hb

end ComputableAnalysis.ModularForms
