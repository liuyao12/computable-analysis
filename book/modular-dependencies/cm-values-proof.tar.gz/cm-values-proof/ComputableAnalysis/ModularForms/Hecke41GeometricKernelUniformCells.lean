import ComputableAnalysis.ModularForms.Hecke41GeometricKernelRectangleSamples
import ComputableAnalysis.ModularForms.PuncturedKernelGridBoundaryVanishing

/-! Uniform actual Hecke kernel cell estimates on justified rectangles. -/
namespace ComputableAnalysis.ModularForms
open ComplexRaw FunctionTheory RiemannHilbert DomainFunctions

theorem hecke41GeometricKernel_uniform_midpoint_cycle_bound (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (J : QInterval × QInterval) (R B : QPos) (hs : rectangleSeparated J R)
    (hxl : -B.val≤J.1.lo) (hxu : J.1.hi≤B.val)
    (hyl : -B.val≤J.2.lo) (hyu : J.2.hi≤B.val)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (eps : QPos) (hX : J.1.lo≤J.1.hi) (hY : J.2.lo≤J.2.hi) :
    ∃ N, ∀ choice : Nat → Bool × Bool, ∀ n, N≤n → ∀ H : QPos,
      (rectangleBisection J choice n).1.width≤2*H.val →
      (rectangleBisection J choice n).2.width≤2*H.val →
      Small (fullRectangleMidpointCycle (hecke41GeometricKernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB)
        (rectangleBisection J choice n)).val (64*eps.val*H.val*H.val) := by
  obtain ⟨N,hN⟩ := domainRectangleNeighborhood_uniform_depth
    (hecke41CauchyIntegrandMap k a) (hecke41CauchyIntegrandMap_holomorphic k a)
    eps J hX hY (hecke41GeometricKernelRectangle_neighborhood_cover k a ha J R B eps hs hX hY hxl hxu hyl hyu hB)
  refine ⟨N, ?_⟩
  intro choice n hn H hx hy
  obtain ⟨c,hc,hnear⟩ := hN choice n hn
  let K := rectangleBisection J choice n
  have hKX : K.1.lo≤K.1.hi := by
    dsimp [K]
    rw [rectangleBisection_coordinates]
    exact bisectionInterval_ordered J.1 hX (fun k => (choice k).1) n
  have hKY : K.2.lo≤K.2.hi := by
    dsimp [K]
    rw [rectangleBisection_coordinates]
    exact bisectionInterval_ordered J.2 hY (fun k => (choice k).2) n
  have hm := (rectangleMidpoints_mem K hKX hKY).1
  have near (q : QComplex) (hq : rationalRectangleContains K q) :
      Small (Centered.offset c (rationalRectangleScalar q)).val
        ((hecke41CauchyIntegrandMap_holomorphic k a).continuousDerivative.delta c hc eps).val :=
    (hnear q hq).mono (minRadius_right _ _)
  have mem (q : QComplex) (hq : rationalRectangleContains K q) : rationalRectangleContains J q :=
    rectangleBisection_contains_initial J hX hY choice n q hq
  have hb := rectangleSampleModel_full_cycle_bound (hecke41GeometricKernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB) K
    ((hecke41CauchyIntegrandMap_holomorphic k a).derivative c hc) (4*eps.val*H.val) H
    (Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) (Rat.le_of_lt eps.property))
      (Rat.le_of_lt H.property)) hKX hKY hx hy
    (fun q hq hd => hecke41GeometricKernelRectangleSample_model_error k a ha J R B hs hxl hxu hyl hyu hB c hc
      (rectangleCenter K) q (mem _ hm) (mem _ hq) H eps hd (near _ hm) (near _ hq))
  have he : 16*(4*eps.val*H.val)*H.val=64*eps.val*H.val*H.val := by grind only
  rw [he] at hb
  exact hb

theorem hecke41GeometricKernel_uniform_dyadic_midpoint_error (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (J : QInterval × QInterval) (R B : QPos) (hs : rectangleSeparated J R)
    (hxl : -B.val≤J.1.lo) (hxu : J.1.hi≤B.val)
    (hyl : -B.val≤J.2.lo) (hyu : J.2.hi≤B.val)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (eps W : QPos) (hX : J.1.lo≤J.1.hi) (hY : J.2.lo≤J.2.hi)
    (hx : J.1.width≤2*W.val) (hy : J.2.width≤2*W.val) :
    ∃ N, ∀ choice : Nat → Bool × Bool, ∀ n, N≤n →
      Small (fullRectangleMidpointCycle (hecke41GeometricKernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB) (rectangleBisection J choice n)).val
        (64*eps.val*(W.val*((1:Rat)/2)^n)*(W.val*((1:Rat)/2)^n)) := by
  obtain ⟨N,hN⟩ := hecke41GeometricKernel_uniform_midpoint_cycle_bound k a ha J R B hs hxl hxu hyl hyu hB eps hX hY
  refine ⟨N, ?_⟩
  intro choice n hn
  let H : QPos := ⟨W.val*((1:Rat)/2)^n,
    Rat.mul_pos W.property (Rat.pow_pos (by decide +kernel))⟩
  have hp : 0≤((1:Rat)/2)^n := Rat.pow_nonneg (by decide +kernel)
  have bounds : (rectangleBisection J choice n).1.width≤2*H.val ∧
      (rectangleBisection J choice n).2.width≤2*H.val := by
    rw [rectangleBisection_coordinates]
    change (bisectionInterval J.1 (fun k => (choice k).1) n).width≤2*H.val ∧
      (bisectionInterval J.2 (fun k => (choice k).2) n).width≤2*H.val
    rw [bisectionInterval_width,bisectionInterval_width]
    have hxx := Rat.mul_le_mul_of_nonneg_right hx hp
    have hyy := Rat.mul_le_mul_of_nonneg_right hy hp
    change J.1.width*((1:Rat)/2)^n≤2*(W.val*((1:Rat)/2)^n) ∧
      J.2.width*((1:Rat)/2)^n≤2*(W.val*((1:Rat)/2)^n)
    constructor <;> grind only
  exact hN choice n hn H bounds.1 bounds.2

theorem hecke41GeometricKernel_indexed_dyadic_cell_bound (k : Nat) (a : Scalar) (ha : hecke41NomePuncturedDomain a)
    (J : QInterval × QInterval) (R B : QPos) (hs : rectangleSeparated J R)
    (hxl : -B.val≤J.1.lo) (hxu : J.1.hi≤B.val)
    (hyl : -B.val≤J.2.lo) (hyu : J.2.hi≤B.val)
    (hB : B.val≤(hecke41NomeGeometricRadius a ha).val)
    (eps W : QPos) (hX : J.1.lo≤J.1.hi) (hY : J.2.lo≤J.2.hi)
    (hx : J.1.width≤2*W.val) (hy : J.2.width≤2*W.val) :
    ∃ N, ∀ n, N≤n → ∀ j l : Nat, j<2^n → l<2^n →
      Small (fullRectangleMidpointCycle (hecke41GeometricKernelRectangleSample k a ha J R B hs hxl hxu hyl hyu hB) (rectangleGridCell J (2^n) j l)).val
        (64*eps.val*(W.val*((1:Rat)/2)^n)*(W.val*((1:Rat)/2)^n)) := by
  obtain ⟨N,hN⟩ := hecke41GeometricKernel_uniform_dyadic_midpoint_error k a ha J R B hs hxl hxu hyl hyu hB eps W hX hY hx hy
  refine ⟨N, ?_⟩
  intro n hn j l hj hk
  obtain ⟨choice,hc⟩ := rectangleGridCell_bisection J n j l hj hk
  have hb := hN choice n hn
  rw [hc] at hb
  exact hb

end ComputableAnalysis.ModularForms
