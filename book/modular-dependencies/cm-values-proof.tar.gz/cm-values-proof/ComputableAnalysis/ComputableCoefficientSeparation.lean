import ComputableAnalysis.ComputableCoefficientApproximation

/-! Nonzero represented coefficients supply their own finite division tests.
The search compares rational endpoints; no precision is supplied by callers. -/
namespace ComputableAnalysis
namespace ComputableCoefficient

theorem real_apart_of_nonzero (x : Real) (hx : ¬ x.preferred.Equiv RealRaw.zero) :
    ∃ n, 0 < (x.compute n).lo ∨ (x.compute n).hi < 0 := by
  classical
  apply Classical.byContradiction
  intro h
  apply hx
  intro n
  apply (RealRaw.compareAt_overlap_iff _ _ n n).2
  change (x.compute n).lo ≤ (0 : Rat) ∧ 0 ≤ (x.compute n).hi
  have hh : ¬ (0 < (x.compute n).lo ∨ (x.compute n).hi < 0) := fun hn => h ⟨n, hn⟩
  constructor <;> grind

theorem apart_persists (x : Real) {n m : Nat} (hnm : n ≤ m)
    (hn : 0 < (x.compute n).lo ∨ (x.compute n).hi < 0) :
    0 < (x.compute m).lo ∨ (x.compute m).hi < 0 := by
  have h := x.valid.2.1 n m hnm
  change (x.compute n).lo ≤ (x.compute m).lo ∧ _ ∧ (x.compute m).hi ≤ (x.compute n).hi at h
  rcases hn with hp | hn
  · left; grind
  · right; grind

def apartStageFrom (x : Real) (hx : ¬ x.preferred.Equiv RealRaw.zero) (n : Nat) : Nat :=
  if 0 < (x.compute n).lo ∨ (x.compute n).hi < 0 then n else apartStageFrom x hx (n+1)
termination_by Classical.choose (real_apart_of_nonzero x hx) - n
decreasing_by
  have h := Classical.choose_spec (real_apart_of_nonzero x hx)
  have hn : n < Classical.choose (real_apart_of_nonzero x hx) := by
    by_cases hn : n < Classical.choose (real_apart_of_nonzero x hx)
    · exact hn
    · have hh := apart_persists x (show Classical.choose (real_apart_of_nonzero x hx) ≤ n by omega) h
      contradiction
  omega

theorem apartStageFrom_spec (x : Real) (hx : ¬ x.preferred.Equiv RealRaw.zero) (n : Nat) :
    n ≤ apartStageFrom x hx n ∧
      (0 < (x.compute (apartStageFrom x hx n)).lo ∨ (x.compute (apartStageFrom x hx n)).hi < 0) := by
  rw [apartStageFrom]
  split
  · exact ⟨Nat.le_refl _, ‹_›⟩
  · have ih := apartStageFrom_spec x hx (n+1)
    exact ⟨by omega, ih.2⟩
termination_by Classical.choose (real_apart_of_nonzero x hx) - n
decreasing_by
  have h := Classical.choose_spec (real_apart_of_nonzero x hx)
  have hn : n < Classical.choose (real_apart_of_nonzero x hx) := by
    by_cases hn : n < Classical.choose (real_apart_of_nonzero x hx)
    · exact hn
    · have hh := apart_persists x (show Classical.choose (real_apart_of_nonzero x hx) ≤ n by omega) h
      contradiction
  omega

def apartStage (x : Real) (hx : ¬ x.preferred.Equiv RealRaw.zero) : Nat := apartStageFrom x hx 0

theorem apartStage_spec (x : Real) (hx : ¬ x.preferred.Equiv RealRaw.zero) :
    0 < (x.compute (apartStage x hx)).lo ∨ (x.compute (apartStage x hx)).hi < 0 :=
  (apartStageFrom_spec x hx 0).2

namespace Value

theorem inv?_exists_of_apart (x : Value) (N : Nat)
    (h : 0 < (x.real.compute N).lo ∨ (x.real.compute N).hi < 0) :
    ∃ v, x.inv? N = some v := by
  unfold inv?
  split
  · exact ⟨_, rfl⟩
  · split
    · exact ⟨_, rfl⟩
    · rcases h with h | h <;> contradiction

/-- The inverse is computed by the existing evaluator after a terminating
search for a rational interval separated from zero. -/
def inverse (x : Value) (hx : ¬ x.real.preferred.Equiv RealRaw.zero) : Value :=
  match he : x.inv? (apartStage x.real hx) with
  | some v => v
  | none => False.elim (by
      obtain ⟨v, hv⟩ := inv?_exists_of_apart x _ (apartStage_spec x.real hx)
      rw [he] at hv
      cases hv)

theorem inverse_spec (x : Value) (hx : ¬ x.real.preferred.Equiv RealRaw.zero) :
    x.inv? (apartStage x.real hx) = some (x.inverse hx) := by
  unfold inverse
  split
  · assumption
  · rename_i he
    obtain ⟨v, hv⟩ := inv?_exists_of_apart x _ (apartStage_spec x.real hx)
    rw [he] at hv
    cases hv

theorem inverse_sample (x : Value) (hx : ¬ x.real.preferred.Equiv RealRaw.zero) (s : Real → Rat) :
    (x.inverse hx).sample s = (x.sample s)⁻¹ := inv?_sample _ _ _ (inverse_spec x hx) s

theorem sample_nonzero_of_apart (x : Value) (N : Nat)
    (h : 0 < (x.real.compute N).lo ∨ (x.real.compute N).hi < 0)
    (m : Nat) (hm : x.observation N ≤ m) (s : Real → Rat) (hs : Samples m s) :
    x.sample s ≠ 0 := by
  have hh := x.encloses N m hm s hs
  intro hz
  rw [hz] at hh
  rcases h with hp | hn <;> grind

/-- Exact reciprocal identity, with the finite inversion schedule hidden. -/
theorem mul_inverse (x : Value) (hx : ¬ x.real.preferred.Equiv RealRaw.zero) :
    (mul x (x.inverse hx)).real.preferred.Equiv (RealRaw.ofRat 1) := by
  apply equiv_of_samples _ (rational 1) (x.observation (apartStage x.real hx))
  intro m hm s hs
  change x.sample s * (x.inverse hx).sample s = 1
  rw [inverse_sample]
  exact Rat.mul_inv_cancel _ (sample_nonzero_of_apart x _ (apartStage_spec x.real hx) m hm s hs)

theorem equiv_refl (x : Value) : x.real.preferred.Equiv x.real.preferred :=
  RealRaw.equiv_refl _ x.real.valid

theorem equiv_trans {x y z : Value} (hxy : x.real.preferred.Equiv y.real.preferred)
    (hyz : y.real.preferred.Equiv z.real.preferred) : x.real.preferred.Equiv z.real.preferred :=
  RealRaw.equiv_trans x.real.valid y.real.valid z.real.valid hxy hyz

theorem mul_congr {a b c d : Value} (hab : a.real.preferred.Equiv b.real.preferred)
    (hcd : c.real.preferred.Equiv d.real.preferred) :
    (mul a c).real.preferred.Equiv (mul b d).real.preferred :=
  RealRaw.mul_equiv a.real.valid b.real.valid c.real.valid d.real.valid hab hcd

theorem mul_one (x : Value) : (mul x (rational 1)).real.preferred.Equiv x.real.preferred := by
  apply equiv_of_samples _ _ 0
  intro m hm s hs
  exact Rat.mul_one _

theorem one_mul (x : Value) : (mul (rational 1) x).real.preferred.Equiv x.real.preferred := by
  apply equiv_of_samples _ _ 0
  intro m hm s hs
  exact Rat.one_mul _

theorem mul_permute (a b c : Value) :
    (mul a (mul b c)).real.preferred.Equiv (mul (mul b a) c).real.preferred := by
  apply equiv_of_samples _ _ 0
  intro m hm s hs
  change a.sample s * (b.sample s * c.sample s) = (b.sample s * a.sample s) * c.sample s
  grind

/-- Equivalent input computations give equivalent reciprocals. -/
theorem inverse_equiv {x y : Value} (hxy : x.real.preferred.Equiv y.real.preferred)
    (hx : ¬ x.real.preferred.Equiv RealRaw.zero) (hy : ¬ y.real.preferred.Equiv RealRaw.zero) :
    (x.inverse hx).real.preferred.Equiv (y.inverse hy).real.preferred := by
  exact equiv_trans (RealRaw.equiv_symm (mul_one (x.inverse hx)))
    (equiv_trans (mul_congr (equiv_refl (x.inverse hx)) (RealRaw.equiv_symm (mul_inverse y hy)))
      (equiv_trans (mul_permute (x.inverse hx) y (y.inverse hy))
        (equiv_trans (mul_congr (mul_congr (RealRaw.equiv_symm hxy) (equiv_refl (x.inverse hx)))
          (equiv_refl (y.inverse hy)))
          (equiv_trans (mul_congr (mul_inverse x hx) (equiv_refl (y.inverse hy))) (one_mul _)))))

end Value
end ComputableCoefficient
end ComputableAnalysis
