import ComputableAnalysis.PolynomialLimitChartContinuity
import ComputableAnalysis.FTA.FiniteApproximateMinimum

/-! Quantitative squared-modulus variation for actual finite polynomials.
The majorants are executable Horner recurrences, not supplied continuity
certificates. -/
namespace ComputableAnalysis

namespace QComplex

theorem normSq_sub_bound (z w : QComplex) :
    qabs (normSq z - normSq w) ≤
      (normBound z + normBound w) * normBound (sub z w) := by
  have hid : normSq z - normSq w =
      (z.re - w.re)*(z.re + w.re) + (z.im - w.im)*(z.im + w.im) := by
    unfold normSq
    grind
  rw [hid]
  have ht := qabs_add_le ((z.re-w.re)*(z.re+w.re)) ((z.im-w.im)*(z.im+w.im))
  rw [qabs_mul, qabs_mul] at ht
  have hr := qabs_add_le z.re w.re
  have hi := qabs_add_le z.im w.im
  have hdr := qabs_nonneg (z.re-w.re)
  have hdi := qabs_nonneg (z.im-w.im)
  have hm1 := Rat.mul_le_mul_of_nonneg_left hr hdr
  have hm2 := Rat.mul_le_mul_of_nonneg_left hi hdi
  have hcross1 := Rat.mul_nonneg (qabs_nonneg (z.re-w.re))
    (Rat.add_nonneg (qabs_nonneg z.im) (qabs_nonneg w.im))
  have hcross2 := Rat.mul_nonneg (qabs_nonneg (z.im-w.im))
    (Rat.add_nonneg (qabs_nonneg z.re) (qabs_nonneg w.re))
  simp only [normBound, sub, add, neg, Rat.sub_eq_add_neg] at *
  grind

end QComplex

namespace CPoly

def scoreMajorant (p : Coeffs) (radius : Rat) : Rat :=
  2 * normMajorant p radius * lipschitzMajorant p radius

theorem scoreMajorant_nonneg (p : Coeffs) (radius : Rat) (hr : 0 ≤ radius) :
    0 ≤ scoreMajorant p radius :=
  Rat.mul_nonneg (Rat.mul_nonneg (by decide +kernel) (normMajorant_nonneg p radius hr))
    (lipschitzMajorant_nonneg p radius hr)

/-- Squared modulus has a computed Lipschitz bound on the entire rational
norm ball. Multiple roots and vanishing coefficients require no case split. -/
theorem score_lipschitz (p : Coeffs) (radius : Rat) (hr : 0 ≤ radius)
    (z w : QComplex) (hz : QComplex.normBound z ≤ radius)
    (hw : QComplex.normBound w ≤ radius) :
    qabs (QComplex.normSq (eval p z) - QComplex.normSq (eval p w)) ≤
      scoreMajorant p radius * QComplex.normBound (QComplex.sub z w) := by
  have h := QComplex.normSq_sub_bound (eval p z) (eval p w)
  have hz' := eval_normMajorant p radius z hz
  have hw' := eval_normMajorant p radius w hw
  have hd := eval_lipschitz p radius z w hz hw
  have hsum : QComplex.normBound (eval p z) + QComplex.normBound (eval p w) ≤
      2 * normMajorant p radius := by grind
  have h1 := Rat.mul_le_mul_of_nonneg_right hsum
    (QComplex.normBound_nonneg (QComplex.sub (eval p z) (eval p w)))
  have h2 := Rat.mul_le_mul_of_nonneg_left hd
    (Rat.mul_nonneg (by decide +kernel : (0 : Rat) ≤ 2) (normMajorant_nonneg p radius hr))
  unfold scoreMajorant
  grind

/-- Exact rational polynomial scores instantiate finite approximate selection.
An actual nearby mesh point yields a bound against the target's actual score.
Mesh construction is not assumed to follow from mere boundedness. -/
theorem finite_score_minimum (p : Coeffs) (radius distance : Rat)
    (hr : 0 ≤ radius) (start target : QComplex) (xs : List QComplex)
    (htarget : QComplex.normBound target ≤ radius)
    (hcover : ∃ x ∈ xs, QComplex.normBound x ≤ radius ∧
      QComplex.normBound (QComplex.sub x target) ≤ distance) :
    QComplex.normSq (eval p (FiniteApproximateMinimum.select
      (fun z => QComplex.normSq (eval p z)) start xs)) ≤
      QComplex.normSq (eval p target) + scoreMajorant p radius * distance := by
  obtain ⟨x, hx, hb, hd⟩ := hcover
  have hmin := FiniteApproximateMinimum.select_le_mem
    (fun z => QComplex.normSq (eval p z)) start xs x hx
  have hl := score_lipschitz p radius hr x target hb htarget
  have hm := Rat.mul_le_mul_of_nonneg_left hd (scoreMajorant_nonneg p radius hr)
  have hs := self_le_qabs (QComplex.normSq (eval p x) - QComplex.normSq (eval p target))
  grind

end CPoly
end ComputableAnalysis
