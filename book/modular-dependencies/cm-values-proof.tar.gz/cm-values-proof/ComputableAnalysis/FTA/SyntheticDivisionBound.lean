import ComputableAnalysis.FTA.ActualTaylorEnvelope
import ComputableAnalysis.FiniteFTABoundary

namespace ComputableAnalysis.FiniteFTABoundary
open QComplex PolynomialDirection

/-- Synthetic division has a coefficient envelope uniform over all centres
in the supplied rational norm ball. No root is supplied or required. -/
theorem syntheticDivide_uniform_bound (p : CPoly.Coeffs) (r : QComplex) (R : Rat)
    (hR : 0 ≤ R) (hr : normBound r ≤ R) :
    normBound (syntheticDivide r p).2 ≤ CPoly.normMajorant p (R+1) ∧
      ∀ a ∈ (syntheticDivide r p).1, normBound a ≤ CPoly.normMajorant p (R+1) := by
  induction p with
  | nil =>
    constructor
    · change normBound QComplex.zero ≤ 0
      decide +kernel
    · intro a ha; simp [syntheticDivide] at ha
  | cons c p ih =>
    have hM := CPoly.normMajorant_nonneg p (R+1) (by grind)
    have hc := normBound_nonneg c
    have htail : CPoly.normMajorant p (R+1) ≤ CPoly.normMajorant (c::p) (R+1) := by
      have hm := Rat.mul_le_mul_of_nonneg_right (show (1 : Rat) ≤ R+1 by grind) hM
      change CPoly.normMajorant p (R+1) ≤ normBound c+(R+1)*CPoly.normMajorant p (R+1)
      grind
    constructor
    · have hm := normBound_mul_le r (syntheticDivide r p).2
      have h1 := Rat.mul_le_mul_of_nonneg_right hr (normBound_nonneg (syntheticDivide r p).2)
      have h2 := Rat.mul_le_mul_of_nonneg_left ih.1 hR
      have ha := normBound_add_le c (mul r (syntheticDivide r p).2)
      have hb := Rat.mul_le_mul_of_nonneg_right (show R ≤ R+1 by grind) hM
      change normBound (add c (mul r (syntheticDivide r p).2)) ≤
        normBound c+(R+1)*CPoly.normMajorant p (R+1)
      grind
    · intro a ha
      change a ∈ (syntheticDivide r p).2 :: (syntheticDivide r p).1 at ha
      rcases List.mem_cons.mp ha with heq | ha
      · subst a; exact Rat.le_trans ih.1 htail
      · exact Rat.le_trans (ih.2 a ha) htail

/-- A shared input coefficient bound yields a shared output bound with an
explicit finite geometric envelope. -/
theorem syntheticDivide_common_bound (p : CPoly.Coeffs) (r : QComplex) (R H : Rat)
    (hR : 0 ≤ R) (hr : normBound r ≤ R) (hp : ∀ a ∈ p, normBound a ≤ H) :
    normBound (syntheticDivide r p).2 ≤ H*geometricEnvelope p.length (R+1) ∧
      ∀ a ∈ (syntheticDivide r p).1, normBound a ≤ H*geometricEnvelope p.length (R+1) := by
  have hb := syntheticDivide_uniform_bound p r R hR hr
  have hm := common_coefficient_majorant p (R+1) H (by grind) hp
  exact ⟨Rat.le_trans hb.1 hm, fun a ha => Rat.le_trans (hb.2 a ha) hm⟩

/-- Padded synthetic quotients permit a fixed-length iteration with no
coefficient-zero test. Remainders of successive iterations are Taylor data. -/
def divisionIterate (r : QComplex) (p : CPoly.Coeffs) : Nat → CPoly.Coeffs
  | 0 => p
  | n+1 => (syntheticDivide r (divisionIterate r p n)).1

theorem divisionIterate_length (r : QComplex) (p : CPoly.Coeffs) (n : Nat) :
    (divisionIterate r p n).length = p.length := by
  induction n with
  | zero => rfl
  | succ n ih => rw [divisionIterate, syntheticDivide_quotient_length, ih]

/-- Every iterated coefficient has a computed common bound, uniformly over
the centre. The extra unit makes the growth factor positive even for empty lists. -/
theorem divisionIterate_bound (p : CPoly.Coeffs) (r : QComplex) (R H : Rat)
    (hR : 0 ≤ R) (hH : 0 ≤ H) (hr : normBound r ≤ R)
    (hp : ∀ a ∈ p, normBound a ≤ H) (n : Nat) :
    ∀ a ∈ divisionIterate r p n,
      normBound a ≤ H*(geometricEnvelope p.length (R+1)+1)^n := by
  let G := geometricEnvelope p.length (R+1)
  have hG : 0 ≤ G := geometricEnvelope_nonneg _ _ (by grind)
  induction n with
  | zero => simpa only [divisionIterate, Rat.pow_zero, Rat.mul_one] using hp
  | succ n ih =>
    intro a ha
    have hb := syntheticDivide_common_bound (divisionIterate r p n) r R
      (H*(G+1)^n) hR hr ih
    rw [divisionIterate_length] at hb
    have hu : 0 ≤ H*(G+1)^n := Rat.mul_nonneg hH (Rat.pow_nonneg (by grind))
    have hm := Rat.mul_le_mul_of_nonneg_left (show G ≤ G+1 by grind) hu
    have ht := hb.2 a ha
    change normBound a ≤ H*(G+1)^(n+1)
    rw [Rat.pow_succ]
    change normBound a ≤ (H*((G+1)^n*(G+1)))
    grind [Rat.mul_assoc]

/-- Actual successive remainder values satisfy the corresponding uniform
Taylor coefficient bound. -/
theorem divisionIterate_remainder_bound (p : CPoly.Coeffs) (r : QComplex) (R H : Rat)
    (hR : 0 ≤ R) (hH : 0 ≤ H) (hr : normBound r ≤ R)
    (hp : ∀ a ∈ p, normBound a ≤ H) (n : Nat) :
    normBound (syntheticDivide r (divisionIterate r p n)).2 ≤
      H*(geometricEnvelope p.length (R+1)+1)^(n+1) := by
  let G := geometricEnvelope p.length (R+1)
  have hG : 0 ≤ G := geometricEnvelope_nonneg _ _ (by grind)
  have hb := syntheticDivide_common_bound (divisionIterate r p n) r R (H*(G+1)^n)
    hR hr (divisionIterate_bound p r R H hR hH hr hp n)
  rw [divisionIterate_length] at hb
  have hu : 0 ≤ H*(G+1)^n := Rat.mul_nonneg hH (Rat.pow_nonneg (by grind))
  have hm := Rat.mul_le_mul_of_nonneg_left (show G ≤ G+1 by grind) hu
  change normBound (syntheticDivide r (divisionIterate r p n)).2 ≤ H*(G+1)^(n+1)
  rw [Rat.pow_succ]
  have ht := hb.1
  grind [Rat.mul_assoc]

end ComputableAnalysis.FiniteFTABoundary
