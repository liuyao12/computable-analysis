import ComputableAnalysis.FTA.ConcreteDescentSchedule

namespace ComputableAnalysis.PolynomialDirection
open QComplex

theorem geometricEnvelope_step (n : Nat) (D : Rat) (hD : 0 ≤ D) :
    geometricEnvelope n D ≤ geometricEnvelope (n+1) D := by
  induction n with
  | zero => change (0 : Rat) ≤ 1+D*0; grind
  | succ n ih =>
    have hm := Rat.mul_le_mul_of_nonneg_left ih hD
    change 1+D*geometricEnvelope n D ≤ 1+D*geometricEnvelope (n+1) D
    grind

theorem geometricEnvelope_mono (n m : Nat) (D : Rat) (hD : 0 ≤ D) (hnm : n ≤ m) :
    geometricEnvelope n D ≤ geometricEnvelope m D := by
  induction hnm with
  | refl => exact Rat.le_refl
  | @step m h ih => exact Rat.le_trans ih (geometricEnvelope_step m D hD)

theorem actual_tail_majorant (b : DescentBounds) (n : Nat) (tail : CPoly.Coeffs)
    (hlen : tail.length ≤ b.tailLength)
    (hp : ∀ a ∈ tail, normBound a ≤ b.coefficient) :
    CPoly.normMajorant tail (scheduleRadius n) ≤
      b.coefficient * geometricEnvelope b.tailLength (scheduleRadius n) := by
  have hD := Rat.le_of_lt (scheduleRadius_pos n)
  have hm := common_coefficient_majorant tail (scheduleRadius n) b.coefficient hD hp
  have hl := geometricEnvelope_mono tail.length b.tailLength (scheduleRadius n) hD hlen
  exact Rat.le_trans hm (Rat.mul_le_mul_of_nonneg_left hl b.coefficient_nonneg)

/-- The significant coefficient's actual directed value satisfies the
coefficient envelope used in the concrete schedule. -/
theorem actual_directed_coefficient_bound (b : DescentBounds) (n : Nat)
    (seed a : QComplex) (eta : Rat) (ha : normBound a ≤ b.coefficient) :
    let d := selectedPaletteDirection (n+1) (by omega) seed eta
    normBound (mul a (pow d (n+1))) ≤ scheduleCoefficientBound b n := by
  have hd := normBound_pow_le (Rat.le_of_lt (scheduleRadius_pos n))
    (selectedPaletteDirection_bound (n+1) (by omega) seed eta) (n+1)
  have hm := normBound_mul_le a (pow (selectedPaletteDirection (n+1) (by omega) seed eta) (n+1))
  have h1 := Rat.mul_le_mul_of_nonneg_right ha
    (normBound_nonneg (pow (selectedPaletteDirection (n+1) (by omega) seed eta) (n+1)))
  have h2 := Rat.mul_le_mul_of_nonneg_left hd b.coefficient_nonneg
  exact Rat.le_trans hm (Rat.le_trans h1 h2)

/-- The actual tail at the concrete step meets the schedule's tail envelope. -/
theorem actual_directed_tail_bound (b : DescentBounds) (n : Nat) (theta : QPos)
    (seed : QComplex) (eta : Rat) (tail : CPoly.Coeffs) (hlen : tail.length ≤ b.tailLength)
    (hp : ∀ a ∈ tail, normBound a ≤ b.coefficient) :
    let d := selectedPaletteDirection (n+1) (by omega) seed eta
    normBound (mul (pow d (n+2))
      (CPoly.eval tail (scaleRat (scheduleStep b n theta).val d))) ≤ scheduleTailBound b n := by
  have hs := scheduleStep_spec b n theta
  have hb := selected_factored_tail_bound tail (n+1) (by omega) seed eta
    (scheduleStep b n theta).val (Rat.le_of_lt (scheduleStep b n theta).property)
    (Rat.le_of_lt hs.2.1)
  have hm := actual_tail_majorant b n tail hlen hp
  have hh := Rat.mul_le_mul_of_nonneg_left hm
    (show 0 ≤ (scheduleRadius n)^(n+2) from Rat.pow_nonneg (Rat.le_of_lt (scheduleRadius_pos n)))
  exact Rat.le_trans hb hh

/-- The concrete schedule gives descent of the actual split polynomial once
its shared bounds and earlier-coefficient cap are justified. -/
theorem concrete_split_descent (b : DescentBounds) (c a : QComplex)
    (early tail : CPoly.Coeffs) (theta : QPos) (hc : normBound c ≤ b.value)
    (hres : b.residual.val ≤ normSq c) (hsign : theta.val < normBound a)
    (ha : normBound a ≤ b.coefficient) (hlen : tail.length ≤ b.tailLength)
    (htail : ∀ q ∈ tail, normBound q ≤ b.coefficient)
    (hearly : ∀ q ∈ early, normBound q ≤ (descentCoefficientCap b early.length theta).val) :
    let n := early.length
    let delta := scheduleMargin b n theta
    let t := (scheduleStep b n theta).val
    let d := selectedPaletteDirection (n+1) (by omega) (mul (conj c) a) delta.val
    normSq (CPoly.eval (c :: (early ++ a :: tail)) (scaleRat t d)) ≤
      normSq c-t^(n+1)*delta.val/2 := by
  let n := early.length
  let delta := scheduleMargin b n theta
  let t := (scheduleStep b n theta).val
  let seed := mul (conj c) a
  let d := selectedPaletteDirection (n+1) (by omega) seed delta.val
  have hdir := residual_palette_inward (n+1) (by omega) c a b.value b.value_nonneg
    b.residual theta hc hres hsign
  change (mul (mul (conj c) a) (pow d (n+1))).re < -delta.val at hdir
  rw [mul_assoc_cert] at hdir
  have hcoeff := actual_directed_coefficient_bound b n seed a delta.val ha
  have htailbound := actual_directed_tail_bound b n theta seed delta.val tail hlen htail
  have hs := scheduleStep_spec b n theta
  exact PolynomialNormDescent.split_polynomial_decrease c a seed d early tail delta
    b.value (scheduleCoefficientBound b n) (scheduleTailBound b n) delta.val t (n+1)
    b.value_nonneg (scheduleCoefficientBound_nonneg b n) (scheduleTailBound_nonneg b n)
    (by omega) rfl rfl hc hcoeff htailbound (Rat.le_of_lt hdir)
    (scheduleStep b n theta).property hs.1 hearly

end ComputableAnalysis.PolynomialDirection
