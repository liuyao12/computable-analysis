import ComputableAnalysis.FTA.PeelPointBound

namespace ComputableAnalysis.QBox

/-- Absolute coordinate bounds control the radius used by the coefficient
search, including its intentional unit margin. -/
theorem coordinateRadius_le_of_bounded (A : QBox) (B : Rat)
    (h : A.CoordinateBounded B) : A.coordinateRadius ≤ 1+B := by
  unfold CoordinateBounded at h
  unfold coordinateRadius max4 maxRat2
  split <;> split <;> split <;> grind

theorem add_coordinateBounded (A B : QBox) (C D : Rat)
    (ha : A.CoordinateBounded C) (hb : B.CoordinateBounded D) :
    (QBox.add A B).CoordinateBounded (C+D) := by
  have h1 := qabs_add_le A.lo.re B.lo.re
  have h2 := qabs_add_le A.hi.re B.hi.re
  have h3 := qabs_add_le A.lo.im B.lo.im
  have h4 := qabs_add_le A.hi.im B.hi.im
  unfold CoordinateBounded QBox.add at *
  simp only [QComplex.add] at *
  constructor
  · grind
  constructor
  · grind
  constructor <;> grind

end ComputableAnalysis.QBox

namespace ComputableAnalysis.RepresentedPolynomial

/-- Explicit coordinate envelopes bound the initial coefficient radius. -/
theorem coefficientRadius_le_of_box_envelopes (p : Coefficients) (C : Rat)
    (h : ∀ a ∈ p, (a.raw.compute 0).CoordinateBounded C) :
    coefficientRadius p ≤ 2*(1+C)*(p.length : Rat) := by
  induction p with
  | nil => change 0 ≤ 2*(1+C)*0; grind
  | cons a p ih =>
    have ha := QBox.coordinateRadius_le_of_bounded (a.raw.compute 0) C (h a (by simp))
    have ht := ih (by intro b hb; exact h b (by simp [hb]))
    simp only [coefficientRadius, List.length_cons, Rat.natCast_add]
    grind

end ComputableAnalysis.RepresentedPolynomial
