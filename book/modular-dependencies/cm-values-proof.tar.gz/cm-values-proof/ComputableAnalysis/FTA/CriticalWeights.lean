import ComputableAnalysis.FTA.PolynomialDerivative
import ComputableAnalysis.FTA.RealFactorValues
import ComputableAnalysis.ComputableCoefficientSeparation

/-! Nonnegative weights for the Gauss--Lucas argument. For a root list,
the weight of one occurrence is the product of the squared distances to all
other occurrences. Multiplicities remain in the list. -/
namespace ComputableAnalysis.RepresentedPolynomial
open Arithmetic
namespace CriticalWeights
abbrev V := ComputableCoefficient.Value
abbrev WeightedRoots := List (ComplexCert × V)

def total : WeightedRoots → V
  | [] => .rational 0
  | (_, w) :: ws => .add w (total ws)

def moment : WeightedRoots → ComplexCert
  | [] => zero
  | (r, w) :: ws => add (mul (realArgument w.real) r) (moment ws)

def scale (v : V) (ws : WeightedRoots) : WeightedRoots :=
  ws.map fun (r, w) => (r, ComputableCoefficient.Value.mul v w)

def weights : List ComplexCert → ComplexCert → WeightedRoots
  | [], _ => []
  | r :: rs, z => (r, normValue (rootProduct rs z)) ::
      scale (normValue (sub z r)) (weights rs z)

private theorem qext {a b : QComplex} (hr : a.re = b.re) (hi : a.im = b.im) : a = b := by
  cases a; cases b; simp_all

theorem total_scale (v : V) (ws : WeightedRoots) :
    (total (scale v ws)).real.preferred.Equiv (ComputableCoefficient.Value.mul v (total ws)).real.preferred := by
  apply ComputableCoefficient.Value.equiv_of_samples _ _ 0
  intro m hm s hs
  induction ws with
  | nil => simp [scale, total, ComputableCoefficient.Value.mul, ComputableCoefficient.Value.rational]
  | cons a ws ih =>
      change v.sample s * a.2.sample s + (total (scale v ws)).sample s =
        v.sample s * (a.2.sample s + (total ws).sample s)
      rw [ih]
      change v.sample s * a.2.sample s + v.sample s * (total ws).sample s =
        v.sample s * (a.2.sample s + (total ws).sample s)
      grind

theorem moment_scale (v : V) (ws : WeightedRoots) :
    (moment (scale v ws)).raw.Equiv (mul (realArgument v.real) (moment ws)).raw := by
  induction ws with
  | nil => exact ComplexRaw.equiv_symm (certMulZero _)
  | cons a ws ih =>
      rcases a with ⟨r, w⟩
      refine certTrans (certAddCongr
        (certMulCongr (ComplexRaw.equiv_symm (realArgument_mul v.real w.real)) (certRefl r)) ih) ?_
      apply Expression.equiv_of_samples
        (.add (.mul (.mul (.parameter (realArgument v.real)) (.parameter (realArgument w.real)))
          (.parameter r)) (.mul (.parameter (realArgument v.real)) (.parameter (moment ws))))
        (.mul (.parameter (realArgument v.real))
          (.add (.mul (.parameter (realArgument w.real)) (.parameter r)) (.parameter (moment ws))))
      intro s
      apply qext <;> simp [Expression.sample, QComplex.add, QComplex.mul] <;> grind

/-- Norm square is the exact real scalar represented by `z * conj z`. -/
theorem norm_bridge (z : ComplexCert) :
    (realArgument (normValue z).real).raw.Equiv (mul z (conj z)).raw := by
  intro n
  let a := (z.raw.compute n).lo
  have ha := ComplexRaw.valid_ordered z.valid n
  have hc := (Expression.mul (.parameter z) (.conj (.parameter z))).contains n
    (fun x => (x.raw.compute n).lo)
    (fun x => ⟨QComplex.le_refl _, ComplexRaw.valid_ordered x.valid n⟩)
  have hn := (normValue z).encloses n n
    (by simp [normValue, ComputableCoefficient.Value.add, ComputableCoefficient.Value.mul, ComputableCoefficient.Value.parameter]) _
    (ComputableCoefficient.samples_lower n)
  have he : QComplex.mul a (QComplex.conj a) = QComplex.ofRat (QComplex.normSq a) := by
    apply qext <;> simp [QComplex.mul, QComplex.conj, QComplex.normSq, QComplex.ofRat] <;> grind
  change ((mul z (conj z)).raw.compute n).lo ≤ QComplex.mul a (QComplex.conj a) ∧
    QComplex.mul a (QComplex.conj a) ≤ ((mul z (conj z)).raw.compute n).hi at hc
  rw [he] at hc
  change ((normValue z).real.compute n).lo ≤ QComplex.normSq a ∧
    QComplex.normSq a ≤ ((normValue z).real.compute n).hi at hn
  apply (ComplexRaw.compareAt_overlap_iff _ _ n n).2
  change (((normValue z).real.compute n).lo ≤ ((mul z (conj z)).raw.compute n).hi.re ∧
    (0 : Rat) ≤ ((mul z (conj z)).raw.compute n).hi.im) ∧
    (((mul z (conj z)).raw.compute n).lo.re ≤ ((normValue z).real.compute n).hi ∧
    ((mul z (conj z)).raw.compute n).lo.im ≤ (0 : Rat))
  exact ⟨⟨Rat.le_trans hn.1 hc.2.1, hc.2.2⟩,
    ⟨Rat.le_trans hc.1.1 hn.2, hc.1.2⟩⟩

theorem norm_sample_nonneg (z : ComplexCert) (s : Real → Rat) : 0 ≤ (normValue z).sample s := by
  have h₁ := rat_square_nonneg_basic (s (realCoordinate z))
  have h₂ := rat_square_nonneg_basic (s (imagCoordinate z))
  change 0 ≤ s (realCoordinate z) * s (realCoordinate z) +
    s (imagCoordinate z) * s (imagCoordinate z)
  grind

theorem weights_support (rs : List ComplexCert) (z : ComplexCert) :
    ∀ a ∈ weights rs z, a.1 ∈ rs ∧ ∀ s, 0 ≤ a.2.sample s := by
  induction rs with
  | nil => simp [weights]
  | cons r rs ih =>
      intro a ha
      rcases List.mem_cons.mp ha with h | h
      · subst a
        exact ⟨by simp, norm_sample_nonneg _⟩
      · obtain ⟨b, hb, rfl⟩ := List.mem_map.mp h
        refine ⟨by simpa using Or.inr (ih b hb).1, ?_⟩
        intro s
        exact Rat.mul_nonneg (norm_sample_nonneg _ s) ((ih b hb).2 s)

theorem total_sample_nonneg (ws : WeightedRoots)
    (hw : ∀ a ∈ ws, ∀ s, 0 ≤ a.2.sample s) (s : Real → Rat) : 0 ≤ (total ws).sample s := by
  induction ws with
  | nil => exact Rat.le_refl
  | cons a ws ih =>
      have ha := hw a (by simp) s
      have ht := ih (fun b hb => hw b (by simp [hb]))
      change 0 ≤ a.2.sample s + (total ws).sample s
      grind

theorem nonneg_of_samples (v : V) (hv : ∀ s, 0 ≤ v.sample s) :
    RealRaw.zero.Le v.real.preferred := by
  intro n m
  have he := v.encloses m (v.observation m) (Nat.le_refl _) _
    (ComputableCoefficient.samples_lower _)
  exact Rat.le_trans (hv _) he.2

/-- The algebraic heart of Gauss--Lucas, before normalizing the weights. -/
theorem barycenter_identity (rs : List ComplexCert) (z : ComplexCert) :
    (mul z (realArgument (total (weights rs z)).real)).raw.Equiv
      (add (moment (weights rs z))
        (mul (rootProduct rs z) (conj (rootProductDerivative rs z)))).raw := by
  induction rs with
  | nil =>
      have hz : (mul z (realArgument (total (weights [] z)).real)).raw.Equiv zero.raw := certMulZero z
      exact certTrans hz (ComplexRaw.equiv_symm
        (certTrans (certAddCongr (certRefl zero)
          (certTrans (certMulCongr (certRefl one) conj_zero) (certMulZero one))) (zero_add zero)))
  | cons r rs ih =>
      let d := sub z r
      let q := rootProduct rs z
      let e := rootProductDerivative rs z
      let s := realArgument (total (weights rs z)).real
      let m := moment (weights rs z)
      have ht : (realArgument (total (weights (r :: rs) z)).real).raw.Equiv
          (add (mul q (conj q)) (mul (mul d (conj d)) s)).raw := by
        refine certTrans (ComplexRaw.equiv_symm (realArgument_add _ _)) ?_
        refine certAddCongr (norm_bridge q) ?_
        have hscale : (realArgument (total (scale (normValue d) (weights rs z))).real).raw.Equiv
            (realArgument (ComputableCoefficient.Value.mul (normValue d) (total (weights rs z))).real).raw :=
          ComplexRaw.ofRealRaw_equiv_of_equiv (total (scale (normValue d) (weights rs z))).real.valid
            (ComputableCoefficient.Value.mul (normValue d) (total (weights rs z))).real.valid
            (total_scale (normValue d) (weights rs z))
        refine certTrans hscale ?_
        exact certTrans (ComplexRaw.equiv_symm (realArgument_mul _ _))
          (certMulCongr (norm_bridge d) (certRefl s))
      have hm : (moment (weights (r :: rs) z)).raw.Equiv
          (add (mul (mul q (conj q)) r) (mul (mul d (conj d)) m)).raw :=
        certAddCongr (certMulCongr (norm_bridge q) (certRefl r))
          (certTrans (moment_scale _ _) (certMulCongr (norm_bridge d) (certRefl m)))
      have hd : (conj (rootProductDerivative (r :: rs) z)).raw.Equiv
          (add (conj q) (mul (conj d) (conj e))).raw :=
        certTrans (conj_add q (mul d e)) (certAddCongr (certRefl _) (conj_mul d e))
      have step : (mul z (add (mul q (conj q)) (mul (mul d (conj d)) s))).raw.Equiv
          (add (mul (mul q (conj q)) z) (mul (mul d (conj d)) (mul z s))).raw := by
        apply Expression.equiv_of_samples
          (.mul (.parameter z) (.add (.mul (.parameter q) (.conj (.parameter q)))
            (.mul (.mul (.parameter d) (.conj (.parameter d))) (.parameter s))))
          (.add (.mul (.mul (.parameter q) (.conj (.parameter q))) (.parameter z))
            (.mul (.mul (.parameter d) (.conj (.parameter d))) (.mul (.parameter z) (.parameter s))))
        intro t
        apply qext <;> simp [Expression.sample, QComplex.add, QComplex.mul, QComplex.conj] <;> grind
      refine certTrans (certMulCongr (certRefl z) ht) (certTrans step
        (certTrans (certAddCongr (certRefl _) (certMulCongr (certRefl _) ih)) ?_))
      refine certTrans ?_ (ComplexRaw.equiv_symm (certAddCongr hm (certMulCongr (certRefl _) hd)))
      apply Expression.equiv_of_samples
        (.add (.mul (.mul (.parameter q) (.conj (.parameter q))) (.parameter z))
          (.mul (.mul (.add (.parameter z) (.neg (.parameter r)))
            (.conj (.add (.parameter z) (.neg (.parameter r)))))
            (.add (.parameter m) (.mul (.parameter q) (.conj (.parameter e))))))
        (.add (.add (.mul (.mul (.parameter q) (.conj (.parameter q))) (.parameter r))
          (.mul (.mul (.add (.parameter z) (.neg (.parameter r)))
            (.conj (.add (.parameter z) (.neg (.parameter r))))) (.parameter m)))
          (.mul (.mul (.add (.parameter z) (.neg (.parameter r))) (.parameter q))
            (.add (.conj (.parameter q))
              (.mul (.conj (.add (.parameter z) (.neg (.parameter r)))) (.conj (.parameter e))))))
      intro t
      apply qext <;> simp [Expression.sample, QComplex.add, QComplex.mul, QComplex.neg,
        QComplex.conj] <;> grind

end CriticalWeights
end ComputableAnalysis.RepresentedPolynomial
