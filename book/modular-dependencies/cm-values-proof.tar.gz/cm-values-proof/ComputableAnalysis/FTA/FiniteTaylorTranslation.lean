import ComputableAnalysis.FTA.SyntheticDivisionBound

namespace ComputableAnalysis.FiniteFTABoundary
open QComplex

private theorem complex_ext (x y : QComplex) (hr : x.re = y.re) (hi : x.im = y.im) : x = y := by
  cases x
  cases y
  simp_all

private theorem eval_append_zero (p : CPoly.Coeffs) (z : QComplex) :
    CPoly.eval (p ++ [QComplex.zero]) z = CPoly.eval p z := by
  induction p with
  | nil =>
    apply complex_ext <;> simp only [CPoly.eval, List.nil_append, List.foldr_cons,
      List.foldr_nil, QComplex.add, QComplex.mul, QComplex.zero] <;> grind
  | cons c p ih =>
    change add c (mul z (CPoly.eval (p ++ [QComplex.zero]) z)) = _
    rw [ih]
    rfl

def trimmedQuotient (r : QComplex) (p : CPoly.Coeffs) : CPoly.Coeffs :=
  (syntheticDivide r p).1.dropLast

theorem trimmedQuotient_length (r : QComplex) (p : CPoly.Coeffs) :
    (trimmedQuotient r p).length = p.length-1 := by
  rw [trimmedQuotient, List.length_dropLast, syntheticDivide_quotient_length]

theorem trimmedQuotient_eval (r z : QComplex) (p : CPoly.Coeffs) :
    CPoly.eval (trimmedQuotient r p) z = CPoly.eval (syntheticDivide r p).1 z := by
  cases p with
  | nil => rfl
  | cons c p =>
    obtain ⟨q, hq, _⟩ := syntheticDivide_quotient_padded r (by simp : c::p ≠ [])
    rw [trimmedQuotient, hq]
    simp only [List.dropLast_append_cons, List.dropLast_singleton, List.append_nil]
    exact (eval_append_zero q z).symm

/-- Executable finite Taylor translation, with one coefficient per input
coefficient and no test for represented or rational coefficient equality. -/
def finiteTaylor (r : QComplex) (p : CPoly.Coeffs) : CPoly.Coeffs :=
  match p with
  | [] => []
  | c :: p => (syntheticDivide r (c::p)).2 :: finiteTaylor r (trimmedQuotient r (c::p))
termination_by p.length
decreasing_by rw [trimmedQuotient_length]; simp

theorem finiteTaylor_length (r : QComplex) (p : CPoly.Coeffs) :
    (finiteTaylor r p).length = p.length := by
  cases p with
  | nil => rw [finiteTaylor]
  | cons c p =>
    rw [finiteTaylor, List.length_cons, finiteTaylor_length, trimmedQuotient_length]
    simp
termination_by p.length
decreasing_by rw [trimmedQuotient_length]; simp

/-- Exact translated evaluation for arbitrary rational centre and argument. -/
theorem finiteTaylor_eval (r h : QComplex) (p : CPoly.Coeffs) :
    CPoly.eval p (add r h) = CPoly.eval (finiteTaylor r p) h := by
  cases p with
  | nil => rw [finiteTaylor]; rfl
  | cons c p =>
    have hs := syntheticDivide_spec r (add r h) (c::p)
    have hid : sub (add r h) r = h := by
      apply complex_ext <;> simp only [sub, add, neg] <;> grind
    dsimp only at hs
    rw [hid, ← trimmedQuotient_eval, finiteTaylor_eval r h (trimmedQuotient r (c::p))] at hs
    rw [finiteTaylor]
    exact hs
termination_by p.length
decreasing_by rw [trimmedQuotient_length]; simp

/-- The padded quotient retains an arbitrary leading coefficient literally. -/
theorem syntheticDivide_leading (r c a : QComplex) (p : CPoly.Coeffs) :
    ∃ q, (syntheticDivide r (c :: (p ++ [a]))).1 = q ++ [a, QComplex.zero] := by
  have ha : add a (mul r QComplex.zero) = a := by
    apply complex_ext <;> simp only [add, mul, QComplex.zero] <;> grind
  induction p generalizing c with
  | nil =>
    refine ⟨[], ?_⟩
    simp only [List.nil_append, syntheticDivide, ha]
  | cons d p ih =>
    obtain ⟨q, hq⟩ := ih d
    refine ⟨(syntheticDivide r (d :: (p ++ [a]))).2 :: q, ?_⟩
    change (syntheticDivide r (d :: (p ++ [a]))).2 ::
      (syntheticDivide r (d :: (p ++ [a]))).1 = _
    rw [hq]
    rfl

theorem trimmedQuotient_leading (r c a : QComplex) (p : CPoly.Coeffs) :
    ∃ q, trimmedQuotient r (c :: (p ++ [a])) = q ++ [a] := by
  obtain ⟨q, hq⟩ := syntheticDivide_leading r c a p
  refine ⟨q, ?_⟩
  rw [trimmedQuotient, hq]
  simp only [List.dropLast_append_cons, List.dropLast]

/-- Finite Taylor translation preserves every literal leading coefficient,
including the monic coefficient used to terminate the threshold scan. -/
theorem finiteTaylor_leading (r a : QComplex) (p : CPoly.Coeffs) :
    ∃ q, finiteTaylor r (p ++ [a]) = q ++ [a] := by
  cases p with
  | nil =>
    refine ⟨[], ?_⟩
    have ha : add a (mul r QComplex.zero) = a := by
      apply complex_ext <;> simp only [add, mul, QComplex.zero] <;> grind
    simp only [List.nil_append, finiteTaylor, syntheticDivide, trimmedQuotient,
      List.dropLast_singleton, ha]
  | cons c p =>
    obtain ⟨q, hq⟩ := trimmedQuotient_leading r c a p
    obtain ⟨qs, hqs⟩ := finiteTaylor_leading r a q
    refine ⟨(syntheticDivide r (c :: (p ++ [a]))).2 :: qs, ?_⟩
    rw [List.cons_append, finiteTaylor]
    change (syntheticDivide r (c :: (p ++ [a]))).2 ::
      finiteTaylor r (trimmedQuotient r (c :: (p ++ [a]))) = _
    rw [hq, hqs]
    rfl
termination_by p.length
decreasing_by
  have hl := trimmedQuotient_length r (c :: (p ++ [a]))
  rw [hq] at hl
  simp only [List.length_cons, List.length_append, List.length_nil] at hl
  simp only [List.length_cons]
  omega

end ComputableAnalysis.FiniteFTABoundary
