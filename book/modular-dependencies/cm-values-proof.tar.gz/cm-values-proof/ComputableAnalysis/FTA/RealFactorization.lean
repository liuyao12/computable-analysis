import ComputableAnalysis.FTA.ConjugateDivision

/-! Complete factorization over represented real coefficients. -/
namespace ComputableAnalysis.RepresentedPolynomial

/-- Factors carry actual represented real parameters. The quadratic is
`(x-u)^2+v^2`, with nonzero `v`. -/
inductive RealFactor where
  | linear (u : Real)
  | quadratic (u v : Real) (hv : ¬ v.preferred.Equiv RealRaw.zero)

def RealFactor.degree : RealFactor → Nat
  | .linear _ => 1
  | .quadratic _ _ _ => 2

def RealFactor.eval : RealFactor → ComplexCert → ComplexCert
  | .linear u, x => sub x (realArgument u)
  | .quadratic u v _, x => mul (sub x (ofParts u v)) (sub x (conj (ofParts u v)))

def realFactorProduct : List RealFactor → ComplexCert → ComplexCert
  | [], _ => one
  | f :: fs, x => mul (f.eval x) (realFactorProduct fs x)

def realFactorDegree : List RealFactor → Nat
  | [] => 0
  | f :: fs => f.degree + realFactorDegree fs

theorem parts_equiv (r : ComplexCert) :
    r.raw.Equiv (ofParts (realCoordinate r) (imagCoordinate r)).raw := certRefl r

theorem nonreal_imag_nonzero (r : ComplexCert) (hr : ¬ IsReal r) :
    ¬ (imagCoordinate r).preferred.Equiv RealRaw.zero := by
  intro hi
  apply hr
  intro n
  have hh := (RealRaw.compareAt_overlap_iff _ _ n n).1 (hi n)
  change (r.raw.compute n).lo.im ≤ (0 : Rat) ∧ 0 ≤ (r.raw.compute n).hi.im at hh
  have ho := (ComplexRaw.valid_ordered r.valid n).1
  apply (ComplexRaw.compareAt_overlap_iff _ _ n n).2
  change ((r.raw.compute n).lo.re ≤ (r.raw.compute n).hi.re ∧
    -(r.raw.compute n).hi.im ≤ (r.raw.compute n).hi.im) ∧
    ((r.raw.compute n).lo.re ≤ (r.raw.compute n).hi.re ∧
    (r.raw.compute n).lo.im ≤ -(r.raw.compute n).lo.im)
  constructor <;> constructor <;> grind

private theorem constant_eval (c x : ComplexCert) : (eval [c] x).raw.Equiv c.raw :=
  certTrans (certAddCongr (certRefl c) (certMulZero x)) (add_zero c)

/-- Every real monic polynomial is a product of real linear and irreducible
quadratic factors, counting multiplicities. Equality holds at every complex
argument, and hence at every real argument. -/
theorem monic_real_factorization (p : Coefficients) (hp : Monic p) (hre : RealCoefficients p) :
    ∃ fs : List RealFactor, realFactorDegree fs = p.length - 1 ∧
      ∀ x : ComplexCert, (eval p x).raw.Equiv (realFactorProduct fs x).raw := by
  classical
  by_cases hd : 2 ≤ p.length
  · obtain ⟨r, hr⟩ := monic_root_existence p hp hd
    by_cases hreal : IsReal r
    · let q := (syntheticDivide r p).1
      have hq := syntheticDivide_monic r p hp hd
      have hqr := (syntheticDivide_real r hreal p hre).1
      obtain ⟨fs, hdeg, hfs⟩ := monic_real_factorization q hq hqr
      refine ⟨.linear (realCoordinate r) :: fs, ?_, ?_⟩
      · have hlen := syntheticDivide_length r p
        change 1 + realFactorDegree fs = _
        dsimp [q] at hdeg
        omega
      · intro x
        exact certTrans (syntheticDivide_factor hr x)
          (certMulCongr (certSubCongr (certRefl x) (IsReal.projection hreal)) (hfs x))
    · let q := (quadraticDivide (conjugateConstant r) (conjugateLinear r) p).1
      have hdegree := conjugateDivide_degree p hp hre r hr hreal
      have hq := quadraticDivide_monic (conjugateConstant r) (conjugateLinear r) p hp hdegree
      have hqr := (quadraticDivide_real (conjugateConstant r) (conjugateLinear r)
        (conjugateConstant_real r) (conjugateLinear_real r) p hre).1
      obtain ⟨fs, hdeg, hfs⟩ := monic_real_factorization q hq hqr
      refine ⟨.quadratic (realCoordinate r) (imagCoordinate r) (nonreal_imag_nonzero r hreal) :: fs, ?_, ?_⟩
      · have hlen := quadraticDivide_length (conjugateConstant r) (conjugateLinear r) p
        change 2 + realFactorDegree fs = _
        dsimp [q] at hdeg
        omega
      · intro x
        have he := parts_equiv r
        have hec : (conj r).raw.Equiv (conj (ofParts (realCoordinate r) (imagCoordinate r))).raw :=
          ComplexRaw.conj_equiv he
        exact certTrans (conjugateDivide_factor p hre r hr hreal x)
          (certMulCongr (certMulCongr (certSubCongr (certRefl x) he)
            (certSubCongr (certRefl x) hec)) (hfs x))
  · obtain ⟨q, rfl⟩ := hp
    have hq : q = [] := by
      have hh : q.length = 0 := by
        have hlen : (q ++ [one]).length = q.length + 1 := by simp
        omega
      exact List.length_eq_zero_iff.mp hh
    subst q
    exact ⟨[], rfl, fun x => constant_eval one x⟩
termination_by p.length
decreasing_by
  · rw [syntheticDivide_length]; omega
  · rw [quadraticDivide_length]; omega

/-- A reciprocal of a nonzero real coefficient is real. -/
theorem inverse_real (c b : ComplexCert) (hc : IsReal c) (hn : ¬ c.raw.Equiv zero.raw)
    (hb : (mul c b).raw.Equiv one.raw) : IsReal b := by
  apply mul_cancel_left_of_nonzero (a := c) hn
  have hconj : (conj (mul c b)).raw.Equiv (conj one).raw := ComplexRaw.conj_equiv hb
  exact certTrans (ComplexRaw.equiv_symm (certMulCongr hc (certRefl (conj b))))
    (certTrans (ComplexRaw.equiv_symm (conj_mul c b))
      (certTrans hconj (certTrans IsReal.one (ComplexRaw.equiv_symm hb))))

theorem normalize_real (q : Coefficients) (hq : RealCoefficients q)
    (b : ComplexCert) (hb : IsReal b) : RealCoefficients (normalize q b) := by
  induction q with
  | nil => exact ⟨IsReal.one, True.intro⟩
  | cons a q ih => exact ⟨IsReal.mul hb hq.1, ih hq.2⟩

/-- Complete real factorization with an arbitrary nonzero real leading
coefficient. No rational-coefficient restriction or supplied roots are needed. -/
theorem real_coefficients_factorization (q : Coefficients) (hq : RealCoefficients q)
    (c : ComplexCert) (hcr : IsReal c) (hc : ¬ c.raw.Equiv zero.raw) :
    ∃ fs : List RealFactor, realFactorDegree fs = q.length ∧
      ∀ x : ComplexCert, (eval (q ++ [c]) x).raw.Equiv (mul c (realFactorProduct fs x)).raw := by
  obtain ⟨b, hb⟩ := exists_inverse c hc
  have hbr := inverse_real c b hcr hc hb
  obtain ⟨fs, hdeg, hfs⟩ := monic_real_factorization (normalize q b)
    ⟨q.map (mul b), rfl⟩ (normalize_real q hq b hbr)
  refine ⟨fs, ?_, fun x => certTrans (normalize_spec q c b hb x) (certMulCongr (certRefl c) (hfs x))⟩
  simpa [normalize] using hdeg

end ComputableAnalysis.RepresentedPolynomial
