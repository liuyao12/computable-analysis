import ComputableAnalysis.FTA.SampledResidualTransport
import ComputableAnalysis.FTA.ApproximateMinimumTransport

namespace ComputableAnalysis.RepresentedPolynomial
open PolynomialDirection

def residualCoefficientBudget (q : Coefficients) (eps : QPos) : QPos :=
  let R := interiorSearchRadius q
  let M := sampleNormMajorant (q++[one]) 0 R
  ⟨eps.val/(8*(M+1)), by
    have hM := sampleNormMajorant_nonneg (q++[one]) 0 R
      (Rat.le_of_lt (interiorSearchRadius_pos q))
    rw [Rat.div_def]
    exact Rat.mul_pos eps.property (Rat.inv_pos.mpr (by grind))⟩

def residualCoefficientStage (q : Coefficients) (eps : QPos) (start : Nat) : Nat :=
  coefficientPrecision (q++[one]) (interiorSearchRadius q)
    (Rat.le_of_lt (interiorSearchRadius_pos q)) (residualCoefficientBudget q eps) start

/-- Actual finite approximate roots for arbitrary represented monic
coefficients, with coefficient precision selected by a terminating search. -/
def representedResidualCandidate (q : Coefficients) (eps : QPos) (start : Nat) : QComplex :=
  rationalResidualCandidate (coefficientSamples q (residualCoefficientStage q eps start))
    (minimumHalfBudget eps) start

/-- Every later coefficient sample at the computed candidate has squared
residual below the requested tolerance. The tested point is not supplied. -/
theorem representedResidualCandidate_later (q : Coefficients) (hq : 0 < q.length)
    (eps : QPos) (start m : Nat) (hm : residualCoefficientStage q eps start ≤ m) :
    QComplex.normSq (CPoly.eval (coefficientSamples (q++[one]) m)
      (representedResidualCandidate q eps start)) < eps.val := by
  let R := interiorSearchRadius q
  let M := sampleNormMajorant (q++[one]) 0 R
  let n := residualCoefficientStage q eps start
  have hR : 0 ≤ R := Rat.le_of_lt (interiorSearchRadius_pos q)
  have hM : 0 ≤ M := sampleNormMajorant_nonneg (q++[one]) 0 R hR
  have hD := (coefficientPrecision_spec (q++[one]) R hR (residualCoefficientBudget q eps) start).2
  change sampleDifferenceMajorant (q++[one]) n R ≤ eps.val/(8*(M+1)) at hD
  have h := sampled_candidate_later_residual q hq n n m (Nat.le_refl _) hm (minimumHalfBudget eps) start
  have hu := sampleNormMajorant_uniform (q++[one]) n R hR
  have hn := sampleNormMajorant_nonneg (q++[one]) n R hR
  have hd : 0 < 8*(M+1) := by grind
  have ht : 0 ≤ eps.val/(8*(M+1)) := Rat.le_of_lt (by
    rw [Rat.div_def]; exact Rat.mul_pos eps.property (Rat.inv_pos.mpr hd))
  have h1 := Rat.mul_le_mul_of_nonneg_left hD (show 0 ≤ 2*sampleNormMajorant (q++[one]) n R by grind)
  have h2 := Rat.mul_le_mul_of_nonneg_right hu ht
  have hi := Rat.mul_inv_cancel (8*(M+1)) (Rat.ne_of_gt hd)
  have hbudget : 4*M*(eps.val/(8*(M+1))) ≤ eps.val/2 := by
    have hc := Rat.mul_le_mul_of_nonneg_right (show M ≤ M+1 by grind) ht
    have hid : 4*(M+1)*(eps.val/(8*(M+1))) = eps.val/2 := by
      rw [Rat.div_def, Rat.div_def]
      have htwo : (2 : Rat)*(2 : Rat)⁻¹ = 1 := by decide +kernel
      grind
    grind
  change QComplex.normSq (CPoly.eval (coefficientSamples (q++[one]) m)
    (representedResidualCandidate q eps start)) < eps.val/2+
      2*sampleNormMajorant (q++[one]) n R*sampleDifferenceMajorant (q++[one]) n R at h
  change sampleNormMajorant (q++[one]) n R ≤ 2*M at hu
  simp only [Rat.div_def] at *
  grind

/-- Exact residual bound for arbitrary valid represented monic coefficients.
Finite samples justify the raw-value order; no root is assumed. -/
theorem representedResidualCandidate_exact (q : Coefficients) (hq : 0 < q.length)
    (eps : QPos) (start : Nat) :
    (normValue (eval (q++[one]) (ofQComplex (representedResidualCandidate q eps start)))).real.preferred.Le
      (RealRaw.ofRat eps.val) := by
  intro i j
  let n := residualCoefficientStage q eps start
  let m := max n i
  let x := representedResidualCandidate q eps start
  have hxsample := sample_eval_contains (q++[one]) (show i ≤ m by dsimp [m]; omega)
    (B := QBox.point x) (QComplex.le_refl x) (QComplex.le_refl x)
  have hx : ((eval (q++[one]) (ofQComplex x)).raw.compute i).lo ≤
      CPoly.eval (coefficientSamples (q++[one]) m) x ∧
      CPoly.eval (coefficientSamples (q++[one]) m) x ≤
      ((eval (q++[one]) (ofQComplex x)).raw.compute i).hi := by
    rw [eval_compute]
    exact hxsample
  have hb := (normValue_contains (eval (q++[one]) (ofQComplex x)) i _ hx.1 hx.2).1
  have hs := representedResidualCandidate_later q hq eps start m (by dsimp [m, n]; omega)
  change ((normValue (eval (q++[one]) (ofQComplex x))).real.compute i).lo ≤ eps.val
  exact Rat.le_trans hb (Rat.le_of_lt hs)

/-- The residual role survives equivalent coefficient and point names. This
certifies the mathematical role of a candidate, not identical selection under
rerunning the algorithm on different names. -/
theorem representedResidualCandidate_exact_transport (q : Coefficients) (hq : 0 < q.length)
    (eps : QPos) (start : Nat) (p : Coefficients) (hp : Equivalent (q++[one]) p)
    (z : ComplexCert)
    (hz : (ofQComplex (representedResidualCandidate q eps start)).raw.Equiv z.raw) :
    (normValue (eval p z)).real.preferred.Le (RealRaw.ofRat eps.val) := by
  let x := ofQComplex (representedResidualCandidate q eps start)
  have he := normValue_equiv (eval_equiv hp hz)
  have hle := RealRaw.le_of_equiv (normValue (eval p z)).real.valid
    (normValue (eval (q++[one]) x)).real.valid (RealRaw.equiv_symm he)
  exact RealRaw.le_trans (normValue (eval (q++[one]) x)).real.valid hle
    (representedResidualCandidate_exact q hq eps start)

end ComputableAnalysis.RepresentedPolynomial
