import ComputableAnalysis.FTA.SignificantCoefficientScan

namespace ComputableAnalysis.PolynomialDirection

/-- A positive budget for earlier coefficients may depend on the selected
order and its significance threshold. Construction proceeds backwards. -/
def backwardThresholds (cap : Nat → QPos → QPos) : Nat → QPos → List QPos
  | 0, _ => []
  | n + 1, theta =>
      backwardThresholds cap n (QPos.minimum theta (cap n theta)) ++ [theta]

theorem backwardThresholds_length (cap : Nat → QPos → QPos) (n : Nat) (theta : QPos) :
    (backwardThresholds cap n theta).length = n := by
  induction n generalizing theta with
  | zero => rfl
  | succ n ih => simp [backwardThresholds, ih]

/-- Every computed threshold stays below the supplied top threshold. -/
theorem backwardThresholds_le (cap : Nat → QPos → QPos) (n : Nat) (theta : QPos) :
    ∀ q ∈ backwardThresholds cap n theta, q.val ≤ theta.val := by
  induction n generalizing theta with
  | zero => intro q hq; simp [backwardThresholds] at hq
  | succ n ih =>
    intro q hq
    rw [backwardThresholds] at hq
    rcases List.mem_append.mp hq with hq | hq
    · exact Rat.le_trans (ih _ q hq) (QPos.minimum_le_left theta (cap n theta))
    · have heq : q = theta := by simpa using hq
      subst q
      exact Rat.le_refl

/-- Compatibility records the finite inequalities, without any root or
convergence claim. The executable schedule below proves this predicate. -/
inductive ThresholdCompatible (cap : Nat → QPos → QPos) : List QPos → Prop
  | nil : ThresholdCompatible cap []
  | snoc {xs : List QPos} {theta : QPos} : ThresholdCompatible cap xs →
      (∀ q ∈ xs, q.val ≤ (cap xs.length theta).val) →
      ThresholdCompatible cap (xs ++ [theta])

/-- All earlier thresholds satisfy the budget belonging to every later entry,
with each budget evaluated at that entry's actual positive threshold. -/
theorem backwardThresholds_compatible (cap : Nat → QPos → QPos) (n : Nat) (theta : QPos) :
    ThresholdCompatible cap (backwardThresholds cap n theta) := by
  induction n generalizing theta with
  | zero => exact ThresholdCompatible.nil
  | succ n ih =>
    rw [backwardThresholds]
    apply ThresholdCompatible.snoc (ih _)
    intro q hq
    rw [backwardThresholds_length]
    exact Rat.le_trans (backwardThresholds_le cap n _ q hq)
      (QPos.minimum_le_right theta (cap n theta))

/-- Any selected entry inherits its own cap on every earlier threshold. -/
theorem ThresholdCompatible.prefix_cap (cap : Nat → QPos → QPos)
    (xs : List QPos) (hc : ThresholdCompatible cap xs)
    (before : List QPos) (theta : QPos) (after : List QPos)
    (heq : xs = before ++ theta :: after) :
    ∀ q ∈ before, q.val ≤ (cap before.length theta).val := by
  induction hc generalizing before theta after with
  | nil => have hl := congrArg List.length heq; simp at hl
  | @snoc xs last hc hb ih =>
    rcases List.append_eq_append_iff.mp heq with ⟨as, hbefore, htail⟩ | ⟨bs, hxs, htail⟩
    · cases as with
      | nil =>
        simp only [List.append_nil] at hbefore
        simp only [List.nil_append, List.cons.injEq] at htail
        rcases htail with ⟨htheta, hafter⟩
        subst before
        subst theta
        exact hb
      | cons a as =>
        have hl := congrArg List.length htail
        simp at hl
    · cases bs with
      | nil =>
        simp only [List.append_nil] at hxs
        simp only [List.nil_append, List.cons.injEq] at htail
        rcases htail with ⟨htheta, hafter⟩
        subst before
        subst theta
        exact hb
      | cons a bs =>
        simp only [List.cons_append, List.cons.injEq] at htail
        have htheta := htail.1
        subst a
        exact ih before theta bs hxs

/-- The leading threshold is retained exactly, so choosing it below one
preserves the monic passing-entry guarantee. -/
theorem backwardThresholds_last (cap : Nat → QPos → QPos) (n : Nat) (theta : QPos) :
    backwardThresholds cap (n + 1) theta =
      backwardThresholds cap n (QPos.minimum theta (cap n theta)) ++ [theta] := rfl

end ComputableAnalysis.PolynomialDirection
