import ComputableAnalysis.FTA.ScheduledCoefficientScan

namespace ComputableAnalysis.PolynomialDirection
open PolynomialNormDescent

/-- Half the explicit local descent gap for a fixed schedule entry. -/
def scheduleGap (b : DescentBounds) (n : Nat) (theta : QPos) : QPos :=
  let g := localGap (scheduleMargin b n theta) (scheduleStep b n theta).val
    (scheduleStep b n theta).property (n+1)
  ⟨g.val/2, by
    rw [Rat.div_def]
    exact Rat.mul_pos g.property (by decide +kernel)⟩

/-- Finite positive minimum across the schedule's possible selected orders.
The terminal unit is harmless and also defines the empty case. -/
def minimumOrderGap (b : DescentBounds) : List QPos → Nat → QPos
  | [], _ => ⟨1, by decide +kernel⟩
  | theta :: xs, n => QPos.minimum (scheduleGap b n theta) (minimumOrderGap b xs (n+1))

theorem minimumOrderGap_le_entry (b : DescentBounds) (before after : List QPos)
    (theta : QPos) (n : Nat) :
    (minimumOrderGap b (before ++ theta :: after) n).val ≤
      (scheduleGap b (n+before.length) theta).val := by
  induction before generalizing n with
  | nil =>
    simp only [List.nil_append, List.length_nil, Nat.add_zero, minimumOrderGap]
    exact QPos.minimum_le_left _ _
  | cons q before ih =>
    have hm := QPos.minimum_le_right (scheduleGap b n q)
      (minimumOrderGap b (before ++ theta :: after) (n+1))
    have ht := ih (n+1)
    have hidx : n+1+before.length = n+(q::before).length := by simp; omega
    rw [hidx] at ht
    exact Rat.le_trans hm ht

def commonDescentGap (b : DescentBounds) (degree : Nat) : QPos :=
  minimumOrderGap b (concreteThresholds b degree) 0

/-- The common positive gap is below the actual selected entry's gap,
regardless of which threshold the finite coefficient scan selects. -/
theorem commonDescentGap_le_selected (b : DescentBounds) (degree : Nat)
    (before after : List QPos) (theta : QPos)
    (hsplit : concreteThresholds b degree = before ++ theta :: after) :
    (commonDescentGap b degree).val ≤ (scheduleGap b before.length theta).val := by
  unfold commonDescentGap
  rw [hsplit]
  simpa only [Nat.zero_add] using minimumOrderGap_le_entry b before after theta 0

/-- Aligned coefficient scanning yields both its actual earlier-coefficient
cap and a common positive lower bound on the selected descent gap. -/
theorem scheduled_common_gap (b : DescentBounds) (degree : Nat)
    (xs : List (QComplex × QPos)) (halign : xs.map Prod.snd = concreteThresholds b degree)
    (hpass : ∃ x ∈ xs, x.2.val < QComplex.normBound x.1) :
    ∃ before x after, xs = before ++ x :: after ∧
      x.2.val < QComplex.normBound x.1 ∧
      (∀ a ∈ before.map Prod.fst,
        QComplex.normBound a ≤ (descentCoefficientCap b before.length x.2).val) ∧
      (commonDescentGap b degree).val ≤ (scheduleGap b before.length x.2).val := by
  obtain ⟨before, x, after, hsplit, _, hp, hb⟩ := scheduled_significant_cap b degree xs halign hpass
  have hschedule : concreteThresholds b degree =
      before.map Prod.snd ++ x.2 :: after.map Prod.snd := by
    rw [← halign, hsplit, List.map_append, List.map_cons]
  have hg := commonDescentGap_le_selected b degree (before.map Prod.snd)
    (after.map Prod.snd) x.2 hschedule
  rw [List.length_map] at hg
  exact ⟨before, x, after, hsplit, hp, hb, hg⟩

/-- Uniform progress for an actual monic finite local polynomial. The common
gap depends on shared bounds and coefficient count, not the selected order. -/
theorem exists_monic_common_descent (b : DescentBounds) (c : QComplex) (p : CPoly.Coeffs)
    (hc : QComplex.normBound c ≤ b.value) (hres : b.residual.val ≤ QComplex.normSq c)
    (hp : ∀ a ∈ p ++ [QComplex.one], QComplex.normBound a ≤ b.coefficient)
    (hlen : p.length+1 ≤ b.tailLength) :
    ∃ h : QComplex, QComplex.normBound h ≤ 1 ∧
      QComplex.normSq (CPoly.eval (c :: (p ++ [QComplex.one])) h) ≤
        QComplex.normSq c-(commonDescentGap b (p.length+1)).val := by
  let xs := (p ++ [QComplex.one]).zip (concreteThresholds b (p.length+1))
  obtain ⟨before, x, after, hsplit, _, hsign, hcap⟩ := monic_zip_scan_cap b p
  change xs = before ++ x :: after at hsplit
  have hfst : xs.map Prod.fst = p ++ [QComplex.one] := by
    apply List.map_fst_zip
    simp only [concreteThresholds, backwardThresholds_length, List.length_append,
      List.length_cons, List.length_nil]
    omega
  have hsnd : xs.map Prod.snd = concreteThresholds b (p.length+1) := by
    apply List.map_snd_zip
    simp only [concreteThresholds, backwardThresholds_length, List.length_append,
      List.length_cons, List.length_nil]
    omega
  have hpoly : p ++ [QComplex.one] = before.map Prod.fst ++ x.1 :: after.map Prod.fst := by
    rw [← hfst]
    change xs = before ++ x :: after at hsplit
    rw [hsplit, List.map_append, List.map_cons]
  have hschedule : concreteThresholds b (p.length+1) =
      before.map Prod.snd ++ x.2 :: after.map Prod.snd := by
    rw [← hsnd, hsplit, List.map_append, List.map_cons]
  have hgap := commonDescentGap_le_selected b (p.length+1) (before.map Prod.snd)
    (after.map Prod.snd) x.2 hschedule
  rw [List.length_map] at hgap
  have ha : QComplex.normBound x.1 ≤ b.coefficient := by
    apply hp
    rw [hpoly]
    simp
  have htail : ∀ a ∈ after.map Prod.fst, QComplex.normBound a ≤ b.coefficient := by
    intro a ha
    apply hp
    rw [hpoly]
    simp [ha]
  have htlen : (after.map Prod.fst).length ≤ b.tailLength := by
    have hl := congrArg List.length hpoly
    simp only [List.length_append, List.length_cons, List.length_nil, List.length_map] at hl
    simp only [List.length_map]
    omega
  have hcap' : ∀ a ∈ before.map Prod.fst, QComplex.normBound a ≤
      (descentCoefficientCap b (before.map Prod.fst).length x.2).val := by
    simpa only [List.length_map] using hcap
  have hd := concrete_split_descent b c x.1 (before.map Prod.fst) (after.map Prod.fst)
    x.2 hc hres hsign ha htlen htail hcap'
  let n := before.length
  let delta := scheduleMargin b n x.2
  let t := (scheduleStep b n x.2).val
  let d := selectedPaletteDirection (n+1) (by omega) (QComplex.mul (QComplex.conj c) x.1) delta.val
  refine ⟨QComplex.scaleRat t d, schedule_displacement_bound b n x.2 _ delta.val, ?_⟩
  rw [hpoly]
  simp only [List.length_map] at hd
  change QComplex.normSq (CPoly.eval (c :: (before.map Prod.fst ++ x.1 :: after.map Prod.fst))
    (QComplex.scaleRat t d)) ≤ QComplex.normSq c-t^(n+1)*delta.val/2 at hd
  change (commonDescentGap b (p.length+1)).val ≤ t^(n+1)*delta.val/2 at hgap
  grind only

end ComputableAnalysis.PolynomialDirection
