import ComputableAnalysis.FTA.UniformRationalDescent
import ComputableAnalysis.FTA.MinimumPrecisionSearch

namespace ComputableAnalysis.PolynomialDirection
open QComplex PolynomialCoercivity FiniteApproximateMinimum

def rationalSearchRadius (q : CPoly.Coeffs) : Rat :=
  2*((CPoly.normMajorant (q++[QComplex.one]) 1)^2+coefficientBound q+3)+1

theorem rationalSearchRadius_pos (q : CPoly.Coeffs) : 0 < rationalSearchRadius q := by
  have hc := coefficientBound_nonneg q
  have hm := CPoly.normMajorant_nonneg (q++[QComplex.one]) 1 (by decide +kernel)
  have hs := Rat.pow_nonneg hm (n := 2)
  unfold rationalSearchRadius
  grind

def rationalSearchBox (q : CPoly.Coeffs) : QBox :=
  ⟨⟨-rationalSearchRadius q, -rationalSearchRadius q⟩,
    ⟨rationalSearchRadius q, rationalSearchRadius q⟩⟩

theorem rationalSearchBox_ordered (q : CPoly.Coeffs) : (rationalSearchBox q).Ordered := by
  have hp := rationalSearchRadius_pos q
  constructor <;> change -rationalSearchRadius q ≤ rationalSearchRadius q <;> grind

/-- Coercivity proves the mesh minimizer's interior margin; it is not
assumed of the finite selection algorithm. -/
theorem rational_mesh_interior (q : CPoly.Coeffs) (hq : 0 < q.length) (depth : Nat)
    (hbudget : budget (q++[QComplex.one]) (rationalSearchBox q) depth ≤ 1) :
    normBound (polynomialMinimum (q++[QComplex.one]) (rationalSearchBox q) depth) ≤
      rationalSearchRadius q-1 := by
  let p := q++[QComplex.one]
  let box := rationalSearchBox q
  let x := polynomialMinimum p box depth
  let C := CPoly.normMajorant p 1
  have hC : 0 ≤ C := CPoly.normMajorant_nonneg p 1 (by decide +kernel)
  have hR := rationalSearchRadius_pos q
  have hl : box.lo ≤ QComplex.zero := by constructor <;> change -rationalSearchRadius q ≤ 0 <;> grind
  have hh : QComplex.zero ≤ box.hi := by constructor <;> change 0 ≤ rationalSearchRadius q <;> grind
  have hmin := polynomialMinimum_le p box depth (rationalSearchBox_ordered q) QComplex.zero hl hh
  change normSq (CPoly.eval p x) ≤ normSq (CPoly.eval p QComplex.zero)+budget p box depth at hmin
  have hz := CPoly.eval_normMajorant p 1 QComplex.zero (by decide +kernel)
  have hzero := normSq_le_normBound_square (CPoly.eval p QComplex.zero)
  have hn := normBound_nonneg (CPoly.eval p QComplex.zero)
  have h1 := Rat.mul_le_mul_of_nonneg_left hz hn
  have h2 := Rat.mul_le_mul_of_nonneg_right hz hC
  have hnorm := normBound_le_normSq_add_one (CPoly.eval p x)
  have heval : normBound (CPoly.eval p x) ≤ C^2+2 := by
    simp only [Rat.pow_succ, Rat.pow_zero, Rat.one_mul] at *
    grind
  have hM : 0 ≤ C^2+2 := by have h := Rat.pow_nonneg hC (n := 2); grind
  have hb := monic_sublevel_bound q hq x (C^2+2) hM heval
  change normBound x ≤ rationalSearchRadius q-1
  unfold rationalSearchRadius
  change normBound x ≤ 2*(C^2+coefficientBound q+3)+1-1
  grind

/-- A sufficiently fine actual mesh minimum has arbitrarily small residual. -/
theorem rational_mesh_residual (q : CPoly.Coeffs) (hq : 0 < q.length) (rho : QPos) (depth : Nat)
    (hbudget : budget (q++[QComplex.one]) (rationalSearchBox q) depth ≤ 1)
    (hgap : budget (q++[QComplex.one]) (rationalSearchBox q) depth <
      (rationalDescentGap (q++[QComplex.one]) (rationalSearchRadius q)
        (Rat.le_of_lt (rationalSearchRadius_pos q)) rho).val) :
    normSq (CPoly.eval (q++[QComplex.one])
      (polynomialMinimum (q++[QComplex.one]) (rationalSearchBox q) depth)) < rho.val := by
  let x := polynomialMinimum (q++[QComplex.one]) (rationalSearchBox q) depth
  have hb := rational_mesh_interior q hq depth hbudget
  have hre := neg_qabs_le_self x.re
  have hrei := self_le_qabs x.re
  have him := neg_qabs_le_self x.im
  have himi := self_le_qabs x.im
  have hr0 := qabs_nonneg x.re
  have hi0 := qabs_nonneg x.im
  change qabs x.re+qabs x.im ≤ rationalSearchRadius q-1 at hb
  apply rational_approximate_minimum_residual (q++[QComplex.one]) ⟨q, rfl⟩
    (by simp only [List.length_append, List.length_cons, List.length_nil]; omega)
    (rationalSearchRadius q) (Rat.le_of_lt (rationalSearchRadius_pos q)) rho
    (rationalSearchBox q) x (budget (q++[QComplex.one]) (rationalSearchBox q) depth)
  · change qabs x.re+qabs x.im ≤ rationalSearchRadius q; grind
  · change -rationalSearchRadius q+1 ≤ x.re; grind
  · change x.re+1 ≤ rationalSearchRadius q; grind
  · change -rationalSearchRadius q+1 ≤ x.im; grind
  · change x.im+1 ≤ rationalSearchRadius q; grind
  · intro z hl hh
    exact polynomialMinimum_le _ _ _ (rationalSearchBox_ordered q) z hl hh
  · exact hgap

def rationalResidualBudget (q : CPoly.Coeffs) (rho : QPos) : QPos :=
  let g := rationalDescentGap (q++[QComplex.one]) (rationalSearchRadius q)
    (Rat.le_of_lt (rationalSearchRadius_pos q)) rho
  QPos.minimum ⟨1, by decide +kernel⟩
    ⟨g.val/2, by rw [Rat.div_def]; exact Rat.mul_pos g.property (by decide +kernel)⟩

/-- Executable rational approximate root from finite minimization, with an
explicit precision search and no root-existence theorem in termination. -/
def rationalResidualCandidate (q : CPoly.Coeffs) (rho : QPos) (start : Nat) : QComplex :=
  polynomialMinimum (q++[QComplex.one]) (rationalSearchBox q)
    (meshPrecision (q++[QComplex.one]) (rationalSearchBox q) (rationalSearchBox_ordered q)
      (rationalResidualBudget q rho) start)

theorem rationalResidualCandidate_spec (q : CPoly.Coeffs) (hq : 0 < q.length)
    (rho : QPos) (start : Nat) :
    normSq (CPoly.eval (q++[QComplex.one]) (rationalResidualCandidate q rho start)) < rho.val := by
  have hs := (meshPrecision_spec (q++[QComplex.one]) (rationalSearchBox q)
    (rationalSearchBox_ordered q) (rationalResidualBudget q rho) start).2
  apply rational_mesh_residual q hq rho
  · exact Rat.le_trans hs (QPos.minimum_le_left _ _)
  · let g := rationalDescentGap (q++[QComplex.one]) (rationalSearchRadius q)
      (Rat.le_of_lt (rationalSearchRadius_pos q)) rho
    let half : QPos := ⟨g.val/2, by
      rw [Rat.div_def]
      exact Rat.mul_pos g.property (by decide +kernel)⟩
    have hb := QPos.minimum_le_right (⟨1, by decide +kernel⟩ : QPos) half
    have hpos := (rationalDescentGap (q++[QComplex.one]) (rationalSearchRadius q)
      (Rat.le_of_lt (rationalSearchRadius_pos q)) rho).property
    change (rationalResidualBudget q rho).val ≤
      (rationalDescentGap (q++[QComplex.one]) (rationalSearchRadius q)
        (Rat.le_of_lt (rationalSearchRadius_pos q)) rho).val/2 at hb
    have hbound := Rat.le_trans hs hb
    simp only [Rat.div_def] at hbound
    have hhalf : (2 : Rat)⁻¹ = 1/2 := by decide +kernel
    rw [hhalf] at hbound
    grind

end ComputableAnalysis.PolynomialDirection
