import ComputableAnalysis.FTA.SampledResidualCandidateBound

namespace ComputableAnalysis.RepresentedPolynomial
open PolynomialDirection

private theorem monic_samples (q : Coefficients) (k : Nat) :
    coefficientSamples (q++[one]) k = coefficientSamples q k ++ [QComplex.one] := by
  simp [coefficientSamples, one, ofQComplex, ComplexRaw.ofQComplex]

/-- The actual sampled candidate retains a quantified residual bound at every
later coefficient stage, even though its location depends on the sample. -/
theorem sampled_candidate_later_residual (q : Coefficients) (hq : 0 < q.length)
    (n k m : Nat) (hk : n ≤ k) (hm : n ≤ m) (rho : QPos) (start : Nat) :
    let R := interiorSearchRadius q
    let x := rationalResidualCandidate (coefficientSamples q k) rho start
    QComplex.normSq (CPoly.eval (coefficientSamples (q++[one]) m) x) <
      rho.val + 2*sampleNormMajorant (q++[one]) n R * sampleDifferenceMajorant (q++[one]) n R := by
  let R := interiorSearchRadius q
  let x := rationalResidualCandidate (coefficientSamples q k) rho start
  have hR : 0 ≤ R := Rat.le_of_lt (interiorSearchRadius_pos q)
  have hb := sampledResidualCandidate_bound q hq k rho start
  have hx : QComplex.normBound x ≤ R := by change QComplex.normBound x ≤ R-1 at hb; grind
  have hdiff := sample_score_difference_le (q++[one]) n m k hm hk R hR x hx
  have hs := rationalResidualCandidate_spec (coefficientSamples q k)
    (by simpa [coefficientSamples] using hq) rho start
  rw [← monic_samples q k] at hs
  have hu := self_le_qabs (QComplex.normSq (CPoly.eval (coefficientSamples (q++[one]) m) x) -
    QComplex.normSq (CPoly.eval (coefficientSamples (q++[one]) k) x))
  change QComplex.normSq (CPoly.eval (coefficientSamples (q++[one]) k) x) < rho.val at hs
  change QComplex.normSq (CPoly.eval (coefficientSamples (q++[one]) m) x) < _
  grind

end ComputableAnalysis.RepresentedPolynomial
