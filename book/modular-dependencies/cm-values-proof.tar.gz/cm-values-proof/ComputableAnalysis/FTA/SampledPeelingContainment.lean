import ComputableAnalysis.FTA.ResidualNormBound

namespace ComputableAnalysis.RepresentedPolynomial

/-- Rational reconstruction using actual remainder samples is contained in
its represented reconstruction box at the same stage. -/
theorem sampledPeeling_contains (items : List (QComplex × ComplexCert))
    (n : Nat) (z : QComplex) :
    ((peelingValue items (ofQComplex z)).raw.compute n).lo ≤
      PolynomialDirection.finitePeelingValue (sampledPeeling items n) z ∧
    PolynomialDirection.finitePeelingValue (sampledPeeling items n) z ≤
      ((peelingValue items (ofQComplex z)).raw.compute n).hi := by
  induction items with
  | nil => exact ⟨QComplex.le_refl _, QComplex.le_refl _⟩
  | cons item items ih =>
    rcases item with ⟨r, e⟩
    have hf : (sub (ofQComplex z) (ofQComplex r)).raw.compute n =
        QBox.point (QComplex.sub z r) := rfl
    have hm := QBox.mul_contains
      (A := (sub (ofQComplex z) (ofQComplex r)).raw.compute n)
      (B := (peelingValue items (ofQComplex z)).raw.compute n)
      (z := QComplex.sub z r)
      (w := PolynomialDirection.finitePeelingValue (sampledPeeling items n) z)
      (by rw [hf]; exact QComplex.le_refl _)
      (by rw [hf]; exact QComplex.le_refl _) ih.1 ih.2
    exact QBox.add_contains (A := e.raw.compute n)
      (C := QBox.mul ((sub (ofQComplex z) (ofQComplex r)).raw.compute n)
        ((peelingValue items (ofQComplex z)).raw.compute n))
      (QComplex.le_refl _) (ComplexRaw.valid_ordered e.valid n) hm.1 hm.2

end ComputableAnalysis.RepresentedPolynomial
