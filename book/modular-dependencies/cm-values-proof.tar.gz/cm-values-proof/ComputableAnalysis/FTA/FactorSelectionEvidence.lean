import ComputableAnalysis.FTA.ActualFactorProximity

namespace ComputableAnalysis.PolynomialDirection
open RepresentedPolynomial

/-- Successful finite search returns a member of the supplied list. -/
theorem firstPassing_mem (test : QComplex → Bool) (xs : List QComplex)
    (h : xs.any test = true) : firstPassing test xs ∈ xs := by
  induction xs with
  | nil => simp at h
  | cons x xs ih =>
    rw [firstPassing]
    by_cases hx : test x = true
    · simp [hx]
    · have ht : xs.any test = true := by simpa [List.any_cons, hx] using h
      simp [hx, ih ht]

/-- The nearby-factor algorithm returns an actual factor, not merely a point
satisfying the proximity inequality. -/
theorem nearbyFactor_mem (xs : List (QComplex × QComplex)) (z : QComplex)
    (rho : Rat) (hrho : 0 ≤ rho)
    (hsmall : QComplex.normSq (finiteFactorProduct xs z) < rho^xs.length) :
    nearbyFactor xs z rho ∈ xs.map Prod.fst := by
  obtain ⟨x, hx, hn⟩ := finiteFactorProduct_near xs z rho hrho hsmall
  apply firstPassing_mem
  apply List.any_eq_true.mpr
  exact ⟨x.1, List.mem_map.mpr ⟨x, hx, rfl⟩, by simpa using hn⟩

/-- A squared-distance budget gives a rational norm-distance bound, without
constructing a square root. -/
theorem normBound_lt_of_normSq_lt (w : QComplex) (eps : QPos)
    (h : QComplex.normSq w < (eps.val/2)^2) : QComplex.normBound w < eps.val := by
  have hs := PolynomialCoercivity.normBound_square_le w
  have hd := eps.property
  have hn := QComplex.normBound_nonneg w
  by_cases hb : QComplex.normBound w < eps.val
  · exact hb
  · have he : eps.val ≤ QComplex.normBound w := by grind
    have h1 := Rat.mul_le_mul_of_nonneg_left he (Rat.le_of_lt hd)
    have h2 := Rat.mul_le_mul_of_nonneg_right he hn
    simp only [Rat.pow_succ, Rat.pow_zero, Rat.one_mul] at h
    have hid : (eps.val/2)*(eps.val/2) = (eps.val*eps.val)/4 := by
      simp only [Rat.div_def]
      grind
    rw [hid] at h
    have hh := Rat.mul_lt_mul_of_pos_left h (show (0 : Rat) < 2 by decide +kernel)
    simp only [Rat.div_def] at hh
    have hp := Rat.mul_pos hd hd
    grind

/-- Finite selection provides both membership and the step estimate needed
for a coherent sequence of factor centers. -/
theorem nearbyFactor_step (xs : List (QComplex × QComplex)) (z : QComplex)
    (eps : QPos)
    (hsmall : QComplex.normSq (finiteFactorProduct xs z) < ((eps.val/2)^2)^xs.length) :
    nearbyFactor xs z ((eps.val/2)^2) ∈ xs.map Prod.fst ∧
    QComplex.normBound (QComplex.sub z (nearbyFactor xs z ((eps.val/2)^2))) < eps.val := by
  have hr : 0 ≤ (eps.val/2)^2 := by
    rw [Rat.pow_succ, Rat.pow_succ, Rat.pow_zero, Rat.one_mul]
    exact rat_square_nonneg_basic _
  exact ⟨nearbyFactor_mem xs z _ hr hsmall,
    normBound_lt_of_normSq_lt _ eps (nearbyFactor_spec xs z _ hr hsmall)⟩

end ComputableAnalysis.PolynomialDirection
