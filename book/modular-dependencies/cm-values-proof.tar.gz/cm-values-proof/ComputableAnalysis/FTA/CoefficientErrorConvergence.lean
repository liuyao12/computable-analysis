import ComputableAnalysis.FTA.SampledScoreComparison

/-! Convergence of the actual coefficient-box Horner error, without assuming
a rate for arbitrary represented coefficients. An executable precision search
still requires the separately proved termination bridge. -/
namespace ComputableAnalysis.RepresentedPolynomial

theorem sampleDifferenceMajorant_nonneg (p : Coefficients) (n : Nat) (R : Rat)
    (hR : 0 ≤ R) : 0 ≤ sampleDifferenceMajorant p n R := by
  induction p with
  | nil => exact Rat.le_refl
  | cons a p ih =>
    have hw := a.valid.1 n
    exact Rat.add_nonneg (Rat.add_nonneg hw.1 hw.2) (Rat.mul_nonneg hR ih)

/-- Arbitrary valid coefficient enclosures suffice to make the computed
Horner difference majorant small; no fixed rate is imposed on input names. -/
theorem sampleDifferenceMajorant_shrinks (p : Coefficients) (R : Rat) (hR : 0 ≤ R) :
    ShrinksToZero (fun n => sampleDifferenceMajorant p n R) := by
  induction p with
  | nil =>
    intro eps
    exact ⟨0, fun _ _ => Rat.le_of_lt eps.property⟩
  | cons a p ih =>
    intro eps
    have hquarter : 0 < eps.val / 4 := by
      rw [Rat.div_def]
      exact Rat.mul_pos eps.property (by decide +kernel)
    have hden : 0 < 4 * (R+1) := by grind
    have htailpos : 0 < eps.val / (4*(R+1)) := by
      rw [Rat.div_def]
      exact Rat.mul_pos eps.property (Rat.inv_pos.mpr hden)
    obtain ⟨N, hN⟩ := a.valid.2.2 ⟨eps.val/4, hquarter⟩
    obtain ⟨M, hM⟩ := ih ⟨eps.val/(4*(R+1)), htailpos⟩
    refine ⟨max N M, ?_⟩
    intro n hn
    have hw := hN n (by omega)
    have ht := hM n (by omega)
    have hm := Rat.mul_le_mul_of_nonneg_left ht hR
    have hi := Rat.mul_inv_cancel (4*(R+1)) (Rat.ne_of_gt hden)
    have hscaled : R * (eps.val/(4*(R+1))) ≤ eps.val/4 := by
      have hm' := Rat.mul_le_mul_of_nonneg_right
        (show R ≤ R+1 by grind) (Rat.le_of_lt htailpos)
      have hid : (R+1) * (eps.val/(4*(R+1))) = eps.val/4 := by
        rw [Rat.div_def, Rat.div_def]
        have hfour : (4 : Rat) * (4 : Rat)⁻¹ = 1 := by decide +kernel
        grind
      rw [hid] at hm'
      exact hm' 
    change (a.raw.compute n).width + (a.raw.compute n).height +
      R * sampleDifferenceMajorant p n R ≤ eps.val
    simp only [Rat.div_def] at *
    grind

end ComputableAnalysis.RepresentedPolynomial
