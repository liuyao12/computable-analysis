import ComputableAnalysis.FTA.NormalizedMinimumSearch
import ComputableAnalysis.FTA.Minimizer

/-! Exact represented-score comparison for the executable approximate
minimum. The proof uses finite enclosures, not the minimizer existence or
cluster-point theorems imported with the existing norm enclosure lemma. -/
namespace ComputableAnalysis.RepresentedPolynomial

/-- Exact closed-box membership expressed by every valid name enclosure
meeting the rational box. Names need not have boxes contained in the domain. -/
def InMinimumBox (box : QBox) (z : ComplexCert) : Prop :=
  ∀ n, box.lo ≤ (z.raw.compute n).hi ∧ (z.raw.compute n).lo ≤ box.hi

def comparisonCorner (box : QBox) (z : ComplexCert) (n : Nat) : QComplex :=
  { re := if (z.raw.compute n).lo.re < box.lo.re then box.lo.re else (z.raw.compute n).lo.re
    im := if (z.raw.compute n).lo.im < box.lo.im then box.lo.im else (z.raw.compute n).lo.im }

theorem comparisonCorner_mem (box : QBox) (ho : box.Ordered)
    (z : ComplexCert) (hz : InMinimumBox box z) (n : Nat) :
    box.lo ≤ comparisonCorner box z n ∧ comparisonCorner box z n ≤ box.hi ∧
      (z.raw.compute n).lo ≤ comparisonCorner box z n ∧
      comparisonCorner box z n ≤ (z.raw.compute n).hi := by
  have hd := hz n
  have hv := ComplexRaw.valid_ordered z.valid n
  simp only [QBox.Ordered] at ho hv
  simp only [QComplex.le_def] at *
  dsimp [comparisonCorner]
  split <;> split <;> constructor <;> (try constructor) <;> (try constructor) <;> grind

/-- Every represented argument in the full closed rational box satisfies the
exact approximate-minimum law. Equality and order concern valid raw values;
sample stages and mesh depth are internal to the executable constructor. -/
theorem approximateMinimum_exact_le (p : Coefficients) (box : QBox) (ho : box.Ordered)
    (eps : QPos) (start : Nat) (z : ComplexCert) (hz : InMinimumBox box z) :
    (normValue (eval p (ofQComplex (approximateMinimum p box ho eps start)))).real.preferred.Le
      (RealRaw.add (normValue (eval p z)).real.preferred (RealRaw.ofRat eps.val)) := by
  intro i j
  let stage := scheduledCoefficientStage p box (minimumCoefficientBudget p box eps) start
  let k := max stage (max i j)
  let x := approximateMinimum p box ho eps start
  let y := comparisonCorner box z j
  have hy := comparisonCorner_mem box ho z hz j
  have hxsample := sample_eval_contains p (show i ≤ k by dsimp [k]; omega)
    (B := QBox.point x) (QComplex.le_refl x) (QComplex.le_refl x)
  have hx : ((eval p (ofQComplex x)).raw.compute i).lo ≤ CPoly.eval (coefficientSamples p k) x ∧
      CPoly.eval (coefficientSamples p k) x ≤ ((eval p (ofQComplex x)).raw.compute i).hi := by
    rw [eval_compute]
    exact hxsample
  have hysample := sample_eval_contains p (show j ≤ k by dsimp [k]; omega) hy.2.2.1 hy.2.2.2
  have hyy : ((eval p z).raw.compute j).lo ≤ CPoly.eval (coefficientSamples p k) y ∧
      CPoly.eval (coefficientSamples p k) y ≤ ((eval p z).raw.compute j).hi := by
    rw [eval_compute]
    exact hysample
  have hn1 := (normValue_contains (eval p (ofQComplex x)) i _ hx.1 hx.2).1
  have hn2 := (normValue_contains (eval p z) j _ hyy.1 hyy.2).2
  have hmin := approximateMinimum_le p box ho eps start k
    (show stage ≤ k by dsimp [k]; omega) y hy.1 hy.2.1
  change ((normValue (eval p (ofQComplex x))).real.compute i).lo ≤
    ((normValue (eval p z)).real.compute j).hi + eps.val
  grind

end ComputableAnalysis.RepresentedPolynomial
