import ComputableAnalysis.FTA.CoefficientScoreError
import ComputableAnalysis.FTA.Approximation

namespace ComputableAnalysis.RepresentedPolynomial

def sampleNormMajorant : Coefficients → Nat → Rat → Rat
  | [], _, _ => 0
  | a :: p, n, R => (a.raw.compute n).normMajorant + R * sampleNormMajorant p n R

def sampleDifferenceMajorant : Coefficients → Nat → Rat → Rat
  | [], _, _ => 0
  | a :: p, n, R => (a.raw.compute n).width + (a.raw.compute n).height +
      R * sampleDifferenceMajorant p n R

theorem sample_normMajorant_le (p : Coefficients) (n k : Nat) (hk : n ≤ k)
    (R : Rat) (hR : 0 ≤ R) :
    CPoly.normMajorant (coefficientSamples p k) R ≤ sampleNormMajorant p n R := by
  induction p with
  | nil => exact Rat.le_refl
  | cons a p ih =>
    have hn := ComplexRaw.valid_nestedIn a.valid hk
    have ho := ComplexRaw.valid_ordered a.valid k
    have hb := QBox.normBound_le_of_mem (a.raw.compute n) (a.raw.compute k).lo
      hn.1 (QComplex.le_trans ho hn.2)
    have hm := Rat.mul_le_mul_of_nonneg_left ih hR
    change QComplex.normBound (a.raw.compute k).lo +
      R * CPoly.normMajorant (coefficientSamples p k) R ≤
      (a.raw.compute n).normMajorant + R * sampleNormMajorant p n R
    grind

theorem sample_differenceMajorant_le (p : Coefficients) (n k m : Nat)
    (hk : n ≤ k) (hm : n ≤ m) (R : Rat) (hR : 0 ≤ R) :
    CPoly.differenceMajorant (coefficientSamples p k) (coefficientSamples p m) R ≤
      sampleDifferenceMajorant p n R := by
  induction p with
  | nil => exact Rat.le_refl
  | cons a p ih =>
    have hn1 := ComplexRaw.valid_nestedIn a.valid hk
    have hn2 := ComplexRaw.valid_nestedIn a.valid hm
    have ho1 := ComplexRaw.valid_ordered a.valid k
    have ho2 := ComplexRaw.valid_ordered a.valid m
    have hhi1 := QComplex.le_trans ho1 hn1.2
    have hhi2 := QComplex.le_trans ho2 hn2.2
    have hr := qabs_sub_le_of_common_bounds hn1.1.1 hhi1.1 hn2.1.1 hhi2.1
    have hi := qabs_sub_le_of_common_bounds hn1.1.2 hhi1.2 hn2.1.2 hhi2.2
    have htail := Rat.mul_le_mul_of_nonneg_left ih hR
    change QComplex.normBound (QComplex.sub (a.raw.compute k).lo (a.raw.compute m).lo) +
      R * CPoly.differenceMajorant (coefficientSamples p k) (coefficientSamples p m) R ≤
      (a.raw.compute n).width + (a.raw.compute n).height + R * sampleDifferenceMajorant p n R
    simp only [QComplex.normBound, QComplex.sub, QComplex.add, QComplex.neg,
      QBox.width, QBox.height, Rat.sub_eq_add_neg] at *
    grind

/-- Any two sufficiently late coefficient samples have uniformly controlled
score differences on the entire rational norm ball. The error is computed
from actual coefficient enclosures at one earlier stage. -/
theorem sample_score_difference_le (p : Coefficients) (n k m : Nat)
    (hk : n ≤ k) (hm : n ≤ m) (R : Rat) (hR : 0 ≤ R)
    (z : QComplex) (hz : QComplex.normBound z ≤ R) :
    qabs (QComplex.normSq (CPoly.eval (coefficientSamples p k) z) -
      QComplex.normSq (CPoly.eval (coefficientSamples p m) z)) ≤
      2 * sampleNormMajorant p n R * sampleDifferenceMajorant p n R := by
  have hlen : (coefficientSamples p k).length = (coefficientSamples p m).length := by
    simp [coefficientSamples]
  have h := CPoly.score_coefficient_difference _ _ hlen R hR z hz
  have h1 := sample_normMajorant_le p n k hk R hR
  have h2 := sample_normMajorant_le p n m hm R hR
  have hd := sample_differenceMajorant_le p n k m hk hm R hR
  have hs : CPoly.normMajorant (coefficientSamples p k) R +
      CPoly.normMajorant (coefficientSamples p m) R ≤ 2 * sampleNormMajorant p n R := by grind
  have hnon := Rat.add_nonneg (CPoly.normMajorant_nonneg (coefficientSamples p k) R hR)
    (CPoly.normMajorant_nonneg (coefficientSamples p m) R hR)
  have hmajor : 0 ≤ 2 * sampleNormMajorant p n R := Rat.le_trans hnon hs
  have hleft := Rat.mul_le_mul_of_nonneg_right hs
    (CPoly.differenceMajorant_nonneg (coefficientSamples p k) (coefficientSamples p m) R hR)
  have hright := Rat.mul_le_mul_of_nonneg_left hd hmajor
  unfold CPoly.coefficientScoreError at h
  grind

/-- The literal mesh minimizer at sample stage `k` is approximately minimal
for every later sample stage `m`. The coefficient error is computed solely
from stage `n` enclosures, uniformly in both sample stages. -/
theorem sampled_minimum_le (p : Coefficients) (n k m depth : Nat)
    (hk : n ≤ k) (hm : n ≤ m) (box : QBox) (ho : box.Ordered)
    (z : QComplex) (hl : box.lo ≤ z) (hh : z ≤ box.hi) :
    QComplex.normSq (CPoly.eval (coefficientSamples p m)
      (FiniteApproximateMinimum.polynomialMinimum (coefficientSamples p k) box depth)) ≤
      QComplex.normSq (CPoly.eval (coefficientSamples p m) z) +
        FiniteApproximateMinimum.budget (coefficientSamples p k) box depth +
        4 * sampleNormMajorant p n box.normMajorant * sampleDifferenceMajorant p n box.normMajorant := by
  let x := FiniteApproximateMinimum.polynomialMinimum (coefficientSamples p k) box depth
  have hbox := FiniteApproximateMinimum.polynomialMinimum_in_box (coefficientSamples p k) box depth ho
  have hmin := FiniteApproximateMinimum.polynomialMinimum_le (coefficientSamples p k) box depth ho z hl hh
  have hx := sample_score_difference_le p n k m hk hm box.normMajorant box.normMajorant_nonneg
    x (QBox.normBound_le_of_mem box x hbox.1 hbox.2)
  have hz := sample_score_difference_le p n k m hk hm box.normMajorant box.normMajorant_nonneg
    z (QBox.normBound_le_of_mem box z hl hh)
  have hs := neg_qabs_le_self (QComplex.normSq (CPoly.eval (coefficientSamples p k) x) -
    QComplex.normSq (CPoly.eval (coefficientSamples p m) x))
  have ht := self_le_qabs (QComplex.normSq (CPoly.eval (coefficientSamples p k) z) -
    QComplex.normSq (CPoly.eval (coefficientSamples p m) z))
  change QComplex.normSq (CPoly.eval (coefficientSamples p k) x) ≤
    QComplex.normSq (CPoly.eval (coefficientSamples p k) z) +
      FiniteApproximateMinimum.budget (coefficientSamples p k) box depth at hmin
  change QComplex.normSq (CPoly.eval (coefficientSamples p m) x) ≤ _
  grind

end ComputableAnalysis.RepresentedPolynomial
