import ComputableAnalysis.FTA.PolynomialScoreVariation
import ComputableAnalysis.FiniteFTASubdivision

namespace ComputableAnalysis.FiniteApproximateMinimum
open FiniteFTASubdivision

def mesh (box : QBox) (depth : Nat) : List QComplex :=
  (dyadicSubdivide depth box).map QBox.lo

theorem subdivision_cover (box : QBox) (depth : Nat) (ho : box.Ordered)
    (z : QComplex) (hl : box.lo ≤ z) (hh : z ≤ box.hi) :
    ∃ child ∈ dyadicSubdivide depth box, child.lo ≤ z ∧ z ≤ child.hi := by
  induction depth generalizing box with
  | zero => exact ⟨box, by simp [dyadicSubdivide], hl, hh⟩
  | succ n ih =>
    obtain ⟨child, hc, hcl, hch⟩ := dyadicChildren_cover ho z hl hh
    obtain ⟨leaf, hf, hfl, hfh⟩ := ih child (dyadicChildren_ordered ho child hc) hcl hch
    refine ⟨leaf, ?_, hfl, hfh⟩
    exact List.mem_flatMap.mpr ⟨child, hc, hf⟩

/-- An executable finite mesh covers the box with explicit dyadic error.
The mesh points stay in the original box, including degenerate boxes. -/
theorem mesh_cover (box : QBox) (depth : Nat) (ho : box.Ordered)
    (z : QComplex) (hl : box.lo ≤ z) (hh : z ≤ box.hi) :
    ∃ x ∈ mesh box depth, box.lo ≤ x ∧ x ≤ box.hi ∧
      QComplex.normBound (QComplex.sub x z) ≤
        box.width / ((2^depth : Nat) : Rat) + box.height / ((2^depth : Nat) : Rat) := by
  obtain ⟨child, hc, hcl, hch⟩ := subdivision_cover box depth ho z hl hh
  have hn := dyadicSubdivide_nestedIn_parent ho child hc
  have hco := dyadicSubdivide_ordered ho child hc
  have he := dyadicSubdivide_width_height_exact ho hc
  have hr := qabs_sub_le_of_common_bounds (Rat.le_refl (a := child.lo.re)) hco.1 hcl.1 hch.1
  have hi := qabs_sub_le_of_common_bounds (Rat.le_refl (a := child.lo.im)) hco.2 hcl.2 hch.2
  refine ⟨child.lo, List.mem_map.mpr ⟨child, hc, rfl⟩, hn.1,
    QComplex.le_trans hco hn.2, ?_⟩
  have hdist : QComplex.normBound (QComplex.sub child.lo z) ≤ child.width + child.height := by
    simp only [QComplex.normBound, QComplex.sub, QComplex.add, QComplex.neg,
      Rat.sub_eq_add_neg, QBox.width, QBox.height] at *
    grind
  rwa [he.1, he.2] at hdist

def polynomialMinimum (p : CPoly.Coeffs) (box : QBox) (depth : Nat) : QComplex :=
  select (fun z => QComplex.normSq (CPoly.eval p z)) box.lo (mesh box depth)

def budget (p : CPoly.Coeffs) (box : QBox) (depth : Nat) : Rat :=
  CPoly.scoreMajorant p box.normMajorant *
    (box.width / ((2^depth : Nat) : Rat) + box.height / ((2^depth : Nat) : Rat))

theorem budget_shrinks (p : CPoly.Coeffs) (box : QBox) (ho : box.Ordered) :
    ShrinksToZero (budget p box) := by
  let A := CPoly.scoreMajorant p box.normMajorant * (box.width + box.height)
  have hsize := (QBox.ordered_iff_width_height_nonneg box).1 ho
  have hA : 0 ≤ A := Rat.mul_nonneg
    (CPoly.scoreMajorant_nonneg p box.normMajorant box.normMajorant_nonneg)
    (Rat.add_nonneg hsize.1 hsize.2)
  let N := A.num.natAbs + 1
  have hAN : A ≤ (N : Rat) := by
    have hden : (0 : Rat) < (A.den : Rat) :=
      Rat.natCast_pos.mpr (Nat.pos_of_ne_zero A.den_nz)
    apply Rat.le_of_mul_le_mul_right (c := (A.den : Rat))
    · rw [Rat.mul_comm A _, rat_den_mul_self]
      have hnum : (A.num : Rat) ≤ ((A.num.natAbs : Nat) : Rat) := by
        exact_mod_cast (show A.num ≤ (A.num.natAbs : Int) from Int.le_natAbs)
      have hnat : A.num.natAbs ≤ N * A.den := by
        have hm := Nat.le_mul_of_pos_right N (Nat.pos_of_ne_zero A.den_nz)
        dsimp [N] at *
        omega
      exact Rat.le_trans hnum (by exact_mod_cast hnat)
    · exact hden
  apply shrinksToZero_of_natOverSuccBound (C := N)
  intro n
  have hp : (0 : Rat) < ((n+1 : Nat) : Rat) := Rat.natCast_pos.mpr (by omega)
  have hpow : ((n+1 : Nat) : Rat) ≤ ((2^n : Nat) : Rat) := by
    exact_mod_cast (Nat.lt_two_pow_self (n := n))
  have hi := QInterval.one_div_le_one_div_of_pos hp hpow
  have hm := Rat.mul_le_mul_of_nonneg_left hi hA
  have hN := Rat.mul_le_mul_of_nonneg_right hAN
    (Rat.le_of_lt (Rat.inv_pos.mpr hp))
  simp only [Rat.div_def, Rat.one_mul] at hm
  unfold budget
  dsimp [A] at hm
  simp only [Rat.div_def]
  grind

/-- The actual selected polynomial score is within an explicit shrinking
dyadic budget of every rational argument in the original box. -/
theorem polynomialMinimum_le (p : CPoly.Coeffs) (box : QBox) (depth : Nat)
    (ho : box.Ordered) (z : QComplex) (hl : box.lo ≤ z) (hh : z ≤ box.hi) :
    QComplex.normSq (CPoly.eval p (polynomialMinimum p box depth)) ≤
      QComplex.normSq (CPoly.eval p z) + CPoly.scoreMajorant p box.normMajorant *
        (box.width / ((2^depth : Nat) : Rat) + box.height / ((2^depth : Nat) : Rat)) := by
  apply CPoly.finite_score_minimum p box.normMajorant _ box.normMajorant_nonneg
    box.lo z (mesh box depth) (QBox.normBound_le_of_mem box z hl hh)
  obtain ⟨x, hx, hxl, hxh, hd⟩ := mesh_cover box depth ho z hl hh
  exact ⟨x, hx, QBox.normBound_le_of_mem box x hxl hxh, hd⟩

end ComputableAnalysis.FiniteApproximateMinimum
