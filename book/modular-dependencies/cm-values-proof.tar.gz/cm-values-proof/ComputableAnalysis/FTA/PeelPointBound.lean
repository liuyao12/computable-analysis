import ComputableAnalysis.FTA.CoherentCenters

namespace ComputableAnalysis.RepresentedPolynomial

/-- The actual first peeling center is uniformly bounded over every residual
tolerance and every search starting stage. -/
theorem approximatePeelPoint_bound (p : Coefficients) (hdegree : 2 ≤ p.length)
    (eps : QPos) (start : Nat) :
    QComplex.normBound (approximatePeelPoint p eps start) ≤ interiorSearchRadius p.dropLast-1 := by
  have hq : 0 < p.dropLast.length := by rw [List.length_dropLast]; omega
  exact sampledResidualCandidate_bound p.dropLast hq
    (residualCoefficientStage p.dropLast eps start) (minimumHalfBudget eps) start

/-- A supplied coefficient envelope gives a polynomial-independent radius
formula. This permits propagation of bounds through later synthetic quotients. -/
theorem approximatePeelPoint_bound_of_coefficientRadius (p : Coefficients)
    (hdegree : 2 ≤ p.length) (C : Rat) (hC : coefficientRadius p.dropLast ≤ C)
    (eps : QPos) (start : Nat) :
    QComplex.normBound (approximatePeelPoint p eps start) ≤
      2*((C+1)^2+C+3) := by
  have hb := approximatePeelPoint_bound p hdegree eps start
  have hn := coefficientRadius_nonneg p.dropLast
  have hc : 0 ≤ C := Rat.le_trans hn hC
  have h1 := Rat.mul_le_mul_of_nonneg_left
    (show coefficientRadius p.dropLast+1 ≤ C+1 by grind)
    (show 0 ≤ coefficientRadius p.dropLast+1 by grind)
  have h2 := Rat.mul_le_mul_of_nonneg_right
    (show coefficientRadius p.dropLast+1 ≤ C+1 by grind)
    (show 0 ≤ C+1 by grind)
  unfold interiorSearchRadius at hb
  simp only [Rat.pow_succ, Rat.pow_zero, Rat.one_mul] at *
  grind

end ComputableAnalysis.RepresentedPolynomial
