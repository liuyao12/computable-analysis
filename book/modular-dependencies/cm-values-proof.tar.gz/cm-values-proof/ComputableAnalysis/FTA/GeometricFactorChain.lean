import ComputableAnalysis.FTA.ComputedFactorChain
import ComputableAnalysis.FTA.Enclosures

namespace ComputableAnalysis.RepresentedPolynomial

def factorTailRadius (n : Nat) : Rat := 1/((2^n : Nat) : Rat)

theorem factorTailRadius_pos (n : Nat) : 0 < factorTailRadius n := by
  unfold factorTailRadius
  rw [Rat.div_def]
  exact Rat.mul_pos (by decide +kernel) (Rat.inv_pos.mpr
    (Rat.natCast_pos.mpr (Nat.pow_pos (by omega))))

theorem factorTailRadius_half (n : Nat) : factorTailRadius (n+1) = factorTailRadius n/2 := by
  have hp : ((2^(n+1) : Nat) : Rat) = ((2^n : Nat) : Rat)*2 := by
    exact_mod_cast (Nat.pow_succ 2 n)
  unfold factorTailRadius
  rw [hp]
  simp only [Rat.div_def, Rat.inv_mul_rev]
  grind

theorem factorTailRadius_shrinks : ShrinksToZero factorTailRadius :=
  dyadic_scale_shrinks 1 (by decide +kernel)

def factorStepBudget (n : Nat) : QPos :=
  squaredTolerance ⟨factorTailRadius (n+1)/2, by
    rw [Rat.div_def]
    exact Rat.mul_pos (factorTailRadius_pos (n+1)) (by decide +kernel)⟩

def geometricFactorCenters (p : Coefficients) (hp : Monic p) (n : Nat) : QComplex :=
  (computedFactorChain p hp factorStepBudget n).1

theorem geometricFactorCenters_step (p : Coefficients) (hp : Monic p)
    (hd : 2 ≤ p.length) (n : Nat) :
    QComplex.normBound (QComplex.sub (geometricFactorCenters p hp (n+1))
      (geometricFactorCenters p hp n)) ≤ factorTailRadius n-factorTailRadius (n+1) := by
  have hs := computedFactorChain_step p hp hd factorStepBudget n
  have heq : QComplex.normSq (QComplex.sub (geometricFactorCenters p hp (n+1))
      (geometricFactorCenters p hp n)) = QComplex.normSq
      (QComplex.sub (geometricFactorCenters p hp n) (geometricFactorCenters p hp (n+1))) := by
    simp only [QComplex.normSq, QComplex.sub, QComplex.add, QComplex.neg]
    grind
  have hb := PolynomialDirection.normBound_lt_of_normSq_lt
    (QComplex.sub (geometricFactorCenters p hp (n+1)) (geometricFactorCenters p hp n))
    ⟨factorTailRadius (n+1), factorTailRadius_pos (n+1)⟩
    (by rw [heq]; exact hs)
  have hh := factorTailRadius_half n
  grind

/-- Executable factor centers with constructed summable steps give valid
complex boxes without an abstract completion or a cluster selection. -/
theorem geometricFactorCenters_valid (p : Coefficients) (hp : Monic p) (hd : 2 ≤ p.length) :
    (ComplexRaw.cauchyStabilize (centerCandidates (geometricFactorCenters p hp)) factorTailRadius).Valid :=
  coherentCenters_valid _ _ (fun n => Rat.le_of_lt (factorTailRadius_pos n))
    factorTailRadius_shrinks (geometricFactorCenters_step p hp hd)

end ComputableAnalysis.RepresentedPolynomial
