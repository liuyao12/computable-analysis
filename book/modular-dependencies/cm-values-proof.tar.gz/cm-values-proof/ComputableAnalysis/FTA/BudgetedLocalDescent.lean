import ComputableAnalysis.FTA.ResidualDirectionMargin

namespace ComputableAnalysis.PolynomialNormDescent
open QComplex PolynomialDirection

/-- Positive finite descent gap, retained as quantitative proof data. -/
def localGap (delta : QPos) (t : Rat) (ht : 0 < t) (k : Nat) : QPos :=
  ⟨t^k*delta.val, Rat.mul_pos (by
    induction k with
    | zero => rw [Rat.pow_zero]; decide +kernel
    | succ k ih => rw [Rat.pow_succ]; exact Rat.mul_pos ih ht) delta.property⟩

/-- The norm bound used to compute the perturbation allowance is uniform
for all positive steps below one. -/
theorem localValue_normBound (c a r : QComplex) (C A R t : Rat) (k : Nat)
    (hC : 0 ≤ C) (hA : 0 ≤ A) (hR : 0 ≤ R) (ht : 0 ≤ t) (ht1 : t ≤ 1)
    (hc : normBound c ≤ C) (ha : normBound a ≤ A) (hr : normBound r ≤ R) :
    normBound (add c (scaleRat (t^k) (add a (scaleRat t r)))) ≤ C+A+R := by
  have hp : t^k ≤ 1 := by
    induction k with
    | zero => rw [Rat.pow_zero]; exact Rat.le_refl
    | succ k ih =>
      rw [Rat.pow_succ]
      have hm := Rat.mul_le_mul_of_nonneg_right ih ht
      grind
  have hp0 : 0 ≤ t^k := Rat.pow_nonneg ht
  have hi := normBound_add_le a (scaleRat t r)
  rw [normBound_scaleRat, qabs_eq_self_of_nonneg ht] at hi
  have htr := Rat.mul_le_mul_of_nonneg_left hr ht
  have htr1 := Rat.mul_le_mul_of_nonneg_right ht1 hR
  have hb : normBound (add a (scaleRat t r)) ≤ A+R := by grind
  have ho := normBound_add_le c (scaleRat (t^k) (add a (scaleRat t r)))
  rw [normBound_scaleRat, qabs_eq_self_of_nonneg hp0] at ho
  have hm := Rat.mul_le_mul_of_nonneg_left hb hp0
  have hm1 := Rat.mul_le_mul_of_nonneg_right hp (show 0 ≤ A+R by grind)
  grind

/-- A computed allowance, rather than a separately supplied error-budget
inequality, preserves half the finite descent gap. -/
theorem decrease_with_computed_allowance (c a r e : QComplex) (delta : QPos)
    (C A R t : Rat) (k : Nat) (hC : 0 ≤ C) (hA : 0 ≤ A) (hR : 0 ≤ R)
    (hk : 0 < k) (hc : normBound c ≤ C) (ha : normBound a ≤ A)
    (hr : normBound r ≤ R) (hdir : (mul (conj c) a).re ≤ -delta.val)
    (ht : 0 < t) (htle : t ≤ step delta.val C A R)
    (he : normBound e ≤ (errorAllowance (C+A+R) (by grind) (localGap delta t ht k)).val) :
    normSq (add (add c (scaleRat (t^k) (add a (scaleRat t r)))) e) ≤
      normSq c - t^k*delta.val/2 := by
  have hd := decrease_at_smaller_step c a r delta.val C A R t k delta.property
    hC hA hR hk hc ha hr hdir ht htle
  have hz := localValue_normBound c a r C A R t k hC hA hR
    (Rat.le_of_lt ht) (Rat.le_of_lt hd.1) hc ha hr
  let E := errorAllowance (C+A+R) (by grind) (localGap delta t ht k)
  have hs := score_add_error _ e (C+A+R) E.val (by grind) (Rat.le_of_lt E.property) hz he
  have hb := errorAllowance_cost (C+A+R) (by grind) (localGap delta t ht k)
  change (2*(C+A+R)+E.val)*E.val ≤ t^k*delta.val/2 at hb
  grind

/-- Actual earlier polynomial coefficients meeting the computed cap can be
fed directly into the descent theorem; no error certificate is supplied. -/
theorem decrease_with_capped_early_terms (c a r seed : QComplex) (early : CPoly.Coeffs)
    (delta : QPos) (C A R eta t : Rat) (k : Nat)
    (hC : 0 ≤ C) (hA : 0 ≤ A) (hR : 0 ≤ R) (hk : 0 < k)
    (hc : normBound c ≤ C) (ha : normBound a ≤ A) (hr : normBound r ≤ R)
    (hdir : (mul (conj c) a).re ≤ -delta.val) (ht : 0 < t)
    (htle : t ≤ step delta.val C A R)
    (hp : ∀ b ∈ early, normBound b ≤
      (earlyCoefficientCap (errorAllowance (C+A+R) (by grind) (localGap delta t ht k))
        early.length (paletteRadius k hk) t (Rat.le_of_lt (paletteRadius_pos k hk))
        (Rat.le_of_lt ht)).val) :
    let h := scaleRat t (selectedPaletteDirection k hk seed eta)
    normSq (add (add c (scaleRat (t^k) (add a (scaleRat t r))))
      (mul h (CPoly.eval early h))) ≤ normSq c - t^k*delta.val/2 := by
  have hd := decrease_at_smaller_step c a r delta.val C A R t k delta.property
    hC hA hR hk hc ha hr hdir ht htle
  have he := selected_early_budget early k hk seed eta t (Rat.le_of_lt ht)
    (Rat.le_of_lt hd.1) (errorAllowance (C+A+R) (by grind) (localGap delta t ht k)) hp
  exact decrease_with_computed_allowance c a r _ delta C A R t k hC hA hR hk
    hc ha hr hdir ht htle he

end ComputableAnalysis.PolynomialNormDescent
