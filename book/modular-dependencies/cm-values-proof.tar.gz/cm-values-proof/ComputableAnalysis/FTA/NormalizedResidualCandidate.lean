import ComputableAnalysis.FTA.ScaledResidualTransport

namespace ComputableAnalysis.RepresentedPolynomial

def normalizedResidualBudget (c : ComplexCert) (eps : QPos) : QPos :=
  ⟨eps.val/((leadingValueBound c)^2+1), by
    have hC : 0 ≤ leadingValueBound c := (c.raw.compute 0).normMajorant_nonneg
    have hs := Rat.pow_nonneg hC (n := 2)
    rw [Rat.div_def]
    exact Rat.mul_pos eps.property (Rat.inv_pos.mpr (by grind))⟩

/-- The reciprocal is justified by its exact inverse law; its search-based
construction can be supplied independently of the approximate-root algorithm. -/
def normalizedResidualCandidate (q : Coefficients) (c inverse : ComplexCert)
    (eps : QPos) (start : Nat) : QComplex :=
  representedResidualCandidate (q.map (mul inverse)) (normalizedResidualBudget c eps) start

theorem normalizedResidualCandidate_exact (q : Coefficients) (hq : 0 < q.length)
    (c inverse : ComplexCert) (hinverse : (mul c inverse).raw.Equiv one.raw)
    (eps : QPos) (start : Nat) :
    (normValue (eval (q++[c]) (ofQComplex (normalizedResidualCandidate q c inverse eps start)))).real.preferred.Le
      (RealRaw.ofRat eps.val) := by
  let x := ofQComplex (normalizedResidualCandidate q c inverse eps start)
  let C := leadingValueBound c
  let tol := normalizedResidualBudget c eps
  have hbase := representedResidualCandidate_scaled c (q.map (mul inverse))
    (by simpa using hq) tol start
  have heq := normValue_equiv (normalize_spec q c inverse hinverse x)
  have hleft := RealRaw.le_of_equiv (normValue (eval (q++[c]) x)).real.valid
    (normValue (mul c (eval (normalize q inverse) x))).real.valid heq
  have hC : 0 ≤ C := (c.raw.compute 0).normMajorant_nonneg
  have hs := Rat.pow_nonneg hC (n := 2)
  have hd : 0 < C^2+1 := by grind
  have hi := Rat.mul_inv_cancel (C^2+1) (Rat.ne_of_gt hd)
  have ht : 0 ≤ tol.val := Rat.le_of_lt tol.property
  have hm := Rat.mul_le_mul_of_nonneg_right (show C^2 ≤ C^2+1 by grind) ht
  have hid : (C^2+1)*tol.val = eps.val := by
    change (C^2+1)*(eps.val/(C^2+1)) = eps.val
    rw [Rat.div_def, ← Rat.mul_assoc, Rat.mul_comm (C^2+1) eps.val,
      Rat.mul_assoc, hi, Rat.mul_one]
  rw [hid] at hm
  have hright : (RealRaw.ofRat (C^2*tol.val)).Le (RealRaw.ofRat eps.val) := by
    intro i j
    exact hm
  exact RealRaw.le_trans (y := RealRaw.ofRat (C^2*tol.val)) (RealRaw.ofRat_valid (C^2*tol.val))
    (RealRaw.le_trans (normValue (mul c (eval (normalize q inverse) x))).real.valid hleft hbase) hright

def reciprocalStageTest (c : ComplexCert) (n : Nat) : Bool :=
  decide (0 < ((normValue c).real.compute n).lo)

theorem reciprocalStageTest_eventually (c : ComplexCert) (hc : ¬ c.raw.Equiv zero.raw) :
    ∃ N, ∀ n, N ≤ n → reciprocalStageTest c n = true := by
  obtain ⟨N, hN⟩ := exists_positive_norm_stage c hc
  refine ⟨N, ?_⟩
  intro n hn
  have hb := (normValue c).real.valid.2.1 N n hn
  have hlo : ((normValue c).real.compute N).lo ≤ ((normValue c).real.compute n).lo := hb.1
  have hp : 0 < ((normValue c).real.compute n).lo := by grind only
  simpa [reciprocalStageTest] using hp

def searchedReciprocalStage (c : ComplexCert) (hc : ¬ c.raw.Equiv zero.raw) : Nat :=
  RiemannHilbert.PrecisionSearch.firstFrom (reciprocalStageTest c)
    (reciprocalStageTest_eventually c hc) 0

theorem searchedReciprocalStage_positive (c : ComplexCert) (hc : ¬ c.raw.Equiv zero.raw) :
    0 < ((normValue c).real.compute (searchedReciprocalStage c hc)).lo := by
  have hs := (RiemannHilbert.PrecisionSearch.firstFrom_spec (reciprocalStageTest c)
    (reciprocalStageTest_eventually c hc) 0).2
  simpa [searchedReciprocalStage, reciprocalStageTest] using hs

def searchedReciprocal (c : ComplexCert) (hc : ¬ c.raw.Equiv zero.raw) : ComplexCert :=
  inverseAt c (searchedReciprocalStage c hc) (searchedReciprocalStage_positive c hc)

theorem searchedReciprocal_spec (c : ComplexCert) (hc : ¬ c.raw.Equiv zero.raw) :
    (mul c (searchedReciprocal c hc)).raw.Equiv one.raw := mul_inverseAt _ _ _

/-- Approximate-root construction for arbitrary valid represented coefficients
with a nonzero leading coefficient; all internal searches are hidden. -/
def nonmonicResidualCandidate (q : Coefficients) (c : ComplexCert)
    (hc : ¬ c.raw.Equiv zero.raw) (eps : QPos) (start : Nat) : QComplex :=
  normalizedResidualCandidate q c (searchedReciprocal c hc) eps start

theorem nonmonicResidualCandidate_exact (q : Coefficients) (hq : 0 < q.length)
    (c : ComplexCert) (hc : ¬ c.raw.Equiv zero.raw) (eps : QPos) (start : Nat) :
    (normValue (eval (q++[c]) (ofQComplex (nonmonicResidualCandidate q c hc eps start)))).real.preferred.Le
      (RealRaw.ofRat eps.val) :=
  normalizedResidualCandidate_exact q hq c _ (searchedReciprocal_spec c hc) eps start

end ComputableAnalysis.RepresentedPolynomial
