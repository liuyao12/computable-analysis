import ComputableAnalysis.FTA.ExactApproximateMinimum

namespace ComputableAnalysis.RepresentedPolynomial
open PolynomialCoercivity

def interiorSearchRadius (q : Coefficients) : Rat :=
  2 * ((coefficientRadius q + 1)^2 + coefficientRadius q + 3) + 1

theorem interiorSearchRadius_pos (q : Coefficients) : 0 < interiorSearchRadius q := by
  have hc := coefficientRadius_nonneg q
  have hs := Rat.pow_nonneg (show 0 ≤ coefficientRadius q + 1 by grind) (n := 2)
  unfold interiorSearchRadius
  grind

def interiorSearchBox (q : Coefficients) : QBox :=
  let R := interiorSearchRadius q
  ⟨⟨-R, -R⟩, ⟨R, R⟩⟩

theorem interiorSearchBox_ordered (q : Coefficients) : (interiorSearchBox q).Ordered := by
  have h := interiorSearchRadius_pos q
  constructor <;> change -interiorSearchRadius q ≤ interiorSearchRadius q <;> grind

private theorem monicSamples (q : Coefficients) (k : Nat) :
    coefficientSamples (q++[one]) k = coefficientSamples q k ++ [QComplex.one] := by
  simp [coefficientSamples, one, ofQComplex, ComplexRaw.ofQComplex]

/-- The actual scheduled monic-polynomial minimizer is bounded independently
of its precision. The search radius leaves one rational unit of spare margin. -/
theorem approximateMinimum_interior_bound (q : Coefficients) (hq : 0 < q.length)
    (eps : QPos) (heps : eps.val ≤ 1) (start : Nat) :
    QComplex.normBound (approximateMinimum (q++[one]) (interiorSearchBox q)
      (interiorSearchBox_ordered q) eps start) ≤ interiorSearchRadius q - 1 := by
  let box := interiorSearchBox q
  let x := approximateMinimum (q++[one]) box (interiorSearchBox_ordered q) eps start
  let k := scheduledCoefficientStage (q++[one]) box (minimumCoefficientBudget (q++[one]) box eps) start
  let C := coefficientRadius q
  have hC : 0 ≤ C := coefficientRadius_nonneg q
  have hR := interiorSearchRadius_pos q
  have hzlo : box.lo ≤ QComplex.zero := by constructor <;> change -interiorSearchRadius q ≤ 0 <;> grind
  have hzhi : QComplex.zero ≤ box.hi := by constructor <;> change 0 ≤ interiorSearchRadius q <;> grind
  have hmin := approximateMinimum_le (q++[one]) box (interiorSearchBox_ordered q)
    eps start k (Nat.le_refl _) QComplex.zero hzlo hzhi
  have hb := coefficientSamples_bound q k
  have hz := eval_normBound_on_unit (coefficientSamples (q++[one]) k) QComplex.zero
    (by decide +kernel)
  rw [monicSamples, coefficientBound_append] at hz
  have hone : coefficientBound [QComplex.one] = 1 := by decide +kernel
  rw [hone] at hz
  have hzbound : QComplex.normBound (CPoly.eval (coefficientSamples (q++[one]) k) QComplex.zero) ≤ C+1 := by
    rw [monicSamples]
    grind
  have hzero := normSq_le_normBound_square (CPoly.eval (coefficientSamples (q++[one]) k) QComplex.zero)
  have h0 := QComplex.normBound_nonneg (CPoly.eval (coefficientSamples (q++[one]) k) QComplex.zero)
  have h1 := Rat.mul_le_mul_of_nonneg_left hzbound h0
  have h2 := Rat.mul_le_mul_of_nonneg_right hzbound (show 0 ≤ C+1 by grind)
  have hnorm := normBound_le_normSq_add_one (CPoly.eval (coefficientSamples (q++[one]) k) x)
  have heval : QComplex.normBound (CPoly.eval (coefficientSamples q k ++ [QComplex.one]) x) ≤ (C+1)^2+2 := by
    rw [← monicSamples]
    change QComplex.normSq (CPoly.eval (coefficientSamples (q++[one]) k) x) ≤
      QComplex.normSq (CPoly.eval (coefficientSamples (q++[one]) k) QComplex.zero) + eps.val at hmin
    simp only [Rat.pow_succ, Rat.pow_zero, Rat.one_mul]
    grind
  have hM : 0 ≤ (C+1)^2+2 := by have h := Rat.pow_nonneg (show 0 ≤ C+1 by grind) (n := 2); grind
  have hx := monic_sublevel_bound (coefficientSamples q k)
    (by simpa [coefficientSamples] using hq) x ((C+1)^2+2) hM heval
  change QComplex.normBound x ≤ interiorSearchRadius q - 1
  unfold interiorSearchRadius
  dsimp [C] at *
  grind

/-- All actual candidates have a unit coordinate margin, even when the
finite mesh contains boundary points. No supplied interior witness is needed. -/
theorem approximateMinimum_unit_margin (q : Coefficients) (hq : 0 < q.length)
    (eps : QPos) (heps : eps.val ≤ 1) (start : Nat) :
    let box := interiorSearchBox q
    let x := approximateMinimum (q++[one]) box (interiorSearchBox_ordered q) eps start
    box.lo.re + 1 ≤ x.re ∧ x.re + 1 ≤ box.hi.re ∧
      box.lo.im + 1 ≤ x.im ∧ x.im + 1 ≤ box.hi.im := by
  let x := approximateMinimum (q++[one]) (interiorSearchBox q) (interiorSearchBox_ordered q) eps start
  have hb := approximateMinimum_interior_bound q hq eps heps start
  have hr0 := qabs_nonneg x.re
  have hi0 := qabs_nonneg x.im
  have hrlo := neg_qabs_le_self x.re
  have hrhi := self_le_qabs x.re
  have hilo := neg_qabs_le_self x.im
  have hihi := self_le_qabs x.im
  change qabs x.re + qabs x.im ≤ interiorSearchRadius q - 1 at hb
  change -interiorSearchRadius q + 1 ≤ x.re ∧ x.re + 1 ≤ interiorSearchRadius q ∧
    -interiorSearchRadius q + 1 ≤ x.im ∧ x.im + 1 ≤ interiorSearchRadius q
  constructor <;> (try constructor) <;> (try constructor) <;> grind

end ComputableAnalysis.RepresentedPolynomial
