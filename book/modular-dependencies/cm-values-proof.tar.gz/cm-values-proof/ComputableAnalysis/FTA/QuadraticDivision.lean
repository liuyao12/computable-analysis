import ComputableAnalysis.FTA.RealAlgebra

/-! Monic quadratic division uses only finite represented-coefficient arithmetic. -/
namespace ComputableAnalysis.RepresentedPolynomial
open Arithmetic

def quadraticEval (b₀ b₁ x : ComplexCert) : ComplexCert := add b₀ (mul x (add b₁ x))

/-- Quotient, constant remainder, and linear remainder, in that order. -/
def quadraticDivide (b₀ b₁ : ComplexCert) : Coefficients → Coefficients × ComplexCert × ComplexCert
  | [] => ([], zero, zero)
  | [c] => ([], c, zero)
  | [c, d] => ([], c, d)
  | c :: d :: e :: p =>
      let qr := quadraticDivide b₀ b₁ (d :: e :: p)
      (qr.2.2 :: qr.1, sub c (mul b₀ qr.2.2), sub qr.2.1 (mul b₁ qr.2.2))

private theorem qext {a b : QComplex} (hre : a.re = b.re) (him : a.im = b.im) : a = b := by
  cases a; cases b; simp_all

set_option maxRecDepth 4096 in
set_option maxHeartbeats 800000 in
theorem quadraticDivide_spec (b₀ b₁ x : ComplexCert) (p : Coefficients) :
    (eval p x).raw.Equiv
      (add (mul (quadraticEval b₀ b₁ x) (eval (quadraticDivide b₀ b₁ p).1 x))
        (add (quadraticDivide b₀ b₁ p).2.1 (mul x (quadraticDivide b₀ b₁ p).2.2))).raw := by
  induction p with
  | nil =>
      apply Expression.equiv_of_samples (.constant QComplex.zero)
        (.add (.mul (.parameter (quadraticEval b₀ b₁ x)) (.constant QComplex.zero))
          (.add (.constant QComplex.zero) (.mul (.parameter x) (.constant QComplex.zero))))
      intro s
      apply qext <;> simp [Expression.sample, QComplex.add, QComplex.mul, QComplex.zero] <;> grind
  | cons c p ih =>
      cases p with
      | nil =>
          apply Expression.equiv_of_samples
            (.add (.parameter c) (.mul (.parameter x) (.constant QComplex.zero)))
            (.add (.mul (.parameter (quadraticEval b₀ b₁ x)) (.constant QComplex.zero))
              (.add (.parameter c) (.mul (.parameter x) (.constant QComplex.zero))))
          intro s
          apply qext <;> simp [Expression.sample, QComplex.add, QComplex.mul, QComplex.zero] <;> grind
      | cons d p =>
          cases p with
          | nil =>
              apply Expression.equiv_of_samples
                (.add (.parameter c) (.mul (.parameter x)
                  (.add (.parameter d) (.mul (.parameter x) (.constant QComplex.zero)))))
                (.add (.mul (.parameter (quadraticEval b₀ b₁ x)) (.constant QComplex.zero))
                  (.add (.parameter c) (.mul (.parameter x) (.parameter d))))
              intro s
              apply qext <;> simp [Expression.sample, QComplex.add, QComplex.mul, QComplex.zero] <;> grind
          | cons e p =>
              let qr := quadraticDivide b₀ b₁ (d :: e :: p)
              refine certTrans (certAddCongr (certRefl c) (certMulCongr (certRefl x) ih)) ?_
              change (add c (mul x (add (mul (quadraticEval b₀ b₁ x) (eval qr.1 x))
                (add qr.2.1 (mul x qr.2.2))))).raw.Equiv
                (add (mul (quadraticEval b₀ b₁ x) (add qr.2.2 (mul x (eval qr.1 x))))
                  (add (sub c (mul b₀ qr.2.2)) (mul x (sub qr.2.1 (mul b₁ qr.2.2))))).raw
              apply Expression.equiv_of_samples
                (.add (.parameter c) (.mul (.parameter x)
                  (.add (.mul (.add (.parameter b₀) (.mul (.parameter x) (.add (.parameter b₁) (.parameter x))))
                    (.parameter (eval qr.1 x)))
                    (.add (.parameter qr.2.1) (.mul (.parameter x) (.parameter qr.2.2))))))
                (.add (.mul (.add (.parameter b₀) (.mul (.parameter x) (.add (.parameter b₁) (.parameter x))))
                    (.add (.parameter qr.2.2) (.mul (.parameter x) (.parameter (eval qr.1 x)))))
                  (.add (.add (.parameter c) (.neg (.mul (.parameter b₀) (.parameter qr.2.2))))
                    (.mul (.parameter x) (.add (.parameter qr.2.1) (.neg (.mul (.parameter b₁) (.parameter qr.2.2)))))))
              intro s
              apply qext <;> simp [Expression.sample, QComplex.add, QComplex.mul, QComplex.neg] <;> grind

theorem quadraticDivide_length (b₀ b₁ : ComplexCert) (p : Coefficients) :
    (quadraticDivide b₀ b₁ p).1.length = p.length - 2 := by
  induction p with
  | nil => rfl
  | cons c p ih =>
      cases p with
      | nil => rfl
      | cons d p =>
          cases p with
          | nil => rfl
          | cons e p => simpa [quadraticDivide] using congrArg Nat.succ ih

theorem quadraticDivide_real (b₀ b₁ : ComplexCert) (h₀ : IsReal b₀) (h₁ : IsReal b₁)
    (p : Coefficients) (hp : RealCoefficients p) :
    RealCoefficients (quadraticDivide b₀ b₁ p).1 ∧
      IsReal (quadraticDivide b₀ b₁ p).2.1 ∧ IsReal (quadraticDivide b₀ b₁ p).2.2 := by
  induction p with
  | nil => exact ⟨True.intro, IsReal.zero, IsReal.zero⟩
  | cons c p ih =>
      cases p with
      | nil => exact ⟨True.intro, hp.1, IsReal.zero⟩
      | cons d p =>
          cases p with
          | nil => exact ⟨True.intro, hp.1, hp.2.1⟩
          | cons e p =>
              have hh := ih hp.2
              exact ⟨⟨hh.2.2, hh.1⟩, IsReal.sub hp.1 (IsReal.mul h₀ hh.2.2),
                IsReal.sub hh.2.1 (IsReal.mul h₁ hh.2.2)⟩

theorem quadraticDivide_monic (b₀ b₁ : ComplexCert) (p : Coefficients)
    (hp : Monic p) (hdegree : 3 ≤ p.length) : Monic (quadraticDivide b₀ b₁ p).1 := by
  obtain ⟨q, rfl⟩ := hp
  induction q with
  | nil => simp at hdegree
  | cons c q ih =>
      cases q with
      | nil => simp at hdegree
      | cons d q =>
          cases q with
          | nil => exact ⟨[], rfl⟩
          | cons e q =>
              obtain ⟨tail, ht⟩ := ih (by simp)
              refine ⟨(quadraticDivide b₀ b₁ ((d :: e :: q) ++ [one])).2.2 :: tail, ?_⟩
              change (quadraticDivide b₀ b₁ ((d :: e :: q) ++ [one])).2.2 ::
                (quadraticDivide b₀ b₁ ((d :: e :: q) ++ [one])).1 = _
              rw [ht]
              rfl

end ComputableAnalysis.RepresentedPolynomial
