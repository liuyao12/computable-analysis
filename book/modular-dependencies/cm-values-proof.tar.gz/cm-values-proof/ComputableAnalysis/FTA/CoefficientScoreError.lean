import ComputableAnalysis.FTA.DyadicScoreMinimum

/-! Executable Horner bounds for perturbing every polynomial coefficient.
These finite estimates supply the coefficient-error term in approximate
minimization; they do not yet construct a represented root. -/
namespace ComputableAnalysis.CPoly

def differenceMajorant : Coeffs → Coeffs → Rat → Rat
  | a :: p, b :: q, R => QComplex.normBound (QComplex.sub a b) + R * differenceMajorant p q R
  | _, _, _ => 0

theorem differenceMajorant_nonneg (p q : Coeffs) (R : Rat) (hR : 0 ≤ R) :
    0 ≤ differenceMajorant p q R := by
  induction p generalizing q with
  | nil => exact Rat.le_refl
  | cons a p ih =>
    cases q with
    | nil => exact Rat.le_refl
    | cons b q =>
      change 0 ≤ QComplex.normBound (QComplex.sub a b) + R * differenceMajorant p q R
      exact Rat.add_nonneg (QComplex.normBound_nonneg _) (Rat.mul_nonneg hR (ih q))

theorem eval_coefficient_difference (p q : Coeffs) (hlen : p.length = q.length)
    (R : Rat) (z : QComplex) (hz : QComplex.normBound z ≤ R) :
    QComplex.normBound (QComplex.sub (eval p z) (eval q z)) ≤ differenceMajorant p q R := by
  induction p generalizing q with
  | nil =>
    cases q with
    | nil =>
      simp only [eval, List.foldr_nil, differenceMajorant, QComplex.sub,
        QComplex.add, QComplex.neg, QComplex.zero, QComplex.normBound, qabs]
      grind
    | cons b q => simp at hlen
  | cons a p ih =>
    cases q with
    | nil => simp at hlen
    | cons b q =>
      have ht : p.length = q.length := by simpa using hlen
      have hd := ih q ht
      have he : QComplex.sub (eval (a::p) z) (eval (b::q) z) =
          QComplex.add (QComplex.sub a b)
            (QComplex.mul z (QComplex.sub (eval p z) (eval q z))) := by
        simp only [eval, List.foldr_cons, QComplex.sub, QComplex.add, QComplex.neg,
          QComplex.mul, QComplex.mk.injEq]
        constructor <;> grind
      rw [he]
      have hm := QComplex.normBound_mul_le z (QComplex.sub (eval p z) (eval q z))
      have h1 := Rat.mul_le_mul_of_nonneg_right hz
        (QComplex.normBound_nonneg (QComplex.sub (eval p z) (eval q z)))
      have hR : 0 ≤ R := Rat.le_trans (QComplex.normBound_nonneg z) hz
      have h2 := Rat.mul_le_mul_of_nonneg_left hd hR
      have ha := QComplex.normBound_add_le (QComplex.sub a b)
        (QComplex.mul z (QComplex.sub (eval p z) (eval q z)))
      change _ ≤ QComplex.normBound (QComplex.sub a b) + R * differenceMajorant p q R
      grind

def coefficientScoreError (p q : Coeffs) (R : Rat) : Rat :=
  (normMajorant p R + normMajorant q R) * differenceMajorant p q R

theorem score_coefficient_difference (p q : Coeffs) (hlen : p.length = q.length)
    (R : Rat) (hR : 0 ≤ R) (z : QComplex) (hz : QComplex.normBound z ≤ R) :
    qabs (QComplex.normSq (eval p z) - QComplex.normSq (eval q z)) ≤
      coefficientScoreError p q R := by
  have h := QComplex.normSq_sub_bound (eval p z) (eval q z)
  have hp := eval_normMajorant p R z hz
  have hq := eval_normMajorant q R z hz
  have hd := eval_coefficient_difference p q hlen R z hz
  have hsum : QComplex.normBound (eval p z) + QComplex.normBound (eval q z) ≤
      normMajorant p R + normMajorant q R := rat_add_le_add hp hq
  have h1 := Rat.mul_le_mul_of_nonneg_right hsum
    (QComplex.normBound_nonneg (QComplex.sub (eval p z) (eval q z)))
  have h2 := Rat.mul_le_mul_of_nonneg_left hd
    (Rat.add_nonneg (normMajorant_nonneg p R hR) (normMajorant_nonneg q R hR))
  unfold coefficientScoreError
  grind

end ComputableAnalysis.CPoly

namespace ComputableAnalysis.FiniteApproximateMinimum

theorem polynomialMinimum_in_box (p : CPoly.Coeffs) (box : QBox) (depth : Nat)
    (ho : box.Ordered) : box.lo ≤ polynomialMinimum p box depth ∧
      polynomialMinimum p box depth ≤ box.hi := by
  have h := select_mem (fun z => QComplex.normSq (CPoly.eval p z)) box.lo (mesh box depth)
  change polynomialMinimum p box depth = box.lo ∨
    polynomialMinimum p box depth ∈ mesh box depth at h
  rcases h with h | h
  · rw [h]
    exact ⟨QComplex.le_refl _, ho⟩
  · obtain ⟨child, hc, he⟩ := List.mem_map.mp h
    have hn := FiniteFTASubdivision.dyadicSubdivide_nestedIn_parent ho child hc
    have hco := FiniteFTASubdivision.dyadicSubdivide_ordered ho child hc
    rw [← he]
    exact ⟨hn.1, QComplex.le_trans hco hn.2⟩

/-- Minimizing a sampled polynomial transfers to any equal-length polynomial
with a computed coefficient perturbation bound. The two error charges arise
at the selected point and at the comparison point. -/
theorem perturbed_polynomialMinimum_le (p q : CPoly.Coeffs)
    (hlen : p.length = q.length) (box : QBox) (depth : Nat) (ho : box.Ordered)
    (z : QComplex) (hl : box.lo ≤ z) (hh : z ≤ box.hi) :
    QComplex.normSq (CPoly.eval q (polynomialMinimum p box depth)) ≤
      QComplex.normSq (CPoly.eval q z) + budget p box depth +
        2 * CPoly.coefficientScoreError p q box.normMajorant := by
  have hmin := polynomialMinimum_le p box depth ho z hl hh
  have hbox := polynomialMinimum_in_box p box depth ho
  have hselected := CPoly.score_coefficient_difference p q hlen box.normMajorant
    box.normMajorant_nonneg (polynomialMinimum p box depth)
    (QBox.normBound_le_of_mem box _ hbox.1 hbox.2)
  have htarget := CPoly.score_coefficient_difference p q hlen box.normMajorant
    box.normMajorant_nonneg z (QBox.normBound_le_of_mem box z hl hh)
  have hs := neg_qabs_le_self (QComplex.normSq (CPoly.eval p (polynomialMinimum p box depth)) -
    QComplex.normSq (CPoly.eval q (polynomialMinimum p box depth)))
  have ht := self_le_qabs (QComplex.normSq (CPoly.eval p z) - QComplex.normSq (CPoly.eval q z))
  change QComplex.normSq (CPoly.eval p (polynomialMinimum p box depth)) ≤
    QComplex.normSq (CPoly.eval p z) + budget p box depth at hmin
  grind

end ComputableAnalysis.FiniteApproximateMinimum
