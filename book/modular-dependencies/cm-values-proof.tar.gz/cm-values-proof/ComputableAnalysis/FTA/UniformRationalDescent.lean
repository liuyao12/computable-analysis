import ComputableAnalysis.FTA.CommonDescentGap

namespace ComputableAnalysis.PolynomialDirection
open QComplex FiniteFTABoundary

def rationalDescentBounds (p : CPoly.Coeffs) (R : Rat) (hR : 0 ≤ R) (rho : QPos) : DescentBounds where
  value := CPoly.normMajorant p R
  coefficient := taylorCoefficientBound p R
  value_nonneg := CPoly.normMajorant_nonneg p R hR
  coefficient_nonneg := taylorCoefficientBound_nonneg p R hR
  tailLength := p.length
  residual := rho

def rationalDescentGap (p : CPoly.Coeffs) (R : Rat) (hR : 0 ≤ R) (rho : QPos) : QPos :=
  commonDescentGap (rationalDescentBounds p R hR rho) (p.length-1)

private theorem add_zero (r : QComplex) : add r QComplex.zero = r := by
  cases r
  simp only [add, QComplex.zero, QComplex.mk.injEq]
  constructor <;> grind

private theorem eval_zero (c : QComplex) (p : CPoly.Coeffs) :
    CPoly.eval (c::p) QComplex.zero = c := by
  cases c
  simp only [CPoly.eval, List.foldr_cons, add, mul, QComplex.zero, QComplex.mk.injEq]
  constructor <;> grind

/-- A single computed positive gap works at all rational centres in a norm
ball where the monic polynomial's squared residual exceeds the fixed floor.
Every Taylor and schedule bound is constructed from the original polynomial. -/
theorem uniform_monic_rational_descent (p : CPoly.Coeffs)
    (hmonic : ∃ q, p = q ++ [QComplex.one]) (hdegree : 2 ≤ p.length)
    (R : Rat) (hR : 0 ≤ R) (rho : QPos) (r : QComplex) (hr : normBound r ≤ R)
    (hres : rho.val ≤ normSq (CPoly.eval p r)) :
    ∃ h : QComplex, normBound h ≤ 1 ∧
      normSq (CPoly.eval p (add r h)) ≤ normSq (CPoly.eval p r) -
        (rationalDescentGap p R hR rho).val := by
  obtain ⟨original, hp⟩ := hmonic
  obtain ⟨translated, ht⟩ := finiteTaylor_leading r QComplex.one original
  rw [← hp] at ht
  have hl := finiteTaylor_length r p
  rw [ht] at hl
  cases translated with
  | nil => simp at hl; omega
  | cons c q =>
    have hc : c = CPoly.eval p r := by
      have he := finiteTaylor_eval r QComplex.zero p
      rw [add_zero, ht, List.cons_append, eval_zero] at he
      exact he.symm
    let b := rationalDescentBounds p R hR rho
    have hcoeff := taylorCoefficientBound_spec p r R hR hr
    have hpcoeff : ∀ a ∈ q ++ [QComplex.one], normBound a ≤ b.coefficient := by
      intro a ha
      apply hcoeff
      rw [ht, List.cons_append]
      simp [ha]
    have hvalue : normBound c ≤ b.value := by
      rw [hc]
      exact CPoly.eval_normMajorant p R r hr
    have hres' : b.residual.val ≤ normSq c := by rw [hc]; exact hres
    have hlen : q.length+1 ≤ b.tailLength := by
      change q.length+1 ≤ p.length
      simp only [List.length_append, List.length_cons, List.length_nil] at hl
      omega
    obtain ⟨h, hh, hd⟩ := exists_monic_common_descent b c q hvalue hres' hpcoeff hlen
    refine ⟨h, hh, ?_⟩
    rw [finiteTaylor_eval r h p, ht, List.cons_append]
    have hdegree' : q.length+1 = p.length-1 := by
      simp only [List.length_append, List.length_cons, List.length_nil] at hl
      omega
    rw [hdegree', hc] at hd
    rw [hc]
    exact hd

/-- Uniform descent excludes a positive residual at an approximate minimum
whose comparison error is smaller than the computed common gap. -/
theorem rational_approximate_minimum_residual (p : CPoly.Coeffs)
    (hmonic : ∃ q, p = q ++ [QComplex.one]) (hdegree : 2 ≤ p.length)
    (R : Rat) (hR : 0 ≤ R) (rho : QPos) (box : QBox) (r : QComplex) (error : Rat)
    (hr : normBound r ≤ R)
    (hlre : box.lo.re+1 ≤ r.re) (hhre : r.re+1 ≤ box.hi.re)
    (hlim : box.lo.im+1 ≤ r.im) (hhim : r.im+1 ≤ box.hi.im)
    (hmin : ∀ z : QComplex, box.lo ≤ z → z ≤ box.hi →
      normSq (CPoly.eval p r) ≤ normSq (CPoly.eval p z)+error)
    (herror : error < (rationalDescentGap p R hR rho).val) :
    normSq (CPoly.eval p r) < rho.val := by
  by_cases hsmall : normSq (CPoly.eval p r) < rho.val
  · exact hsmall
  · have hres : rho.val ≤ normSq (CPoly.eval p r) := by grind
    obtain ⟨h, hh, hd⟩ := uniform_monic_rational_descent p hmonic hdegree R hR rho r hr hres
    have hdom := PolynomialDescentDomain.displacement_in_box box r h 1 hlre hhre hlim hhim hh
    have hm := hmin (add r h) hdom.1 hdom.2
    grind only

end ComputableAnalysis.PolynomialDirection
