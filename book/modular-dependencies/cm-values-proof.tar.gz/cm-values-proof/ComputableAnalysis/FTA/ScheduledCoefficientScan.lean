import ComputableAnalysis.FTA.FiniteTaylorBound

namespace ComputableAnalysis.PolynomialDirection
open QComplex

/-- Reuse the rational scan while retaining each positive threshold's identity
for lookup in the backward schedule. -/
def positiveSignificantIndex (xs : List (QComplex × QPos)) : Nat :=
  significantIndex (xs.map (fun x => (x.1, x.2.val)))

theorem positiveSignificantIndex_spec (xs : List (QComplex × QPos))
    (h : ∃ x ∈ xs, x.2.val < normBound x.1) :
    ∃ before x after, xs = before ++ x :: after ∧
      positiveSignificantIndex xs = before.length ∧ x.2.val < normBound x.1 ∧
      ∀ y ∈ before, normBound y.1 ≤ y.2.val := by
  induction xs with
  | nil => obtain ⟨x, hx, _⟩ := h; simp at hx
  | cons x xs ih =>
    by_cases hx : x.2.val < normBound x.1
    · refine ⟨[], x, xs, rfl, ?_, hx, ?_⟩
      · simp [positiveSignificantIndex, significantIndex, hx]
      · intro y hy; simp at hy
    · have htail : ∃ y ∈ xs, y.2.val < normBound y.1 := by
        obtain ⟨y, hy, hp⟩ := h
        rcases List.mem_cons.mp hy with heq | hy
        · subst y; exact False.elim (hx hp)
        · exact ⟨y, hy, hp⟩
      obtain ⟨before, y, after, heq, hi, hp, hb⟩ := ih htail
      refine ⟨x :: before, y, after, ?_, ?_, hp, ?_⟩
      · simp [heq]
      · simp only [positiveSignificantIndex, List.map_cons, significantIndex, hx, if_false,
          List.length_cons] at *
        exact congrArg (fun n => n+1) hi
      · intro z hz
        rcases List.mem_cons.mp hz with heq | hz
        · subst z; grind
        · exact hb z hz

/-- Schedule alignment converts the scan's individual earlier thresholds into
the common coefficient cap required by the actual polynomial descent theorem. -/
theorem scheduled_significant_cap (b : DescentBounds) (degree : Nat)
    (xs : List (QComplex × QPos)) (halign : xs.map Prod.snd = concreteThresholds b degree)
    (hpass : ∃ x ∈ xs, x.2.val < normBound x.1) :
    ∃ before x after, xs = before ++ x :: after ∧
      positiveSignificantIndex xs = before.length ∧ x.2.val < normBound x.1 ∧
      ∀ a ∈ before.map Prod.fst,
        normBound a ≤ (descentCoefficientCap b before.length x.2).val := by
  obtain ⟨before, x, after, hsplit, hi, hp, hb⟩ := positiveSignificantIndex_spec xs hpass
  have hschedule : concreteThresholds b degree =
      before.map Prod.snd ++ x.2 :: after.map Prod.snd := by
    rw [← halign, hsplit, List.map_append, List.map_cons]
  have hcap := concreteThresholds_prefix_cap b degree (before.map Prod.snd) x.2
    (after.map Prod.snd) hschedule
  refine ⟨before, x, after, hsplit, hi, hp, ?_⟩
  intro a ha
  obtain ⟨y, hy, rfl⟩ := List.mem_map.mp ha
  have hc := hcap y.2 (List.mem_map.mpr ⟨y, hy, rfl⟩)
  rw [List.length_map] at hc
  exact Rat.le_trans (hb y hy) hc

/-- The monic leading entry supplies the passing test without any assumed
nonzero-coefficient witness. -/
theorem scheduled_monic_cap (b : DescentBounds) (degree : Nat)
    (xs : List (QComplex × QPos)) (theta : QPos) (htheta : theta.val < 1)
    (halign : (xs ++ [(QComplex.one, theta)]).map Prod.snd = concreteThresholds b degree) :
    ∃ before x after, xs ++ [(QComplex.one, theta)] = before ++ x :: after ∧
      positiveSignificantIndex (xs ++ [(QComplex.one, theta)]) = before.length ∧
      x.2.val < normBound x.1 ∧ ∀ a ∈ before.map Prod.fst,
        normBound a ≤ (descentCoefficientCap b before.length x.2).val := by
  apply scheduled_significant_cap b degree _ halign
  refine ⟨(QComplex.one, theta), ?_, ?_⟩
  · simp
  · have hn : normBound QComplex.one = 1 := by decide +kernel
    simpa only [hn] using htheta

/-- Pairing a supplied monic coefficient list with the concrete schedule
constructs the alignment and passing-entry evidence automatically. -/
theorem monic_zip_scan_cap (b : DescentBounds) (p : CPoly.Coeffs) :
    let xs := (p ++ [QComplex.one]).zip (concreteThresholds b (p.length+1))
    ∃ before x after, xs = before ++ x :: after ∧
      positiveSignificantIndex xs = before.length ∧ x.2.val < normBound x.1 ∧
      ∀ a ∈ before.map Prod.fst,
        normBound a ≤ (descentCoefficientCap b before.length x.2).val := by
  apply scheduled_significant_cap b (p.length+1)
  · apply List.map_snd_zip
    simp only [concreteThresholds, backwardThresholds_length, List.length_append,
      List.length_cons, List.length_nil]
    omega
  · refine ⟨(QComplex.one, ⟨1/2, by decide +kernel⟩), ?_, ?_⟩
    · rw [concreteThresholds, backwardThresholds,
        List.zip_append (by rw [backwardThresholds_length])]
      simp
    · decide +kernel

end ComputableAnalysis.PolynomialDirection
