import ComputableAnalysis.FTA.RepresentedDivisionEnvelope

namespace ComputableAnalysis.RepresentedPolynomial
open PolynomialDirection

/-- A radius computed from degree and a common initial coordinate envelope. -/
def peelRadius (degree : Nat) (C : Rat) : Rat :=
  let B := 2*(1+C)*(degree : Rat)
  2*((B+1)^2+B+3)

theorem peelRadius_nonneg (degree : Nat) (C : Rat) (hC : 0 ≤ C) :
    0 ≤ peelRadius degree C := by
  have hd : 0 ≤ (degree : Rat) := by exact_mod_cast (Nat.zero_le degree)
  have hB := Rat.mul_nonneg (show 0 ≤ 2*(1+C) by grind) hd
  have hs := Rat.pow_nonneg (show 0 ≤ 2*(1+C)*(degree : Rat)+1 by grind) (n := 2)
  unfold peelRadius
  grind

/-- The actual center satisfies the explicit envelope radius uniformly in
residual tolerance and precision-search starting stage. -/
theorem approximatePeelPoint_envelope (p : Coefficients) (hdegree : 2 ≤ p.length)
    (C : Rat) (hC : 0 ≤ C)
    (hp : ∀ a ∈ p, (a.raw.compute 0).CoordinateBounded C)
    (eps : QPos) (start : Nat) :
    QComplex.normBound (approximatePeelPoint p eps start) ≤ peelRadius p.dropLast.length C := by
  exact approximatePeelPoint_bound_of_coefficientRadius p hdegree _
    (coefficientRadius_le_of_box_envelopes p.dropLast C
      (by intro a ha; exact hp a (List.dropLast_subset p ha))) eps start

private theorem point_coordinateBounded (z : QComplex) (R : Rat)
    (hz : QComplex.normBound z ≤ R) : (QBox.point z).CoordinateBounded R := by
  have hr := qabs_nonneg z.re
  have hi := qabs_nonneg z.im
  change qabs z.re+qabs z.im ≤ R at hz
  change qabs z.re ≤ R ∧ qabs z.re ≤ R ∧ qabs z.im ≤ R ∧ qabs z.im ≤ R
  grind

/-- The actual approximate peeling step preserves a constructed coefficient
envelope; no center, remainder, or quotient bound is assumed. -/
theorem approximatePeel_division_envelope (p : Coefficients) (hdegree : 2 ≤ p.length)
    (C : Rat) (hC : 0 ≤ C)
    (hp : ∀ a ∈ p, (a.raw.compute 0).CoordinateBounded C)
    (eps : QPos) (start : Nat) :
    let r := ofQComplex (approximatePeelPoint p eps start)
    let E := C*geometricEnvelope p.length (1+2*peelRadius p.dropLast.length C)
    ((syntheticDivide r p).2.raw.compute 0).CoordinateBounded E ∧
    ∀ a ∈ (syntheticDivide r p).1, (a.raw.compute 0).CoordinateBounded E := by
  apply syntheticDivide_box_envelope p _ C (peelRadius p.dropLast.length C) hC
    (peelRadius_nonneg _ C hC)
  · exact point_coordinateBounded _ _ (approximatePeelPoint_envelope p hdegree C hC hp eps start)
  · exact hp

end ComputableAnalysis.RepresentedPolynomial
