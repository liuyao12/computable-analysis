import ComputableAnalysis.ComplexReciprocalCalculus
import ComputableAnalysis.FTA.Direction

namespace ComputableAnalysis.PolynomialDirection
open QComplex

/-- A five-vector rational palette bounds every coefficient whose inward
scores are all small. `b` has negative real part and `w` positive imaginary
part. The vectors will later be supplied as powers of rational directions. -/
theorem palette_coefficient_bound (c b w : QComplex) (eta : Rat)
    (heta : 0 ≤ eta) (hb : b.re < 0) (hw : 0 < w.im)
    (hone : -eta ≤ c.re)
    (hb1 : -eta ≤ (mul c b).re) (hb2 : -eta ≤ (mul c (conj b)).re)
    (hw1 : -eta ≤ (mul c w).re) (hw2 : -eta ≤ (mul c (conj w)).re) :
    normBound c ≤ eta *
      ((1 + (-b.re)⁻¹) + (1 + qabs w.re * (1 + (-b.re)⁻¹)) * w.im⁻¹) := by
  have hu : 0 < -b.re := by grind
  have hui := Rat.inv_pos.mpr hu
  have hwi := Rat.inv_pos.mpr hw
  have huc := Rat.mul_inv_cancel (-b.re) (Rat.ne_of_gt hu)
  have hwc := Rat.mul_inv_cancel w.im (Rat.ne_of_gt hw)
  have hreal : (-b.re)*c.re ≤ eta := by
    simp only [mul, conj] at hb1 hb2
    grind
  have hrealScaled := Rat.mul_le_mul_of_nonneg_right hreal (Rat.le_of_lt hui)
  rw [Rat.mul_comm (-b.re) c.re, Rat.mul_assoc, huc, Rat.mul_one] at hrealScaled
  have hreUpper : c.re ≤ eta * (-b.re)⁻¹ := hrealScaled
  have hsum : 0 ≤ 1 + (-b.re)⁻¹ := by grind
  have hrealAbs : qabs c.re ≤ eta * (1 + (-b.re)⁻¹) := by
    have he := Rat.mul_nonneg heta (Rat.le_of_lt hui)
    by_cases hcneg : c.re < 0
    · rw [qabs_eq_neg_of_nonpos (show c.re ≤ 0 by grind)]
      grind
    · rw [qabs_eq_self_of_nonneg (show 0 ≤ c.re by grind)]
      grind
  have hprodAbs := Rat.mul_le_mul_of_nonneg_right hrealAbs (qabs_nonneg w.re)
  have hprod : c.re*w.re ≤ eta * (1 + (-b.re)⁻¹) * qabs w.re := by
    have hs := self_le_qabs (c.re*w.re)
    rw [qabs_mul] at hs
    grind
  have himagAbs : qabs c.im * w.im ≤ eta + eta * (1 + (-b.re)⁻¹) * qabs w.re := by
    simp only [mul, conj] at hw1 hw2
    by_cases hcneg : c.im < 0
    · rw [qabs_eq_neg_of_nonpos (show c.im ≤ 0 by grind)]
      grind
    · rw [qabs_eq_self_of_nonneg (show 0 ≤ c.im by grind)]
      grind
  have himagScaled := Rat.mul_le_mul_of_nonneg_right himagAbs (Rat.le_of_lt hwi)
  rw [Rat.mul_assoc, hwc, Rat.mul_one] at himagScaled
  have himag : qabs c.im ≤ (eta + eta * (1 + (-b.re)⁻¹) * qabs w.re) * w.im⁻¹ := himagScaled
  unfold normBound
  grind

/-- A coefficient exceeding the palette's quantitative bound must give a
strictly inward score in at least one of the five tested vectors. -/
theorem palette_detects_large_coefficient (c b w : QComplex) (eta : Rat)
    (heta : 0 ≤ eta) (hb : b.re < 0) (hw : 0 < w.im)
    (hlarge : eta * ((1 + (-b.re)⁻¹) +
      (1 + qabs w.re * (1 + (-b.re)⁻¹)) * w.im⁻¹) < normBound c) :
    c.re < -eta ∨ (mul c b).re < -eta ∨ (mul c (conj b)).re < -eta ∨
      (mul c w).re < -eta ∨ (mul c (conj w)).re < -eta := by
  by_cases h1 : c.re < -eta
  · exact Or.inl h1
  by_cases h2 : (mul c b).re < -eta
  · exact Or.inr (Or.inl h2)
  by_cases h3 : (mul c (conj b)).re < -eta
  · exact Or.inr (Or.inr (Or.inl h3))
  by_cases h4 : (mul c w).re < -eta
  · exact Or.inr (Or.inr (Or.inr (Or.inl h4)))
  by_cases h5 : (mul c (conj w)).re < -eta
  · exact Or.inr (Or.inr (Or.inr (Or.inr h5)))
  have hbound := palette_coefficient_bound c b w eta heta hb hw
    (by grind) (by grind) (by grind) (by grind) (by grind)
  grind

/-- Every positive local order admits the two rational power vectors needed
by the quantitative palette bound. This does not use complex root extraction. -/
theorem exists_power_palette (order : Nat) (horder : 0 < order) :
    ∃ d e : QComplex, (pow d order).re < 0 ∧ 0 < (pow e order).im := by
  obtain ⟨d, hd⟩ := exists_power_negative_real order horder
  exact ⟨d, ⟨1, smallStep order⟩, hd, smallStep_power_im_pos order horder⟩

end ComputableAnalysis.PolynomialDirection
