import ComputableAnalysis.FTA.BoxCoefficientEnvelope

namespace ComputableAnalysis.QBox

private theorem product_abs_bound (a b C D : Rat) (ha : qabs a ≤ C)
    (hb : qabs b ≤ D) : qabs (a*b) ≤ C*D := by
  have hC := Rat.le_trans (qabs_nonneg a) ha
  have h1 := Rat.mul_le_mul_of_nonneg_right ha (qabs_nonneg b)
  have h2 := Rat.mul_le_mul_of_nonneg_left hb hC
  rw [qabs_mul]
  grind

/-- The literal four-corner interval product preserves an absolute envelope. -/
theorem mulRealInterval_abs_bound (a b c d C D : Rat)
    (ha : qabs a ≤ C) (hb : qabs b ≤ C) (hc : qabs c ≤ D) (hd : qabs d ≤ D) :
    qabs (mulRealInterval a b c d).lo ≤ C*D ∧
    qabs (mulRealInterval a b c d).hi ≤ C*D := by
  have h1 := product_abs_bound a c C D ha hc
  have h2 := product_abs_bound a d C D ha hd
  have h3 := product_abs_bound b c C D hb hc
  have h4 := product_abs_bound b d C D hb hd
  constructor
  · unfold mulRealInterval min4 minRat
    dsimp only
    repeat' split
    all_goals grind
  · unfold mulRealInterval max4 maxRat2
    dsimp only
    repeat' split
    all_goals grind

/-- Both coordinates of the complex interval product have envelope twice
the product of the input coordinate envelopes. -/
theorem mul_coordinateBounded (A B : QBox) (C D : Rat)
    (ha : A.CoordinateBounded C) (hb : B.CoordinateBounded D) :
    (QBox.mul A B).CoordinateBounded (2*C*D) := by
  have rr := mulRealInterval_abs_bound A.lo.re A.hi.re B.lo.re B.hi.re C D
    ha.1 ha.2.1 hb.1 hb.2.1
  have ii := mulRealInterval_abs_bound A.lo.im A.hi.im B.lo.im B.hi.im C D
    ha.2.2.1 ha.2.2.2 hb.2.2.1 hb.2.2.2
  have ri := mulRealInterval_abs_bound A.lo.re A.hi.re B.lo.im B.hi.im C D
    ha.1 ha.2.1 hb.2.2.1 hb.2.2.2
  have ir := mulRealInterval_abs_bound A.lo.im A.hi.im B.lo.re B.hi.re C D
    ha.2.2.1 ha.2.2.2 hb.1 hb.2.1
  have h1 := qabs_sub_le (mulRealInterval A.lo.re A.hi.re B.lo.re B.hi.re).lo
    (mulRealInterval A.lo.im A.hi.im B.lo.im B.hi.im).hi
  have h2 := qabs_sub_le (mulRealInterval A.lo.re A.hi.re B.lo.re B.hi.re).hi
    (mulRealInterval A.lo.im A.hi.im B.lo.im B.hi.im).lo
  have h3 := qabs_add_le (mulRealInterval A.lo.re A.hi.re B.lo.im B.hi.im).lo
    (mulRealInterval A.lo.im A.hi.im B.lo.re B.hi.re).lo
  have h4 := qabs_add_le (mulRealInterval A.lo.re A.hi.re B.lo.im B.hi.im).hi
    (mulRealInterval A.lo.im A.hi.im B.lo.re B.hi.re).hi
  change _ ≤ 2*C*D ∧ _ ≤ 2*C*D ∧ _ ≤ 2*C*D ∧ _ ≤ 2*C*D
  constructor
  · change qabs (_-_) ≤ _; grind
  constructor
  · change qabs (_-_) ≤ _; grind
  constructor <;> change qabs (_+_) ≤ _ <;> grind

end ComputableAnalysis.QBox
