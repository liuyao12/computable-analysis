import ComputableAnalysis.FTA.ActualPeelEnvelope

namespace ComputableAnalysis.RepresentedPolynomial
open PolynomialDirection

/-- Finite iteration of the actual coefficient-envelope recurrence. -/
def peelingRadius : Nat → Rat → Rat
  | 0, _ => 0
  | n+1, C =>
      let R := peelRadius n C
      let E := C*geometricEnvelope (n+1) (1+2*R)
      max R (peelingRadius n E)

theorem peelingRadius_nonneg (n : Nat) (C : Rat) (hC : 0 ≤ C) :
    0 ≤ peelingRadius n C := by
  cases n with
  | zero => exact Rat.le_refl
  | succ n =>
    have hr := peelRadius_nonneg n C hC
    change 0 ≤ max (peelRadius n C) _
    grind

/-- Every factor center in the actual complete approximate peeling lies in
one ball computed solely from degree and the original coefficient envelope. -/
theorem approximatePeeling_uniform_bound (p : Coefficients) (hp : Monic p)
    (C : Rat) (hC : 0 ≤ C)
    (hc : ∀ a ∈ p, (a.raw.compute 0).CoordinateBounded C)
    (eps : QPos) (start : Nat) (item : QComplex × ComplexCert)
    (hi : item ∈ approximatePeeling p hp eps start) :
    QComplex.normBound item.1 ≤ peelingRadius p.length C := by
  rw [approximatePeeling] at hi
  split at hi
  · rename_i hd
    let r := ofQComplex (approximatePeelPoint p eps start)
    let E := C*geometricEnvelope p.length (1+2*peelRadius p.dropLast.length C)
    have hr := approximatePeelPoint_envelope p hd C hC hc eps start
    have he : 0 ≤ E := Rat.mul_nonneg hC
      (geometricEnvelope_nonneg p.length _ (by have h := peelRadius_nonneg p.dropLast.length C hC; grind))
    have hq := (approximatePeel_division_envelope p hd C hC hc eps start).2
    rcases List.mem_cons.mp hi with hx | hi
    · subst item
      have hl : p.length = (p.length-1)+1 := by omega
      rw [hl, peelingRadius]
      rw [List.length_dropLast] at hr
      exact Rat.le_trans hr (by grind)
    · have ht := approximatePeeling_uniform_bound (syntheticDivide r p).1
        (syntheticDivide_monic r p hp hd) E he hq eps start item hi
      rw [syntheticDivide_length] at ht
      have hl : p.length = (p.length-1)+1 := by omega
      rw [hl, peelingRadius]
      change QComplex.normBound item.1 ≤ max _ _
      have hE : E = C*geometricEnvelope ((p.length-1)+1)
          (1+2*peelRadius (p.length-1) C) := by
        dsimp [E]; rw [List.length_dropLast, ← hl]
      rw [hE] at ht
      grind
  · simp at hi
termination_by p.length
decreasing_by rw [syntheticDivide_length]; omega

def initialCoefficientEnvelope (p : Coefficients) : Rat :=
  p.foldr (fun a bound => max (a.raw.compute 0).coordinateRadius bound) 0

theorem initialCoefficientEnvelope_nonneg (p : Coefficients) :
    0 ≤ initialCoefficientEnvelope p := by
  induction p with
  | nil => exact Rat.le_refl
  | cons a p ih => change 0 ≤ max _ (initialCoefficientEnvelope p); grind

theorem initialCoefficientEnvelope_bounds (p : Coefficients) :
    ∀ a ∈ p, (a.raw.compute 0).CoordinateBounded (initialCoefficientEnvelope p) := by
  induction p with
  | nil => simp
  | cons a p ih =>
    intro b hb
    rcases List.mem_cons.mp hb with heq | hb
    · subst b
      exact (QBox.coordinateBounded_radius _).mono (by change _ ≤ max (a.raw.compute 0).coordinateRadius (initialCoefficientEnvelope p); grind)
    · exact (ih b hb).mono (by change _ ≤ max (a.raw.compute 0).coordinateRadius (initialCoefficientEnvelope p); grind)

/-- Whole-family bounds require no caller-supplied coefficient envelope. -/
theorem approximatePeeling_computed_bound (p : Coefficients) (hp : Monic p)
    (eps : QPos) (start : Nat) (item : QComplex × ComplexCert)
    (hi : item ∈ approximatePeeling p hp eps start) :
    QComplex.normBound item.1 ≤ peelingRadius p.length (initialCoefficientEnvelope p) :=
  approximatePeeling_uniform_bound p hp _ (initialCoefficientEnvelope_nonneg p)
    (initialCoefficientEnvelope_bounds p) eps start item hi

end ComputableAnalysis.RepresentedPolynomial
