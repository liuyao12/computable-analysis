import ComputableAnalysis.FTA.NormDescent
import ComputableAnalysis.FTA.PolynomialScoreVariation

namespace ComputableAnalysis.PolynomialNormDescent
open QComplex

/-- An actual additive error has an explicit squared-modulus cost. -/
theorem score_add_error (z e : QComplex) (B E : Rat)
    (hB : 0 ≤ B) (hE : 0 ≤ E) (hz : normBound z ≤ B) (he : normBound e ≤ E) :
    normSq (add z e) ≤ normSq z + (2*B+E)*E := by
  have ha := normBound_add_le z e
  have hs := normSq_sub_bound (add z e) z
  have hid : sub (add z e) z = e := by
    cases z
    cases e
    simp only [sub, add, neg, QComplex.mk.injEq]
    constructor <;> grind
  rw [hid] at hs
  have hsum : normBound (add z e) + normBound z ≤ 2*B+E := by grind
  have h1 := Rat.mul_le_mul_of_nonneg_right hsum (normBound_nonneg e)
  have h2 := Rat.mul_le_mul_of_nonneg_left he (show 0 ≤ 2*B+E by grind)
  have hu := self_le_qabs (normSq (add z e) - normSq z)
  grind

private theorem unit_power (t : Rat) (ht : 0 ≤ t) (ht1 : t ≤ 1) (k : Nat) :
    0 ≤ t^k ∧ t^k ≤ 1 := by
  constructor
  · exact Rat.pow_nonneg ht
  · induction k with
    | zero => rw [Rat.pow_zero]; exact Rat.le_refl
    | succ k ih =>
      rw [Rat.pow_succ]
      have hm := Rat.mul_le_mul_of_nonneg_right ih ht
      grind

/-- The finite descent survives small earlier Taylor terms. The error is
measured on the actual value, with its squared-score cost deducted explicitly. -/
theorem decrease_with_early_error (c a r e : QComplex) (δ C A R E t : Rat) (k : Nat)
    (hδ : 0 < δ) (hC : 0 ≤ C) (hA : 0 ≤ A) (hR : 0 ≤ R) (hE : 0 ≤ E)
    (hk : 0 < k) (hc : normBound c ≤ C) (ha : normBound a ≤ A)
    (hr : normBound r ≤ R) (he : normBound e ≤ E)
    (hdir : (mul (conj c) a).re ≤ -δ) (htpos : 0 < t) (ht1 : t < 1)
    (hbudget : t*(2*C*R+(A+R)^2) ≤ δ)
    (herror : (2*(C+A+R)+E)*E ≤ t^k*δ/2) :
    normSq (add (add c (scaleRat (t^k) (add a (scaleRat t r)))) e) ≤
      normSq c - t^k*δ/2 := by
  have hd := decrease_of_budget c a r δ C A R t k hδ hC hA hR hk hc ha hr
    hdir htpos ht1 hbudget
  have hp := unit_power t (Rat.le_of_lt htpos) (Rat.le_of_lt ht1) k
  have hinner := normBound_add_le a (scaleRat t r)
  rw [normBound_scaleRat, qabs_eq_self_of_nonneg (Rat.le_of_lt htpos)] at hinner
  have htr := Rat.mul_le_mul_of_nonneg_left hr (Rat.le_of_lt htpos)
  have htr1 := Rat.mul_le_mul_of_nonneg_right (Rat.le_of_lt ht1) hR
  have hi : normBound (add a (scaleRat t r)) ≤ A+R := by grind
  have houter := normBound_add_le c (scaleRat (t^k) (add a (scaleRat t r)))
  rw [normBound_scaleRat, qabs_eq_self_of_nonneg hp.1] at houter
  have hmul := Rat.mul_le_mul_of_nonneg_left hi hp.1
  have hmul1 := Rat.mul_le_mul_of_nonneg_right hp.2 (show 0 ≤ A+R by grind)
  have hz : normBound (add c (scaleRat (t^k) (add a (scaleRat t r)))) ≤ C+A+R := by grind
  have hs := score_add_error _ e (C+A+R) E (by grind) hE hz he
  grind

end ComputableAnalysis.PolynomialNormDescent
