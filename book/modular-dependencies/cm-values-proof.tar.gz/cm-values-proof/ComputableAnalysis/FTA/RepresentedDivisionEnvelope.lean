import ComputableAnalysis.FTA.BoxProductEnvelope

namespace ComputableAnalysis.RepresentedPolynomial
open PolynomialDirection

/-- One division envelope controls both the remainder and every quotient
coefficient at the original sampling stage. -/
theorem syntheticDivide_box_envelope (p : Coefficients) (r : ComplexCert)
    (C R : Rat) (hC : 0 ≤ C) (hR : 0 ≤ R)
    (hr : (r.raw.compute 0).CoordinateBounded R)
    (hp : ∀ a ∈ p, (a.raw.compute 0).CoordinateBounded C) :
    ((syntheticDivide r p).2.raw.compute 0).CoordinateBounded
      (C*geometricEnvelope p.length (1+2*R)) ∧
    ∀ a ∈ (syntheticDivide r p).1, (a.raw.compute 0).CoordinateBounded
      (C*geometricEnvelope p.length (1+2*R)) := by
  induction p with
  | nil =>
    constructor
    · change qabs 0 ≤ C*0 ∧ qabs 0 ≤ C*0 ∧ qabs 0 ≤ C*0 ∧ qabs 0 ≤ C*0
      simp only [Rat.mul_zero]; decide +kernel
    · intro a ha; simp [syntheticDivide] at ha
  | cons c p ih =>
    have hc := hp c (by simp)
    have ht := ih (by intro a ha; exact hp a (by simp [ha]))
    have hE := Rat.mul_nonneg hC
      (geometricEnvelope_nonneg p.length (1+2*R) (by grind))
    have hmono : C*geometricEnvelope p.length (1+2*R) ≤
        C*geometricEnvelope (c::p).length (1+2*R) := by
      simp only [List.length_cons, geometricEnvelope]
      have hm := Rat.mul_le_mul_of_nonneg_right (show (1 : Rat) ≤ 1+2*R by grind) hE
      grind
    cases p with
    | nil =>
      constructor
      · simpa [syntheticDivide, geometricEnvelope, Rat.add_zero, Rat.mul_one] using hc
      · intro a ha; simp [syntheticDivide] at ha
    | cons d p =>
      have hm := QBox.mul_coordinateBounded (r.raw.compute 0)
        ((syntheticDivide r (d::p)).2.raw.compute 0) R
        (C*geometricEnvelope (d::p).length (1+2*R)) hr ht.1
      have ha := QBox.add_coordinateBounded (c.raw.compute 0)
        (QBox.mul (r.raw.compute 0) ((syntheticDivide r (d::p)).2.raw.compute 0))
        C (2*R*(C*geometricEnvelope (d::p).length (1+2*R))) hc hm
      have hbound : C+2*R*(C*geometricEnvelope (d::p).length (1+2*R)) ≤
          C*geometricEnvelope (c::d::p).length (1+2*R) := by
        simp only [List.length_cons, geometricEnvelope] at *
        grind
      constructor
      · exact ha.mono hbound
      · intro a ha
        change a ∈ (syntheticDivide r (d::p)).2 :: (syntheticDivide r (d::p)).1 at ha
        rcases List.mem_cons.mp ha with heq | ha
        · subst a; exact ht.1.mono hmono
        · exact (ht.2 a ha).mono hmono

/-- The quotient search radius is controlled by the same explicit envelope. -/
theorem syntheticDivide_coefficientRadius_bound (p : Coefficients) (r : ComplexCert)
    (C R : Rat) (hC : 0 ≤ C) (hR : 0 ≤ R)
    (hr : (r.raw.compute 0).CoordinateBounded R)
    (hp : ∀ a ∈ p, (a.raw.compute 0).CoordinateBounded C) :
    coefficientRadius (syntheticDivide r p).1 ≤
      2*(1+C*geometricEnvelope p.length (1+2*R))*((p.length-1 : Nat) : Rat) := by
  have hb := coefficientRadius_le_of_box_envelopes (syntheticDivide r p).1
    (C*geometricEnvelope p.length (1+2*R))
    (syntheticDivide_box_envelope p r C R hC hR hr hp).2
  simpa only [syntheticDivide_length] using hb

end ComputableAnalysis.RepresentedPolynomial
