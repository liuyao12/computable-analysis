import ComputableAnalysis.FTA.ReconstructionComparison

namespace ComputableAnalysis.RepresentedPolynomial

def reconstructionWidth (xs ys : List (QComplex × ComplexCert)) (z : QComplex)
    (n : Nat) : Rat :=
  ((peelingValue xs (ofQComplex z)).raw.compute n).width +
  ((peelingValue ys (ofQComplex z)).raw.compute n).width +
  ((peelingValue xs (ofQComplex z)).raw.compute n).height +
  ((peelingValue ys (ofQComplex z)).raw.compute n).height

def reconstructionAdequate (xs ys : List (QComplex × ComplexCert)) (z : QComplex)
    (eps : QPos) (n : Nat) : Bool := decide (reconstructionWidth xs ys z n ≤ eps.val)

theorem reconstructionAdequate_eventually (xs ys : List (QComplex × ComplexCert))
    (z : QComplex) (eps : QPos) :
    ∃ N, ∀ n, N ≤ n → reconstructionAdequate xs ys z eps n = true := by
  let quarter : QPos := ⟨eps.val/4, by rw [Rat.div_def]; exact Rat.mul_pos eps.property (by decide +kernel)⟩
  obtain ⟨N, hN⟩ := (peelingValue xs (ofQComplex z)).valid.2.2 quarter
  obtain ⟨M, hM⟩ := (peelingValue ys (ofQComplex z)).valid.2.2 quarter
  refine ⟨max N M, ?_⟩
  intro n hn
  have hx := hN n (by omega)
  have hy := hM n (by omega)
  have hb : reconstructionWidth xs ys z n ≤ eps.val := by
    change _ ≤ eps.val/4 ∧ _ ≤ eps.val/4 at hx hy
    unfold reconstructionWidth
    grind
  simpa [reconstructionAdequate] using hb

/-- Executable search; the shrinking-box proof supplies termination only. -/
def reconstructionStage (xs ys : List (QComplex × ComplexCert)) (z : QComplex)
    (eps : QPos) (start : Nat) : Nat :=
  RiemannHilbert.PrecisionSearch.firstFrom (reconstructionAdequate xs ys z eps)
    (reconstructionAdequate_eventually xs ys z eps) start

theorem reconstructionStage_spec (xs ys : List (QComplex × ComplexCert))
    (z : QComplex) (eps : QPos) (start : Nat) :
    start ≤ reconstructionStage xs ys z eps start ∧
    reconstructionWidth xs ys z (reconstructionStage xs ys z eps start) ≤ eps.val := by
  have h := RiemannHilbert.PrecisionSearch.firstFrom_spec
    (reconstructionAdequate xs ys z eps) (reconstructionAdequate_eventually xs ys z eps) start
  exact ⟨h.1, by simpa [reconstructionStage, reconstructionAdequate] using h.2⟩

theorem reconstructionStage_later_width (xs ys : List (QComplex × ComplexCert))
    (z : QComplex) (eps : QPos) (start n : Nat)
    (hn : reconstructionStage xs ys z eps start ≤ n) :
    reconstructionWidth xs ys z n ≤ eps.val := by
  have hx := QBox.width_height_le_of_nested
    (ComplexRaw.valid_nestedIn (peelingValue xs (ofQComplex z)).valid hn)
  have hy := QBox.width_height_le_of_nested
    (ComplexRaw.valid_nestedIn (peelingValue ys (ofQComplex z)).valid hn)
  have hs := (reconstructionStage_spec xs ys z eps start).2
  unfold reconstructionWidth at *
  grind

theorem reconstructionStage_bound (xs ys : List (QComplex × ComplexCert))
    (z : QComplex) (eps : QPos) (start : Nat)
    (h : (peelingValue xs (ofQComplex z)).raw.Equiv
      (peelingValue ys (ofQComplex z)).raw) :
    let n := reconstructionStage xs ys z eps start
    QComplex.normBound (QComplex.sub
      (PolynomialDirection.finitePeelingValue (sampledPeeling xs n) z)
      (PolynomialDirection.finitePeelingValue (sampledPeeling ys n) z)) ≤ eps.val :=
  Rat.le_trans (sampledPeeling_comparison xs ys z _ h)
    (reconstructionStage_spec xs ys z eps start).2

/-- Actual peelings admit arbitrary comparison precision at every later stage,
allowing a common stage with the separately computed remainder precision. -/
theorem approximatePeeling_precision_bound (p : Coefficients) (hp : Monic p)
    (eps eta tolerance : QPos) (start stop searchStart n : Nat) (z : QComplex)
    (hn : reconstructionStage (approximatePeeling p hp eps start)
      (approximatePeeling p hp eta stop) z tolerance searchStart ≤ n) :
    QComplex.normBound (QComplex.sub
      (PolynomialDirection.finitePeelingValue
        (sampledPeeling (approximatePeeling p hp eps start) n) z)
      (PolynomialDirection.finitePeelingValue
        (sampledPeeling (approximatePeeling p hp eta stop) n) z)) ≤ tolerance.val :=
  Rat.le_trans (approximatePeeling_comparison p hp eps eta start stop n z)
    (reconstructionStage_later_width _ _ z tolerance searchStart n hn)

end ComputableAnalysis.RepresentedPolynomial
