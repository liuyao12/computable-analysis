import ComputableAnalysis.FTA.FactorSelectionEvidence

namespace ComputableAnalysis.RepresentedPolynomial

/-- Finite telescoping of the successive-center budgets gives a tail bound. -/
theorem coherentCenters_tail (centers : Nat → QComplex) (radius : Nat → Rat)
    (hstep : ∀ n, QComplex.normBound (QComplex.sub (centers (n+1)) (centers n)) ≤
      radius n-radius (n+1)) (k n : Nat) (hkn : k ≤ n) :
    QComplex.normBound (QComplex.sub (centers n) (centers k)) ≤ radius k-radius n := by
  induction n with
  | zero =>
    have hk : k = 0 := by omega
    subst k
    change QComplex.normBound (QComplex.sub (centers 0) (centers 0)) ≤ radius 0-radius 0
    simp [QComplex.normBound, QComplex.sub, QComplex.add, QComplex.neg, qabs] <;> grind
  | succ n ih =>
    by_cases h : k ≤ n
    · have ht := ih h
      have hs := hstep n
      have hid : QComplex.sub (centers (n+1)) (centers k) =
          QComplex.add (QComplex.sub (centers (n+1)) (centers n))
            (QComplex.sub (centers n) (centers k)) := by
        cases centers (n+1); cases centers n; cases centers k
        simp only [QComplex.sub, QComplex.add, QComplex.neg, QComplex.mk.injEq]
        constructor <;> grind
      rw [hid]
      have hb := QComplex.normBound_add_le
        (QComplex.sub (centers (n+1)) (centers n)) (QComplex.sub (centers n) (centers k))
      grind
    · have hk : k = n+1 := by omega
      subst k
      simp [QComplex.normBound, QComplex.sub, QComplex.add, QComplex.neg, qabs] <;> grind

def centerCandidates (centers : Nat → QComplex) : ComplexRaw where
  compute n := QBox.point (centers n)

/-- The supplied finite step estimates imply the future-box condition used
by the executable prefix-intersection construction. -/
theorem coherentCenters_future (centers : Nat → QComplex) (radius : Nat → Rat)
    (hr : ∀ n, 0 ≤ radius n)
    (hstep : ∀ n, QComplex.normBound (QComplex.sub (centers (n+1)) (centers n)) ≤
      radius n-radius (n+1)) (k n : Nat) (hkn : k ≤ n) :
    ((centerCandidates centers).compute n).NestedIn
      (QBox.expand ((centerCandidates centers).compute k) (radius k)) := by
  have ht := coherentCenters_tail centers radius hstep k n hkn
  have hn := hr n
  have ha := qabs_nonneg ((centers n).re-(centers k).re)
  have hb := qabs_nonneg ((centers n).im-(centers k).im)
  have ar := neg_qabs_le_self ((centers n).re-(centers k).re)
  have br := self_le_qabs ((centers n).re-(centers k).re)
  have ai := neg_qabs_le_self ((centers n).im-(centers k).im)
  have bi := self_le_qabs ((centers n).im-(centers k).im)
  change qabs ((centers n).re + -(centers k).re) +
    qabs ((centers n).im + -(centers k).im) ≤ _ at ht
  change ((centers k).re-radius k ≤ (centers n).re ∧
    (centers k).im-radius k ≤ (centers n).im) ∧
    ((centers n).re ≤ (centers k).re+radius k ∧
    (centers n).im ≤ (centers k).im+radius k)
  grind [Rat.sub_eq_add_neg]

/-- Coherent executable rational centers produce a valid represented complex
number by finite box intersections, without an abstract completion. -/
theorem coherentCenters_valid (centers : Nat → QComplex) (radius : Nat → Rat)
    (hr : ∀ n, 0 ≤ radius n)
    (hshrink : ShrinksToZero radius)
    (hstep : ∀ n, QComplex.normBound (QComplex.sub (centers (n+1)) (centers n)) ≤
      radius n-radius (n+1)) :
    (ComplexRaw.cauchyStabilize (centerCandidates centers) radius).Valid := by
  apply ComplexRaw.cauchyStabilize_valid
  · intro n; exact QComplex.le_refl _
  · intro eps; refine ⟨0, ?_⟩
    intro n hn
    have he := eps.property
    simp only [centerCandidates, QBox.point, QBox.width, QBox.height]
    constructor <;> grind
  · exact coherentCenters_future centers radius hr hstep
  · exact hshrink

end ComputableAnalysis.RepresentedPolynomial
