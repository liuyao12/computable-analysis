import ComputableAnalysis.FTA.EarlyCoefficientBudget
import ComputableAnalysis.ComplexReciprocalCalculus

namespace ComputableAnalysis.PolynomialDirection
open QComplex

/-- Positive residual and a significant coefficient force their cross-product
to be significant. This uses rational reciprocal arithmetic, not square roots. -/
theorem residual_cross_bound (c a : QComplex) (C : Rat) (rho theta : QPos)
    (hC : 0 ≤ C) (hc : normBound c ≤ C) (hrho : rho.val ≤ normSq c)
    (ha : theta.val < normBound a) :
    theta.val*rho.val < C * normBound (mul (conj c) a) := by
  have hconj : normBound (conj c) = normBound c := by simp [normBound, conj, qabs_neg]
  have hs : normSq (conj c) = normSq c := by simp only [normSq, conj]; grind
  have hpos : 0 < normSq (conj c) := by rw [hs]; have := rho.property; grind
  have hinv := inverse_normBound_le hC rho.property (by rw [hconj]; exact hc)
    (by rw [hs]; exact hrho)
  have hi : mul (inverse (conj c)) (conj c) = one := by
    rw [mul_comm_cert]
    exact mul_inverse_of_normSq_ne_zero _ (Rat.ne_of_gt hpos)
  have hid : mul (inverse (conj c)) (mul (conj c) a) = a := by
    rw [← mul_assoc_cert, hi, one_mul_cert]
  have hm := normBound_mul_le (inverse (conj c)) (mul (conj c) a)
  rw [hid] at hm
  have hb := Rat.mul_le_mul_of_nonneg_right hinv (normBound_nonneg (mul (conj c) a))
  have hscale := Rat.mul_le_mul_of_nonneg_left (Rat.le_trans hm hb) (Rat.le_of_lt rho.property)
  have hstrict := Rat.mul_lt_mul_of_pos_right ha rho.property
  have hcancel := Rat.mul_inv_cancel rho.val (Rat.ne_of_gt rho.property)
  have heq : rho.val*(C*rho.val⁻¹*normBound (mul (conj c) a)) =
      C*normBound (mul (conj c) a) := by
    grind [Rat.mul_assoc, Rat.mul_comm]
  rw [heq] at hscale
  grind

def residualInwardMargin (order : Nat) (ho : 0 < order) (C : Rat) (hC : 0 ≤ C)
    (rho theta : QPos) : QPos :=
  ⟨theta.val*rho.val/(2*(C+1)*paletteConstant order ho), by
    rw [Rat.div_def]
    exact Rat.mul_pos (Rat.mul_pos theta.property rho.property)
      (Rat.inv_pos.mpr (Rat.mul_pos (by grind) (paletteConstant_pos order ho)))⟩

/-- A computed inward margin depends only on a residual floor, coefficient
threshold, value bound, and order, rather than on the tested point. -/
theorem residual_palette_inward (order : Nat) (ho : 0 < order) (c a : QComplex)
    (C : Rat) (hC : 0 ≤ C) (rho theta : QPos) (hc : normBound c ≤ C)
    (hrho : rho.val ≤ normSq c) (ha : theta.val < normBound a) :
    let eta := (residualInwardMargin order ho C hC rho theta).val
    let d := selectedPaletteDirection order ho (mul (conj c) a) eta
    (mul (mul (conj c) a) (pow d order)).re < -eta := by
  let eta := (residualInwardMargin order ho C hC rho theta).val
  have heta : 0 < eta := (residualInwardMargin order ho C hC rho theta).property
  have hb := residual_cross_bound c a C rho theta hC hc hrho ha
  have hden : 0 < 2*(C+1)*paletteConstant order ho :=
    Rat.mul_pos (by grind) (paletteConstant_pos order ho)
  have heq : (2*(C+1)*paletteConstant order ho)*eta = theta.val*rho.val := by
    change (2*(C+1)*paletteConstant order ho)*
      (theta.val*rho.val/(2*(C+1)*paletteConstant order ho)) = _
    rw [Rat.div_def, ← Rat.mul_assoc,
      Rat.mul_comm (2*(C+1)*paletteConstant order ho) (theta.val*rho.val), Rat.mul_assoc,
      Rat.mul_inv_cancel _ (Rat.ne_of_gt hden), Rat.mul_one]
  have hp := normBound_nonneg (mul (conj c) a)
  have hlarge : eta*paletteConstant order ho < normBound (mul (conj c) a) := by
    have hm := Rat.mul_le_mul_of_nonneg_right (show C ≤ 2*(C+1) by grind) hp
    have hbound : 2*(C+1)*(eta*paletteConstant order ho) <
        2*(C+1)*normBound (mul (conj c) a) := by grind
    exact Rat.lt_of_mul_lt_mul_left hbound (by grind)
  exact selectedPaletteDirection_spec order ho (mul (conj c) a) eta
    (Rat.le_of_lt heta) hlarge

end ComputableAnalysis.PolynomialDirection
