import ComputableAnalysis.FTA.FiniteFactorFamilyMatching

namespace ComputableAnalysis.RepresentedPolynomial

def squaredTolerance (delta : QPos) : QPos :=
  ⟨delta.val^2, by
    rw [Rat.pow_succ, Rat.pow_succ, Rat.pow_zero, Rat.one_mul]
    exact Rat.mul_pos delta.property delta.property⟩

def normWidthAdequate (z : ComplexCert) (delta : QPos) (n : Nat) : Bool :=
  decide (((normValue z).real.compute n).width ≤ delta.val^2)

theorem normWidthAdequate_eventually (z : ComplexCert) (delta : QPos) :
    ∃ N, ∀ n, N ≤ n → normWidthAdequate z delta n = true := by
  obtain ⟨N, hN⟩ := (normValue z).real.valid.2.2 (squaredTolerance delta)
  refine ⟨N, ?_⟩
  intro n hn
  have hb : ((normValue z).real.compute n).width ≤ delta.val^2 := hN n hn
  simpa [normWidthAdequate] using hb

def residualNormStage (z : ComplexCert) (delta : QPos) : Nat :=
  RiemannHilbert.PrecisionSearch.firstFrom (normWidthAdequate z delta)
    (normWidthAdequate_eventually z delta) 0

theorem residualNormStage_width (z : ComplexCert) (delta : QPos) (n : Nat)
    (hn : residualNormStage z delta ≤ n) : ((normValue z).real.compute n).width ≤ delta.val^2 := by
  have hs := (RiemannHilbert.PrecisionSearch.firstFrom_spec (normWidthAdequate z delta)
    (normWidthAdequate_eventually z delta) 0).2
  have hb : ((normValue z).real.compute (residualNormStage z delta)).width ≤ delta.val^2 := by
    simpa [residualNormStage, normWidthAdequate] using hs
  have hnest := (normValue z).real.valid.2.1 (residualNormStage z delta) n hn
  change ((normValue z).real.compute (residualNormStage z delta)).lo ≤
      ((normValue z).real.compute n).lo ∧
      ((normValue z).real.compute n).lo ≤ ((normValue z).real.compute n).hi ∧
      ((normValue z).real.compute n).hi ≤
        ((normValue z).real.compute (residualNormStage z delta)).hi at hnest
  unfold QInterval.width at *
  grind

/-- Exact squared-residual control yields an explicit shrinking bound on every
rational point in sufficiently precise represented-value boxes. -/
theorem residualNormStage_bound (z : ComplexCert) (delta : QPos)
    (hsmall : (normValue z).real.preferred.Le (RealRaw.ofRat (delta.val^2)))
    (n : Nat) (hn : residualNormStage z delta ≤ n) (w : QComplex)
    (hl : (z.raw.compute n).lo ≤ w) (hh : w ≤ (z.raw.compute n).hi) :
    QComplex.normBound w ≤ 2*delta.val := by
  have hwidth := residualNormStage_width z delta n hn
  have hcontains := (normValue_contains z n w hl hh).2
  have hlo := hsmall n n
  change ((normValue z).real.compute n).lo ≤ delta.val^2 at hlo
  have hs := PolynomialCoercivity.normBound_square_le w
  have hn0 := QComplex.normBound_nonneg w
  have hd := delta.property
  unfold QInterval.width at hwidth
  have hscore : QComplex.normSq w ≤ 2*delta.val^2 := by grind
  simp only [Rat.pow_succ, Rat.pow_zero, Rat.one_mul] at hscore
  have hsq : QComplex.normBound w*QComplex.normBound w ≤ (2*delta.val)*(2*delta.val) := by grind
  by_cases hb : QComplex.normBound w ≤ 2*delta.val
  · exact hb
  · have hlt : 2*delta.val < QComplex.normBound w := by grind
    have hpos : 0 < QComplex.normBound w := by grind
    have h1 := Rat.mul_lt_mul_of_pos_left hlt hpos
    have h2 := Rat.mul_lt_mul_of_pos_right hlt (show 0 < 2*delta.val by grind)
    grind

/-- Actual approximate-peeling remainders satisfy the shrinking norm bound,
with their sampling precision constructed beneath the statement. -/
theorem approximatePeeling_remainder_norm_bound (p : Coefficients) (hp : Monic p)
    (delta : QPos) (start : Nat) (item : QComplex × ComplexCert)
    (hitem : item ∈ approximatePeeling p hp (squaredTolerance delta) start)
    (n : Nat) (hn : residualNormStage item.2 delta ≤ n) (w : QComplex)
    (hl : (item.2.raw.compute n).lo ≤ w) (hh : w ≤ (item.2.raw.compute n).hi) :
    QComplex.normBound w ≤ 2*delta.val :=
  residualNormStage_bound item.2 delta
    (approximatePeeling_remainders p hp (squaredTolerance delta) start item hitem) n hn w hl hh

/-- One executable sampling stage controls the entire finite remainder list. -/
def peelingRemainderStage (items : List (QComplex × ComplexCert)) (delta : QPos) : Nat :=
  items.foldr (fun item stage => max (residualNormStage item.2 delta) stage) 0

theorem peelingRemainderStage_le (items : List (QComplex × ComplexCert)) (delta : QPos)
    (item : QComplex × ComplexCert) (hitem : item ∈ items) :
    residualNormStage item.2 delta ≤ peelingRemainderStage items delta := by
  induction items with
  | nil => simp at hitem
  | cons x xs ih =>
    rcases List.mem_cons.mp hitem with heq | hitem
    · subst item
      change residualNormStage x.2 delta ≤ max (residualNormStage x.2 delta) (peelingRemainderStage xs delta)
      omega
    · have ht := ih hitem
      change residualNormStage item.2 delta ≤ max (residualNormStage x.2 delta) (peelingRemainderStage xs delta)
      omega

def sampledPeeling (items : List (QComplex × ComplexCert)) (n : Nat) : List (QComplex × QComplex) :=
  items.map (fun item => (item.1, (item.2.raw.compute n).lo))

/-- All actual lower-corner remainder samples share the shrinking norm bound
at every stage after the computed finite maximum. -/
theorem sampledPeeling_remainders_bound (p : Coefficients) (hp : Monic p)
    (delta : QPos) (start n : Nat)
    (hn : peelingRemainderStage (approximatePeeling p hp (squaredTolerance delta) start) delta ≤ n) :
    ∀ x ∈ sampledPeeling (approximatePeeling p hp (squaredTolerance delta) start) n,
      QComplex.normBound x.2 ≤ 2*delta.val := by
  intro x hx
  obtain ⟨item, hi, rfl⟩ := List.mem_map.mp hx
  have hs := peelingRemainderStage_le (approximatePeeling p hp (squaredTolerance delta) start) delta item hi
  exact approximatePeeling_remainder_norm_bound p hp delta start item hi n (by omega) _
    (QComplex.le_refl _) (ComplexRaw.valid_ordered item.2.valid n)

end ComputableAnalysis.RepresentedPolynomial
