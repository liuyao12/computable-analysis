import ComputableAnalysis.FTA.ActualFactorSelection

namespace ComputableAnalysis.RepresentedPolynomial

def firstPeelingFactor (p : Coefficients) (error : QPos) : QComplex × ComplexCert :=
  let eps := squaredTolerance (peelingTolerance p error)
  let r := approximatePeelPoint p eps 0
  (r, (syntheticDivide (ofQComplex r) p).2)

theorem firstPeelingFactor_member (p : Coefficients) (hp : Monic p)
    (hd : 2 ≤ p.length) (error : QPos) :
    firstPeelingFactor p error ∈ errorBudgetPeeling p hp error 0 := by
  unfold errorBudgetPeeling
  rw [approximatePeeling]
  simp only [dif_pos hd]
  exact List.mem_cons_self

/-- The initial record and every subsequent factor are computed from the
polynomial and the supplied step schedule. -/
def computedFactorChain (p : Coefficients) (hp : Monic p) (steps : Nat → QPos)
    (n : Nat) : QComplex × ComplexCert :=
  peelingFactorChain p hp steps (firstPeelingFactor p (consecutivePeelingAllowance p steps 0)) n

theorem computedFactorChain_member (p : Coefficients) (hp : Monic p)
    (hd : 2 ≤ p.length) (steps : Nat → QPos) (n : Nat) :
    computedFactorChain p hp steps n ∈
      errorBudgetPeeling p hp (consecutivePeelingAllowance p steps n) 0 :=
  peelingFactorChain_member p hp steps _ (firstPeelingFactor_member p hp hd _) n

theorem computedFactorChain_step (p : Coefficients) (hp : Monic p)
    (hd : 2 ≤ p.length) (steps : Nat → QPos) (n : Nat) :
    QComplex.normSq (QComplex.sub (computedFactorChain p hp steps n).1
      (computedFactorChain p hp steps (n+1)).1) < (steps n).val :=
  peelingFactorChain_step p hp steps _ (firstPeelingFactor_member p hp hd _) n

theorem computedFactorChain_bound (p : Coefficients) (hp : Monic p)
    (hd : 2 ≤ p.length) (steps : Nat → QPos) (n : Nat) :
    QComplex.normBound (computedFactorChain p hp steps n).1 ≤ wholeFactorRadius p :=
  approximatePeeling_computed_bound p hp _ 0 _ (computedFactorChain_member p hp hd steps n)

end ComputableAnalysis.RepresentedPolynomial
