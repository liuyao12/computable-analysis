import ComputableAnalysis.FTA.CriticalWeights

/-! Gauss--Lucas for arbitrary represented complex coefficients. Convex-hull
membership is witnessed by a finite nonnegative real combination of roots,
with total weight exactly one. -/
namespace ComputableAnalysis.RepresentedPolynomial
open Arithmetic ComputableCoefficient
open CriticalWeights

/-- Membership in the convex hull of polynomial roots, expressed directly
by finite nonnegative real weights. No convexity or critical-point conclusion
is assumed in this definition. -/
def InRootConvexHull (p : Coefficients) (z : ComplexCert) : Prop :=
  ∃ ws : WeightedRoots,
    (∀ a ∈ ws, Root p a.1 ∧ RealRaw.zero.Le a.2.real.preferred) ∧
    (total ws).real.preferred.Equiv (RealRaw.ofRat 1) ∧
    (moment ws).raw.Equiv z.raw

private theorem qext {a b : QComplex} (hr : a.re = b.re) (hi : a.im = b.im) : a = b := by
  cases a; cases b; simp_all

theorem rootProduct_zero_of_mem (rs : List ComplexCert) (r : ComplexCert) (hr : r ∈ rs) :
    (rootProduct rs r).raw.Equiv zero.raw := by
  induction rs with
  | nil => simp at hr
  | cons a rs ih =>
      rcases List.mem_cons.mp hr with h | h
      · subst r
        exact certTrans (certMulCongr (sub_self a) (certRefl _)) (zero_mul _)
      · exact certTrans (certMulCongr (certRefl _) (ih h)) (certMulZero _)

theorem rootProduct_nonzero (rs : List ComplexCert) (z : ComplexCert)
    (hz : ∀ r ∈ rs, ¬ z.raw.Equiv r.raw) : ¬ (rootProduct rs z).raw.Equiv zero.raw := by
  induction rs with
  | nil => exact certOneNonzero
  | cons r rs ih =>
      exact mul_nonzero (fun h => hz r (by simp) (certSubEqZero h))
        (ih (fun r hr => hz r (by simp [hr])))

theorem root_in_convexHull (p : Coefficients) (z : ComplexCert) (hz : Root p z) :
    InRootConvexHull p z := by
  refine ⟨[(z, .rational 1)], ?_, ?_, ?_⟩
  · intro a ha
    have ha : a = (z, Value.rational 1) := by simpa using ha
    subst a
    exact ⟨hz, fun _ _ => by change (0 : Rat) ≤ 1; decide +kernel⟩
  · apply Value.equiv_of_samples _ (.rational 1) 0
    intros
    change (1 : Rat) + 0 = 1
    decide +kernel
  · exact certTrans (add_zero _) (certOneMul z)

private theorem total_weights_positive (r : ComplexCert) (rs : List ComplexCert) (z : ComplexCert)
    (hz : ∀ a ∈ rs, ¬ z.raw.Equiv a.raw) :
    ∃ N, 0 < ((total (weights (r :: rs) z)).real.compute N).lo := by
  let w := normValue (rootProduct rs z)
  let t := total (weights (r :: rs) z)
  obtain ⟨N, hN⟩ := exists_positive_norm_stage (rootProduct rs z) (rootProduct_nonzero rs z hz)
  let δ := (w.real.compute N).lo
  have hδ : 0 < δ := hN
  have half : 0 < δ/2 := by exact Rat.mul_pos hδ (by decide +kernel)
  obtain ⟨M, hM⟩ := t.real.valid.2.2 ⟨δ/2, half⟩
  let k := max M N
  let l := max (w.observation N) (t.observation k)
  let s : Real → Rat := fun a => (a.compute l).lo
  have hs := samples_lower l
  have hw := w.encloses N l (Nat.le_max_left _ _) s hs
  have ht := t.encloses k l (Nat.le_max_right _ _) s hs
  have htail : 0 ≤ (total (scale (normValue (sub z r)) (weights rs z))).sample s := by
    apply total_sample_nonneg
    intro a ha s
    obtain ⟨b, hb, rfl⟩ := List.mem_map.mp ha
    exact Rat.mul_nonneg (norm_sample_nonneg _ _) ((weights_support rs z b hb).2 s)
  have hwidth := hM k (Nat.le_max_left _ _)
  change (t.real.compute k).hi - (t.real.compute k).lo ≤ δ/2 at hwidth
  have hlower : δ ≤ t.sample s := by
    change δ ≤ w.sample s + (total (scale (normValue (sub z r)) (weights rs z))).sample s
    have hwlo : δ ≤ w.sample s := hw.1
    grind
  refine ⟨k, ?_⟩
  change 0 < (t.real.compute k).lo
  have hhalf : δ/2+δ/2=δ := by grind
  grind

private theorem normalize_weights (ws : WeightedRoots) (z : ComplexCert)
    (hpos : ∃ N, 0 < ((total ws).real.compute N).lo)
    (hw : ∀ a ∈ ws, ∀ s, 0 ≤ a.2.sample s)
    (hbalance : (mul z (realArgument (total ws).real)).raw.Equiv (moment ws).raw) :
    ∃ vs : WeightedRoots,
      (∀ a ∈ vs, ∃ b ∈ ws, a.1 = b.1 ∧ RealRaw.zero.Le a.2.real.preferred) ∧
      (total vs).real.preferred.Equiv (RealRaw.ofRat 1) ∧ (moment vs).raw.Equiv z.raw := by
  obtain ⟨N, hN⟩ := hpos
  let t := total ws
  let v := Value.positiveInv t N hN
  have hv : (Value.mul v t).real.preferred.Equiv (RealRaw.ofRat 1) := by
    apply Value.equiv_of_samples _ (.rational 1) (t.observation N)
    intro m hm s hs
    have ht := t.encloses N m hm s hs
    have hp : 0 < t.sample s := by have := ht.1; grind
    change (t.sample s)⁻¹ * t.sample s = 1
    rw [Rat.mul_comm]
    exact Rat.mul_inv_cancel _ (Rat.ne_of_gt hp)
  refine ⟨scale v ws, ?_, ?_, ?_⟩
  · intro a ha
    obtain ⟨b, hb, rfl⟩ := List.mem_map.mp ha
    refine ⟨b, hb, rfl, ?_⟩
    intro n m
    let k := max (t.observation N) ((Value.mul v b.2).observation m)
    let s : Real → Rat := fun x => (x.compute k).lo
    have hs := samples_lower k
    have ht := t.encloses N k (Nat.le_max_left _ _) s hs
    have hp : 0 < t.sample s := by have := ht.1; grind
    have he := (Value.mul v b.2).encloses m k (Nat.le_max_right _ _) s hs
    have hsample : 0 ≤ (Value.mul v b.2).sample s :=
      Rat.mul_nonneg (Rat.le_of_lt (Rat.inv_pos.mpr hp)) (hw b hb s)
    exact Rat.le_trans hsample he.2
  · exact RealRaw.equiv_trans (total (scale v ws)).real.valid (Value.mul v t).real.valid
      (RealRaw.ofRat_valid 1) (total_scale v ws) hv
  · have hprod : (mul (realArgument v.real) (realArgument t.real)).raw.Equiv one.raw :=
      certTrans (realArgument_mul v.real t.real)
        (ComplexRaw.ofRealRaw_equiv_of_equiv (y := RealRaw.ofRat 1)
          (Value.mul v t).real.valid (RealRaw.ofRat_valid 1) hv)
    refine certTrans (moment_scale v ws)
      (certTrans (certMulCongr (certRefl _) (ComplexRaw.equiv_symm hbalance)) ?_)
    have hperm : (mul (realArgument v.real) (mul z (realArgument t.real))).raw.Equiv
        (mul (mul (realArgument v.real) (realArgument t.real)) z).raw := by
      apply Expression.equiv_of_samples
        (.mul (.parameter (realArgument v.real)) (.mul (.parameter z) (.parameter (realArgument t.real))))
        (.mul (.mul (.parameter (realArgument v.real)) (.parameter (realArgument t.real))) (.parameter z))
      intro s
      apply qext <;> simp [Expression.sample, QComplex.mul] <;> grind
    exact certTrans hperm (certTrans (certMulCongr hprod (certRefl z)) (certOneMul z))

/-- Every critical point of a nonconstant complex polynomial is in the
convex hull of its roots. All coefficients, roots, weights, and arguments
are arbitrary valid represented values. -/
theorem gauss_lucas (q : Coefficients) (c : ComplexCert)
    (hq : 0 < q.length) (hc : ¬ c.raw.Equiv zero.raw)
    (z : ComplexCert) (hz : Root (derivative (q ++ [c])) z) :
    InRootConvexHull (q ++ [c]) z := by
  classical
  obtain ⟨rs, hlen, he, hd⟩ := complex_factorization_with_derivative q c hc
  have hroot : ∀ r ∈ rs, Root (q ++ [c]) r := by
    intro r hr
    exact certTrans (he r) (certTrans
      (certMulCongr (certRefl c) (rootProduct_zero_of_mem rs r hr)) (certMulZero c))
  by_cases hr : ∃ r ∈ rs, z.raw.Equiv r.raw
  · obtain ⟨r, hr, hzr⟩ := hr
    exact root_in_convexHull _ z (root_congr (equivalent_refl _) (ComplexRaw.equiv_symm hzr) (hroot r hr))
  have hapart : ∀ r ∈ rs, ¬ z.raw.Equiv r.raw := fun r hm h => hr ⟨r, hm, h⟩
  have hd0 : (rootProductDerivative rs z).raw.Equiv zero.raw := by
    apply mul_cancel_left_of_nonzero hc
    exact certTrans (ComplexRaw.equiv_symm (hd z))
      (certTrans (ComplexRaw.equiv_symm (eval_derivative _ z))
        (certTrans hz (ComplexRaw.equiv_symm (certMulZero c))))
  have hbalance : (mul z (realArgument (total (weights rs z)).real)).raw.Equiv
      (moment (weights rs z)).raw :=
    certTrans (barycenter_identity rs z)
      (certTrans (certAddCongr (certRefl _) (certTrans
        (certMulCongr (certRefl _) (certTrans (certConjCongr hd0) conj_zero)) (certMulZero _))) (add_zero _))
  have hpos : ∃ N, 0 < ((total (weights rs z)).real.compute N).lo := by
    cases rs with
    | nil => simp at hlen; omega
    | cons r rs => exact total_weights_positive r rs z (fun a ha => hapart a (by simp [ha]))
  obtain ⟨vs, hv, hsum, hmoment⟩ := normalize_weights (weights rs z) z hpos
    (fun a ha => (weights_support rs z a ha).2) hbalance
  refine ⟨vs, ?_, hsum, hmoment⟩
  intro a ha
  obtain ⟨b, hb, hab, hnonneg⟩ := hv a ha
  exact ⟨hab ▸ hroot b.1 (weights_support rs z b hb).1, hnonneg⟩

end ComputableAnalysis.RepresentedPolynomial
