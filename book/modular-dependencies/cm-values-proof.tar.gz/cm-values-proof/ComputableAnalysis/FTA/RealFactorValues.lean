import ComputableAnalysis.FTA.RealFactorization

/-! The real factorization identity as equality of raw real values. -/
namespace ComputableAnalysis.RepresentedPolynomial
open ComputableCoefficient

private theorem expression_real_bridge (e : Arithmetic.Expression) (v : Value)
    (hobs : ∀ n, v.observation n ≤ n)
    (hsample : ∀ n, e.sample (fun a => (a.raw.compute n).lo) =
      QComplex.ofRat (v.sample (fun a => (a.compute n).lo))) :
    e.value.raw.Equiv (realArgument v.real).raw := by
  intro n
  have he := e.contains n (fun a => (a.raw.compute n).lo)
    (fun a => ⟨QComplex.le_refl _, ComplexRaw.valid_ordered a.valid n⟩)
  have hv := v.encloses n n (hobs n) _ (samples_lower n)
  rw [hsample n] at he
  apply (ComplexRaw.compareAt_overlap_iff _ _ n n).2
  change ((e.value.raw.compute n).lo.re ≤ (v.real.compute n).hi ∧
    (e.value.raw.compute n).lo.im ≤ (0 : Rat)) ∧
    ((v.real.compute n).lo ≤ (e.value.raw.compute n).hi.re ∧
    (0 : Rat) ≤ (e.value.raw.compute n).hi.im)
  exact ⟨⟨Rat.le_trans he.1.1 hv.2, he.1.2⟩, ⟨Rat.le_trans hv.1 he.2.1, he.2.2⟩⟩

theorem realArgument_add (a b : Real) :
    (add (realArgument a) (realArgument b)).raw.Equiv
      (realArgument (Value.add (.parameter a) (.parameter b)).real).raw := by
  apply expression_real_bridge
    (.add (.parameter (realArgument a)) (.parameter (realArgument b)))
  · intro n; simp [Value.add, Value.parameter]
  · intro n
    simp [Arithmetic.Expression.sample, Value.add, Value.parameter,
      realArgument, ComplexRaw.ofRealRaw, QComplex.add, QComplex.ofRat, Real.compute] <;> grind

theorem realArgument_sub (a b : Real) :
    (sub (realArgument a) (realArgument b)).raw.Equiv
      (realArgument (Value.sub (.parameter a) (.parameter b)).real).raw := by
  apply expression_real_bridge
    (.add (.parameter (realArgument a)) (.neg (.parameter (realArgument b))))
  · intro n; simp [Value.sub, Value.add, Value.neg, Value.parameter]
  · intro n
    simp [Arithmetic.Expression.sample, Value.sub, Value.add, Value.neg, Value.parameter,
      realArgument, ComplexRaw.ofRealRaw, QComplex.add, QComplex.neg, QComplex.ofRat, Real.compute] <;> grind

theorem realArgument_mul (a b : Real) :
    (mul (realArgument a) (realArgument b)).raw.Equiv
      (realArgument (Value.mul (.parameter a) (.parameter b)).real).raw := by
  apply expression_real_bridge
    (.mul (.parameter (realArgument a)) (.parameter (realArgument b)))
  · intro n; simp [Value.mul, Value.parameter]
  · intro n
    simp [Arithmetic.Expression.sample, Value.mul, Value.parameter,
      realArgument, ComplexRaw.ofRealRaw, QComplex.mul, QComplex.ofRat, Real.compute] <;> grind

def RealFactor.realValue : RealFactor → Real → Value
  | .linear u, x => .sub (.parameter x) (.parameter u)
  | .quadratic u v _, x => quadraticValue u v x

def realFactorValueProduct : List RealFactor → Real → Value
  | [], _ => .rational 1
  | f :: fs, x => .mul (f.realValue x) (realFactorValueProduct fs x)

/-- The explicit real formulas agree with their complex polynomial factors. -/
theorem RealFactor.eval_real (f : RealFactor) (x : Real) :
    (f.eval (realArgument x)).raw.Equiv (realArgument (f.realValue x).real).raw := by
  cases f with
  | linear u => exact realArgument_sub x u
  | quadratic u v hv => exact conjugate_pair_quadratic u v x

theorem realFactorProduct_real (fs : List RealFactor) (x : Real) :
    (realFactorProduct fs (realArgument x)).raw.Equiv
      (realArgument (realFactorValueProduct fs x).real).raw := by
  induction fs with
  | nil => exact certRefl one
  | cons f fs ih =>
      exact certTrans (certMulCongr (f.eval_real x) ih)
        (realArgument_mul (f.realValue x).real (realFactorValueProduct fs x).real)

/-- Real-coefficient Horner evaluation on the original raw representatives. -/
def realPolynomialValue : List Real → Real → Value
  | [], _ => .rational 0
  | a :: p, x => .add (.parameter a) (.mul (.parameter x) (realPolynomialValue p x))

theorem realPolynomialValue_bridge (p : List Real) (x : Real) :
    (eval (ofReal p) (realArgument x)).raw.Equiv
      (realArgument (realPolynomialValue p x).real).raw := by
  induction p with
  | nil => exact certRefl zero
  | cons a p ih =>
      exact certTrans (certAddCongr (certRefl (realArgument a))
        (certTrans (certMulCongr (certRefl (realArgument x)) ih)
          (realArgument_mul x (realPolynomialValue p x).real)))
        (realArgument_add a (Value.mul (.parameter x) (realPolynomialValue p x)).real)

/-- Real evaluation respects equivalent coefficient and argument representatives. -/
theorem realPolynomialValue_equiv {p q : List Real} (hp : Equivalent (ofReal p) (ofReal q))
    {x y : Real} (hxy : x.preferred.Equiv y.preferred) :
    (realPolynomialValue p x).real.preferred.Equiv (realPolynomialValue q y).real.preferred := by
  have harg : (realArgument x).raw.Equiv (realArgument y).raw :=
    ComplexRaw.ofRealRaw_equiv_of_equiv x.valid y.valid hxy
  exact ComplexRaw.realPart_equiv (certTrans
    (ComplexRaw.equiv_symm (realPolynomialValue_bridge p x))
    (certTrans (eval_equiv hp harg) (realPolynomialValue_bridge q y)))

set_option maxHeartbeats 1600000 in
/-- Every real polynomial with a nonzero leading coefficient factors into
real linear factors and quadratics `(x-u)^2+v^2` with nonzero `v`. The identity
is exact raw-real equality for every represented real argument. -/
theorem real_factorization (q : List Real) (c : Real)
    (hc : ¬ c.preferred.Equiv RealRaw.zero) :
    ∃ fs : List RealFactor, realFactorDegree fs = q.length ∧
      ∀ x : Real, (realPolynomialValue (q ++ [c]) x).real.preferred.Equiv
        (Value.mul (.parameter c) (realFactorValueProduct fs x)).real.preferred := by
  have hcn : ¬ (realArgument c).raw.Equiv zero.raw := by
    intro h
    exact hc (ComplexRaw.realPart_equiv h)
  obtain ⟨fs, hdeg, hfs⟩ := real_coefficients_factorization (ofReal q)
    (realCoefficients_ofReal q) (realArgument c) (IsReal.realArgument c) hcn
  refine ⟨fs, by simpa [ofReal] using hdeg, ?_⟩
  intro x
  have hf := hfs (realArgument x)
  have hemb : ofReal (q ++ [c]) = ofReal q ++ [realArgument c] := by simp only [ofReal, List.map_append, List.map_cons, List.map_nil]; rfl
  rw [← hemb] at hf
  have h := certTrans (ComplexRaw.equiv_symm (realPolynomialValue_bridge (q ++ [c]) x))
    (certTrans hf (certTrans (certMulCongr (certRefl (realArgument c)) (realFactorProduct_real fs x))
      (realArgument_mul c (realFactorValueProduct fs x).real)))
  exact ComplexRaw.realPart_equiv h

set_option maxHeartbeats 1600000 in
/-- The quadratic factors in the factorization have no real roots. -/
theorem quadraticValue_nonzero (u v : Real) (hv : ¬ v.preferred.Equiv RealRaw.zero) (x : Real) :
    ¬ (quadraticValue u v x).real.preferred.Equiv RealRaw.zero := by
  have hnr : ¬ IsReal (ofParts u v) := fun h => hv (IsReal.imag_zero h)
  have h₀ : ¬ (sub (realArgument x) (ofParts u v)).raw.Equiv zero.raw := by
    intro h
    exact hnr (IsReal.of_equiv (IsReal.realArgument x) (certSubEqZero h))
  have h₁ : ¬ (sub (realArgument x) (conj (ofParts u v))).raw.Equiv zero.raw := by
    intro h
    exact hnr (isReal_of_conj_real (IsReal.of_equiv (IsReal.realArgument x) (certSubEqZero h)))
  intro h
  have he : (realArgument (quadraticValue u v x).real).raw.Equiv zero.raw :=
    ComplexRaw.ofRealRaw_equiv_of_equiv (y := RealRaw.zero)
      (quadraticValue u v x).real.valid (RealRaw.ofRat_valid 0) h
  exact mul_nonzero h₀ h₁ (certTrans (conjugate_pair_quadratic u v x) he)

end ComputableAnalysis.RepresentedPolynomial
