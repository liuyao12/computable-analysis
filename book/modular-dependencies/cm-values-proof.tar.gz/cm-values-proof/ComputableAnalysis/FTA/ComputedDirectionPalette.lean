import ComputableAnalysis.FTA.DirectionPaletteBound
import ComputableAnalysis.FTA.NegativeDirectionSearch

namespace ComputableAnalysis.PolynomialDirection
open QComplex RepresentedPolynomial RiemannHilbert

def negativePowerTest (order : Nat) (d : QComplex) : Bool := decide ((pow d order).re < 0)

def negativePowerAdequate (order stage : Nat) : Bool :=
  (directionCandidates stage).any (negativePowerTest order)

theorem negativePowerAdequate_eventually (order : Nat) (ho : 0 < order) :
    ∃ N, ∀ n, N ≤ n → negativePowerAdequate order n = true := by
  obtain ⟨d, hd⟩ := exists_power_negative_real order ho
  refine ⟨rationalPointIndex d, ?_⟩
  intro n hn
  apply List.any_eq_true.mpr
  refine ⟨d, List.mem_map.mpr ⟨rationalPointIndex d,
    List.mem_range.mpr (by omega), rationalPoint_index d⟩, ?_⟩
  simpa [negativePowerTest] using hd

def negativePowerStage (order : Nat) (ho : 0 < order) : Nat :=
  PrecisionSearch.firstFrom (negativePowerAdequate order)
    (negativePowerAdequate_eventually order ho) 0

def negativePowerDirection (order : Nat) (ho : 0 < order) : QComplex :=
  firstPassing (negativePowerTest order) (directionCandidates (negativePowerStage order ho))

theorem negativePowerDirection_spec (order : Nat) (ho : 0 < order) :
    (pow (negativePowerDirection order ho) order).re < 0 := by
  have hs := (PrecisionSearch.firstFrom_spec (negativePowerAdequate order)
    (negativePowerAdequate_eventually order ho) 0).2
  have h := firstPassing_spec (negativePowerTest order)
    (directionCandidates (negativePowerStage order ho)) hs
  simpa [negativePowerTest, negativePowerDirection] using h

def imaginaryPowerDirection (order : Nat) : QComplex := ⟨1, smallStep order⟩

def paletteConstant (order : Nat) (ho : 0 < order) : Rat :=
  let b := pow (negativePowerDirection order ho) order
  let w := pow (imaginaryPowerDirection order) order
  (1 + (-b.re)⁻¹) + (1 + qabs w.re * (1 + (-b.re)⁻¹)) * w.im⁻¹

theorem paletteConstant_pos (order : Nat) (ho : 0 < order) : 0 < paletteConstant order ho := by
  have hb := negativePowerDirection_spec order ho
  have hw := smallStep_power_im_pos order ho
  have hu : 0 < -(pow (negativePowerDirection order ho) order).re := by grind
  have hi := Rat.inv_pos.mpr hu
  have hwi := Rat.inv_pos.mpr hw
  change 0 < (pow (imaginaryPowerDirection order) order).im⁻¹ at hwi
  have hfirst : 0 < 1 + (-(pow (negativePowerDirection order ho) order).re)⁻¹ := by grind
  have hp := Rat.mul_nonneg (qabs_nonneg (pow (imaginaryPowerDirection order) order).re)
    (Rat.le_of_lt hfirst)
  have hsecond : 0 ≤ 1 + qabs (pow (imaginaryPowerDirection order) order).re *
    (1 + (-(pow (negativePowerDirection order ho) order).re)⁻¹) := by grind
  have hprod := Rat.mul_nonneg hsecond (Rat.le_of_lt hwi)
  unfold paletteConstant
  change 0 < (1 + (-(pow (negativePowerDirection order ho) order).re)⁻¹) +
    (1 + qabs (pow (imaginaryPowerDirection order) order).re *
      (1 + (-(pow (negativePowerDirection order ho) order).re)⁻¹)) *
      (pow (imaginaryPowerDirection order) order).im⁻¹
  grind

/-- A literal fixed palette for each order gives a uniform inward alternative
with a computed constant, independent of the tested coefficient. -/
theorem computed_palette_detects (order : Nat) (ho : 0 < order) (c : QComplex)
    (eta : Rat) (heta : 0 ≤ eta) (hlarge : eta * paletteConstant order ho < normBound c) :
    let b := pow (negativePowerDirection order ho) order
    let w := pow (imaginaryPowerDirection order) order
    c.re < -eta ∨ (mul c b).re < -eta ∨ (mul c (conj b)).re < -eta ∨
      (mul c w).re < -eta ∨ (mul c (conj w)).re < -eta := by
  exact palette_detects_large_coefficient c _ _ eta heta (negativePowerDirection_spec order ho)
    (smallStep_power_im_pos order ho) hlarge

theorem power_conjugate (d : QComplex) (order : Nat) :
    pow (conj d) order = conj (pow d order) := by
  induction order with
  | zero => rfl
  | succ n ih =>
    rw [pow, ih]
    change mul (conj d) (conj (pow d n)) = conj (mul d (pow d n))
    simp only [QComplex.mul, QComplex.conj, QComplex.mk.injEq]
    constructor <;> grind

private theorem power_one (order : Nat) : pow QComplex.one order = QComplex.one := by
  induction order with
  | zero => rfl
  | succ n ih => rw [pow, ih, mul_one_cert]

def directionPalette (order : Nat) (ho : 0 < order) : List QComplex :=
  let d := negativePowerDirection order ho
  let e := imaginaryPowerDirection order
  [one, d, conj d, e, conj e]

def paletteScoreTest (c : QComplex) (order : Nat) (eta : Rat) (d : QComplex) : Bool :=
  decide ((mul c (pow d order)).re < -eta)

def selectedPaletteDirection (order : Nat) (ho : 0 < order) (c : QComplex) (eta : Rat) : QComplex :=
  firstPassing (paletteScoreTest c order eta) (directionPalette order ho)

/-- Finite selection returns an actual direction with the quantitative inward
margin, rather than only an existential vector alternative. -/
theorem selectedPaletteDirection_spec (order : Nat) (ho : 0 < order) (c : QComplex)
    (eta : Rat) (heta : 0 ≤ eta) (hlarge : eta * paletteConstant order ho < normBound c) :
    (mul c (pow (selectedPaletteDirection order ho c eta) order)).re < -eta := by
  have h := computed_palette_detects order ho c eta heta hlarge
  have hgood : (directionPalette order ho).any (paletteScoreTest c order eta) = true := by
    simp only [directionPalette, List.any_cons, List.any_nil, paletteScoreTest,
      power_conjugate, power_one, mul_one_cert, Bool.or_eq_true_iff, decide_eq_true_eq, Bool.false_eq_true, or_false]
    exact h
  have hs := firstPassing_spec (paletteScoreTest c order eta) (directionPalette order ho) hgood
  simpa [paletteScoreTest, selectedPaletteDirection] using hs

/-- Uniform size control also holds when no palette test succeeds. -/
theorem firstPassing_normBound_le (test : QComplex → Bool) (xs : List QComplex)
    (B : Rat) (hB : 1 ≤ B) (hx : ∀ d ∈ xs, normBound d ≤ B) :
    normBound (firstPassing test xs) ≤ B := by
  induction xs with
  | nil => simpa [firstPassing, QComplex.normBound, QComplex.one, qabs, show ¬ (1 : Rat) < 0 from by decide, Rat.add_zero] using hB
  | cons d ds ih =>
    rw [firstPassing]
    split
    · exact hx d (by simp)
    · exact ih (by intro e he; exact hx e (by simp [he]))

def paletteRadius (order : Nat) (ho : 0 < order) : Rat :=
  1 + normBound (negativePowerDirection order ho) + normBound (imaginaryPowerDirection order)

theorem paletteRadius_pos (order : Nat) (ho : 0 < order) : 0 < paletteRadius order ho := by
  have hd := normBound_nonneg (negativePowerDirection order ho)
  have he := normBound_nonneg (imaginaryPowerDirection order)
  unfold paletteRadius
  grind

theorem selectedPaletteDirection_bound (order : Nat) (ho : 0 < order)
    (c : QComplex) (eta : Rat) :
    normBound (selectedPaletteDirection order ho c eta) ≤ paletteRadius order ho := by
  apply firstPassing_normBound_le _ _ _ (by
    have hn := normBound_nonneg (negativePowerDirection order ho)
    have he := normBound_nonneg (imaginaryPowerDirection order)
    unfold paletteRadius
    grind)
  intro d hd
  simp only [directionPalette, List.mem_cons, List.not_mem_nil, or_false] at hd
  have hn := normBound_nonneg (negativePowerDirection order ho)
  have he := normBound_nonneg (imaginaryPowerDirection order)
  have hc (z : QComplex) : normBound (QComplex.conj z) = normBound z := by
    simp [QComplex.normBound, QComplex.conj, qabs_neg]
  rcases hd with h | h | h | h | h <;> subst d
  · change (qabs 1 + qabs 0) ≤ _
    simp only [qabs, show ¬ (1 : Rat) < 0 from by decide, show ¬ (0 : Rat) < 0 from by decide, if_false]
    unfold paletteRadius
    grind
  · unfold paletteRadius; grind
  · rw [hc]; unfold paletteRadius; grind
  · unfold paletteRadius; grind
  · rw [hc]; unfold paletteRadius; grind

end ComputableAnalysis.PolynomialDirection
