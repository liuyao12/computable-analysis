import ComputableAnalysis.FTA.ComputedDirectionPalette
import ComputableAnalysis.PolynomialLimitChartContinuity

namespace ComputableAnalysis.PolynomialDirection
open QComplex

/-- All scaled selected directions share an order-dependent radius. -/
theorem selected_scaled_bound (order : Nat) (ho : 0 < order) (c : QComplex)
    (eta t : Rat) (ht : 0 ≤ t) (ht1 : t ≤ 1) :
    normBound (scaleRat t (selectedPaletteDirection order ho c eta)) ≤ paletteRadius order ho := by
  rw [normBound_scaleRat, qabs_eq_self_of_nonneg ht]
  have hb := selectedPaletteDirection_bound order ho c eta
  have hm := Rat.mul_le_mul_of_nonneg_left hb ht
  have hn := Rat.mul_le_mul_of_nonneg_right ht1
    (Rat.le_of_lt (paletteRadius_pos order ho))
  grind

/-- A supplied finite Taylor tail has a computed bound uniform over the
coefficient used to select the direction and over the step in the unit interval. -/
theorem selected_tail_bound (tail : CPoly.Coeffs) (order : Nat) (ho : 0 < order)
    (c : QComplex) (eta t : Rat) (ht : 0 ≤ t) (ht1 : t ≤ 1) :
    normBound (CPoly.eval tail (scaleRat t (selectedPaletteDirection order ho c eta))) ≤
      CPoly.normMajorant tail (paletteRadius order ho) :=
  CPoly.eval_normMajorant _ _ _ (selected_scaled_bound order ho c eta t ht ht1)

/-- The actual factored remainder has a uniform computable majorant. -/
theorem selected_factored_tail_bound (tail : CPoly.Coeffs) (order : Nat) (ho : 0 < order)
    (c : QComplex) (eta t : Rat) (ht : 0 ≤ t) (ht1 : t ≤ 1) :
    let d := selectedPaletteDirection order ho c eta
    normBound (mul (pow d (order + 1)) (CPoly.eval tail (scaleRat t d))) ≤
      (paletteRadius order ho)^(order + 1) * CPoly.normMajorant tail (paletteRadius order ho) := by
  have hp := normBound_pow_le (Rat.le_of_lt (paletteRadius_pos order ho))
    (selectedPaletteDirection_bound order ho c eta) (order + 1)
  have he := selected_tail_bound tail order ho c eta t ht ht1
  have hm := normBound_mul_le
    (pow (selectedPaletteDirection order ho c eta) (order + 1))
    (CPoly.eval tail (scaleRat t (selectedPaletteDirection order ho c eta)))
  have h1 := Rat.mul_le_mul_of_nonneg_right hp
    (normBound_nonneg (CPoly.eval tail (scaleRat t (selectedPaletteDirection order ho c eta))))
  have h2 := Rat.mul_le_mul_of_nonneg_left he
    (show 0 ≤ (paletteRadius order ho)^(order + 1) from
      Rat.pow_nonneg (Rat.le_of_lt (paletteRadius_pos order ho)))
  exact Rat.le_trans hm (Rat.le_trans h1 h2)

/-- Earlier Taylor terms are bounded from their actual finite coefficients.
Their majorant must be made small enough relative to the selected-order gap. -/
theorem selected_early_terms_bound (early : CPoly.Coeffs) (order : Nat) (ho : 0 < order)
    (c : QComplex) (eta t : Rat) (ht : 0 ≤ t) (ht1 : t ≤ 1) :
    let h := scaleRat t (selectedPaletteDirection order ho c eta)
    normBound (mul h (CPoly.eval early h)) ≤
      t * paletteRadius order ho * CPoly.normMajorant early (paletteRadius order ho) := by
  let h := scaleRat t (selectedPaletteDirection order ho c eta)
  have he := selected_tail_bound early order ho c eta t ht ht1
  have hm := normBound_mul_le h (CPoly.eval early h)
  have hd : normBound h ≤ t * paletteRadius order ho := by
    dsimp [h]
    rw [normBound_scaleRat, qabs_eq_self_of_nonneg ht]
    exact Rat.mul_le_mul_of_nonneg_left (selectedPaletteDirection_bound order ho c eta) ht
  have h1 := Rat.mul_le_mul_of_nonneg_right hd (normBound_nonneg (CPoly.eval early h))
  have h2 := Rat.mul_le_mul_of_nonneg_left he
    (Rat.mul_nonneg ht (Rat.le_of_lt (paletteRadius_pos order ho)))
  exact Rat.le_trans hm (Rat.le_trans h1 h2)

end ComputableAnalysis.PolynomialDirection
