import ComputableAnalysis.FTA.FiniteTaylorTranslation

namespace ComputableAnalysis.FiniteFTABoundary
open QComplex PolynomialDirection

private theorem power_ge_one (G : Rat) (hG : 1 ≤ G) (n : Nat) : 1 ≤ G^n := by
  induction n with
  | zero => rw [Rat.pow_zero]; exact Rat.le_refl
  | succ n ih =>
    have hm := Rat.mul_le_mul_of_nonneg_right ih (show 0 ≤ G by grind)
    rw [Rat.pow_succ]
    grind

/-- A fixed envelope for the complete translated list. Fuel controls only
the quantitative bound; the Taylor algorithm itself already terminates. -/
theorem finiteTaylor_bound_of_length (fuel N : Nat) (p : CPoly.Coeffs) (r : QComplex)
    (R H : Rat) (hR : 0 ≤ R) (hH : 0 ≤ H) (hr : normBound r ≤ R)
    (hfuel : p.length ≤ fuel) (hN : p.length ≤ N)
    (hp : ∀ a ∈ p, normBound a ≤ H) :
    ∀ a ∈ finiteTaylor r p, normBound a ≤ H*(geometricEnvelope N (R+1)+1)^fuel := by
  let G := geometricEnvelope N (R+1)
  have hG : 0 ≤ G := geometricEnvelope_nonneg N (R+1) (by grind)
  induction fuel generalizing p H with
  | zero =>
    have hnil : p = [] := List.length_eq_zero_iff.mp (by omega)
    subst p
    intro a ha
    rw [finiteTaylor] at ha
    simp at ha
  | succ fuel ih =>
    cases p with
    | nil => intro a ha; rw [finiteTaylor] at ha; simp at ha
    | cons c p =>
      have hb := syntheticDivide_common_bound (c::p) r R H hR hr hp
      have hm := geometricEnvelope_mono (c::p).length N (R+1) (by grind) hN
      have hmul := Rat.mul_le_mul_of_nonneg_left hm hH
      have hsmall := Rat.mul_le_mul_of_nonneg_left (show G ≤ G+1 by grind) hH
      let q := trimmedQuotient r (c::p)
      have hq : q.length = (c::p).length-1 := trimmedQuotient_length r (c::p)
      have hquot : ∀ a ∈ q, normBound a ≤ H*(G+1) := by
        intro a ha
        have hmem := List.dropLast_subset (syntheticDivide r (c::p)).1 ha
        exact Rat.le_trans (hb.2 a hmem) (Rat.le_trans hmul hsmall)
      have hnew : 0 ≤ H*(G+1) := Rat.mul_nonneg hH (by grind)
      have ht := ih q (H*(G+1)) hnew (by simp only [List.length_cons] at hfuel hq; omega)
        (by simp only [List.length_cons] at hN hq; omega) hquot
      intro a ha
      rw [finiteTaylor] at ha
      rcases List.mem_cons.mp ha with heq | ha
      · subst a
        have hpow := power_ge_one (G+1) (by grind) fuel
        have h1 := Rat.mul_le_mul_of_nonneg_left hpow (show 0 ≤ G+1 by grind)
        have h2 := Rat.mul_le_mul_of_nonneg_left h1 hH
        have hh := hb.1
        change normBound (syntheticDivide r (c::p)).2 ≤ H*(G+1)^(fuel+1)
        rw [Rat.pow_succ]
        grind [Rat.mul_assoc, Rat.mul_comm]
      · have hh := ht a ha
        change normBound a ≤ H*(G+1)^(fuel+1)
        rw [Rat.pow_succ]
        grind [Rat.mul_assoc, Rat.mul_comm]

/-- One computable coefficient bound works at every centre in the ball. -/
theorem finiteTaylor_uniform_bound (p : CPoly.Coeffs) (r : QComplex) (R H : Rat)
    (hR : 0 ≤ R) (hH : 0 ≤ H) (hr : normBound r ≤ R)
    (hp : ∀ a ∈ p, normBound a ≤ H) :
    ∀ a ∈ finiteTaylor r p,
      normBound a ≤ H*(geometricEnvelope p.length (R+1)+1)^p.length :=
  finiteTaylor_bound_of_length p.length p.length p r R H hR hH hr
    (Nat.le_refl _) (Nat.le_refl _) hp

theorem coefficient_sum_bound (p : CPoly.Coeffs) :
    ∀ a ∈ p, normBound a ≤ CPoly.normMajorant p 1 := by
  induction p with
  | nil => intro a ha; simp at ha
  | cons c p ih =>
    intro a ha
    have hc := normBound_nonneg c
    have ht := CPoly.normMajorant_nonneg p 1 (by decide +kernel)
    change normBound a ≤ normBound c+1*CPoly.normMajorant p 1
    rcases List.mem_cons.mp ha with heq | ha
    · subst a; grind
    · have hb := ih a ha; grind

def taylorCoefficientBound (p : CPoly.Coeffs) (R : Rat) : Rat :=
  CPoly.normMajorant p 1 * (geometricEnvelope p.length (R+1)+1)^p.length

theorem taylorCoefficientBound_nonneg (p : CPoly.Coeffs) (R : Rat) (hR : 0 ≤ R) :
    0 ≤ taylorCoefficientBound p R := by
  have hG := geometricEnvelope_nonneg p.length (R+1) (by grind)
  exact Rat.mul_nonneg (CPoly.normMajorant_nonneg p 1 (by decide +kernel))
    (Rat.pow_nonneg (by grind))

/-- The common Taylor bound is computed solely from the supplied polynomial
and centre radius, with no caller-supplied coefficient bound. -/
theorem taylorCoefficientBound_spec (p : CPoly.Coeffs) (r : QComplex) (R : Rat)
    (hR : 0 ≤ R) (hr : normBound r ≤ R) :
    ∀ a ∈ finiteTaylor r p, normBound a ≤ taylorCoefficientBound p R :=
  finiteTaylor_uniform_bound p r R (CPoly.normMajorant p 1) hR
    (CPoly.normMajorant_nonneg p 1 (by decide +kernel)) hr (coefficient_sum_bound p)

end ComputableAnalysis.FiniteFTABoundary
