import ComputableAnalysis.FTA.BackwardThresholdSchedule
import ComputableAnalysis.FTA.PerturbedNormDescent

namespace ComputableAnalysis.PolynomialDirection

/-- Positive error allowance computed from a value bound and score gap. -/
def errorAllowance (B : Rat) (hB : 0 ≤ B) (gap : QPos) : QPos :=
  ⟨gap.val / (2*(2*B+gap.val+1)), by
    have hg := gap.property
    have hd : 0 < 2*(2*B+gap.val+1) := by grind
    rw [Rat.div_def]
    exact Rat.mul_pos hg (Rat.inv_pos.mpr hd)⟩

theorem errorAllowance_cost (B : Rat) (hB : 0 ≤ B) (gap : QPos) :
    (2*B+(errorAllowance B hB gap).val)*(errorAllowance B hB gap).val ≤ gap.val/2 := by
  let L := 2*B+gap.val+1
  have hg := gap.property
  have hL : 0 < L := by dsimp [L]; grind
  have hi := Rat.inv_pos.mpr hL
  have hc := Rat.mul_inv_cancel L (Rat.ne_of_gt hL)
  have hE := (errorAllowance B hB gap).property
  have hEq : (errorAllowance B hB gap).val * (2*L) = gap.val := by
    change (gap.val/(2*L))*(2*L) = gap.val
    rw [Rat.div_def]
    have hh := Rat.mul_inv_cancel (2*L) (by grind : 2*L ≠ 0)
    grind
  have hEL : (errorAllowance B hB gap).val * L = gap.val/2 := by
    rw [Rat.div_def]
    have hh : (2 : Rat) * (2 : Rat)⁻¹ = 1 := by decide +kernel
    grind
  have hL1 : 1 ≤ L := by dsimp [L]; grind
  have hbound := Rat.mul_le_mul_of_nonneg_left hL1 (Rat.le_of_lt hE)
  have hEle : (errorAllowance B hB gap).val ≤ gap.val := by grind
  have hsmall : 2*B+(errorAllowance B hB gap).val ≤ L := by dsimp [L]; grind
  have hm := Rat.mul_le_mul_of_nonneg_right hsmall (Rat.le_of_lt hE)
  grind

/-- Finite geometric Horner envelope for a common coefficient cap. -/
def geometricEnvelope : Nat → Rat → Rat
  | 0, _ => 0
  | n + 1, D => 1 + D * geometricEnvelope n D

theorem geometricEnvelope_nonneg (n : Nat) (D : Rat) (hD : 0 ≤ D) :
    0 ≤ geometricEnvelope n D := by
  induction n with
  | zero => exact Rat.le_refl
  | succ n ih =>
    have hm := Rat.mul_nonneg hD ih
    change 0 ≤ 1 + D * geometricEnvelope n D
    grind

theorem common_coefficient_majorant (p : CPoly.Coeffs) (D u : Rat)
    (hD : 0 ≤ D) (hp : ∀ a ∈ p, QComplex.normBound a ≤ u) :
    CPoly.normMajorant p D ≤ u * geometricEnvelope p.length D := by
  induction p with
  | nil => simp only [CPoly.normMajorant, List.length_nil, geometricEnvelope, Rat.mul_zero]; exact Rat.le_refl
  | cons a p ih =>
    have ha := hp a (by simp)
    have ht := ih (by intro b hb; exact hp b (by simp [hb]))
    have hm := Rat.mul_le_mul_of_nonneg_left ht hD
    simp only [CPoly.normMajorant, List.length_cons, geometricEnvelope]
    grind

/-- Positive coefficient cap converts a finite earlier-term envelope into
an actual error allowance. No root-existence evidence is used. -/
def coefficientAllowance (E : QPos) (F : Rat) (hF : 0 ≤ F) : QPos :=
  ⟨E.val/(F+1), by
    rw [Rat.div_def]
    exact Rat.mul_pos E.property (Rat.inv_pos.mpr (by grind))⟩

theorem coefficientAllowance_budget (E : QPos) (F : Rat) (hF : 0 ≤ F) :
    F * (coefficientAllowance E F hF).val ≤ E.val := by
  have hd : 0 < F+1 := by grind
  have hi := Rat.inv_pos.mpr hd
  have hc := Rat.mul_inv_cancel (F+1) (Rat.ne_of_gt hd)
  have hm := Rat.mul_le_mul_of_nonneg_right (show F ≤ F+1 by grind)
    (Rat.le_of_lt (Rat.mul_pos E.property hi))
  have heq : (F+1)*(E.val*(F+1)⁻¹) = E.val := by
    rw [← Rat.mul_assoc, Rat.mul_comm (F+1) E.val, Rat.mul_assoc, hc, Rat.mul_one]
  rw [heq] at hm
  change F*(E.val/(F+1)) ≤ E.val
  rw [Rat.div_def]
  exact hm

def earlyCoefficientCap (E : QPos) (n : Nat) (D t : Rat)
    (hD : 0 ≤ D) (ht : 0 ≤ t) : QPos :=
  coefficientAllowance E (t*D*geometricEnvelope n D)
    (Rat.mul_nonneg (Rat.mul_nonneg ht hD) (geometricEnvelope_nonneg n D hD))

/-- The computed cap bounds the actual early Taylor contribution. -/
theorem selected_early_budget (early : CPoly.Coeffs) (order : Nat) (ho : 0 < order)
    (c : QComplex) (eta t : Rat) (ht : 0 ≤ t) (ht1 : t ≤ 1) (E : QPos)
    (hp : ∀ a ∈ early, QComplex.normBound a ≤
      (earlyCoefficientCap E early.length (paletteRadius order ho) t
        (Rat.le_of_lt (paletteRadius_pos order ho)) ht).val) :
    let h := QComplex.scaleRat t (selectedPaletteDirection order ho c eta)
    QComplex.normBound (QComplex.mul h (CPoly.eval early h)) ≤ E.val := by
  let D := paletteRadius order ho
  have hD : 0 ≤ D := Rat.le_of_lt (paletteRadius_pos order ho)
  let u := earlyCoefficientCap E early.length D t hD ht
  have hm := common_coefficient_majorant early D u.val hD hp
  have he := selected_early_terms_bound early order ho c eta t ht ht1
  have hmul := Rat.mul_le_mul_of_nonneg_left hm (Rat.mul_nonneg ht hD)
  have hb := coefficientAllowance_budget E (t*D*geometricEnvelope early.length D)
    (Rat.mul_nonneg (Rat.mul_nonneg ht hD) (geometricEnvelope_nonneg early.length D hD))
  change (t*D*geometricEnvelope early.length D)*u.val ≤ E.val at hb
  change QComplex.normBound (QComplex.mul
    (QComplex.scaleRat t (selectedPaletteDirection order ho c eta))
    (CPoly.eval early (QComplex.scaleRat t (selectedPaletteDirection order ho c eta)))) ≤ E.val
  grind

end ComputableAnalysis.PolynomialDirection
