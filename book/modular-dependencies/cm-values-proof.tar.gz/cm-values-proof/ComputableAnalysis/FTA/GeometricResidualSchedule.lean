import ComputableAnalysis.FTA.FactorCenterResidual

namespace ComputableAnalysis.RepresentedPolynomial

theorem proximityAllowance_le_target (target : QPos) :
    (proximityAllowance target).val ≤ target.val := by
  have ht := target.property
  have he := (proximityAllowance target).property
  have hc := Rat.mul_inv_cancel (4*(target.val+1)) (Rat.ne_of_gt (show 0 < 4*(target.val+1) by grind))
  have hid : (4*(target.val+1))*(proximityAllowance target).val = target.val := by
    change (4*(target.val+1))*(target.val/(4*(target.val+1))) = target.val
    rw [Rat.div_def]; grind
  have hm := Rat.mul_le_mul_of_nonneg_right
    (show (1 : Rat) ≤ 4*(target.val+1) by grind) (Rat.le_of_lt he)
  grind

private theorem power_le_base (r : Rat) (hr : 0 ≤ r) (hb : r ≤ 1) (n : Nat) : r^(n+1) ≤ r := by
  induction n with
  | zero => simp only [Rat.pow_succ, Rat.pow_zero, Rat.one_mul]; exact Rat.le_refl
  | succ n ih =>
    have h1 := Rat.mul_le_mul_of_nonneg_right ih hr
    have h2 := Rat.mul_le_mul_of_nonneg_left hb hr
    rw [Rat.pow_succ]
    grind

theorem factorTailRadius_le_one (n : Nat) : factorTailRadius n ≤ 1 := by
  induction n with
  | zero => decide +kernel
  | succ n ih =>
    rw [factorTailRadius_half]
    rw [Rat.div_def]
    grind

theorem factorStepBudget_le_radius (n : Nat) : (factorStepBudget n).val ≤ factorTailRadius n := by
  have hp := factorTailRadius_pos (n+1)
  have h1 := factorTailRadius_le_one (n+1)
  have hh := factorTailRadius_half n
  have hm := Rat.mul_le_mul_of_nonneg_left (show factorTailRadius (n+1)/2 ≤ 1 by
    rw [Rat.div_def]; grind) (show 0 ≤ factorTailRadius (n+1)/2 by rw [Rat.div_def]; grind)
  change (factorTailRadius (n+1)/2)^2 ≤ _
  simp only [Rat.pow_succ, Rat.pow_zero, Rat.one_mul]
  rw [Rat.div_def] at *
  grind

/-- Actual chain error allowances shrink at an explicit geometric rate. -/
theorem geometricAllowance_bound (p : Coefficients) (hd : 2 ≤ p.length) (n : Nat) :
    (consecutivePeelingAllowance p factorStepBudget n).val ≤ factorTailRadius n := by
  have hc := consecutivePeelingAllowance_current p factorStepBudget n
  have ha := proximityAllowance_le_target (proximityTarget (factorStepBudget n) (p.length-1))
  have hb := factorStepBudget_le_radius n
  have hr := (factorStepBudget n).property
  have h1 := factorTailRadius_le_one n
  have hpow : (factorStepBudget n).val^(p.length-1) ≤ (factorStepBudget n).val := by
    have hl : p.length-1 = (p.length-2)+1 := by omega
    rw [hl]
    exact power_le_base _ (Rat.le_of_lt hr) (by grind) _
  change _ ≤ (factorStepBudget n).val^(p.length-1) at ha
  change _ ≤ (proximityAllowance (proximityTarget (factorStepBudget n) (p.length-1))).val at hc
  grind

theorem geometricAllowance_shrinks (p : Coefficients) (hd : 2 ≤ p.length) :
    ShrinksToZero (fun n => (consecutivePeelingAllowance p factorStepBudget n).val) := by
  intro eps
  obtain ⟨N, hN⟩ := factorTailRadius_shrinks eps
  exact ⟨N, fun n hn => Rat.le_trans (geometricAllowance_bound p hd n) (hN n hn)⟩

/-- The exact squared residual at actual geometric-chain centers is bounded
by a constructed sequence shrinking to zero. -/
theorem geometricFactorCenters_residual (p : Coefficients) (hp : Monic p)
    (hd : 2 ≤ p.length) (n : Nat) :
    (normValue (eval p (ofQComplex (geometricFactorCenters p hp n)))).real.preferred.Le
      (RealRaw.ofRat (factorTailRadius n)) := by
  have hs := computedFactorChain_residual p hp hd factorStepBudget n
  have hb := geometricAllowance_bound p hd n
  have h1 := factorTailRadius_le_one n
  have he := (consecutivePeelingAllowance p factorStepBudget n).property
  have hm := Rat.mul_le_mul_of_nonneg_left (show (consecutivePeelingAllowance p factorStepBudget n).val ≤ 1 by grind)
    (Rat.le_of_lt he)
  intro i j
  have hv := hs i j
  change ((normValue (eval p (ofQComplex (geometricFactorCenters p hp n)))).real.compute i).lo ≤
    (consecutivePeelingAllowance p factorStepBudget n).val^2 at hv
  change ((normValue (eval p (ofQComplex (geometricFactorCenters p hp n)))).real.compute i).lo ≤ factorTailRadius n
  simp only [Rat.pow_succ, Rat.pow_zero, Rat.one_mul] at hv
  grind

end ComputableAnalysis.RepresentedPolynomial
