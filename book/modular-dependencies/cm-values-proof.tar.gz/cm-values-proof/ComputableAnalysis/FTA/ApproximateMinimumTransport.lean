import ComputableAnalysis.FTA.ExactApproximateMinimum
import ComputableAnalysis.FTA.RootExistence

namespace ComputableAnalysis.RepresentedPolynomial

/-- Changing coefficient and comparison-point names preserves the exact
approximate-minimization role of the computed candidate. It does not assert
that rerunning selection with different names returns the identical point. -/
theorem approximateMinimum_exact_le_transport {p q : Coefficients}
    (hpq : Equivalent p q) (box : QBox) (ho : box.Ordered) (eps : QPos)
    (start : Nat) (z w : ComplexCert) (hz : InMinimumBox box z)
    (hzw : z.raw.Equiv w.raw) :
    (normValue (eval q (ofQComplex (approximateMinimum p box ho eps start)))).real.preferred.Le
      (RealRaw.add (normValue (eval q w)).real.preferred (RealRaw.ofRat eps.val)) := by
  let x := ofQComplex (approximateMinimum p box ho eps start)
  have hx := normValue_equiv (eval_equiv hpq (ComplexRaw.equiv_refl x.raw x.valid))
  have hy := normValue_equiv (eval_equiv hpq hzw)
  have hbase := approximateMinimum_exact_le p box ho eps start z hz
  have hleft := RealRaw.le_of_equiv (normValue (eval q x)).real.valid
    (normValue (eval p x)).real.valid (RealRaw.equiv_symm hx)
  have hright := RealRaw.add_equiv (y := RealRaw.ofRat eps.val) (y' := RealRaw.ofRat eps.val) (normValue (eval p z)).real.valid
    (normValue (eval q w)).real.valid (RealRaw.ofRat_valid eps.val) (RealRaw.ofRat_valid eps.val)
    hy (RealRaw.equiv_refl (RealRaw.ofRat eps.val) (RealRaw.ofRat_valid eps.val))
  have hrightLe := RealRaw.le_of_equiv
    (RealRaw.add_valid (y := RealRaw.ofRat eps.val) (normValue (eval p z)).real.valid (RealRaw.ofRat_valid eps.val))
    (RealRaw.add_valid (y := RealRaw.ofRat eps.val) (normValue (eval q w)).real.valid (RealRaw.ofRat_valid eps.val)) hright
  exact RealRaw.le_trans
    (RealRaw.add_valid (y := RealRaw.ofRat eps.val) (normValue (eval p z)).real.valid (RealRaw.ofRat_valid eps.val))
    (RealRaw.le_trans (normValue (eval p x)).real.valid hleft hbase) hrightLe

/-- Any actual in-domain competitor whose score enclosure certifies a
decrease exceeding the approximation tolerance is impossible. This is the
checked contradiction step; constructing such a competitor uniformly from
a positive residual remains the quantitative polynomial-descent task. -/
theorem approximateMinimum_no_certified_descent (p : Coefficients) (box : QBox)
    (ho : box.Ordered) (eps : QPos) (start : Nat) (z : ComplexCert)
    (hz : InMinimumBox box z) (i j : Nat)
    (hgap : ((normValue (eval p z)).real.compute j).hi + eps.val <
      ((normValue (eval p (ofQComplex (approximateMinimum p box ho eps start)))).real.compute i).lo) :
    False := by
  have h := approximateMinimum_exact_le p box ho eps start z hz i j
  change ((normValue (eval p (ofQComplex (approximateMinimum p box ho eps start)))).real.compute i).lo ≤
    ((normValue (eval p z)).real.compute j).hi + eps.val at h
  grind

end ComputableAnalysis.RepresentedPolynomial
