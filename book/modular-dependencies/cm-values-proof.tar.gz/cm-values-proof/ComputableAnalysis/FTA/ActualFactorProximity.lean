import ComputableAnalysis.FTA.ReconstructionPrecision

namespace ComputableAnalysis.RepresentedPolynomial

/-- A finite maximum of the actual factor distances, computed without a
uniform location hypothesis. -/
def factorDistanceBound (items : List (QComplex × ComplexCert)) (z : QComplex) : Rat :=
  items.foldr (fun item bound => max (QComplex.normBound (QComplex.sub z item.1)) bound) 0

theorem factorDistanceBound_nonneg (items : List (QComplex × ComplexCert)) (z : QComplex) :
    0 ≤ factorDistanceBound items z := by
  induction items with
  | nil => exact Rat.le_refl
  | cons item items ih => change 0 ≤ max _ (factorDistanceBound items z); grind

theorem factorDistanceBound_member (items : List (QComplex × ComplexCert)) (z : QComplex)
    (item : QComplex × ComplexCert) (hi : item ∈ items) :
    QComplex.normBound (QComplex.sub z item.1) ≤ factorDistanceBound items z := by
  induction items with
  | nil => simp at hi
  | cons x xs ih =>
    change _ ≤ max _ (factorDistanceBound xs z)
    rcases List.mem_cons.mp hi with heq | hi
    · subst item; grind
    · have ht := ih hi; grind

/-- Actual sampled peeling errors have a finite computed bound once the
simultaneous remainder stage has been reached. -/
theorem actualPeeling_error_bound (p : Coefficients) (hp : Monic p)
    (delta : QPos) (start n : Nat) (z : QComplex)
    (hn : peelingRemainderStage (approximatePeeling p hp (squaredTolerance delta) start) delta ≤ n) :
    let items := approximatePeeling p hp (squaredTolerance delta) start
    PolynomialDirection.peelingErrorMajorant (sampledPeeling items n) z ≤
      (2*delta.val)*PolynomialDirection.geometricEnvelope items.length (factorDistanceBound items z) := by
  dsimp only
  have hb := PolynomialDirection.peelingErrorMajorant_uniform
    (sampledPeeling (approximatePeeling p hp (squaredTolerance delta) start) n) z
    (2*delta.val) (factorDistanceBound (approximatePeeling p hp (squaredTolerance delta) start) z)
    (by have hd := delta.property; grind) (factorDistanceBound_nonneg _ z)
    (sampledPeeling_remainders_bound p hp delta start n hn)
    (by
      intro x hx
      obtain ⟨item, hi, rfl⟩ := List.mem_map.mp hx
      exact factorDistanceBound_member _ z item hi)
  simpa [sampledPeeling] using hb

/-- Actual complete peelings supply directed factor proximity at a common
computed sampling stage, subject to the finite omitted-error budget. -/
theorem actualPeeling_near (p : Coefficients) (hp : Monic p)
    (delta eta tolerance : QPos) (start stop n searchStart : Nat)
    (x : QComplex × ComplexCert)
    (hx : x ∈ approximatePeeling p hp (squaredTolerance delta) start)
    (rho : Rat) (hrho : 0 ≤ rho)
    (hn : reconstructionStage
      (approximatePeeling p hp (squaredTolerance eta) stop)
      (approximatePeeling p hp (squaredTolerance delta) start) x.1 tolerance searchStart ≤ n)
    (hsmall :
      (tolerance.val +
        PolynomialDirection.peelingErrorMajorant
          (sampledPeeling (approximatePeeling p hp (squaredTolerance delta) start) n) x.1 +
        PolynomialDirection.peelingErrorMajorant
          (sampledPeeling (approximatePeeling p hp (squaredTolerance eta) stop) n) x.1)^2 <
      rho^(sampledPeeling (approximatePeeling p hp (squaredTolerance eta) stop) n).length) :
    QComplex.normSq (QComplex.sub x.1
      (PolynomialDirection.nearbyFactor
        (sampledPeeling (approximatePeeling p hp (squaredTolerance eta) stop) n) x.1 rho)) < rho := by
  apply PolynomialDirection.finiteFactorFamily_near
    (sampledPeeling (approximatePeeling p hp (squaredTolerance delta) start) n)
    (sampledPeeling (approximatePeeling p hp (squaredTolerance eta) stop) n)
    (x.1, (x.2.raw.compute n).lo)
    (List.mem_map.mpr ⟨x, hx, rfl⟩) tolerance.val rho
    (Rat.le_of_lt tolerance.property) hrho
  · exact approximatePeeling_precision_bound p hp (squaredTolerance eta)
      (squaredTolerance delta) tolerance stop start searchStart n x.1 hn
  · exact hsmall

end ComputableAnalysis.RepresentedPolynomial
