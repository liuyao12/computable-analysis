import ComputableAnalysis.FTA.FiniteTaylorSplit
import ComputableAnalysis.FTA.DomainDescentStep

namespace ComputableAnalysis.PolynomialDirection
open QComplex PolynomialNormDescent PolynomialDescentDomain

/-- Rational upper bounds and residual floor used to compute the schedule.
These are numerical parameters, with no root or descent conclusion stored. -/
structure DescentBounds where
  value : Rat
  coefficient : Rat
  value_nonneg : 0 ≤ value
  coefficient_nonneg : 0 ≤ coefficient
  tailLength : Nat
  residual : QPos

def scheduleRadius (n : Nat) : Rat := paletteRadius (n+1) (by omega)

theorem scheduleRadius_pos (n : Nat) : 0 < scheduleRadius n := paletteRadius_pos _ _

def scheduleMargin (b : DescentBounds) (n : Nat) (theta : QPos) : QPos :=
  residualInwardMargin (n+1) (by omega) b.value b.value_nonneg b.residual theta

def scheduleCoefficientBound (b : DescentBounds) (n : Nat) : Rat :=
  b.coefficient * (scheduleRadius n)^(n+1)

def scheduleTailBound (b : DescentBounds) (n : Nat) : Rat :=
  (scheduleRadius n)^(n+2) * (b.coefficient * geometricEnvelope b.tailLength (scheduleRadius n))

theorem scheduleCoefficientBound_nonneg (b : DescentBounds) (n : Nat) :
    0 ≤ scheduleCoefficientBound b n :=
  Rat.mul_nonneg b.coefficient_nonneg (Rat.pow_nonneg (Rat.le_of_lt (scheduleRadius_pos n)))

theorem scheduleTailBound_nonneg (b : DescentBounds) (n : Nat) :
    0 ≤ scheduleTailBound b n :=
  Rat.mul_nonneg (Rat.pow_nonneg (Rat.le_of_lt (scheduleRadius_pos n)))
    (Rat.mul_nonneg b.coefficient_nonneg
      (geometricEnvelope_nonneg b.tailLength _ (Rat.le_of_lt (scheduleRadius_pos n))))

/-- The proxy direction has exactly the common radius, making the step
independent of the direction later selected from the palette. -/
def scheduleStep (b : DescentBounds) (n : Nat) (theta : QPos) : QPos :=
  ⟨combinedStep (scheduleMargin b n theta).val b.value (scheduleCoefficientBound b n)
    (scheduleTailBound b n) ⟨1, by decide +kernel⟩ ⟨scheduleRadius n, 0⟩,
    (combinedStep_spec _ _ _ _ (scheduleMargin b n theta).property _ _).1⟩

theorem scheduleStep_spec (b : DescentBounds) (n : Nat) (theta : QPos) :
    (scheduleStep b n theta).val ≤ step (scheduleMargin b n theta).val b.value
      (scheduleCoefficientBound b n) (scheduleTailBound b n) ∧
    (scheduleStep b n theta).val < 1 ∧
    (scheduleStep b n theta).val * scheduleRadius n ≤ 1 := by
  have hs := combinedStep_spec (scheduleMargin b n theta).val b.value
    (scheduleCoefficientBound b n) (scheduleTailBound b n)
    (scheduleMargin b n theta).property ⟨1, by decide +kernel⟩ ⟨scheduleRadius n, 0⟩
  have hb := PolynomialDescent.step_spec (-2*(scheduleMargin b n theta).val)
    [2*b.value*scheduleTailBound b n+(scheduleCoefficientBound b n+scheduleTailBound b n)^2]
    (by have := (scheduleMargin b n theta).property; grind)
  have ht : 0 < (scheduleStep b n theta).val := (scheduleStep b n theta).property
  have hn : normBound (⟨scheduleRadius n, 0⟩ : QComplex) = scheduleRadius n := by
    simp only [normBound, qabs_eq_self_of_nonneg (Rat.le_of_lt (scheduleRadius_pos n))]
    have hz : qabs (0 : Rat) = 0 := by decide +kernel
    rw [hz, Rat.add_zero]
  refine ⟨hs.2.1, ?_, ?_⟩
  · have hlt := hb.2.1
    change step (scheduleMargin b n theta).val b.value
      (scheduleCoefficientBound b n) (scheduleTailBound b n) < 1 at hlt
    have hle : (scheduleStep b n theta).val ≤ step (scheduleMargin b n theta).val
        b.value (scheduleCoefficientBound b n) (scheduleTailBound b n) := hs.2.1
    grind only
  · have hd := hs.2.2
    change normBound (scaleRat (scheduleStep b n theta).val ⟨scheduleRadius n, 0⟩) ≤ 1 at hd
    rw [normBound_scaleRat, qabs_eq_self_of_nonneg (Rat.le_of_lt ht), hn] at hd
    exact hd

theorem schedule_displacement_bound (b : DescentBounds) (n : Nat) (theta : QPos)
    (seed : QComplex) (eta : Rat) :
    normBound (scaleRat (scheduleStep b n theta).val
      (selectedPaletteDirection (n+1) (by omega) seed eta)) ≤ 1 := by
  rw [normBound_scaleRat,
    qabs_eq_self_of_nonneg (Rat.le_of_lt (scheduleStep b n theta).property)]
  have hm := Rat.mul_le_mul_of_nonneg_left
    (selectedPaletteDirection_bound (n+1) (by omega) seed eta)
    (Rat.le_of_lt (scheduleStep b n theta).property)
  exact Rat.le_trans hm (scheduleStep_spec b n theta).2.2

def descentCoefficientCap (b : DescentBounds) (n : Nat) (theta : QPos) : QPos :=
  let B := b.value + scheduleCoefficientBound b n + scheduleTailBound b n
  let hB : 0 ≤ B := Rat.add_nonneg (Rat.add_nonneg b.value_nonneg
    (scheduleCoefficientBound_nonneg b n)) (scheduleTailBound_nonneg b n)
  let E := errorAllowance B hB
    (localGap (scheduleMargin b n theta) (scheduleStep b n theta).val
      (scheduleStep b n theta).property (n+1))
  earlyCoefficientCap E n (scheduleRadius n) (scheduleStep b n theta).val
    (Rat.le_of_lt (scheduleRadius_pos n)) (Rat.le_of_lt (scheduleStep b n theta).property)

def concreteThresholds (b : DescentBounds) (degree : Nat) : List QPos :=
  backwardThresholds (descentCoefficientCap b) degree ⟨1/2, by decide +kernel⟩

theorem concreteThresholds_compatible (b : DescentBounds) (degree : Nat) :
    ThresholdCompatible (descentCoefficientCap b) (concreteThresholds b degree) :=
  backwardThresholds_compatible _ _ _

theorem concreteThresholds_prefix_cap (b : DescentBounds) (degree : Nat)
    (before : List QPos) (theta : QPos) (after : List QPos)
    (hsplit : concreteThresholds b degree = before ++ theta :: after) :
    ∀ q ∈ before, q.val ≤ (descentCoefficientCap b before.length theta).val :=
  ThresholdCompatible.prefix_cap _ _ (concreteThresholds_compatible b degree) _ _ _ hsplit

end ComputableAnalysis.PolynomialDirection
