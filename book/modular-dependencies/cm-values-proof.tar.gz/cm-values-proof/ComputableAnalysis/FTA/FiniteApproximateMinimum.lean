import ComputableAnalysis.Basic

/-! Executable finite minimization of rational upper bounds. Interval scores
need not be decidably ordered as represented values. No cluster selection is
used. The cover theorem separates finite selection from the later polynomial
variation and mesh-cover obligations. -/
namespace ComputableAnalysis.FiniteApproximateMinimum

def select {α : Type} (upper : α → Rat) (start : α) : List α → α
  | [] => start
  | x :: xs => select upper (if upper x ≤ upper start then x else start) xs

theorem select_le_start {α : Type} (upper : α → Rat) (start : α) (xs : List α) :
    upper (select upper start xs) ≤ upper start := by
  induction xs generalizing start with
  | nil => exact Rat.le_refl
  | cons x xs ih =>
    rw [select]
    split
    · exact Rat.le_trans (ih x) ‹upper x ≤ upper start›
    · exact ih start

theorem select_mem {α : Type} (upper : α → Rat) (start : α) (xs : List α) :
    select upper start xs = start ∨ select upper start xs ∈ xs := by
  induction xs generalizing start with
  | nil => exact Or.inl rfl
  | cons x xs ih =>
    rw [select]
    split
    · rcases ih x with h | h
      · exact Or.inr (by simp [h])
      · exact Or.inr (by simp [h])
    · rcases ih start with h | h
      · exact Or.inl h
      · exact Or.inr (by simp [h])

theorem select_le_mem {α : Type} (upper : α → Rat) (start : α) (xs : List α)
    (x : α) (hx : x ∈ xs) : upper (select upper start xs) ≤ upper x := by
  induction xs generalizing start with
  | nil => simp at hx
  | cons a xs ih =>
    have hx' : x = a ∨ x ∈ xs := by simpa using hx
    rcases hx' with rfl | hx'
    · rw [select]
      split
      · exact select_le_start upper x xs
      · exact Rat.le_trans (select_le_start upper start xs) (by grind)
    · rw [select]
      exact ih _ hx'

/-- An upper-bound minimizer has true score at most the competitor's true
score plus the competitor's enclosure width. Only finite rational inequalities
are used; score comparisons are never performed by the algorithm. -/
theorem score_le_competitor {α : Type} (lower upper score : α → Rat)
    (start : α) (xs : List α) (error : Rat)
    (henclose : ∀ x, x = start ∨ x ∈ xs → lower x ≤ score x ∧ score x ≤ upper x)
    (hwidth : ∀ x ∈ xs, upper x - lower x ≤ error)
    (x : α) (hx : x ∈ xs) :
    score (select upper start xs) ≤ score x + error := by
  have hs := (henclose _ (select_mem upper start xs)).2
  have hc := select_le_mem upper start xs x hx
  have hl := (henclose x (Or.inr hx)).1
  have hw := hwidth x hx
  grind

/-- A finite cover's variation error adds to the score-enclosure error.
Constructing the cover and polynomial variation bounds is a separate task. -/
theorem score_le_covered {α : Type} (lower upper score : α → Rat)
    (start : α) (xs : List α) (error variation : Rat)
    (henclose : ∀ x, x = start ∨ x ∈ xs → lower x ≤ score x ∧ score x ≤ upper x)
    (hwidth : ∀ x ∈ xs, upper x - lower x ≤ error)
    (target : Rat) (hcover : ∃ x ∈ xs, score x ≤ target + variation) :
    score (select upper start xs) ≤ target + variation + error := by
  obtain ⟨x, hx, hnear⟩ := hcover
  have h := score_le_competitor lower upper score start xs error henclose hwidth x hx
  grind

/-- A witnessed decrease larger than the certified approximation budget
contradicts approximate minimality. This supplies the finite contradiction
step without asserting existence of a minimizing point. -/
theorem no_excess_descent (selected competitor budget decrease : Rat)
    (hminimum : selected ≤ competitor + budget)
    (hdescent : competitor ≤ selected - decrease) (hgap : budget < decrease) : False := by
  grind

end ComputableAnalysis.FiniteApproximateMinimum
