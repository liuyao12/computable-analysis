import ComputableAnalysis.FTA.RepresentedResidualPrecision

namespace ComputableAnalysis.RepresentedPolynomial

def leadingValueBound (c : ComplexCert) : Rat := (c.raw.compute 0).normMajorant

/-- Multiplication by an arbitrary represented leading coefficient has a
computed squared-residual factor, using its initial enclosing box. -/
theorem representedResidualCandidate_scaled (c : ComplexCert) (q : Coefficients)
    (hq : 0 < q.length) (eps : QPos) (start : Nat) :
    (normValue (mul c (eval (q++[one])
      (ofQComplex (representedResidualCandidate q eps start))))).real.preferred.Le
      (RealRaw.ofRat ((leadingValueBound c)^2*eps.val)) := by
  intro i j
  let n := residualCoefficientStage q eps start
  let m := max n i
  let x := representedResidualCandidate q eps start
  let a := (c.raw.compute i).lo
  let w := CPoly.eval (coefficientSamples (q++[one]) m) x
  let C := leadingValueBound c
  have hxsample := sample_eval_contains (q++[one]) (show i ≤ m by dsimp [m]; omega)
    (B := QBox.point x) (QComplex.le_refl x) (QComplex.le_refl x)
  have hx : ((eval (q++[one]) (ofQComplex x)).raw.compute i).lo ≤ w ∧
      w ≤ ((eval (q++[one]) (ofQComplex x)).raw.compute i).hi := by
    rw [eval_compute]
    exact hxsample
  have ha := ComplexRaw.valid_ordered c.valid i
  have hprod := QBox.mul_contains (QComplex.le_refl a) ha hx.1 hx.2
  have hpoint : ((mul c (eval (q++[one]) (ofQComplex x))).raw.compute i).lo ≤ QComplex.mul a w ∧
      QComplex.mul a w ≤ ((mul c (eval (q++[one]) (ofQComplex x))).raw.compute i).hi := by
    exact hprod
  have hscore := (normValue_contains (mul c (eval (q++[one]) (ofQComplex x))) i _ hpoint.1 hpoint.2).1
  have hs := representedResidualCandidate_later q hq eps start m (by dsimp [m, n]; omega)
  have hnest := ComplexRaw.valid_nestedIn c.valid (Nat.zero_le i)
  have hnorm : QComplex.normBound a ≤ C :=
    QBox.normBound_le_of_mem (c.raw.compute 0) a hnest.1
      (QComplex.le_trans ha hnest.2)
  have hC : 0 ≤ C := (c.raw.compute 0).normMajorant_nonneg
  have h0 := QComplex.normBound_nonneg a
  have h1 := Rat.mul_le_mul_of_nonneg_left hnorm h0
  have h2 := Rat.mul_le_mul_of_nonneg_right hnorm hC
  have hsq := PolynomialCoercivity.normSq_le_normBound_square a
  have haSq : QComplex.normSq a ≤ C^2 := by
    simp only [Rat.pow_succ, Rat.pow_zero, Rat.one_mul] at *
    grind
  have hw0 : 0 ≤ QComplex.normSq w := by
    have hr := rat_square_nonneg_basic w.re
    have hi := rat_square_nonneg_basic w.im
    unfold QComplex.normSq
    grind
  have hm1 := Rat.mul_le_mul_of_nonneg_right haSq hw0
  have hm2 := Rat.mul_le_mul_of_nonneg_left (Rat.le_of_lt hs) (Rat.pow_nonneg hC (n := 2))
  have hid : QComplex.normSq (QComplex.mul a w) = QComplex.normSq a*QComplex.normSq w := by
    simp only [QComplex.normSq, QComplex.mul]
    grind
  rw [hid] at hscore
  change ((normValue (mul c (eval (q++[one]) (ofQComplex x)))).real.compute i).lo ≤ C^2*eps.val
  exact Rat.le_trans hscore (Rat.le_trans hm1 hm2)

end ComputableAnalysis.RepresentedPolynomial
