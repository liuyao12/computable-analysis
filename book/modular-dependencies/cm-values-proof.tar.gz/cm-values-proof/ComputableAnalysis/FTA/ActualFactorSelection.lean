import ComputableAnalysis.FTA.VaryingPeelingProximity

namespace ComputableAnalysis.RepresentedPolynomial
open PolynomialDirection

/-- Locate the actual retained record for a rational center. Equality is
only tested on rational complex coordinates. -/
def factorRecord (items : List (QComplex × ComplexCert)) (z : QComplex) : QComplex × ComplexCert :=
  match items with
  | [] => (QComplex.zero, zero)
  | item::items => if item.1 = z then item else factorRecord items z

theorem factorRecord_spec (items : List (QComplex × ComplexCert)) (z : QComplex)
    (hz : z ∈ items.map Prod.fst) :
    factorRecord items z ∈ items ∧ (factorRecord items z).1 = z := by
  induction items with
  | nil => simp at hz
  | cons item items ih =>
    rw [factorRecord]
    by_cases hi : item.1 = z
    · simp [hi]
    · have ht : z ∈ items.map Prod.fst := by
        simp only [List.map_cons, List.mem_cons] at hz
        grind
      have hs := ih ht
      simp only [if_neg hi]
      exact ⟨List.mem_cons_of_mem _ hs.1, hs.2⟩

/-- Executable next-factor selection retains the actual represented remainder. -/
def nextPeelingFactor (p : Coefficients) (hp : Monic p)
    (error nextError rho : QPos) (start stop : Nat) (x : QComplex × ComplexCert) :
    QComplex × ComplexCert :=
  let ys := errorBudgetPeeling p hp nextError stop
  let n := varyingProximityStage p hp error nextError rho start stop x.1
  factorRecord ys (nearbyFactor (sampledPeeling ys n) x.1 rho.val)

theorem nextPeelingFactor_spec (p : Coefficients) (hp : Monic p)
    (error nextError rho : QPos)
    (he : error.val ≤ (familyProximityAllowance p rho).val)
    (hf : nextError.val ≤ (familyProximityAllowance p rho).val)
    (start stop : Nat) (x : QComplex × ComplexCert)
    (hx : x ∈ errorBudgetPeeling p hp error start) :
    nextPeelingFactor p hp error nextError rho start stop x ∈ errorBudgetPeeling p hp nextError stop ∧
    QComplex.normSq (QComplex.sub x.1
      (nextPeelingFactor p hp error nextError rho start stop x).1) < rho.val := by
  have hm := varyingPeeling_member p hp error nextError rho he hf start stop x hx
  have hs := varyingPeeling_near p hp error nextError rho he hf start stop x hx
  have hr := factorRecord_spec (errorBudgetPeeling p hp nextError stop) _ hm
  change factorRecord _ _ ∈ _ ∧ _
  exact ⟨hr.1, by unfold nextPeelingFactor; rw [hr.2]; exact hs⟩

/-- Adjacent allowance schedules now supply an actual factor record to the
following recursive step, as well as its squared-distance bound. -/
theorem consecutiveFactor_spec (p : Coefficients) (hp : Monic p)
    (steps : Nat → QPos) (n start stop : Nat) (x : QComplex × ComplexCert)
    (hx : x ∈ errorBudgetPeeling p hp (consecutivePeelingAllowance p steps n) start) :
    let y := nextPeelingFactor p hp (consecutivePeelingAllowance p steps n)
      (consecutivePeelingAllowance p steps (n+1)) (steps n) start stop x
    y ∈ errorBudgetPeeling p hp (consecutivePeelingAllowance p steps (n+1)) stop ∧
    QComplex.normSq (QComplex.sub x.1 y.1) < (steps n).val :=
  nextPeelingFactor_spec p hp _ _ _
    (consecutivePeelingAllowance_current p steps n)
    (consecutivePeelingAllowance_next p steps n) start stop x hx

/-- Primitive recursion of actual factor records through the scheduled families. -/
def peelingFactorChain (p : Coefficients) (hp : Monic p) (steps : Nat → QPos)
    (seed : QComplex × ComplexCert) : Nat → QComplex × ComplexCert
  | 0 => seed
  | n+1 => nextPeelingFactor p hp (consecutivePeelingAllowance p steps n)
      (consecutivePeelingAllowance p steps (n+1)) (steps n) 0 0
      (peelingFactorChain p hp steps seed n)

theorem peelingFactorChain_member (p : Coefficients) (hp : Monic p) (steps : Nat → QPos)
    (seed : QComplex × ComplexCert)
    (hseed : seed ∈ errorBudgetPeeling p hp (consecutivePeelingAllowance p steps 0) 0)
    (n : Nat) :
    peelingFactorChain p hp steps seed n ∈
      errorBudgetPeeling p hp (consecutivePeelingAllowance p steps n) 0 := by
  induction n with
  | zero => exact hseed
  | succ n ih => exact (consecutiveFactor_spec p hp steps n 0 0 _ ih).1

theorem peelingFactorChain_step (p : Coefficients) (hp : Monic p) (steps : Nat → QPos)
    (seed : QComplex × ComplexCert)
    (hseed : seed ∈ errorBudgetPeeling p hp (consecutivePeelingAllowance p steps 0) 0)
    (n : Nat) :
    QComplex.normSq (QComplex.sub (peelingFactorChain p hp steps seed n).1
      (peelingFactorChain p hp steps seed (n+1)).1) < (steps n).val :=
  (consecutiveFactor_spec p hp steps n 0 0 _ (peelingFactorChain_member p hp steps seed hseed n)).2

end ComputableAnalysis.RepresentedPolynomial
