import ComputableAnalysis.FTA.QuadraticDivision

/-! Removing a conjugate pair preserves real coefficients. -/
namespace ComputableAnalysis.RepresentedPolynomial
open Arithmetic

private theorem qext {a b : QComplex} (hre : a.re = b.re) (him : a.im = b.im) : a = b := by
  cases a; cases b; simp_all

def conjugateConstant (r : ComplexCert) := mul r (conj r)
def conjugateLinear (r : ComplexCert) := neg (add r (conj r))

theorem conjugateConstant_real (r : ComplexCert) : IsReal (conjugateConstant r) := by
  apply Expression.equiv_of_samples (.conj (.mul (.parameter r) (.conj (.parameter r))))
    (.mul (.parameter r) (.conj (.parameter r)))
  intro s
  apply qext <;> simp [Expression.sample, QComplex.mul, QComplex.conj] <;> grind

theorem conjugateLinear_real (r : ComplexCert) : IsReal (conjugateLinear r) := by
  apply Expression.equiv_of_samples (.conj (.neg (.add (.parameter r) (.conj (.parameter r)))))
    (.neg (.add (.parameter r) (.conj (.parameter r))))
  intro s
  apply qext <;> simp [Expression.sample, QComplex.add, QComplex.neg, QComplex.conj] <;> grind

theorem conjugateQuadratic_factor (r x : ComplexCert) :
    (quadraticEval (conjugateConstant r) (conjugateLinear r) x).raw.Equiv
      (mul (sub x r) (sub x (conj r))).raw := by
  apply Expression.equiv_of_samples
    (.add (.mul (.parameter r) (.conj (.parameter r)))
      (.mul (.parameter x) (.add (.neg (.add (.parameter r) (.conj (.parameter r)))) (.parameter x))))
    (.mul (.add (.parameter x) (.neg (.parameter r)))
      (.add (.parameter x) (.neg (.conj (.parameter r)))))
  intro s
  apply qext <;> simp [Expression.sample, QComplex.add, QComplex.neg, QComplex.mul, QComplex.conj] <;> grind

private theorem quadratic_root (r : ComplexCert) :
    (quadraticEval (conjugateConstant r) (conjugateLinear r) r).raw.Equiv zero.raw :=
  certTrans (conjugateQuadratic_factor r r)
    (certTrans (certMulCongr (sub_self r) (certRefl (sub r (conj r)))) (zero_mul _))

private theorem quadratic_conjugate_root (r : ComplexCert) :
    (quadraticEval (conjugateConstant r) (conjugateLinear r) (conj r)).raw.Equiv zero.raw :=
  certTrans (conjugateQuadratic_factor r (conj r))
    (certTrans (certMulCongr (certRefl (sub (conj r) r)) (sub_self (conj r))) (certMulZero _))

private theorem remainder_difference (a b r s : ComplexCert) :
    (sub (add a (mul r b)) (add a (mul s b))).raw.Equiv (mul (sub r s) b).raw := by
  apply Expression.equiv_of_samples
    (.add (.add (.parameter a) (.mul (.parameter r) (.parameter b)))
      (.neg (.add (.parameter a) (.mul (.parameter s) (.parameter b)))))
    (.mul (.add (.parameter r) (.neg (.parameter s))) (.parameter b))
  intro t
  apply qext <;> simp [Expression.sample, QComplex.add, QComplex.neg, QComplex.mul] <;> grind

/-- Both real remainders vanish when a polynomial vanishes at a nonreal
root and its conjugate. -/
theorem conjugateDivide_remainders (p : Coefficients) (hp : RealCoefficients p)
    (r : ComplexCert) (hr : Root p r) (hnr : ¬ IsReal r) :
    (quadraticDivide (conjugateConstant r) (conjugateLinear r) p).2.1.raw.Equiv zero.raw ∧
    (quadraticDivide (conjugateConstant r) (conjugateLinear r) p).2.2.raw.Equiv zero.raw := by
  let qr := quadraticDivide (conjugateConstant r) (conjugateLinear r) p
  have hrem (x : ComplexCert) (hx : Root p x)
      (hq : (quadraticEval (conjugateConstant r) (conjugateLinear r) x).raw.Equiv zero.raw) :
      (add qr.2.1 (mul x qr.2.2)).raw.Equiv zero.raw := by
    have h := quadraticDivide_spec (conjugateConstant r) (conjugateLinear r) x p
    have hs := certTrans h (certTrans
      (certAddCongr (certTrans (certMulCongr hq (certRefl (eval qr.1 x))) (zero_mul _))
        (certRefl (add qr.2.1 (mul x qr.2.2)))) (zero_add _))
    exact certTrans (ComplexRaw.equiv_symm hs) hx
  have h₀ := hrem r hr (quadratic_root r)
  have h₁ := hrem (conj r) (realCoefficients_root_conj hp hr) (quadratic_conjugate_root r)
  have hdiff : ¬ (sub r (conj r)).raw.Equiv zero.raw := by
    intro hh
    exact hnr (ComplexRaw.equiv_symm (certSubEqZero hh))
  have hb : qr.2.2.raw.Equiv zero.raw := by
    apply mul_cancel_left_of_nonzero (a := sub r (conj r)) hdiff
    exact certTrans (ComplexRaw.equiv_symm (remainder_difference qr.2.1 qr.2.2 r (conj r)))
      (certTrans (certSubCongr h₀ h₁) (certTrans (sub_self zero) (ComplexRaw.equiv_symm (certMulZero _))))
  have ha : qr.2.1.raw.Equiv zero.raw :=
    certTrans (ComplexRaw.equiv_symm (add_zero qr.2.1))
      (certTrans (certAddCongr (certRefl qr.2.1)
        (ComplexRaw.equiv_symm (certTrans (certMulCongr (certRefl r) hb) (certMulZero r)))) h₀)
  exact ⟨ha, hb⟩

theorem conjugateDivide_degree (p : Coefficients) (hp : Monic p) (hre : RealCoefficients p)
    (r : ComplexCert) (hr : Root p r) (hnr : ¬ IsReal r) : 3 ≤ p.length := by
  obtain ⟨q, rfl⟩ := hp
  cases q with
  | nil => exact False.elim (one_has_no_root r hr)
  | cons c q =>
      cases q with
      | nil =>
          have hh := (conjugateDivide_remainders [c, one] hre r hr hnr).2
          exact False.elim (certOneNonzero hh)
      | cons d q => simp

/-- Exact removal of a conjugate pair, with a real monic quotient. -/
theorem conjugateDivide_factor (p : Coefficients) (hp : RealCoefficients p)
    (r : ComplexCert) (hr : Root p r) (hnr : ¬ IsReal r) (x : ComplexCert) :
    (eval p x).raw.Equiv
      (mul (mul (sub x r) (sub x (conj r)))
        (eval (quadraticDivide (conjugateConstant r) (conjugateLinear r) p).1 x)).raw := by
  let qr := quadraticDivide (conjugateConstant r) (conjugateLinear r) p
  obtain ⟨h₀, h₁⟩ := conjugateDivide_remainders p hp r hr hnr
  have hz : (add qr.2.1 (mul x qr.2.2)).raw.Equiv zero.raw :=
    certTrans (certAddCongr h₀ (certTrans (certMulCongr (certRefl x) h₁) (certMulZero x))) (add_zero zero)
  exact certTrans (quadraticDivide_spec _ _ x p)
    (certTrans (certAddCongr (certMulCongr (conjugateQuadratic_factor r x) (certRefl (eval qr.1 x))) hz)
      (add_zero _))

end ComputableAnalysis.RepresentedPolynomial
