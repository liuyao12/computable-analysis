import ComputableAnalysis.FTA.WholePeelingBound

namespace ComputableAnalysis.RepresentedPolynomial
open PolynomialDirection

def wholeFactorRadius (p : Coefficients) : Rat :=
  peelingRadius p.length (initialCoefficientEnvelope p)

def wholePeelingErrorFactor (p : Coefficients) : Rat :=
  2*geometricEnvelope (p.length-1) (2*wholeFactorRadius p)

theorem wholeFactorRadius_nonneg (p : Coefficients) : 0 ≤ wholeFactorRadius p :=
  peelingRadius_nonneg _ _ (initialCoefficientEnvelope_nonneg p)

theorem wholePeelingErrorFactor_nonneg (p : Coefficients) :
    0 ≤ wholePeelingErrorFactor p :=
  Rat.mul_nonneg (by decide +kernel)
    (geometricEnvelope_nonneg _ _ (by have h := wholeFactorRadius_nonneg p; grind))

/-- The full omitted-remainder error is bounded by a tolerance times a factor
computed only from the original coefficient boxes and degree. -/
theorem sampledPeeling_uniform_error (p : Coefficients) (hp : Monic p)
    (delta : QPos) (start n : Nat) (z : QComplex)
    (hz : QComplex.normBound z ≤ wholeFactorRadius p)
    (hn : peelingRemainderStage (approximatePeeling p hp (squaredTolerance delta) start) delta ≤ n) :
    peelingErrorMajorant (sampledPeeling (approximatePeeling p hp (squaredTolerance delta) start) n) z ≤
      delta.val*wholePeelingErrorFactor p := by
  have hd := delta.property
  have hR := wholeFactorRadius_nonneg p
  have hb := peelingErrorMajorant_uniform
    (sampledPeeling (approximatePeeling p hp (squaredTolerance delta) start) n) z
    (2*delta.val) (2*wholeFactorRadius p) (by grind) (by grind)
    (sampledPeeling_remainders_bound p hp delta start n hn)
    (by
      intro x hx
      obtain ⟨item, hi, rfl⟩ := List.mem_map.mp hx
      have hr := approximatePeeling_computed_bound p hp (squaredTolerance delta) start item hi
      have hs := QComplex.normBound_sub_le z item.1
      change QComplex.normBound item.1 ≤ wholeFactorRadius p at hr
      grind)
  rw [show (sampledPeeling (approximatePeeling p hp (squaredTolerance delta) start) n).length = p.length-1 by
    simp only [sampledPeeling, List.length_map, approximatePeeling_length]] at hb
  unfold wholePeelingErrorFactor
  grind

/-- Remainder tolerance can be selected before constructing the factors. -/
def peelingTolerance (p : Coefficients) (error : QPos) : QPos :=
  coefficientAllowance error (wholePeelingErrorFactor p) (wholePeelingErrorFactor_nonneg p)

theorem sampledPeeling_error_allowance (p : Coefficients) (hp : Monic p)
    (error : QPos) (start n : Nat) (z : QComplex)
    (hz : QComplex.normBound z ≤ wholeFactorRadius p)
    (hn : peelingRemainderStage
      (approximatePeeling p hp (squaredTolerance (peelingTolerance p error)) start)
      (peelingTolerance p error) ≤ n) :
    peelingErrorMajorant
      (sampledPeeling (approximatePeeling p hp (squaredTolerance (peelingTolerance p error)) start) n) z ≤
      error.val := by
  have hb := sampledPeeling_uniform_error p hp (peelingTolerance p error) start n z hz hn
  have he := coefficientAllowance_budget error (wholePeelingErrorFactor p)
    (wholePeelingErrorFactor_nonneg p)
  change wholePeelingErrorFactor p*(peelingTolerance p error).val ≤ error.val at he
  grind

end ComputableAnalysis.RepresentedPolynomial
