import ComputableAnalysis.FTA.GeometricResidualSchedule

namespace ComputableAnalysis.RepresentedPolynomial

/-- The constructed coherent value, with validity proved beneath its interface.
Its role as a polynomial root is a separate zero-evaluation obligation. -/
def coherentFactorValue (p : Coefficients) (hp : Monic p) (hd : 2 ≤ p.length) : ComplexCert :=
  ⟨ComplexRaw.cauchyStabilize (centerCandidates (geometricFactorCenters p hp)) factorTailRadius,
    geometricFactorCenters_valid p hp hd⟩

/-- Every future computed center lies in each earlier coherent-value box. -/
theorem coherentFactorValue_contains_center (p : Coefficients) (hp : Monic p)
    (hd : 2 ≤ p.length) (i n : Nat) (hin : i ≤ n) :
    ((coherentFactorValue p hp hd).raw.compute i).lo ≤ geometricFactorCenters p hp n ∧
    geometricFactorCenters p hp n ≤ ((coherentFactorValue p hp hd).raw.compute i).hi := by
  have hcurrent := ComplexRaw.cauchyStabilize_contains_current
    (coherentCenters_future (geometricFactorCenters p hp) factorTailRadius
      (fun k => Rat.le_of_lt (factorTailRadius_pos k)) (geometricFactorCenters_step p hp hd)) n
  have hnest := ComplexRaw.valid_nestedIn (coherentFactorValue p hp hd).valid hin
  exact ⟨QComplex.le_trans hnest.1 hcurrent.1, QComplex.le_trans hcurrent.2 hnest.2⟩

/-- Later coefficient samples evaluated at a future center lie in each earlier
polynomial-output box of the coherent value. -/
theorem coherentFactorValue_sample_contains (p : Coefficients) (hp : Monic p)
    (hd : 2 ≤ p.length) (i n m : Nat) (hin : i ≤ n) (him : i ≤ m) :
    ((eval p (coherentFactorValue p hp hd)).raw.compute i).lo ≤
      CPoly.eval (coefficientSamples p m) (geometricFactorCenters p hp n) ∧
    CPoly.eval (coefficientSamples p m) (geometricFactorCenters p hp n) ≤
      ((eval p (coherentFactorValue p hp hd)).raw.compute i).hi := by
  have hc := coherentFactorValue_contains_center p hp hd i n hin
  rw [eval_compute]
  exact sample_eval_contains p him hc.1 hc.2

/-- Every polynomial-output box of the coherent value contains rational
points of arbitrarily small norm, constructed from future center evaluations. -/
theorem coherentFactorValue_small_samples (p : Coefficients) (hp : Monic p)
    (hd : 2 ≤ p.length) (i : Nat) (eps : QPos) :
    ∃ w : QComplex,
      ((eval p (coherentFactorValue p hp hd)).raw.compute i).lo ≤ w ∧
      w ≤ ((eval p (coherentFactorValue p hp hd)).raw.compute i).hi ∧
      QComplex.normBound w ≤ eps.val := by
  let delta : QPos := ⟨eps.val/2, by
    rw [Rat.div_def]; exact Rat.mul_pos eps.property (by decide +kernel)⟩
  obtain ⟨N, hN⟩ := factorTailRadius_shrinks (squaredTolerance delta)
  let n := max i N
  let z := eval p (ofQComplex (geometricFactorCenters p hp n))
  have hn : i ≤ n := by dsimp [n]; omega
  have hsmall : (normValue z).real.preferred.Le (RealRaw.ofRat (delta.val^2)) := by
    have hs := geometricFactorCenters_residual p hp hd n
    have hb : factorTailRadius n ≤ delta.val^2 := hN n (by dsimp [n]; omega)
    intro a b
    have hv := hs a b
    change ((normValue z).real.compute a).lo ≤ factorTailRadius n at hv
    change ((normValue z).real.compute a).lo ≤ delta.val^2
    exact Rat.le_trans hv hb
  let m := max i (residualNormStage z delta)
  let w := CPoly.eval (coefficientSamples p m) (geometricFactorCenters p hp n)
  have him : i ≤ m := by dsimp [m]; omega
  have hw := coherentFactorValue_sample_contains p hp hd i n m hn him
  have hc : (z.raw.compute m).lo ≤ w ∧ w ≤ (z.raw.compute m).hi := by
    rw [eval_compute]
    exact sample_eval_contains p (Nat.le_refl m) (B := QBox.point (geometricFactorCenters p hp n))
      (QComplex.le_refl _) (QComplex.le_refl _)
  have hb := residualNormStage_bound z delta hsmall m (by dsimp [m]; omega) w hc.1 hc.2
  refine ⟨w, hw.1, hw.2, ?_⟩
  dsimp [delta] at hb
  rw [Rat.div_def] at hb
  grind

end ComputableAnalysis.RepresentedPolynomial
