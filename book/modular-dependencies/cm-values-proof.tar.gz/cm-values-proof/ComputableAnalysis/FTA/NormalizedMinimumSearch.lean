import ComputableAnalysis.FTA.MinimumPrecisionSearch

namespace ComputableAnalysis.RepresentedPolynomial

theorem sampleNormMajorant_uniform (p : Coefficients) (n : Nat) (R : Rat)
    (hR : 0 ≤ R) : sampleNormMajorant p n R ≤ 2 * sampleNormMajorant p 0 R := by
  induction p with
  | nil => simp [sampleNormMajorant, Rat.mul_zero]
  | cons a p ih =>
    have hn := ComplexRaw.valid_nestedIn a.valid (Nat.zero_le n)
    have ho := ComplexRaw.valid_ordered a.valid n
    have hl := QBox.normBound_le_of_mem (a.raw.compute 0) (a.raw.compute n).lo
      hn.1 (QComplex.le_trans ho hn.2)
    have hh := QBox.normBound_le_of_mem (a.raw.compute 0) (a.raw.compute n).hi
      (QComplex.le_trans hn.1 ho) hn.2
    have hm := Rat.mul_le_mul_of_nonneg_left ih hR
    change (a.raw.compute n).normMajorant + R * sampleNormMajorant p n R ≤
      2 * ((a.raw.compute 0).normMajorant + R * sampleNormMajorant p 0 R)
    unfold QBox.normMajorant at *
    grind

theorem sampleNormMajorant_nonneg (p : Coefficients) (n : Nat) (R : Rat)
    (hR : 0 ≤ R) : 0 ≤ sampleNormMajorant p n R := by
  induction p with
  | nil => exact Rat.le_refl
  | cons a p ih =>
    exact Rat.add_nonneg (a.raw.compute n).normMajorant_nonneg (Rat.mul_nonneg hR ih)

def minimumHalfBudget (eps : QPos) : QPos :=
  ⟨eps.val/2, by rw [Rat.div_def]; exact Rat.mul_pos eps.property (by decide +kernel)⟩

def minimumCoefficientBudget (p : Coefficients) (box : QBox) (eps : QPos) : QPos :=
  ⟨eps.val / (16 * (sampleNormMajorant p 0 box.normMajorant + 1)), by
    have h := sampleNormMajorant_nonneg p 0 box.normMajorant box.normMajorant_nonneg
    rw [Rat.div_def]
    exact Rat.mul_pos eps.property (Rat.inv_pos.mpr (by grind))⟩

def approximateMinimum (p : Coefficients) (box : QBox) (ho : box.Ordered)
    (eps : QPos) (start : Nat) : QComplex :=
  scheduledCandidate p box ho (minimumCoefficientBudget p box eps) (minimumHalfBudget eps) start

/-- A single requested tolerance controls the full mesh and coefficient
error, uniformly over all later samples and rational points in the box. -/
theorem approximateMinimum_le (p : Coefficients) (box : QBox) (ho : box.Ordered)
    (eps : QPos) (start m : Nat)
    (hm : scheduledCoefficientStage p box (minimumCoefficientBudget p box eps) start ≤ m)
    (z : QComplex) (hl : box.lo ≤ z) (hh : z ≤ box.hi) :
    QComplex.normSq (CPoly.eval (coefficientSamples p m) (approximateMinimum p box ho eps start)) ≤
      QComplex.normSq (CPoly.eval (coefficientSamples p m) z) + eps.val := by
  let n := scheduledCoefficientStage p box (minimumCoefficientBudget p box eps) start
  let M := sampleNormMajorant p 0 box.normMajorant
  have hM : 0 ≤ M := sampleNormMajorant_nonneg p 0 box.normMajorant box.normMajorant_nonneg
  have hu := sampleNormMajorant_uniform p n box.normMajorant box.normMajorant_nonneg
  have h := scheduledCandidate_le p box ho (minimumCoefficientBudget p box eps)
    (minimumHalfBudget eps) start m hm z hl hh
  have hd : 0 < 16*(M+1) := by grind
  have ht : 0 ≤ eps.val/(16*(M+1)) := Rat.le_of_lt (by
    rw [Rat.div_def]; exact Rat.mul_pos eps.property (Rat.inv_pos.mpr hd))
  have hmul := Rat.mul_le_mul_of_nonneg_right hu ht
  have hi := Rat.mul_inv_cancel (16*(M+1)) (Rat.ne_of_gt hd)
  have hbudget : 8*M*(eps.val/(16*(M+1))) ≤ eps.val/2 := by
    have hc := Rat.mul_le_mul_of_nonneg_right (show M ≤ M+1 by grind) ht
    have hid : 8*(M+1)*(eps.val/(16*(M+1))) = eps.val/2 := by
      rw [Rat.div_def, Rat.div_def]
      have htwo : (2 : Rat)*(2 : Rat)⁻¹ = 1 := by decide +kernel
      grind
    grind
  change QComplex.normSq (CPoly.eval (coefficientSamples p m) (approximateMinimum p box ho eps start)) ≤
    QComplex.normSq (CPoly.eval (coefficientSamples p m) z) + eps.val/2 +
      4 * sampleNormMajorant p n box.normMajorant * (eps.val/(16*(M+1))) at h
  change sampleNormMajorant p n box.normMajorant * (eps.val/(16*(M+1))) ≤
    2*M*(eps.val/(16*(M+1))) at hmul
  simp only [Rat.div_def] at *
  grind

end ComputableAnalysis.RepresentedPolynomial
