import ComputableAnalysis.FTA.RootPolynomialCoefficients
import ComputableAnalysis.RiemannHilbert.SeriesLimitLaws

namespace ComputableAnalysis.RepresentedPolynomial
open ComplexRaw RiemannHilbert FunctionTheory

private theorem one_bound : Small RepresentedPolynomial.one.raw 1 := by
  refine ⟨?_,?_,?_,?_⟩
  · intro n m; change (-1:Rat)≤1; decide +kernel
  · intro n m; change (1:Rat)≤1; decide +kernel
  · intro n m; change (-1:Rat)≤0; decide +kernel
  · intro n m; change (0:Rat)≤1; decide +kernel

private theorem zero_bound : Small RepresentedPolynomial.zero.raw 1 := by
  refine ⟨?_,?_,?_,?_⟩
  · intro n m; change (-1:Rat)≤0; decide +kernel
  · intro n m; change (0:Rat)≤1; decide +kernel
  · intro n m; change (-1:Rat)≤0; decide +kernel
  · intro n m; change (0:Rat)≤1; decide +kernel

private theorem bound_nonneg (B : Rat) (hB : 0 ≤ B) (n : Nat) : 0 ≤ (1+2*B)^n := by
  induction n with
  | zero => simpa only [Rat.pow_zero] using (show (0:Rat) ≤ 1 by decide +kernel)
  | succ n ih =>
      rw [Rat.pow_succ]
      exact Rat.mul_nonneg ih (by grind)

/-- Uniform finite coefficient bound from bounds on supplied represented roots.
It retains coordinate-box semantics, hence the factor two in multiplication. -/
theorem rootPolynomial_coefficient_small (rs : List ComplexCert) (B : Rat) (hB : 0 ≤ B)
    (hr : ∀ r ∈ rs, Small r.raw B) (k : Nat) :
    Small (coefficient (rootPolynomial rs) k).raw ((1+2*B)^rs.length) := by
  induction rs generalizing k with
  | nil =>
      cases k with
      | zero => simpa only [rootPolynomial,coefficient,List.length_nil,Rat.pow_zero] using one_bound
      | succ k => simpa only [rootPolynomial,coefficient,List.length_nil,Rat.pow_zero] using zero_bound
  | cons r rs ih =>
      have hn := bound_nonneg B hB rs.length
      have hs : Small (neg r).raw B := SeriesLimitLaws.small_neg (hr r (by simp))
      have ht (k : Nat) := ih (fun s h => hr s (by simp [h])) k
      have hp (k : Nat) := Small.mul (neg r).valid (coefficient (rootPolynomial rs) k).valid
        hB hn hs (ht k)
      cases k with
      | zero =>
          have hb := (hp 0).mono (show 2*B*((1+2*B)^rs.length) ≤ (1+2*B)^(rs.length+1) by
            rw [Rat.pow_succ]
            grind)
          exact Small.congr (mul (neg r) (coefficient (rootPolynomial rs) 0)).valid
            (coefficient (rootPolynomial (r::rs)) 0).valid
            (equiv_symm (coefficient_linearMultiply_zero r _)) hb
      | succ k =>
          have hb := LocalODE.small_add (hp (k+1)) (ht k)
          have he : 2*B*((1+2*B)^rs.length)+(1+2*B)^rs.length = (1+2*B)^(rs.length+1) := by
            rw [Rat.pow_succ]
            grind
          rw [he] at hb
          exact Small.congr (add (mul (neg r) (coefficient (rootPolynomial rs) (k+1)))
            (coefficient (rootPolynomial rs) k)).valid
            (coefficient (rootPolynomial (r::rs)) (k+1)).valid
            (equiv_symm (coefficient_linearMultiply_succ r _ k)) hb

end ComputableAnalysis.RepresentedPolynomial
