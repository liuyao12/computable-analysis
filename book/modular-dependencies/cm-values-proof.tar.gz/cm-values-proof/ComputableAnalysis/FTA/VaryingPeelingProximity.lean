import ComputableAnalysis.FTA.ScheduledPeelingProximity

namespace ComputableAnalysis.RepresentedPolynomial
open PolynomialDirection

def errorBudgetPeeling (p : Coefficients) (hp : Monic p) (error : QPos) (start : Nat) :
    List (QComplex × ComplexCert) :=
  approximatePeeling p hp (squaredTolerance (peelingTolerance p error)) start

def varyingProximityStage (p : Coefficients) (hp : Monic p)
    (error nextError rho : QPos) (start stop : Nat) (z : QComplex) : Nat :=
  let xs := errorBudgetPeeling p hp error start
  let ys := errorBudgetPeeling p hp nextError stop
  max (peelingRemainderStage xs (peelingTolerance p error))
    (max (peelingRemainderStage ys (peelingTolerance p nextError))
      (reconstructionStage ys xs z (familyProximityAllowance p rho) 0))

/-- Independent family error allowances give proximity whenever both are
below the explicitly computed step allowance. -/
theorem varyingPeeling_near (p : Coefficients) (hp : Monic p)
    (error nextError rho : QPos)
    (herror : error.val ≤ (familyProximityAllowance p rho).val)
    (hnext : nextError.val ≤ (familyProximityAllowance p rho).val)
    (start stop : Nat) (x : QComplex × ComplexCert)
    (hx : x ∈ errorBudgetPeeling p hp error start) :
    let n := varyingProximityStage p hp error nextError rho start stop x.1
    QComplex.normSq (QComplex.sub x.1
      (nearbyFactor (sampledPeeling (errorBudgetPeeling p hp nextError stop) n) x.1 rho.val)) < rho.val := by
  let n := varyingProximityStage p hp error nextError rho start stop x.1
  have hz : QComplex.normBound x.1 ≤ wholeFactorRadius p :=
    approximatePeeling_computed_bound p hp (squaredTolerance (peelingTolerance p error)) start x hx
  have hxs : peelingRemainderStage (errorBudgetPeeling p hp error start) (peelingTolerance p error) ≤ n := by
    dsimp [n, varyingProximityStage]; omega
  have hys : peelingRemainderStage (errorBudgetPeeling p hp nextError stop) (peelingTolerance p nextError) ≤ n := by
    dsimp [n, varyingProximityStage]; omega
  have hcs : reconstructionStage (errorBudgetPeeling p hp nextError stop)
      (errorBudgetPeeling p hp error start) x.1 (familyProximityAllowance p rho) 0 ≤ n := by
    dsimp [n, varyingProximityStage]; omega
  have hc := approximatePeeling_precision_bound p hp
    (squaredTolerance (peelingTolerance p nextError)) (squaredTolerance (peelingTolerance p error))
    (familyProximityAllowance p rho) stop start 0 n x.1 hcs
  have he := Rat.le_trans (sampledPeeling_error_allowance p hp error start n x.1 hz hxs) herror
  have hf := Rat.le_trans (sampledPeeling_error_allowance p hp nextError stop n x.1 hz hys) hnext
  have hl : (sampledPeeling (errorBudgetPeeling p hp nextError stop) n).length = p.length-1 := by
    simp only [sampledPeeling, List.length_map, errorBudgetPeeling, approximatePeeling_length]
  apply finiteFactorFamily_near_allowance
    (sampledPeeling (errorBudgetPeeling p hp error start) n)
    (sampledPeeling (errorBudgetPeeling p hp nextError stop) n)
    (x.1, (x.2.raw.compute n).lo) (List.mem_map.mpr ⟨x, hx, rfl⟩) rho
  · rw [hl]; exact hc
  · rw [hl]; exact he
  · rw [hl]; exact hf

/-- The selected center belongs to the next actual factor family. -/
theorem varyingPeeling_member (p : Coefficients) (hp : Monic p)
    (error nextError rho : QPos)
    (herror : error.val ≤ (familyProximityAllowance p rho).val)
    (hnext : nextError.val ≤ (familyProximityAllowance p rho).val)
    (start stop : Nat) (x : QComplex × ComplexCert)
    (hx : x ∈ errorBudgetPeeling p hp error start) :
    let n := varyingProximityStage p hp error nextError rho start stop x.1
    nearbyFactor (sampledPeeling (errorBudgetPeeling p hp nextError stop) n) x.1 rho.val ∈
      (errorBudgetPeeling p hp nextError stop).map Prod.fst := by
  let n := varyingProximityStage p hp error nextError rho start stop x.1
  have hz : QComplex.normBound x.1 ≤ wholeFactorRadius p :=
    approximatePeeling_computed_bound p hp (squaredTolerance (peelingTolerance p error)) start x hx
  have hxs : peelingRemainderStage (errorBudgetPeeling p hp error start) (peelingTolerance p error) ≤ n := by
    dsimp [n, varyingProximityStage]; omega
  have hys : peelingRemainderStage (errorBudgetPeeling p hp nextError stop) (peelingTolerance p nextError) ≤ n := by
    dsimp [n, varyingProximityStage]; omega
  have hcs : reconstructionStage (errorBudgetPeeling p hp nextError stop)
      (errorBudgetPeeling p hp error start) x.1 (familyProximityAllowance p rho) 0 ≤ n := by
    dsimp [n, varyingProximityStage]; omega
  have hc := approximatePeeling_precision_bound p hp
    (squaredTolerance (peelingTolerance p nextError)) (squaredTolerance (peelingTolerance p error))
    (familyProximityAllowance p rho) stop start 0 n x.1 hcs
  have he := Rat.le_trans (sampledPeeling_error_allowance p hp error start n x.1 hz hxs) herror
  have hf := Rat.le_trans (sampledPeeling_error_allowance p hp nextError stop n x.1 hz hys) hnext
  have hl : (sampledPeeling (errorBudgetPeeling p hp nextError stop) n).length = p.length-1 := by
    simp only [sampledPeeling, List.length_map, errorBudgetPeeling, approximatePeeling_length]
  have hmem : nearbyFactor (sampledPeeling (errorBudgetPeeling p hp nextError stop) n) x.1 rho.val ∈
      (sampledPeeling (errorBudgetPeeling p hp nextError stop) n).map Prod.fst := by
    apply finiteFactorFamily_member_allowance
      (sampledPeeling (errorBudgetPeeling p hp error start) n)
      (sampledPeeling (errorBudgetPeeling p hp nextError stop) n)
      (x.1, (x.2.raw.compute n).lo) (List.mem_map.mpr ⟨x, hx, rfl⟩) rho
    · rw [hl]; exact hc
    · rw [hl]; exact he
    · rw [hl]; exact hf
  simpa only [sampledPeeling, List.map_map, Function.comp_def] using hmem

/-- Adjacent allowances anticipate both incident proximity requirements.
No monotonicity assumption on the step budgets is needed. -/
def consecutivePeelingAllowance (p : Coefficients) (steps : Nat → QPos) : Nat → QPos
  | 0 => familyProximityAllowance p (steps 0)
  | n+1 => QPos.minimum (familyProximityAllowance p (steps n))
      (familyProximityAllowance p (steps (n+1)))

theorem consecutivePeelingAllowance_current (p : Coefficients) (steps : Nat → QPos) (n : Nat) :
    (consecutivePeelingAllowance p steps n).val ≤ (familyProximityAllowance p (steps n)).val := by
  cases n with
  | zero => exact Rat.le_refl
  | succ n => exact QPos.minimum_le_right _ _

theorem consecutivePeelingAllowance_next (p : Coefficients) (steps : Nat → QPos) (n : Nat) :
    (consecutivePeelingAllowance p steps (n+1)).val ≤ (familyProximityAllowance p (steps n)).val :=
  QPos.minimum_le_left _ _

/-- Every successive actual family pair satisfies its supplied proximity step
with all error budgets selected in advance. -/
theorem consecutivePeeling_near (p : Coefficients) (hp : Monic p)
    (steps : Nat → QPos) (n start stop : Nat) (x : QComplex × ComplexCert)
    (hx : x ∈ errorBudgetPeeling p hp (consecutivePeelingAllowance p steps n) start) :
    let k := varyingProximityStage p hp (consecutivePeelingAllowance p steps n)
      (consecutivePeelingAllowance p steps (n+1)) (steps n) start stop x.1
    QComplex.normSq (QComplex.sub x.1
      (nearbyFactor (sampledPeeling
        (errorBudgetPeeling p hp (consecutivePeelingAllowance p steps (n+1)) stop) k)
        x.1 (steps n).val)) < (steps n).val :=
  varyingPeeling_near p hp _ _ _
    (consecutivePeelingAllowance_current p steps n)
    (consecutivePeelingAllowance_next p steps n) start stop x hx

end ComputableAnalysis.RepresentedPolynomial
