import ComputableAnalysis.FTA.NormalizedResidualCandidate

namespace ComputableAnalysis.RepresentedPolynomial

theorem monic_dropLast (p : Coefficients) (hp : Monic p) : p = p.dropLast ++ [one] := by
  obtain ⟨q, rfl⟩ := hp
  rw [List.dropLast_concat]

def approximatePeelPoint (p : Coefficients) (eps : QPos) (start : Nat) : QComplex :=
  representedResidualCandidate p.dropLast eps start

/-- Synthetic division at an actual computed approximate root has a small
exact remainder; no exact-root hypothesis is introduced. -/
theorem approximatePeel_remainder (p : Coefficients) (hp : Monic p) (hdegree : 2 ≤ p.length)
    (eps : QPos) (start : Nat) :
    (normValue (syntheticDivide (ofQComplex (approximatePeelPoint p eps start)) p).2).real.preferred.Le
      (RealRaw.ofRat eps.val) := by
  let x := ofQComplex (approximatePeelPoint p eps start)
  have hq : 0 < p.dropLast.length := by rw [List.length_dropLast]; omega
  have he := normValue_equiv (syntheticDivide_remainder x p)
  have hl := RealRaw.le_of_equiv (normValue (syntheticDivide x p).2).real.valid
    (normValue (eval p x)).real.valid he
  have hb := representedResidualCandidate_exact p.dropLast hq eps start
  rw [← monic_dropLast p hp] at hb
  exact RealRaw.le_trans (normValue (eval p x)).real.valid hl hb

/-- Finite approximate factor peeling. Every chosen point and exact remainder
is retained; the recursion lowers degree and requires no exact root. -/
def approximatePeeling (p : Coefficients) (hp : Monic p) (eps : QPos) (start : Nat) :
    List (QComplex × ComplexCert) :=
  if hdegree : 2 ≤ p.length then
    let r := approximatePeelPoint p eps start
    let qr := syntheticDivide (ofQComplex r) p
    (r, qr.2) :: approximatePeeling qr.1
      (syntheticDivide_monic (ofQComplex r) p hp hdegree) eps start
  else []
termination_by p.length
decreasing_by rw [syntheticDivide_length]; omega

/-- One finite approximate factor is constructed per polynomial degree. -/
theorem approximatePeeling_length (p : Coefficients) (hp : Monic p) (eps : QPos) (start : Nat) :
    (approximatePeeling p hp eps start).length = p.length-1 := by
  rw [approximatePeeling]
  split
  · rw [List.length_cons, approximatePeeling_length, syntheticDivide_length]
    omega
  · simp only [List.length_nil]
    omega
termination_by p.length
decreasing_by rw [syntheticDivide_length]; omega

/-- Every retained remainder is justified by the actual finite construction. -/
theorem approximatePeeling_remainders (p : Coefficients) (hp : Monic p) (eps : QPos) (start : Nat) :
    ∀ item ∈ approximatePeeling p hp eps start,
      (normValue item.2).real.preferred.Le (RealRaw.ofRat eps.val) := by
  rw [approximatePeeling]
  split
  · intro item hitem
    rcases List.mem_cons.mp hitem with heq | hitem
    · subst item
      exact approximatePeel_remainder p hp ‹2 ≤ p.length› eps start
    · exact approximatePeeling_remainders _ _ eps start item hitem
  · intro item hitem; simp at hitem
termination_by p.length
decreasing_by rw [syntheticDivide_length]; omega

end ComputableAnalysis.RepresentedPolynomial
