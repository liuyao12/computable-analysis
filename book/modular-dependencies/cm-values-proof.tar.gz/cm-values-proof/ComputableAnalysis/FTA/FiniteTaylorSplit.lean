import ComputableAnalysis.FTA.BudgetedLocalDescent

namespace ComputableAnalysis
open QComplex

private theorem complex_ext (x y : QComplex) (hr : x.re = y.re) (hi : x.im = y.im) : x = y := by
  cases x
  cases y
  simp_all

namespace CPoly

/-- Exact Horner concatenation for supplied finite coefficient lists. -/
theorem eval_append_split (p q : Coeffs) (z : QComplex) :
    eval (p ++ q) z = add (eval p z) (mul (pow z p.length) (eval q z)) := by
  induction p with
  | nil =>
    simp only [List.nil_append, List.length_nil, eval, List.foldr_nil, pow]
    apply complex_ext <;> simp only [QComplex.add, QComplex.mul, QComplex.zero, QComplex.one] <;> grind
  | cons a p ih =>
    change add a (mul z (eval (p ++ q) z)) =
      add (add a (mul z (eval p z))) (mul (pow z (p.length+1)) (eval q z))
    rw [ih, pow, mul_add_cert, mul_assoc_cert]
    apply complex_ext <;> simp only [QComplex.add] <;> grind

/-- Splitting at any selected Taylor order retains all earlier coefficients,
including small nonzero ones, in their actual polynomial contribution. -/
theorem eval_selected_split (c a : QComplex) (early tail : Coeffs) (h : QComplex) :
    eval (c :: (early ++ a :: tail)) h =
      add (add c (mul (pow h (early.length+1)) (add a (mul h (eval tail h)))))
        (mul h (eval early h)) := by
  change add c (mul h (eval (early ++ a :: tail) h)) = _
  rw [eval_append_split]
  change add c (mul h (add (eval early h)
    (mul (pow h early.length) (add a (mul h (eval tail h)))))) = _
  rw [mul_add_cert, ← mul_assoc_cert, ← pow]
  apply complex_ext <;> simp only [QComplex.add] <;> grind

end CPoly

namespace PolynomialDirection

theorem scaled_power (t : Rat) (d : QComplex) (k : Nat) :
    pow (scaleRat t d) k = scaleRat (t^k) (pow d k) := by
  induction k with
  | zero =>
    simp only [pow, Rat.pow_zero]
    apply complex_ext <;> simp only [scaleRat, QComplex.one] <;> grind
  | succ k ih =>
    rw [pow, ih, pow, Rat.pow_succ]
    apply complex_ext <;> simp only [QComplex.mul, scaleRat] <;> grind

/-- The actual split polynomial equals the local expression consumed by the
quantitative norm-descent theorem, with the exact earlier contribution. -/
theorem scaled_selected_split (c a : QComplex) (early tail : CPoly.Coeffs)
    (t : Rat) (d : QComplex) :
    let h := scaleRat t d
    CPoly.eval (c :: (early ++ a :: tail)) h =
      add (add c (scaleRat (t^(early.length+1))
        (add (mul a (pow d (early.length+1)))
          (scaleRat t (mul (pow d (early.length+2)) (CPoly.eval tail h))))))
        (mul h (CPoly.eval early h)) := by
  dsimp only
  rw [CPoly.eval_selected_split, scaled_power]
  have hid : mul (scaleRat (t^(early.length+1)) (pow d (early.length+1)))
      (add a (mul (scaleRat t d) (CPoly.eval tail (scaleRat t d)))) =
      scaleRat (t^(early.length+1))
        (add (mul a (pow d (early.length+1)))
          (scaleRat t (mul (pow d (early.length+2)) (CPoly.eval tail (scaleRat t d))))) := by
    change mul (scaleRat (t^(early.length+1)) (pow d (early.length+1))) _ =
      scaleRat (t^(early.length+1))
        (add (mul a (pow d (early.length+1)))
          (scaleRat t (mul (mul d (pow d (early.length+1))) (CPoly.eval tail (scaleRat t d)))))
    apply complex_ext <;> simp only [QComplex.mul, QComplex.add, scaleRat] <;> grind
  rw [hid]

end PolynomialDirection
namespace PolynomialNormDescent
open PolynomialDirection

/-- The descent result now applies to the actual supplied split polynomial,
with every coefficient retained and its earlier error evaluated explicitly. -/
theorem split_polynomial_decrease (c a seed d : QComplex) (early tail : CPoly.Coeffs)
    (delta : QPos) (C A R eta t : Rat) (k : Nat)
    (hC : 0 ≤ C) (hA : 0 ≤ A) (hR : 0 ≤ R) (hk : 0 < k)
    (hlen : early.length+1 = k) (hd : d = selectedPaletteDirection k hk seed eta)
    (hc : normBound c ≤ C) (ha : normBound (mul a (pow d k)) ≤ A)
    (hr : normBound (mul (pow d (k+1)) (CPoly.eval tail (scaleRat t d))) ≤ R)
    (hdir : (mul (conj c) (mul a (pow d k))).re ≤ -delta.val)
    (ht : 0 < t) (htle : t ≤ step delta.val C A R)
    (hp : ∀ b ∈ early, normBound b ≤
      (earlyCoefficientCap (errorAllowance (C+A+R) (by grind) (localGap delta t ht k))
        early.length (paletteRadius k hk) t (Rat.le_of_lt (paletteRadius_pos k hk))
        (Rat.le_of_lt ht)).val) :
    normSq (CPoly.eval (c :: (early ++ a :: tail)) (scaleRat t d)) ≤
      normSq c - t^k*delta.val/2 := by
  have hnext : early.length+2 = k+1 := by omega
  rw [scaled_selected_split, hlen, hnext]
  have hs := decrease_with_capped_early_terms c (mul a (pow d k))
    (mul (pow d (k+1)) (CPoly.eval tail (scaleRat t d))) seed early
    delta C A R eta t k hC hA hR hk hc ha hr hdir ht htle hp
  simpa only [← hd] using hs

end PolynomialNormDescent
end ComputableAnalysis
