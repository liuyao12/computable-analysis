import ComputableAnalysis.FTA.RepresentedDirection
import ComputableAnalysis.FTA.MinimumPrecisionSearch
import ComputableAnalysis.FTA.Minimizer

namespace ComputableAnalysis.RepresentedPolynomial
open RiemannHilbert

def directionValue (c : ComplexCert) (order : Nat) (d : QComplex) : ComplexCert :=
  mul c (ofQComplex (QComplex.pow d order))

def directionTest (c : ComplexCert) (order stage : Nat) (d : QComplex) : Bool :=
  decide (((directionValue c order d).raw.compute stage).hi.re < 0)

def directionCandidates (stage : Nat) : List QComplex :=
  (List.range (stage+1)).map rationalPoint

def directionAdequate (c : ComplexCert) (order stage : Nat) : Bool :=
  (directionCandidates stage).any (directionTest c order stage)

theorem directionAdequate_eventually (c : ComplexCert) (hc : ¬ c.raw.Equiv zero.raw)
    (order : Nat) (horder : 0 < order) :
    ∃ N, ∀ n, N ≤ n → directionAdequate c order n = true := by
  obtain ⟨d, hd⟩ := exists_represented_negative_direction c hc order horder
  obtain ⟨s, hs⟩ := hd
  refine ⟨max s (rationalPointIndex d), ?_⟩
  intro n hn
  have hnest := ComplexRaw.valid_nestedIn (directionValue c order d).valid (show s ≤ n by omega)
  have hnegative : ((directionValue c order d).raw.compute n).hi.re < 0 := by
    change ((directionValue c order d).raw.compute s).hi.re < 0 at hs
    have hhi := hnest.2.1
    grind
  apply List.any_eq_true.mpr
  refine ⟨d, List.mem_map.mpr ⟨rationalPointIndex d, List.mem_range.mpr (by omega), rationalPoint_index d⟩, ?_⟩
  simpa [directionTest] using hnegative

def directionSearchStage (c : ComplexCert) (hc : ¬ c.raw.Equiv zero.raw)
    (order : Nat) (horder : 0 < order) : Nat :=
  PrecisionSearch.firstFrom (directionAdequate c order)
    (directionAdequate_eventually c hc order horder) 0

def firstPassing (test : QComplex → Bool) : List QComplex → QComplex
  | [] => QComplex.one
  | d :: ds => if test d then d else firstPassing test ds

theorem firstPassing_spec (test : QComplex → Bool) (xs : List QComplex)
    (h : xs.any test = true) : test (firstPassing test xs) = true := by
  induction xs with
  | nil => simp at h
  | cons d ds ih =>
    rw [firstPassing]
    split
    · assumption
    · apply ih
      have hf : test d = false := by cases he : test d <;> simp_all
      simpa [List.any_cons, hf] using h

def negativeDirection (c : ComplexCert) (hc : ¬ c.raw.Equiv zero.raw)
    (order : Nat) (horder : 0 < order) : QComplex :=
  let n := directionSearchStage c hc order horder
  firstPassing (directionTest c order n) (directionCandidates n)

theorem negativeDirection_spec (c : ComplexCert) (hc : ¬ c.raw.Equiv zero.raw)
    (order : Nat) (horder : 0 < order) :
    ((directionValue c order (negativeDirection c hc order horder)).raw.compute
      (directionSearchStage c hc order horder)).hi.re < 0 := by
  have h := (PrecisionSearch.firstFrom_spec (directionAdequate c order)
    (directionAdequate_eventually c hc order horder) 0).2
  have hp := firstPassing_spec (directionTest c order (directionSearchStage c hc order horder))
    (directionCandidates (directionSearchStage c hc order horder)) h
  simpa [directionTest, negativeDirection] using hp

/-- A positive rational inward margin computed from the successful enclosure. -/
def negativeDirectionMargin (c : ComplexCert) (hc : ¬ c.raw.Equiv zero.raw)
    (order : Nat) (horder : 0 < order) : QPos :=
  ⟨-((directionValue c order (negativeDirection c hc order horder)).raw.compute
      (directionSearchStage c hc order horder)).hi.re, by
    have h := negativeDirection_spec c hc order horder
    grind⟩

/-- The computed inward margin controls every rational point in every later
coefficient enclosure, not just the sample used to recognize the direction. -/
theorem negativeDirectionMargin_uniform (c : ComplexCert) (hc : ¬ c.raw.Equiv zero.raw)
    (order : Nat) (horder : 0 < order) (m : Nat)
    (hm : directionSearchStage c hc order horder ≤ m) (v : QComplex)
    (hl : (c.raw.compute m).lo ≤ v) (hh : v ≤ (c.raw.compute m).hi) :
    (QComplex.mul v (QComplex.pow (negativeDirection c hc order horder) order)).re ≤
      -(negativeDirectionMargin c hc order horder).val := by
  let n := directionSearchStage c hc order horder
  let d := negativeDirection c hc order horder
  have hn := ComplexRaw.valid_nestedIn c.valid hm
  have hmul := (QBox.mul_contains (A := c.raw.compute n) (B := QBox.point (QComplex.pow d order)) (QComplex.le_trans hn.1 hl) (QComplex.le_trans hh hn.2)
    (QComplex.le_refl (QComplex.pow d order)) (QComplex.le_refl (QComplex.pow d order))).2.1
  change (QComplex.mul v (QComplex.pow d order)).re ≤
    ((directionValue c order d).raw.compute n).hi.re at hmul
  simpa only [negativeDirectionMargin, Rat.neg_neg] using hmul

end ComputableAnalysis.RepresentedPolynomial
