import ComputableAnalysis.FTA.CoefficientErrorConvergence
import ComputableAnalysis.RiemannHilbert.PrecisionSearch

/-! Literal terminating searches for coefficient and mesh precision. The
runtime evaluates rational bounds; convergence evidence is erased. -/
namespace ComputableAnalysis.RepresentedPolynomial
open RiemannHilbert

def coefficientAdequate (p : Coefficients) (R : Rat) (eps : QPos) (n : Nat) : Bool :=
  decide (sampleDifferenceMajorant p n R ≤ eps.val)

theorem coefficientAdequate_eventually (p : Coefficients) (R : Rat)
    (hR : 0 ≤ R) (eps : QPos) :
    ∃ N, ∀ n, N ≤ n → coefficientAdequate p R eps n = true := by
  obtain ⟨N, hN⟩ := sampleDifferenceMajorant_shrinks p R hR eps
  exact ⟨N, fun n hn => by simpa [coefficientAdequate] using hN n hn⟩

def coefficientPrecision (p : Coefficients) (R : Rat) (hR : 0 ≤ R)
    (eps : QPos) (start : Nat) : Nat :=
  PrecisionSearch.firstFrom (coefficientAdequate p R eps)
    (coefficientAdequate_eventually p R hR eps) start

theorem coefficientPrecision_spec (p : Coefficients) (R : Rat) (hR : 0 ≤ R)
    (eps : QPos) (start : Nat) : start ≤ coefficientPrecision p R hR eps start ∧
      sampleDifferenceMajorant p (coefficientPrecision p R hR eps start) R ≤ eps.val := by
  have h := PrecisionSearch.firstFrom_spec (coefficientAdequate p R eps)
    (coefficientAdequate_eventually p R hR eps) start
  exact ⟨h.1, by simpa [coefficientAdequate, coefficientPrecision] using h.2⟩

end ComputableAnalysis.RepresentedPolynomial

namespace ComputableAnalysis.FiniteApproximateMinimum
open RiemannHilbert

def meshAdequate (p : CPoly.Coeffs) (box : QBox) (eps : QPos) (depth : Nat) : Bool :=
  decide (budget p box depth ≤ eps.val)

theorem meshAdequate_eventually (p : CPoly.Coeffs) (box : QBox)
    (ho : box.Ordered) (eps : QPos) :
    ∃ N, ∀ n, N ≤ n → meshAdequate p box eps n = true := by
  obtain ⟨N, hN⟩ := budget_shrinks p box ho eps
  exact ⟨N, fun n hn => by simpa [meshAdequate] using hN n hn⟩

def meshPrecision (p : CPoly.Coeffs) (box : QBox) (ho : box.Ordered)
    (eps : QPos) (start : Nat) : Nat :=
  PrecisionSearch.firstFrom (meshAdequate p box eps)
    (meshAdequate_eventually p box ho eps) start

theorem meshPrecision_spec (p : CPoly.Coeffs) (box : QBox) (ho : box.Ordered)
    (eps : QPos) (start : Nat) : start ≤ meshPrecision p box ho eps start ∧
      budget p box (meshPrecision p box ho eps start) ≤ eps.val := by
  have h := PrecisionSearch.firstFrom_spec (meshAdequate p box eps)
    (meshAdequate_eventually p box ho eps) start
  exact ⟨h.1, by simpa [meshAdequate, meshPrecision] using h.2⟩

end ComputableAnalysis.FiniteApproximateMinimum

namespace ComputableAnalysis.RepresentedPolynomial
open FiniteApproximateMinimum

def scheduledCoefficientStage (p : Coefficients) (box : QBox) (eps : QPos)
    (start : Nat) : Nat :=
  coefficientPrecision p box.normMajorant box.normMajorant_nonneg eps start

def scheduledMeshDepth (p : Coefficients) (box : QBox) (ho : box.Ordered)
    (coeff mesh : QPos) (start : Nat) : Nat :=
  meshPrecision (coefficientSamples p (scheduledCoefficientStage p box coeff start))
    box ho mesh 0

def scheduledCandidate (p : Coefficients) (box : QBox) (ho : box.Ordered)
    (coeff mesh : QPos) (start : Nat) : QComplex :=
  polynomialMinimum (coefficientSamples p (scheduledCoefficientStage p box coeff start))
    box (scheduledMeshDepth p box ho coeff mesh start)

/-- A completely executable scheduled candidate has a checked comparison
against every rational argument and every later coefficient sample. The
remaining normalization of the coefficient budget is explicit in the bound. -/
theorem scheduledCandidate_le (p : Coefficients) (box : QBox) (ho : box.Ordered)
    (coeff mesh : QPos) (start m : Nat)
    (hm : scheduledCoefficientStage p box coeff start ≤ m)
    (z : QComplex) (hl : box.lo ≤ z) (hh : z ≤ box.hi) :
    QComplex.normSq (CPoly.eval (coefficientSamples p m)
      (scheduledCandidate p box ho coeff mesh start)) ≤
      QComplex.normSq (CPoly.eval (coefficientSamples p m) z) + mesh.val +
        4 * sampleNormMajorant p (scheduledCoefficientStage p box coeff start) box.normMajorant * coeff.val := by
  let n := scheduledCoefficientStage p box coeff start
  let d := scheduledMeshDepth p box ho coeff mesh start
  have hc := (coefficientPrecision_spec p box.normMajorant box.normMajorant_nonneg coeff start).2
  have hg := (meshPrecision_spec (coefficientSamples p n) box ho mesh 0).2
  have h := sampled_minimum_le p n n m d (Nat.le_refl _) hm box ho z hl hh
  have hnorm : 0 ≤ sampleNormMajorant p n box.normMajorant :=
    Rat.le_trans (CPoly.normMajorant_nonneg (coefficientSamples p n) box.normMajorant box.normMajorant_nonneg)
      (sample_normMajorant_le p n n (Nat.le_refl _) box.normMajorant box.normMajorant_nonneg)
  have hmul := Rat.mul_le_mul_of_nonneg_left hc
    (Rat.mul_nonneg (by decide +kernel : (0 : Rat) ≤ 4) hnorm)
  change budget (coefficientSamples p n) box d ≤ mesh.val at hg
  change sampleDifferenceMajorant p n box.normMajorant ≤ coeff.val at hc
  change 4 * sampleNormMajorant p n box.normMajorant * sampleDifferenceMajorant p n box.normMajorant ≤
    4 * sampleNormMajorant p n box.normMajorant * coeff.val at hmul
  change QComplex.normSq (CPoly.eval (coefficientSamples p m)
    (polynomialMinimum (coefficientSamples p n) box d)) ≤
      QComplex.normSq (CPoly.eval (coefficientSamples p m) z) + mesh.val +
        4 * sampleNormMajorant p n box.normMajorant * coeff.val
  grind

end ComputableAnalysis.RepresentedPolynomial
