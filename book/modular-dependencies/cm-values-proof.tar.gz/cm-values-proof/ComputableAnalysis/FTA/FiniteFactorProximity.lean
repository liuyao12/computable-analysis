import ComputableAnalysis.FTA.FinitePeelingError

namespace ComputableAnalysis.PolynomialDirection
open QComplex RepresentedPolynomial

/-- Squared norms avoid extracting any rational or represented square root. -/
theorem finiteFactorProduct_separation (xs : List (QComplex × QComplex)) (z : QComplex)
    (rho : Rat) (hrho : 0 ≤ rho)
    (hsep : ∀ x ∈ xs, rho ≤ normSq (sub z x.1)) :
    rho^xs.length ≤ normSq (finiteFactorProduct xs z) := by
  induction xs with
  | nil => change (rho^0) ≤ normSq QComplex.one; rw [Rat.pow_zero]; decide +kernel
  | cons x xs ih =>
    have ht := ih (by intro y hy; exact hsep y (by simp [hy]))
    have hh := hsep x (by simp)
    have hid : normSq (finiteFactorProduct (x::xs) z) =
        normSq (sub z x.1)*normSq (finiteFactorProduct xs z) := by
      simp only [finiteFactorProduct, normSq, QComplex.mul]
      grind
    have h1 := Rat.mul_le_mul_of_nonneg_left ht hrho
    have hnon : 0 ≤ normSq (finiteFactorProduct xs z) := by
      have hr := rat_square_nonneg_basic (finiteFactorProduct xs z).re
      have hi := rat_square_nonneg_basic (finiteFactorProduct xs z).im
      unfold normSq
      grind
    have h2 := Rat.mul_le_mul_of_nonneg_right hh hnon
    rw [hid]
    simp only [List.length_cons, Rat.pow_succ]
    grind

/-- A small product forces a nearby actual factor, including repeated roots. -/
theorem finiteFactorProduct_near (xs : List (QComplex × QComplex)) (z : QComplex)
    (rho : Rat) (hrho : 0 ≤ rho) (hsmall : normSq (finiteFactorProduct xs z) < rho^xs.length) :
    ∃ x ∈ xs, normSq (sub z x.1) < rho := by
  by_cases hnear : ∃ x ∈ xs, normSq (sub z x.1) < rho
  · exact hnear
  · have hsep : ∀ x ∈ xs, rho ≤ normSq (sub z x.1) := by
      intro x hx
      have hn : ¬ normSq (sub z x.1) < rho := by
        intro h; exact hnear ⟨x, hx, h⟩
      grind
    have hb := finiteFactorProduct_separation xs z rho hrho hsep
    grind

def nearbyFactor (xs : List (QComplex × QComplex)) (z : QComplex) (rho : Rat) : QComplex :=
  firstPassing (fun r => decide (normSq (sub z r) < rho)) (xs.map Prod.fst)

/-- Executable selection realizes the proximity bound. -/
theorem nearbyFactor_spec (xs : List (QComplex × QComplex)) (z : QComplex)
    (rho : Rat) (hrho : 0 ≤ rho) (hsmall : normSq (finiteFactorProduct xs z) < rho^xs.length) :
    normSq (sub z (nearbyFactor xs z rho)) < rho := by
  obtain ⟨x, hx, hn⟩ := finiteFactorProduct_near xs z rho hrho hsmall
  have hgood : (xs.map Prod.fst).any (fun r => decide (normSq (sub z r) < rho)) = true := by
    apply List.any_eq_true.mpr
    exact ⟨x.1, List.mem_map.mpr ⟨x, hx, rfl⟩, by simpa using hn⟩
  have hs := firstPassing_spec (fun r => decide (normSq (sub z r) < rho)) (xs.map Prod.fst) hgood
  simpa [nearbyFactor] using hs

end ComputableAnalysis.PolynomialDirection
