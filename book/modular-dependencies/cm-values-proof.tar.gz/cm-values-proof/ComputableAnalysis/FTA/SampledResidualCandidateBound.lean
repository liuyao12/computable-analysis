import ComputableAnalysis.FTA.RationalMeshResidual
import ComputableAnalysis.FTA.MinimumInteriorMargin

namespace ComputableAnalysis
open QComplex PolynomialCoercivity PolynomialDirection FiniteApproximateMinimum

theorem CPoly.normMajorant_one (p : CPoly.Coeffs) :
    CPoly.normMajorant p 1 = coefficientBound p := by
  induction p with
  | nil => rfl
  | cons a p ih => simp only [CPoly.normMajorant, coefficientBound, ih, Rat.one_mul]

namespace PolynomialDirection

theorem rationalResidualCandidate_interior (q : CPoly.Coeffs) (hq : 0 < q.length)
    (rho : QPos) (start : Nat) :
    normBound (rationalResidualCandidate q rho start) ≤ rationalSearchRadius q-1 := by
  apply rational_mesh_interior q hq
  have hb := (meshPrecision_spec (q++[QComplex.one]) (rationalSearchBox q)
    (rationalSearchBox_ordered q) (rationalResidualBudget q rho) start).2
  exact Rat.le_trans hb (QPos.minimum_le_left _ _)

end PolynomialDirection

namespace RepresentedPolynomial

/-- Every rational approximate root of every coefficient sample stays inside
one centre-independent ball computed from the original coefficient names. -/
theorem sampledResidualCandidate_bound (q : Coefficients) (hq : 0 < q.length)
    (k : Nat) (rho : QPos) (start : Nat) :
    normBound (rationalResidualCandidate (coefficientSamples q k) rho start) ≤
      interiorSearchRadius q-1 := by
  have hb := rationalResidualCandidate_interior (coefficientSamples q k)
    (by simpa [coefficientSamples] using hq) rho start
  have hc := coefficientSamples_bound q k
  have h0 := coefficientBound_nonneg (coefficientSamples q k)
  have hC := coefficientRadius_nonneg q
  have hm : CPoly.normMajorant (coefficientSamples q k ++ [QComplex.one]) 1 =
      coefficientBound (coefficientSamples q k)+1 := by
    rw [CPoly.normMajorant_one, coefficientBound_append]
    have hone : coefficientBound [QComplex.one] = 1 := by decide +kernel
    rw [hone]
  have h1 := Rat.mul_le_mul_of_nonneg_left (show coefficientBound (coefficientSamples q k)+1 ≤ coefficientRadius q+1 by grind)
    (show 0 ≤ coefficientBound (coefficientSamples q k)+1 by grind)
  have h2 := Rat.mul_le_mul_of_nonneg_right (show coefficientBound (coefficientSamples q k)+1 ≤ coefficientRadius q+1 by grind)
    (show 0 ≤ coefficientRadius q+1 by grind)
  unfold rationalSearchRadius at hb
  rw [hm] at hb
  unfold interiorSearchRadius
  simp only [Rat.pow_succ, Rat.pow_zero, Rat.one_mul] at *
  grind

end RepresentedPolynomial
end ComputableAnalysis
