import ComputableAnalysis.FTA.SampledPeelingContainment

namespace ComputableAnalysis.RepresentedPolynomial

/-- Points in overlapping boxes differ by at most the sum of their coordinate
widths. This finite estimate requires no selection of a completed value. -/
theorem overlapping_samples_bound (A B : QBox) (x y : QComplex)
    (hx : A.lo ≤ x ∧ x ≤ A.hi) (hy : B.lo ≤ y ∧ y ≤ B.hi)
    (hover : A.lo ≤ B.hi ∧ B.lo ≤ A.hi) :
    QComplex.normBound (QComplex.sub x y) ≤ A.width+B.width+A.height+B.height := by
  change (A.lo.re ≤ x.re ∧ A.lo.im ≤ x.im) ∧ (x.re ≤ A.hi.re ∧ x.im ≤ A.hi.im) at hx
  change (B.lo.re ≤ y.re ∧ B.lo.im ≤ y.im) ∧ (y.re ≤ B.hi.re ∧ y.im ≤ B.hi.im) at hy
  change (A.lo.re ≤ B.hi.re ∧ A.lo.im ≤ B.hi.im) ∧
    (B.lo.re ≤ A.hi.re ∧ B.lo.im ≤ A.hi.im) at hover
  have hr : qabs (x.re-y.re) ≤ A.width+B.width := by
    apply qabs_le_of_neg_le_le <;> unfold QBox.width <;> grind
  have hi : qabs (x.im-y.im) ≤ A.height+B.height := by
    apply qabs_le_of_neg_le_le <;> unfold QBox.height <;> grind
  change qabs (x.re + -y.re) + qabs (x.im + -y.im) ≤ _
  grind [Rat.sub_eq_add_neg]

/-- Equivalent represented reconstructions give a finite quantitative bound
on their actual sampled rational values. -/
theorem sampledPeeling_comparison (xs ys : List (QComplex × ComplexCert))
    (z : QComplex) (n : Nat)
    (h : (peelingValue xs (ofQComplex z)).raw.Equiv
      (peelingValue ys (ofQComplex z)).raw) :
    QComplex.normBound (QComplex.sub
      (PolynomialDirection.finitePeelingValue (sampledPeeling xs n) z)
      (PolynomialDirection.finitePeelingValue (sampledPeeling ys n) z)) ≤
    ((peelingValue xs (ofQComplex z)).raw.compute n).width +
    ((peelingValue ys (ofQComplex z)).raw.compute n).width +
    ((peelingValue xs (ofQComplex z)).raw.compute n).height +
    ((peelingValue ys (ofQComplex z)).raw.compute n).height := by
  apply overlapping_samples_bound _ _ _ _ (sampledPeeling_contains xs n z)
    (sampledPeeling_contains ys n z)
  exact (ComplexRaw.compareAt_overlap_iff _ _ n n).mp (h n)

/-- Two actual complete peelings reconstruct the same supplied polynomial,
so the finite comparison applies without an assumed reconstruction identity. -/
theorem approximatePeeling_comparison (p : Coefficients) (hp : Monic p)
    (eps eta : QPos) (start stop n : Nat) (z : QComplex) :
    let xs := approximatePeeling p hp eps start
    let ys := approximatePeeling p hp eta stop
    QComplex.normBound (QComplex.sub
      (PolynomialDirection.finitePeelingValue (sampledPeeling xs n) z)
      (PolynomialDirection.finitePeelingValue (sampledPeeling ys n) z)) ≤
    ((peelingValue xs (ofQComplex z)).raw.compute n).width +
    ((peelingValue ys (ofQComplex z)).raw.compute n).width +
    ((peelingValue xs (ofQComplex z)).raw.compute n).height +
    ((peelingValue ys (ofQComplex z)).raw.compute n).height := by
  apply sampledPeeling_comparison
  exact ComplexRaw.equiv_trans
    (peelingValue (approximatePeeling p hp eps start) (ofQComplex z)).valid
    (eval p (ofQComplex z)).valid
    (peelingValue (approximatePeeling p hp eta stop) (ofQComplex z)).valid
    (ComplexRaw.equiv_symm (approximatePeeling_reconstruction p hp eps start (ofQComplex z)))
    (approximatePeeling_reconstruction p hp eta stop (ofQComplex z))

end ComputableAnalysis.RepresentedPolynomial
