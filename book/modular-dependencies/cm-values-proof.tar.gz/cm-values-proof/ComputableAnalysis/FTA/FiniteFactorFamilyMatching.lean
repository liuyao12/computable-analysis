import ComputableAnalysis.FTA.FiniteFactorProximity

namespace ComputableAnalysis.PolynomialDirection
open QComplex

private theorem complex_ext (x y : QComplex) (hr : x.re = y.re) (hi : x.im = y.im) : x = y := by
  cases x
  cases y
  simp_all

theorem finiteFactorProduct_zero_at_member (xs : List (QComplex × QComplex))
    (x : QComplex × QComplex) (hx : x ∈ xs) : finiteFactorProduct xs x.1 = QComplex.zero := by
  induction xs with
  | nil => simp at hx
  | cons y xs ih =>
    rcases List.mem_cons.mp hx with heq | hx
    · subst x
      rw [finiteFactorProduct]
      apply complex_ext <;> simp only [sub, add, neg, mul, QComplex.zero] <;> grind
    · rw [finiteFactorProduct, ih hx]
      apply complex_ext <;> simp only [mul, QComplex.zero] <;> grind

/-- Comparison and omitted-remainder errors bound the actual second-family product. -/
theorem finiteFactorFamily_product_bound (xs ys : List (QComplex × QComplex))
    (x : QComplex × QComplex) (hx : x ∈ xs) (A : Rat)
    (hcompare : normBound (sub (finitePeelingValue ys x.1) (finitePeelingValue xs x.1)) ≤ A) :
    normSq (finiteFactorProduct ys x.1) ≤
      (A+peelingErrorMajorant xs x.1+peelingErrorMajorant ys x.1)^2 := by
  let z := x.1
  let u := finitePeelingValue xs z
  let v := finitePeelingValue ys z
  let w := finiteFactorProduct ys z
  have hz := finiteFactorProduct_zero_at_member xs x hx
  have hxerr := finitePeeling_error_bound xs z
  rw [hz] at hxerr
  have hu : sub u QComplex.zero = u := by
    apply complex_ext <;> simp only [sub, add, neg, QComplex.zero] <;> grind
  change normBound (sub u QComplex.zero) ≤ peelingErrorMajorant xs z at hxerr
  rw [hu] at hxerr
  have hyerr := finitePeeling_error_bound ys z
  have hv : v = add (sub v u) u := by
    apply complex_ext <;> simp only [sub, add, neg] <;> grind
  have hvbound := normBound_add_le (sub v u) u
  rw [← hv] at hvbound
  have hw : w = sub v (sub v w) := by
    apply complex_ext <;> simp only [sub, add, neg] <;> grind
  have hwbound := normBound_sub_le v (sub v w)
  rw [← hw] at hwbound
  have hb : normBound w ≤ A+peelingErrorMajorant xs z+peelingErrorMajorant ys z := by grind
  have hn := normBound_nonneg w
  have hB : 0 ≤ A+peelingErrorMajorant xs z+peelingErrorMajorant ys z := Rat.le_trans hn hb
  have h1 := Rat.mul_le_mul_of_nonneg_left hb hn
  have h2 := Rat.mul_le_mul_of_nonneg_right hb hB
  have hs := PolynomialCoercivity.normSq_le_normBound_square w
  have hsq : normSq w ≤ (A+peelingErrorMajorant xs z+peelingErrorMajorant ys z)^2 := by
    simp only [Rat.pow_succ, Rat.pow_zero, Rat.one_mul] at *
    grind
  exact hsq

/-- Close reconstructed values and small actual omitted-remainder errors give
executable directed proximity between finite factor families. This is not yet
a multiplicity-preserving bijection. -/
theorem finiteFactorFamily_near (xs ys : List (QComplex × QComplex))
    (x : QComplex × QComplex) (hx : x ∈ xs) (A rho : Rat)
    (hA : 0 ≤ A) (hrho : 0 ≤ rho)
    (hcompare : normBound (sub (finitePeelingValue ys x.1) (finitePeelingValue xs x.1)) ≤ A)
    (hsmall : (A+peelingErrorMajorant xs x.1+peelingErrorMajorant ys x.1)^2 < rho^ys.length) :
    normSq (sub x.1 (nearbyFactor ys x.1 rho)) < rho := by
  have hb := finiteFactorFamily_product_bound xs ys x hx A hcompare
  apply nearbyFactor_spec ys x.1 rho hrho
  grind only

end ComputableAnalysis.PolynomialDirection
