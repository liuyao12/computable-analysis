import ComputableAnalysis.FTA.PaletteTaylorBound

namespace ComputableAnalysis.PolynomialDirection

/-- Each finite coefficient is paired with its rational significance threshold.
The scan uses rational comparisons, including when coefficients vanish. -/
def significantIndex : List (QComplex × Rat) → Nat
  | [] => 0
  | x :: xs => if x.2 < QComplex.normBound x.1 then 0 else significantIndex xs + 1

/-- A passing coefficient ensures that the executable scan selects an actual
entry; every preceding entry satisfies its assigned smallness threshold. -/
theorem significantIndex_spec (xs : List (QComplex × Rat))
    (h : ∃ x ∈ xs, x.2 < QComplex.normBound x.1) :
    ∃ before x after, xs = before ++ x :: after ∧
      significantIndex xs = before.length ∧ x.2 < QComplex.normBound x.1 ∧
      ∀ y ∈ before, QComplex.normBound y.1 ≤ y.2 := by
  induction xs with
  | nil => obtain ⟨x, hx, _⟩ := h; simp at hx
  | cons x xs ih =>
    by_cases hx : x.2 < QComplex.normBound x.1
    · refine ⟨[], x, xs, rfl, ?_, hx, ?_⟩
      · simp [significantIndex, hx]
      · intro y hy; simp at hy
    · have htail : ∃ y ∈ xs, y.2 < QComplex.normBound y.1 := by
        obtain ⟨y, hy, hp⟩ := h
        rcases List.mem_cons.mp hy with heq | hy
        · subst y; exact False.elim (hx hp)
        · exact ⟨y, hy, hp⟩
      obtain ⟨before, y, after, heq, hi, hp, hb⟩ := ih htail
      refine ⟨x :: before, y, after, ?_, ?_, hp, ?_⟩
      · simp [heq]
      · simp [significantIndex, hx, hi]
      · intro z hz
        rcases List.mem_cons.mp hz with heq | hz
        · subst z; grind
        · exact hb z hz

/-- Horner envelope made from thresholds rather than actual coefficient norms. -/
def thresholdMajorant : List (QComplex × Rat) → Rat → Rat
  | [], _ => 0
  | x :: xs, D => x.2 + D * thresholdMajorant xs D

/-- Smallness established by the scan bounds the actual polynomial prefix. -/
theorem prefix_majorant_le (xs : List (QComplex × Rat)) (D : Rat) (hD : 0 ≤ D)
    (hs : ∀ x ∈ xs, QComplex.normBound x.1 ≤ x.2) :
    CPoly.normMajorant (xs.map Prod.fst) D ≤ thresholdMajorant xs D := by
  induction xs with
  | nil => exact Rat.le_refl
  | cons x xs ih =>
    have hx := hs x (by simp)
    have ht := ih (by intro y hy; exact hs y (by simp [hy]))
    have hm := Rat.mul_le_mul_of_nonneg_left ht hD
    simp only [List.map_cons, CPoly.normMajorant, thresholdMajorant]
    grind

/-- The selected order has a concrete earlier prefix whose computed norm
majorant is bounded by the prescribed threshold envelope. -/
theorem significantIndex_prefix_bound (xs : List (QComplex × Rat))
    (h : ∃ x ∈ xs, x.2 < QComplex.normBound x.1) (D : Rat) (hD : 0 ≤ D) :
    ∃ before x after, xs = before ++ x :: after ∧
      significantIndex xs = before.length ∧ x.2 < QComplex.normBound x.1 ∧
      CPoly.normMajorant (before.map Prod.fst) D ≤ thresholdMajorant before D := by
  obtain ⟨before, x, after, heq, hi, hp, hb⟩ := significantIndex_spec xs h
  exact ⟨before, x, after, heq, hi, hp, prefix_majorant_le before D hD hb⟩

/-- The monic leading coefficient makes the finite scan total as soon as its
assigned threshold is strictly below one. -/
theorem monic_significantIndex_prefix_bound (xs : List (QComplex × Rat))
    (theta D : Rat) (htheta : theta < 1) (hD : 0 ≤ D) :
    ∃ before x after, xs ++ [(QComplex.one, theta)] = before ++ x :: after ∧
      significantIndex (xs ++ [(QComplex.one, theta)]) = before.length ∧
      x.2 < QComplex.normBound x.1 ∧
      CPoly.normMajorant (before.map Prod.fst) D ≤ thresholdMajorant before D := by
  apply significantIndex_prefix_bound _ _ D hD
  refine ⟨(QComplex.one, theta), ?_, ?_⟩
  · simp
  · have hn : QComplex.normBound QComplex.one = 1 := by decide +kernel
    simpa only [hn] using htheta

/-- The threshold envelope controls the actual earlier Taylor value on a
selected direction, without replacing that value by an assumed error record. -/
theorem selected_early_threshold_bound (early : List (QComplex × Rat))
    (order : Nat) (ho : 0 < order) (c : QComplex) (eta t : Rat)
    (ht : 0 ≤ t) (ht1 : t ≤ 1)
    (hs : ∀ x ∈ early, QComplex.normBound x.1 ≤ x.2) :
    let h := QComplex.scaleRat t (selectedPaletteDirection order ho c eta)
    QComplex.normBound (QComplex.mul h (CPoly.eval (early.map Prod.fst) h)) ≤
      t * paletteRadius order ho * thresholdMajorant early (paletteRadius order ho) := by
  have hb := selected_early_terms_bound (early.map Prod.fst) order ho c eta t ht ht1
  have hp := prefix_majorant_le early (paletteRadius order ho)
    (Rat.le_of_lt (paletteRadius_pos order ho)) hs
  have hm := Rat.mul_le_mul_of_nonneg_left hp
    (Rat.mul_nonneg ht (Rat.le_of_lt (paletteRadius_pos order ho)))
  exact Rat.le_trans hb hm

end ComputableAnalysis.PolynomialDirection
