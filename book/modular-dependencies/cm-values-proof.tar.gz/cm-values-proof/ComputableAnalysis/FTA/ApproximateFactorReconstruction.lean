import ComputableAnalysis.FTA.ApproximateDeflation

namespace ComputableAnalysis.RepresentedPolynomial

/-- Evaluate the retained approximate factors with their exact remainders.
The terminal monic constant is one. -/
def peelingValue : List (QComplex × ComplexCert) → ComplexCert → ComplexCert
  | [], _ => one
  | (r, remainder) :: items, x =>
      add remainder (mul (sub x (ofQComplex r)) (peelingValue items x))

private theorem singleton_one_eval (x : ComplexCert) : (eval [one] x).raw.Equiv one.raw := by
  have hz : (mul x zero).raw.Equiv zero.raw := by
    apply Arithmetic.Expression.equiv_of_samples
      (.mul (.parameter x) (.constant QComplex.zero)) (.constant QComplex.zero)
    intro s
    simp [Arithmetic.Expression.sample, QComplex.mul, QComplex.zero]
    grind
  exact ComplexRaw.equiv_trans (eval [one] x).valid (add one zero).valid one.valid
    (ComplexRaw.add_equiv (ComplexRaw.equiv_refl one.raw one.valid) hz) (add_zero one)

/-- Exact reconstruction from the actual complete approximate peeling. This
identity retains the error terms rather than treating approximate roots as roots. -/
theorem approximatePeeling_reconstruction (p : Coefficients) (hp : Monic p)
    (eps : QPos) (start : Nat) (x : ComplexCert) :
    (eval p x).raw.Equiv (peelingValue (approximatePeeling p hp eps start) x).raw := by
  rw [approximatePeeling]
  split
  · let r := ofQComplex (approximatePeelPoint p eps start)
    let qr := syntheticDivide r p
    have hi := approximatePeeling_reconstruction qr.1
      (syntheticDivide_monic r p hp ‹2 ≤ p.length›) eps start x
    have hm := ComplexRaw.mul_equiv (sub x r).valid (sub x r).valid
      (eval qr.1 x).valid (peelingValue (approximatePeeling qr.1
        (syntheticDivide_monic r p hp ‹2 ≤ p.length›) eps start) x).valid
      (ComplexRaw.equiv_refl (sub x r).raw (sub x r).valid) hi
    have ha := ComplexRaw.add_equiv (ComplexRaw.equiv_refl qr.2.raw qr.2.valid) hm
    exact ComplexRaw.equiv_trans (eval p x).valid
      (add qr.2 (mul (sub x r) (eval qr.1 x))).valid
      (peelingValue ((approximatePeelPoint p eps start, qr.2) ::
        approximatePeeling qr.1 (syntheticDivide_monic r p hp ‹2 ≤ p.length›) eps start) x).valid
      (syntheticDivide_spec r x p) ha
  · obtain ⟨q, hq⟩ := hp
    have hl := congrArg List.length hq
    have hn : q = [] := List.length_eq_zero_iff.mp (by
      simp only [List.length_append, List.length_cons, List.length_nil] at hl
      omega)
    rw [hn] at hq
    rw [hq]
    exact singleton_one_eval x
termination_by p.length
decreasing_by rw [syntheticDivide_length]; omega

end ComputableAnalysis.RepresentedPolynomial
