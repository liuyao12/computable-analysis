import ComputableAnalysis.FTA.ApproximateFactorReconstruction

namespace ComputableAnalysis.PolynomialDirection
open QComplex

def finitePeelingValue : List (QComplex × QComplex) → QComplex → QComplex
  | [], _ => QComplex.one
  | (r,e)::xs, z => add e (mul (sub z r) (finitePeelingValue xs z))

def finiteFactorProduct : List (QComplex × QComplex) → QComplex → QComplex
  | [], _ => QComplex.one
  | (r,_)::xs, z => mul (sub z r) (finiteFactorProduct xs z)

def peelingErrorMajorant : List (QComplex × QComplex) → QComplex → Rat
  | [], _ => 0
  | (r,e)::xs, z => normBound e+normBound (sub z r)*peelingErrorMajorant xs z

/-- Actual omitted-remainder error has an executable Horner majorant. -/
theorem finitePeeling_error_bound (xs : List (QComplex × QComplex)) (z : QComplex) :
    normBound (sub (finitePeelingValue xs z) (finiteFactorProduct xs z)) ≤ peelingErrorMajorant xs z := by
  induction xs with
  | nil => change normBound (sub QComplex.one QComplex.one) ≤ 0; decide +kernel
  | cons x xs ih =>
    rcases x with ⟨r,e⟩
    have hid : sub (finitePeelingValue ((r,e)::xs) z) (finiteFactorProduct ((r,e)::xs) z) =
        add e (mul (sub z r) (sub (finitePeelingValue xs z) (finiteFactorProduct xs z))) := by
      cases he : e
      simp only [finitePeelingValue, finiteFactorProduct, sub, add, neg, mul, QComplex.mk.injEq]
      constructor <;> grind
    rw [hid]
    have ha := normBound_add_le e (mul (sub z r) (sub (finitePeelingValue xs z) (finiteFactorProduct xs z)))
    have hm := normBound_mul_le (sub z r) (sub (finitePeelingValue xs z) (finiteFactorProduct xs z))
    have hh := Rat.mul_le_mul_of_nonneg_left ih (normBound_nonneg (sub z r))
    change normBound _ ≤ normBound e+normBound (sub z r)*peelingErrorMajorant xs z
    grind

/-- Common remainder and linear-factor bounds give a degree-dependent error
bound for the actual complete finite reconstruction. -/
theorem peelingErrorMajorant_uniform (xs : List (QComplex × QComplex)) (z : QComplex)
    (E D : Rat) (hE : 0 ≤ E) (hD : 0 ≤ D)
    (he : ∀ x ∈ xs, normBound x.2 ≤ E) (hd : ∀ x ∈ xs, normBound (sub z x.1) ≤ D) :
    peelingErrorMajorant xs z ≤ E*geometricEnvelope xs.length D := by
  induction xs with
  | nil => simp only [peelingErrorMajorant, List.length_nil, geometricEnvelope, Rat.mul_zero]; exact Rat.le_refl
  | cons x xs ih =>
    have ht := ih (by intro y hy; exact he y (by simp [hy])) (by intro y hy; exact hd y (by simp [hy]))
    have h1 := Rat.mul_le_mul_of_nonneg_left ht (normBound_nonneg (sub z x.1))
    have h2 := Rat.mul_le_mul_of_nonneg_right (hd x (by simp))
      (Rat.mul_nonneg hE (geometricEnvelope_nonneg xs.length D hD))
    have hh := he x (by simp)
    change normBound x.2+normBound (sub z x.1)*peelingErrorMajorant xs z ≤ E*(1+D*geometricEnvelope xs.length D)
    grind

end ComputableAnalysis.PolynomialDirection
