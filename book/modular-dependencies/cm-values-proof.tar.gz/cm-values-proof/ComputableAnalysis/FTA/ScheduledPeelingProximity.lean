import ComputableAnalysis.FTA.FactorProximityBudget

namespace ComputableAnalysis.RepresentedPolynomial
open PolynomialDirection

def familyProximityAllowance (p : Coefficients) (rho : QPos) : QPos :=
  proximityAllowance (proximityTarget rho (p.length-1))

def proximityPeeling (p : Coefficients) (hp : Monic p) (rho : QPos) (start : Nat) :
    List (QComplex × ComplexCert) :=
  approximatePeeling p hp (squaredTolerance (peelingTolerance p (familyProximityAllowance p rho))) start

/-- One computed maximum supplies comparison precision and both remainder
precisions at the actual first-family factor. -/
def familyProximityStage (p : Coefficients) (hp : Monic p) (rho : QPos)
    (start stop : Nat) (z : QComplex) : Nat :=
  let delta := peelingTolerance p (familyProximityAllowance p rho)
  let xs := proximityPeeling p hp rho start
  let ys := proximityPeeling p hp rho stop
  max (peelingRemainderStage xs delta)
    (max (peelingRemainderStage ys delta)
      (reconstructionStage ys xs z (familyProximityAllowance p rho) 0))

/-- Actual complete factorizations at the constructed tolerance provide
factor proximity with every numerical budget discharged. -/
theorem proximityPeeling_near (p : Coefficients) (hp : Monic p) (rho : QPos)
    (start stop : Nat) (x : QComplex × ComplexCert)
    (hx : x ∈ proximityPeeling p hp rho start) :
    let n := familyProximityStage p hp rho start stop x.1
    QComplex.normSq (QComplex.sub x.1
      (nearbyFactor (sampledPeeling (proximityPeeling p hp rho stop) n) x.1 rho.val)) < rho.val := by
  let delta := peelingTolerance p (familyProximityAllowance p rho)
  let n := familyProximityStage p hp rho start stop x.1
  have hz : QComplex.normBound x.1 ≤ wholeFactorRadius p :=
    approximatePeeling_computed_bound p hp (squaredTolerance delta) start x hx
  have hxs : peelingRemainderStage (proximityPeeling p hp rho start) delta ≤ n := by
    dsimp [n, delta, familyProximityStage]; omega
  have hys : peelingRemainderStage (proximityPeeling p hp rho stop) delta ≤ n := by
    dsimp [n, delta, familyProximityStage]; omega
  have hcs : reconstructionStage (proximityPeeling p hp rho stop)
      (proximityPeeling p hp rho start) x.1 (familyProximityAllowance p rho) 0 ≤ n := by
    dsimp [n, delta, familyProximityStage]; omega
  have hc := approximatePeeling_precision_bound p hp (squaredTolerance delta)
    (squaredTolerance delta) (familyProximityAllowance p rho) stop start 0 n x.1 hcs
  have he := sampledPeeling_error_allowance p hp (familyProximityAllowance p rho) start n x.1 hz hxs
  have hf := sampledPeeling_error_allowance p hp (familyProximityAllowance p rho) stop n x.1 hz hys
  have hl : (sampledPeeling (proximityPeeling p hp rho stop) n).length = p.length-1 := by
    simp only [sampledPeeling, List.length_map, proximityPeeling, approximatePeeling_length]
  apply finiteFactorFamily_near_allowance
    (sampledPeeling (proximityPeeling p hp rho start) n)
    (sampledPeeling (proximityPeeling p hp rho stop) n)
    (x.1, (x.2.raw.compute n).lo)
    (List.mem_map.mpr ⟨x, hx, rfl⟩) rho
  · rw [hl]; exact hc
  · rw [hl]; exact he
  · rw [hl]; exact hf

end ComputableAnalysis.RepresentedPolynomial
