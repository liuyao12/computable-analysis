import ComputableAnalysis.FTA.CoherentFactorValue

namespace ComputableAnalysis.QBox

private theorem nonpos_of_arbitrarily_small (a : Rat)
    (h : ∀ eps : QPos, a ≤ eps.val) : a ≤ 0 := by
  by_cases ha : a ≤ 0
  · exact ha
  · have hp : 0 < a := by grind
    let eps : QPos := ⟨a/2, by rw [Rat.div_def]; exact Rat.mul_pos hp (by decide +kernel)⟩
    have hb := h eps
    change a ≤ a/2 at hb
    rw [Rat.div_def] at hb
    grind

/-- A finite rational box containing points of arbitrarily small norm contains
zero. Only rational inequalities are used. -/
theorem contains_zero_of_small_points (B : QBox)
    (h : ∀ eps : QPos, ∃ w : QComplex, B.lo ≤ w ∧ w ≤ B.hi ∧ QComplex.normBound w ≤ eps.val) :
    B.lo ≤ QComplex.zero ∧ QComplex.zero ≤ B.hi := by
  have bounds : ∀ eps : QPos,
      B.lo.re ≤ eps.val ∧ B.lo.im ≤ eps.val ∧ -B.hi.re ≤ eps.val ∧ -B.hi.im ≤ eps.val := by
    intro eps
    obtain ⟨w, hlo, hhi, hw⟩ := h eps
    have hr := qabs_nonneg w.re
    have hi := qabs_nonneg w.im
    have hpr := self_le_qabs w.re
    have hpi := self_le_qabs w.im
    have hnr := neg_qabs_le_self w.re
    have hni := neg_qabs_le_self w.im
    change B.lo.re ≤ w.re ∧ B.lo.im ≤ w.im at hlo
    change w.re ≤ B.hi.re ∧ w.im ≤ B.hi.im at hhi
    change qabs w.re+qabs w.im ≤ eps.val at hw
    constructor
    · grind
    constructor
    · grind
    constructor <;> grind
  have h1 := nonpos_of_arbitrarily_small B.lo.re (fun eps => (bounds eps).1)
  have h2 := nonpos_of_arbitrarily_small B.lo.im (fun eps => (bounds eps).2.1)
  have h3 := nonpos_of_arbitrarily_small (-B.hi.re) (fun eps => (bounds eps).2.2.1)
  have h4 := nonpos_of_arbitrarily_small (-B.hi.im) (fun eps => (bounds eps).2.2.2)
  change (B.lo.re ≤ 0 ∧ B.lo.im ≤ 0) ∧ (0 ≤ B.hi.re ∧ 0 ≤ B.hi.im)
  constructor <;> constructor <;> grind

end ComputableAnalysis.QBox

namespace ComputableAnalysis.RepresentedPolynomial

/-- Constructive monic FTA: the computed factor chain and finite rational-box
intersections yield an exact root for arbitrary represented coefficients. -/
theorem coherentFactorValue_root (p : Coefficients) (hp : Monic p) (hd : 2 ≤ p.length) :
    Root p (coherentFactorValue p hp hd) := by
  intro n
  apply (ComplexRaw.compareAt_overlap_iff _ _ n n).2
  exact QBox.contains_zero_of_small_points _ (coherentFactorValue_small_samples p hp hd n)

theorem constructive_monic_root_exists (p : Coefficients) (hp : Monic p) (hd : 2 ≤ p.length) :
    ∃ z : ComplexCert, Root p z :=
  ⟨coherentFactorValue p hp hd, coherentFactorValue_root p hp hd⟩

/-- Equivalent coefficient and point names preserve the constructed value's
root role; no equality of independently selected roots is asserted. -/
theorem coherentFactorValue_root_transport (p q : Coefficients) (hp : Monic p)
    (hd : 2 ≤ p.length) (heq : Equivalent p q) (z : ComplexCert)
    (hz : (coherentFactorValue p hp hd).raw.Equiv z.raw) : Root q z :=
  root_congr heq hz (coherentFactorValue_root p hp hd)

end ComputableAnalysis.RepresentedPolynomial
