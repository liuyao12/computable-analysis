import ComputableAnalysis.FTA.GeometricFactorChain

namespace ComputableAnalysis.RepresentedPolynomial
open PolynomialDirection

/-- At an actual factor center the product vanishes, leaving only the proved
omitted-remainder error in the sampled reconstruction. -/
theorem factorCenter_sample_bound (p : Coefficients) (hp : Monic p)
    (error : QPos) (start n : Nat) (item : QComplex × ComplexCert)
    (hi : item ∈ errorBudgetPeeling p hp error start)
    (hn : peelingRemainderStage (errorBudgetPeeling p hp error start) (peelingTolerance p error) ≤ n) :
    QComplex.normBound (finitePeelingValue (sampledPeeling (errorBudgetPeeling p hp error start) n) item.1) ≤ error.val := by
  have hz := approximatePeeling_computed_bound p hp _ start item hi
  have he := sampledPeeling_error_allowance p hp error start n item.1 hz hn
  have hb := finitePeeling_error_bound (sampledPeeling (errorBudgetPeeling p hp error start) n) item.1
  have hzero := finiteFactorProduct_zero_at_member
    (sampledPeeling (errorBudgetPeeling p hp error start) n)
    (item.1, (item.2.raw.compute n).lo) (List.mem_map.mpr ⟨item, hi, rfl⟩)
  rw [hzero] at hb
  have hid : ∀ z : QComplex, QComplex.sub z QComplex.zero = z := by
    intro z; cases z
    simp only [QComplex.sub, QComplex.add, QComplex.neg, QComplex.zero, QComplex.mk.injEq]
    constructor <;> grind
  rw [hid] at hb
  exact Rat.le_trans hb he

/-- Actual family membership gives exact residual control of the represented
reconstruction, using later samples inside each earlier output box. -/
theorem factorCenter_reconstruction_residual (p : Coefficients) (hp : Monic p)
    (error : QPos) (start : Nat) (item : QComplex × ComplexCert)
    (hi : item ∈ errorBudgetPeeling p hp error start) :
    (normValue (peelingValue (errorBudgetPeeling p hp error start) (ofQComplex item.1))).real.preferred.Le
      (RealRaw.ofRat (error.val^2)) := by
  intro i j
  let items := errorBudgetPeeling p hp error start
  let n := max i (peelingRemainderStage items (peelingTolerance p error))
  let w := finitePeelingValue (sampledPeeling items n) item.1
  have hc := sampledPeeling_contains items n item.1
  have hn : i ≤ n := by dsimp [n]; omega
  have hnest := ComplexRaw.valid_nestedIn (peelingValue items (ofQComplex item.1)).valid hn
  have hlo := QComplex.le_trans hnest.1 hc.1
  have hhi := QComplex.le_trans hc.2 hnest.2
  have hb := (normValue_contains (peelingValue items (ofQComplex item.1)) i w hlo hhi).1
  have hs : QComplex.normBound w ≤ error.val :=
    factorCenter_sample_bound p hp error start n item hi (by dsimp [n, items]; omega)
  have hw := QComplex.normBound_nonneg w
  have he := error.property
  have h1 := Rat.mul_le_mul_of_nonneg_left hs hw
  have h2 := Rat.mul_le_mul_of_nonneg_right hs (Rat.le_of_lt he)
  have hsq := PolynomialCoercivity.normSq_le_normBound_square w
  change ((normValue (peelingValue items (ofQComplex item.1))).real.compute i).lo ≤ error.val^2
  simp only [Rat.pow_succ, Rat.pow_zero, Rat.one_mul] at *
  grind

/-- Exact polynomial residual control is derived from actual factor-family
membership and the proved reconstruction identity. -/
theorem factorCenter_polynomial_residual (p : Coefficients) (hp : Monic p)
    (error : QPos) (start : Nat) (item : QComplex × ComplexCert)
    (hi : item ∈ errorBudgetPeeling p hp error start) :
    (normValue (eval p (ofQComplex item.1))).real.preferred.Le (RealRaw.ofRat (error.val^2)) := by
  have he := normValue_equiv (approximatePeeling_reconstruction p hp
    (squaredTolerance (peelingTolerance p error)) start (ofQComplex item.1))
  have hl := RealRaw.le_of_equiv (normValue (eval p (ofQComplex item.1))).real.valid
    (normValue (peelingValue (errorBudgetPeeling p hp error start) (ofQComplex item.1))).real.valid he
  exact RealRaw.le_trans
    (normValue (peelingValue (errorBudgetPeeling p hp error start) (ofQComplex item.1))).real.valid hl
    (factorCenter_reconstruction_residual p hp error start item hi)

theorem computedFactorChain_residual (p : Coefficients) (hp : Monic p)
    (hd : 2 ≤ p.length) (steps : Nat → QPos) (n : Nat) :
    (normValue (eval p (ofQComplex (computedFactorChain p hp steps n).1))).real.preferred.Le
      (RealRaw.ofRat ((consecutivePeelingAllowance p steps n).val^2)) :=
  factorCenter_polynomial_residual p hp _ 0 _ (computedFactorChain_member p hp hd steps n)

end ComputableAnalysis.RepresentedPolynomial
