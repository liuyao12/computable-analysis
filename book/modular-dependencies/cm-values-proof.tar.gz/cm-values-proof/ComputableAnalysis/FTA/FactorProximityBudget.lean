import ComputableAnalysis.FTA.UniformPeelingError

namespace ComputableAnalysis.RepresentedPolynomial

/-- One third-budget controls comparison and both omitted-remainder errors. -/
def proximityAllowance (target : QPos) : QPos :=
  ⟨target.val/(4*(target.val+1)), by
    rw [Rat.div_def]
    exact Rat.mul_pos target.property (Rat.inv_pos.mpr (by have h := target.property; grind))⟩

theorem proximityAllowance_square (target : QPos) :
    (3*(proximityAllowance target).val)^2 < target.val := by
  have ht := target.property
  have he := (proximityAllowance target).property
  have hd : 0 < 4*(target.val+1) := by grind
  have hc := Rat.mul_inv_cancel (4*(target.val+1)) (Rat.ne_of_gt hd)
  have hid : (4*(target.val+1))*(proximityAllowance target).val = target.val := by
    change (4*(target.val+1))*(target.val/(4*(target.val+1))) = target.val
    rw [Rat.div_def]
    grind
  have h1 := Rat.mul_lt_mul_of_pos_right
    (show (3 : Rat) < 4*(target.val+1) by grind) he
  have h2 : 3*(proximityAllowance target).val < 1 := by
    have hm := Rat.mul_lt_mul_of_pos_right
      (show 3*target.val < 4*(target.val+1) by grind) he
    by_cases hb : 3*(proximityAllowance target).val < 1
    · exact hb
    · have hn : 1 ≤ 3*(proximityAllowance target).val := by grind
      have hh := Rat.mul_le_mul_of_nonneg_left hn (Rat.le_of_lt ht)
      grind
  have h3 := Rat.mul_lt_mul_of_pos_left h2 (show 0 < 3*(proximityAllowance target).val by grind)
  simp only [Rat.pow_succ, Rat.pow_zero, Rat.one_mul]
  grind

/-- Every nonnegative combined error below three allowances meets the strict
small-product requirement. -/
theorem proximityAllowance_combined (target : QPos) (A E F : Rat)
    (hA : 0 ≤ A) (hE : 0 ≤ E) (hF : 0 ≤ F)
    (ha : A ≤ (proximityAllowance target).val)
    (he : E ≤ (proximityAllowance target).val)
    (hf : F ≤ (proximityAllowance target).val) :
    (A+E+F)^2 < target.val := by
  have hs := proximityAllowance_square target
  have hb : A+E+F ≤ 3*(proximityAllowance target).val := by grind
  have hn : 0 ≤ A+E+F := by grind
  have hp := (proximityAllowance target).property
  have h1 := Rat.mul_le_mul_of_nonneg_left hb hn
  have h2 := Rat.mul_le_mul_of_nonneg_right hb (show 0 ≤ 3*(proximityAllowance target).val by grind)
  simp only [Rat.pow_succ, Rat.pow_zero, Rat.one_mul] at *
  grind

def proximityTarget (rho : QPos) (degree : Nat) : QPos :=
  ⟨rho.val^degree, by
    induction degree with
    | zero => rw [Rat.pow_zero]; decide +kernel
    | succ n ih => rw [Rat.pow_succ]; exact Rat.mul_pos ih rho.property⟩

/-- The three independently controlled errors suffice for actual finite
factor proximity; callers need no separate squared-budget certificate. -/
theorem finiteFactorFamily_near_allowance
    (xs ys : List (QComplex × QComplex)) (x : QComplex × QComplex) (hx : x ∈ xs)
    (rho : QPos)
    (hc : QComplex.normBound (QComplex.sub
      (PolynomialDirection.finitePeelingValue ys x.1)
      (PolynomialDirection.finitePeelingValue xs x.1)) ≤
      (proximityAllowance (proximityTarget rho ys.length)).val)
    (he : PolynomialDirection.peelingErrorMajorant xs x.1 ≤
      (proximityAllowance (proximityTarget rho ys.length)).val)
    (hf : PolynomialDirection.peelingErrorMajorant ys x.1 ≤
      (proximityAllowance (proximityTarget rho ys.length)).val) :
    QComplex.normSq (QComplex.sub x.1 (PolynomialDirection.nearbyFactor ys x.1 rho.val)) < rho.val := by
  let A := proximityAllowance (proximityTarget rho ys.length)
  have hE : 0 ≤ PolynomialDirection.peelingErrorMajorant xs x.1 :=
    Rat.le_trans (QComplex.normBound_nonneg _)
      (PolynomialDirection.finitePeeling_error_bound xs x.1)
  have hF : 0 ≤ PolynomialDirection.peelingErrorMajorant ys x.1 :=
    Rat.le_trans (QComplex.normBound_nonneg _)
      (PolynomialDirection.finitePeeling_error_bound ys x.1)
  apply PolynomialDirection.finiteFactorFamily_near xs ys x hx A.val rho.val
    (Rat.le_of_lt A.property) (Rat.le_of_lt rho.property) hc
  exact proximityAllowance_combined (proximityTarget rho ys.length) A.val
    _ _ (Rat.le_of_lt A.property) hE hF (Rat.le_refl) he hf

/-- The same constructed budgets also certify actual factor membership. -/
theorem finiteFactorFamily_member_allowance
    (xs ys : List (QComplex × QComplex)) (x : QComplex × QComplex) (hx : x ∈ xs)
    (rho : QPos)
    (hc : QComplex.normBound (QComplex.sub
      (PolynomialDirection.finitePeelingValue ys x.1)
      (PolynomialDirection.finitePeelingValue xs x.1)) ≤
      (proximityAllowance (proximityTarget rho ys.length)).val)
    (he : PolynomialDirection.peelingErrorMajorant xs x.1 ≤
      (proximityAllowance (proximityTarget rho ys.length)).val)
    (hf : PolynomialDirection.peelingErrorMajorant ys x.1 ≤
      (proximityAllowance (proximityTarget rho ys.length)).val) :
    PolynomialDirection.nearbyFactor ys x.1 rho.val ∈ ys.map Prod.fst := by
  let A := proximityAllowance (proximityTarget rho ys.length)
  have hE : 0 ≤ PolynomialDirection.peelingErrorMajorant xs x.1 :=
    Rat.le_trans (QComplex.normBound_nonneg _)
      (PolynomialDirection.finitePeeling_error_bound xs x.1)
  have hF : 0 ≤ PolynomialDirection.peelingErrorMajorant ys x.1 :=
    Rat.le_trans (QComplex.normBound_nonneg _)
      (PolynomialDirection.finitePeeling_error_bound ys x.1)
  have hs := proximityAllowance_combined (proximityTarget rho ys.length) A.val
    _ _ (Rat.le_of_lt A.property) hE hF (Rat.le_refl) he hf
  have hb := PolynomialDirection.finiteFactorFamily_product_bound xs ys x hx A.val hc
  apply PolynomialDirection.nearbyFactor_mem ys x.1 rho.val (Rat.le_of_lt rho.property)
  change _ < rho.val^ys.length at hs
  grind

end ComputableAnalysis.RepresentedPolynomial
