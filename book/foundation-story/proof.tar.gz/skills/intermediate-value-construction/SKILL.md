---
name: intermediate-value-construction
description: Construct roots, target preimages, and monotone inverses using function-specific curvature bounds, rational interval updates, separation, or algebraic formulas. Use for inverse computations or when a proof would otherwise invoke an intermediate value theorem.
---

# Construct a target preimage

Read the [formalization policy](../../FORMALIZATION_GUIDE.md#computable-foundations-exact-mathematical-theorems) and the [checked route catalog](../computable-analysis-formalization/references/existence-construction-routes.md#target-preimages). Retain checked theorems as certifiers; choose an actual recipe for the supplied function.

State the target identity, the full domain, and any required branch or strict-interior condition. A root is the special case of target zero. Keep range and pole evidence explicit.

Use convexity or concavity as an informal guide for proposing an interval update before plain bisection. Do not require a formal convexity predicate, a general tangent definition, or an inverse function theorem to execute this strategy. The separate formalization job proves the proposed update's validity directly from the particular rational formulas and finite evaluator bounds, using inequality proofs: target containment, nesting, and an explicit shrinking schedule. Establish only the supporting-line or secant inequalities actually needed. Estimate the rate after proving these invariants.

For square root, the square function is **convex** on the positive branch. Given \(0<a\le b\) and \(a^2\le q\le b^2\), the right-end supporting line \(2bt-b^2\) and the endpoint secant \((a+b)t-ab\) give
\[
 b' = \frac{b^2+q}{2b},\qquad a' = \frac{q+ab}{a+b}.
\]
Prove \(a\le a'\le b'\le b\) and \((a')^2\le q\le(b')^2\) by rational algebra. Moreover,
\[
 b'-a'=\frac{(b-a)(b^2-q)}{2b(a+b)}
 \le\frac{(b-a)^2}{2b}\le\frac{b-a}{2}.
\]
Starting at \([1,2]\) computes \(\sqrt2\). The last bound proves shrinking; a positive lower bound for \(b\) makes the preceding bound a quadratic width estimate. Compare the resulting valid name with the existing bisection computation by their squared-value bounds, rather than assuming agreement.

This example is checked in [SquareRootSecantNewton.lean](../../ComputableAnalysis/SquareRootSecantNewton.lean): `step_spec`, `bracket_quadratic`, `sqrtTwo_valid`, and `sqrtTwo_equiv_bisection`. The formal proof uses rational inequalities, not a convexity predicate. Audit this and the concrete arctangent inverse with `lake env lean scripts/check_opening_foundation.lean`.

For arctangent on a nonnegative branch, use its **concavity**: the endpoint secant lies below the function and a justified supporting line lies above it. Their target intersections therefore bound the inverse in the opposite order from the convex example. Endpoint values are represented numbers, so enclose the proposed intersections with rational arithmetic and retain an overlap-safe shrinking step. Never rely on deciding exact equality of an interval-computed midpoint and target.

For circle trigonometry specify \(\arctan(u)=\theta/2\), then construct
\[
 \sin\theta=\frac{2u}{1+u^2},\qquad
 \cos\theta=\frac{1-u^2}{1+u^2}.
\]
Keep rational angle coordinates primary (for example a rational multiple of the constructed quarter-turn); derive other target evaluations with the proved continuity evidence. The equation \(\arctan(x)=x\) is a different problem, with only the zero solution, and does not construct general circle coordinates. Handle signs and other quadrants through explicit branch transformations.

```mermaid
flowchart TD
  A[Specify target and domain] --> B{Exact formula available?}
  B -->|Yes| C[Construct formula and prove domain and target identity]
  B -->|No| D{Monotone target brackets with effective decisions?}
  D -->|Yes| E[Run justified bisection with nesting and width bounds]
  D -->|No| F{Polynomial root task?}
  F -->|Yes| G[Use checked constructive FTA and certify any requested real branch]
  F -->|No| H[Develop a function-specific crossing or local inverse recipe]
  E --> I[Prove exact evaluation and representation agreement]
  H --> I
```

Rational evaluations may support exact sign comparisons. Represented evaluations require interval separation or a justified overlapping-bracket alternative; do not wait for an arbitrary exact-zero decision. An initial sign bracket alone does not justify every subdivision decision or coherent shrinking preimages.

`InverseBisectionSearch` already demands validity, domain containment, and output overlap. Construct those fields from the actual function; merely repackaging assumed search evidence is not a new existence proof. A finite bracket with tolerance is an intermediate result until its coherent represented value and exact target identity are proved.

Complex FTA supplies a complex root, not a real root in the requested interval. Prove realness and interval membership independently when those are part of the task. Branch selection can depend on additional separation data.

Verify the chosen Lean declarations with the catalog audit. For new mathematics follow the [formalization skill](../computable-analysis-formalization/SKILL.md), including arbitrary valid represented inputs and exact `RealRaw.Equiv` or `ComplexRaw.Equiv` identities.
